// ======================================
// RENDERER - 3D-Style Drawing Utilities
// ======================================

// === パフォーマンス最適化: グラデーションキャッシュ ===
// createRadialGradient は毎フレーム呼ぶと非常に重いため、キャッシュして再利用する
const _gradientCache = new Map();
function _getCachedGradient(ctx, key, createFn) {
    if (!_gradientCache.has(key)) {
        if (_gradientCache.size > 200) { // キャッシュが多すぎる場合はクリア
            _gradientCache.clear();
        }
        _gradientCache.set(key, createFn());
    }
    return _gradientCache.get(key);
}

// === 背景オフスクリーンキャッシュ ===
// 静的な背景（山・城・木など）を毎フレーム再描画しないためのキャッシュ
// 雲は動くので毎フレーム上書き、それ以外はキャッシュから貼るだけ
const _bgCache = new Map();
function _getCachedBg(key, w, h, drawFn) {
    if (!_bgCache.has(key)) {
        try {
            const c = document.createElement('canvas');
            c.width = w; c.height = h;
            const bctx = c.getContext('2d');
            if (bctx) { drawFn(bctx); _bgCache.set(key, c); }
        } catch(e) { /* offscreen canvas unavailable */ }
    }
    return _bgCache.get(key) || null;
}

// === タンク外観キャッシュ ===
const _tankCache = new Map();
function _getCachedTank(key, w, h, drawFn) {
    if (_tankCache.size > 50) _tankCache.clear(); // 多すぎたらリセット
    if (!_tankCache.has(key)) {
        try {
            const c = document.createElement('canvas');
            c.width = w; c.height = h;
            const tctx = c.getContext('2d');
            if (tctx) { drawFn(tctx, w, h); _tankCache.set(key, c); }
        } catch(e) { /* offscreen canvas unavailable */ }
    }
    return _tankCache.get(key) || null;
}

// === _getFrameNow() フレームキャッシュ ===
// 同じフレーム内で何十回も _getFrameNow() を呼ぶのを1回にまとめる
let _frameNow = 0;
function _getFrameNow() { return _frameNow; }
function _tickFrameNow() { _frameNow = Date.now(); }

// === Android向けパフォーマンスフラグ ===
// shadowBlur はモバイルGPUで非常に重いため、Androidでは完全に無効化する
const _isAndroid = /Android/i.test(navigator.userAgent);
// shadowBlur を安全にセットするラッパー（Androidでは常に0）
function _setShadowBlur(ctx, val) {
    if (_isAndroid) { ctx.shadowBlur = 0; return; }
    ctx.shadowBlur = val;
}

// === _lighten キャッシュ ===
const _lightenCache = new Map();
function _lightenCached(color, amount) {
    const key = color + '_' + amount;
    if (_lightenCache.has(key)) return _lightenCache.get(key);
    let c = color;
    let usePound = false;
    if (c[0] === '#') { c = c.slice(1); usePound = true; }
    const num = parseInt(c, 16);
    const r = Math.max(0, Math.min(255, ((num >> 16) & 0xFF) + amount));
    const g = Math.max(0, Math.min(255, ((num >> 8) & 0xFF) + amount));
    const b = Math.max(0, Math.min(255, (num & 0xFF) + amount));
    const result = (usePound ? '#' : '') + ((r << 16) | (g << 8) | b).toString(16).padStart(6, '0');
    if (_lightenCache.size > 200) _lightenCache.clear();
    _lightenCache.set(key, result);
    return result;
}

const Renderer = {
    // === RENDERING UTILITIES ===
    _roundRect(ctx, x, y, w, h, r) {
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + w - r, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + r);
        ctx.lineTo(x + w, y + h - r);
        ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
        ctx.lineTo(x + r, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - r);
        ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y);
        ctx.closePath();
    },

    _darkenHex(color, percent) {
        if (!color.startsWith('#')) return color;
        const num = parseInt(color.slice(1), 16);
        const amt = Math.round(2.55 * percent);
        const R = (num >> 16) - amt;
        const G = (num >> 8 & 0x00FF) - amt;
        const B = (num & 0x0000FF) - amt;
        return '#' + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 + (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 + (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
    },

    _getStageEnemyVariant(battle) {
        const stageId = battle && battle.stageData && battle.stageData.id;
        const theme = battle && battle.stageData && battle.stageData.enemyTankTheme;
        const variants = {
            stage1:       { shape: 'diamond',   base: '#4CAF50', high: '#8BE28E', shadow: '#1F5A2C', accent: '#D9FFE1', trim: '#7CFF98', glow: 'rgba(80,255,140,0.28)' },
            stage2:       { shape: 'triangle',  base: '#FF8A3D', high: '#FFC184', shadow: '#8A3C12', accent: '#FFF0D8', trim: '#FFD166', glow: 'rgba(255,170,90,0.35)' },
            stage3:       { shape: 'diamond',   base: '#26A69A', high: '#7AE8DB', shadow: '#0E5B54', accent: '#D9FFF8', trim: '#76FFF0', glow: 'rgba(80,255,220,0.32)' },
            stage4:       { shape: 'hex',       base: '#EF6C57', high: '#FFB2A4', shadow: '#7A271F', accent: '#FFE4DF', trim: '#FFC2A8', glow: 'rgba(255,120,110,0.32)' },
            stage5:       { shape: 'crown',     base: '#8E44AD', high: '#D5A6F0', shadow: '#40175A', accent: '#F8E6FF', trim: '#E7B8FF', glow: 'rgba(200,120,255,0.34)' },
            stage_shakkin:{ shape: 'bolt',      base: '#C9A227', high: '#F5DD7A', shadow: '#635011', accent: '#FFF6D6', trim: '#FFE27A', glow: 'rgba(255,215,80,0.34)' },
            stage_boss:   { shape: 'octagon',   base: '#C62828', high: '#FF8A80', shadow: '#5A1212', accent: '#FFE2DE', trim: '#FFB199', glow: 'rgba(255,100,100,0.34)' },
            stage_secret: { shape: 'star',      base: '#D81B60', high: '#FF89B1', shadow: '#6E1032', accent: '#FFE2EE', trim: '#FFB3CF', glow: 'rgba(255,100,180,0.35)' },
            stage8:       { shape: 'kite',      base: '#00ACC1', high: '#7BE7F4', shadow: '#045560', accent: '#D9FBFF', trim: '#9AF6FF', glow: 'rgba(80,240,255,0.33)' },
            event1:       { shape: 'trapezoid', base: '#7CB342', high: '#C7F08C', shadow: '#395B17', accent: '#F1FFD7', trim: '#D6FF85', glow: 'rgba(170,255,90,0.30)' },
            event2:       { shape: 'triangle',  base: '#42A5F5', high: '#9ED3FF', shadow: '#194C7A', accent: '#E1F1FF', trim: '#A8DCFF', glow: 'rgba(110,180,255,0.32)' },
            event3:       { shape: 'star',      base: '#FFB300', high: '#FFE082', shadow: '#7A5400', accent: '#FFF4CF', trim: '#FFE89A', glow: 'rgba(255,210,90,0.33)' },
            event4:       { shape: 'diamond',   base: '#EC407A', high: '#FF9FBE', shadow: '#7A163A', accent: '#FFE4EE', trim: '#FFBED1', glow: 'rgba(255,120,170,0.33)' },
            stage_ex1:    { shape: 'hex',       base: '#5C6BC0', high: '#A9B2F2', shadow: '#28316B', accent: '#E6E9FF', trim: '#BBC6FF', glow: 'rgba(120,140,255,0.33)' },
            stage_ex2:    { shape: 'crown',     base: '#FDD835', high: '#FFF59D', shadow: '#7C6400', accent: '#FFFADB', trim: '#FFF1A8', glow: 'rgba(255,240,100,0.34)' },
            stage_ex3:    { shape: 'bolt',      base: '#F4511E', high: '#FFAA80', shadow: '#7A2108', accent: '#FFE7DE', trim: '#FFC49C', glow: 'rgba(255,130,80,0.34)' },
            c2_stage1:    { shape: 'kite',      base: '#607D8B', high: '#B0BEC5', shadow: '#263238', accent: '#EAF6FF', trim: '#8BE9FF', glow: 'rgba(94,211,255,0.35)' },
            c2_stage2:    { shape: 'triangle',  base: '#00838F', high: '#6EE7F0', shadow: '#003C43', accent: '#DBFCFF', trim: '#8AF7FF', glow: 'rgba(80,240,255,0.35)' },
            c2_stage3:    { shape: 'diamond',   base: '#546E7A', high: '#B4E1E8', shadow: '#22343D', accent: '#E7FCFF', trim: '#92F3FF', glow: 'rgba(100,225,255,0.34)' },
            c2_stage4:    { shape: 'hex',       base: '#FF7043', high: '#FFBEA8', shadow: '#7D2E14', accent: '#FFF0EA', trim: '#FFCEA7', glow: 'rgba(255,140,110,0.33)' },
            c2_stage5:    { shape: 'bolt',      base: '#7CB342', high: '#D6FF8B', shadow: '#315211', accent: '#F2FFDB', trim: '#C7FF70', glow: 'rgba(180,255,90,0.33)' },
            c2_boss:      { shape: 'octagon',   base: '#8E24AA', high: '#E1A6FF', shadow: '#3E104B', accent: '#F8E3FF', trim: '#F0B8FF', glow: 'rgba(210,110,255,0.36)' },
            c3_stage1:    { shape: 'kite',      base: '#F5E6B3', high: '#FFFDF2', shadow: '#A78F48', accent: '#FFFFFF', trim: '#FFE28A', glow: 'rgba(255,240,180,0.34)' },
            c3_stage2:    { shape: 'star',      base: '#CFE8FF', high: '#FFFFFF', shadow: '#7D9AB7', accent: '#FFFBEA', trim: '#FFE082', glow: 'rgba(255,235,150,0.32)' },
            c3_stage3:    { shape: 'crown',     base: '#DCCBFF', high: '#FFFFFF', shadow: '#8D7CB7', accent: '#FFF8F0', trim: '#F2D36B', glow: 'rgba(255,225,140,0.31)' },
            c3_stage4:    { shape: 'diamond',   base: '#FFD6E7', high: '#FFFFFF', shadow: '#B88099', accent: '#FFFDF7', trim: '#FFDB8A', glow: 'rgba(255,220,170,0.31)' },
            c3_stage5:    { shape: 'triangle',  base: '#D6FFF3', high: '#FFFFFF', shadow: '#72A597', accent: '#FFFDF2', trim: '#C9A646', glow: 'rgba(230,255,245,0.30)' },
            c3_boss:      { shape: 'star',      base: '#FFF1B8', high: '#FFFFFF', shadow: '#B19541', accent: '#FFFFFF', trim: '#FFD54F', glow: 'rgba(255,230,120,0.36)' },
            // ★追加: Ch4 (chaosテーマ) 各ステージ固有カラー
            c4_stage1:    { shape: 'kite',      base: '#2D0050', high: '#8822CC', shadow: '#100020', accent: '#D4A0FF', trim: '#AA44FF', glow: 'rgba(150,40,255,0.42)' },  // 深淵の門番・ヴォイド: 暗黒虚空紫
            c4_stage2:    { shape: 'triangle',  base: '#1A1A2E', high: '#555599', shadow: '#0A0A14', accent: '#AAAADD', trim: '#7777CC', glow: 'rgba(100,100,220,0.38)' },  // 廃都の幻影兵（忍者スキン用）
            c4_stage3:    { shape: 'hex',       base: '#6B2D82', high: '#FF80FF', shadow: '#2A0A38', accent: '#FFD6FF', trim: '#FF55FF', glow: 'rgba(255,80,255,0.38)' },  // 楽園の詐欺師: 歪んだ蛍光紫ピンク
            c4_stage4:    { shape: 'bolt',      base: '#1A0A2E', high: '#7744CC', shadow: '#080414', accent: '#CCAAFF', trim: '#9966EE', glow: 'rgba(130,70,230,0.40)' },  // 記憶の封印者
            c4_stage5:    { shape: 'crown',     base: '#500000', high: '#CC0000', shadow: '#200000', accent: '#FF9090', trim: '#FF3333', glow: 'rgba(255,40,40,0.45)' },   // 混沌の先鋒カオスロード: 深紅の王
            c4_boss:      { shape: 'octagon',   base: '#0A0016', high: '#440088', shadow: '#03000A', accent: '#BB88FF', trim: '#7722CC', glow: 'rgba(100,20,200,0.50)' },  // 深淵の主ニヒルム: 絶対の虚無
            // ★追加: Ch5 (genesisテーマ) 各ステージ固有カラー
            c5_stage1:    { shape: 'octagon',   base: '#0A1850', high: '#3366EE', shadow: '#040A22', accent: '#AABBFF', trim: '#6688FF', glow: 'rgba(80,130,255,0.42)' },  // 原初の番人プリモス: 原初宇宙青
            c5_stage2:    { shape: 'star',      base: '#003050', high: '#00AACC', shadow: '#001020', accent: '#99EEFF', trim: '#33CCFF', glow: 'rgba(0,200,255,0.40)' },   // 形なき者アモルファス: 虹彩青緑
            c5_stage3:    { shape: 'crown',     base: '#2A1040', high: '#9966FF', shadow: '#100618', accent: '#DDCCFF', trim: '#CC99FF', glow: 'rgba(180,120,255,0.42)' }, // 鏡の番人エイドロン（タイタンスキン用）
            c5_stage4:    { shape: 'kite',      base: '#050820', high: '#1A2860', shadow: '#020410', accent: '#8899CC', trim: '#4455AA', glow: 'rgba(50,70,180,0.44)' },   // 終焉の砲台群（深淵スキン用）
            c5_stage5:    { shape: 'diamond',   base: '#1A0E00', high: '#886600', shadow: '#080600', accent: '#FFDD88', trim: '#FFAA00', glow: 'rgba(255,200,0,0.44)' },   // 光の守護者ルクセイン（lumenスキン用）
            c5_boss:      { shape: 'star',      base: '#000008', high: '#222266', shadow: '#000003', accent: '#CCCCFF', trim: '#8888EE', glow: 'rgba(120,120,255,0.50)' }  // 原初の意志ルーメン: 宇宙の始まり
        };
        if (variants[stageId]) return variants[stageId];
        if (theme === 'mecha')   return { shape: 'hex',     base: '#607D8B', high: '#B0BEC5', shadow: '#263238', accent: '#E3F8FF', trim: '#8BE9FF', glow: 'rgba(94,211,255,0.33)' };
        if (theme === 'heaven')  return { shape: 'star',    base: '#F3E1A0', high: '#FFFFFF', shadow: '#9E8541', accent: '#FFFDF4', trim: '#FFD86B', glow: 'rgba(255,225,120,0.30)' };
        // ★追加: chaos/genesisテーマのフォールバック（以前は赤オレンジのデフォルトに落ちていた）
        if (theme === 'chaos')   return { shape: 'kite',    base: '#3A0055', high: '#9933BB', shadow: '#180022', accent: '#DDA0FF', trim: '#AA44EE', glow: 'rgba(160,60,240,0.36)' };
        if (theme === 'genesis') return { shape: 'octagon', base: '#080F30', high: '#2244AA', shadow: '#030812', accent: '#AABBEE', trim: '#4466CC', glow: 'rgba(70,110,230,0.36)' };
        return { shape: 'diamond', base: '#D84315', high: '#FF8A65', shadow: '#7A250B', accent: '#FFF1E8', trim: '#FFD166', glow: 'rgba(255,150,90,0.30)' };
    },

    _traceStageEnemyShape(ctx, shape, cx, cy, rx, ry) {
        const points = (count, innerScale = 1, outerScale = 1, rot = -Math.PI / 2) => {
            for (let i = 0; i < count; i++) {
                const a = rot + (Math.PI * 2 * i) / count;
                const px = cx + Math.cos(a) * rx * outerScale;
                const py = cy + Math.sin(a) * ry * innerScale;
                if (i === 0) ctx.moveTo(px, py);
                else ctx.lineTo(px, py);
            }
            ctx.closePath();
        };

        ctx.beginPath();
        switch (shape) {
        case 'triangle':
            ctx.moveTo(cx, cy - ry);
            ctx.lineTo(cx + rx, cy + ry * 0.9);
            ctx.lineTo(cx - rx, cy + ry * 0.9);
            ctx.closePath();
            break;
        case 'diamond':
            ctx.moveTo(cx, cy - ry);
            ctx.lineTo(cx + rx, cy);
            ctx.lineTo(cx, cy + ry);
            ctx.lineTo(cx - rx, cy);
            ctx.closePath();
            break;
        case 'hex':
            points(6, 1, 1, Math.PI / 6);
            break;
        case 'octagon':
            points(8, 1, 1, Math.PI / 8);
            break;
        case 'trapezoid':
            ctx.moveTo(cx - rx * 0.7, cy - ry);
            ctx.lineTo(cx + rx * 0.7, cy - ry);
            ctx.lineTo(cx + rx, cy + ry);
            ctx.lineTo(cx - rx, cy + ry);
            ctx.closePath();
            break;
        case 'kite':
            ctx.moveTo(cx, cy - ry);
            ctx.lineTo(cx + rx * 0.85, cy - ry * 0.1);
            ctx.lineTo(cx, cy + ry);
            ctx.lineTo(cx - rx * 0.85, cy - ry * 0.1);
            ctx.closePath();
            break;
        case 'bolt':
            ctx.moveTo(cx - rx * 0.35, cy - ry);
            ctx.lineTo(cx + rx * 0.08, cy - ry * 0.15);
            ctx.lineTo(cx - rx * 0.05, cy - ry * 0.15);
            ctx.lineTo(cx + rx * 0.38, cy + ry);
            ctx.lineTo(cx - rx * 0.1, cy + ry * 0.2);
            ctx.lineTo(cx + rx * 0.02, cy + ry * 0.2);
            ctx.closePath();
            break;
        case 'crown':
            ctx.moveTo(cx - rx, cy + ry * 0.85);
            ctx.lineTo(cx - rx * 0.88, cy - ry * 0.2);
            ctx.lineTo(cx - rx * 0.45, cy - ry * 0.55);
            ctx.lineTo(cx, cy - ry);
            ctx.lineTo(cx + rx * 0.45, cy - ry * 0.55);
            ctx.lineTo(cx + rx * 0.88, cy - ry * 0.2);
            ctx.lineTo(cx + rx, cy + ry * 0.85);
            ctx.closePath();
            break;
        case 'star':
            for (let i = 0; i < 10; i++) {
                const a = -Math.PI / 2 + i * Math.PI / 5;
                const rScale = i % 2 === 0 ? 1 : 0.45;
                const px = cx + Math.cos(a) * rx * rScale;
                const py = cy + Math.sin(a) * ry * rScale;
                if (i === 0) ctx.moveTo(px, py);
                else ctx.lineTo(px, py);
            }
            ctx.closePath();
            break;
        case 'square':
        default:
            ctx.rect(cx - rx, cy - ry, rx * 2, ry * 2);
            break;
        }
    },

    _drawStageEnemyOverlay(ctx, tx, ty, tw, th, battle, alpha = 1) {
        if (!battle || !battle.stageData) return;
        const variant = this._getStageEnemyVariant(battle);
        const cx = tx + tw / 2;
        // ★バグ修正: cy を 0.42 → 0.32 に変更（大砲と重なる位置→球体ボディ中央へ移動）
        const cy = ty + th * 0.32;
        // ★バグ修正: rx を tw 基準から min(tw,th) 基準に変更
        //   外観ビューでは tw > th のため rx >> ry になり、ダイヤが横つぶれの台形に見えていた
        //   正方形ベースにすることでどの形状も歪まず表示される
        const baseR = Math.min(tw, th) * 0.115;
        const rx = baseR;
        const ry = baseR;

        ctx.save();
        ctx.globalAlpha *= alpha;

        ctx.fillStyle = variant.glow;
        this._traceStageEnemyShape(ctx, variant.shape, cx, cy, rx * 1.45, ry * 1.45);
        ctx.fill();

        ctx.fillStyle = variant.base;
        this._traceStageEnemyShape(ctx, variant.shape, cx, cy, rx, ry);
        ctx.fill();

        ctx.strokeStyle = variant.trim;
        ctx.lineWidth = 2;
        this._traceStageEnemyShape(ctx, variant.shape, cx, cy, rx, ry);
        ctx.stroke();

        ctx.fillStyle = variant.accent;
        this._traceStageEnemyShape(ctx, variant.shape, cx, cy, rx * 0.45, ry * 0.45);
        ctx.fill();

        ctx.strokeStyle = 'rgba(255,255,255,0.35)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(cx - rx * 0.5, cy - ry * 0.35);
        ctx.lineTo(cx + rx * 0.2, cy - ry * 0.55);
        ctx.stroke();

        ctx.restore();
    },
    // === SLIME (High Quality 3D Style v2 - Optimized) ===
    drawSlime(ctx, x, y, w, h, color, darkColor, dir = 1, frame = 0, vy = 0, slimeType = 'slime') {
        ctx.save();

        // ★改善①: プレイヤースキンの bodyColor/darkColor を反映
        if (slimeType === 'player') {
            // ★バグ修正: bodyColor/bodyDark フィールド名を player.js と統一
            const _custom  = window.game?.saveData?.tankCustom;
            const _skinId  = _custom?.playerSkin || 'pslime_default';
            const _skins   = window.TANK_PARTS?.playerSkins;
            const _skinDef = _skins?.find(s => s.id === _skinId);
            if (_skinDef?.bodyColor) color     = _skinDef.bodyColor;
            if (_skinDef?.bodyDark)  darkColor = _skinDef.bodyDark;
        }

        ctx.translate(Math.round(x + w / 2), Math.round(y + h));

        // Animation: Squash & Stretch based on vertical velocity
        let squashY = vy > 3 ? 0.85 : vy < -3 ? 1.15 : 1.0;
        
        // 歩行モーション：移動中は躍動感のある「弾み」を追加
        let walkY = 0;
        let walkRot = 0;
        if (frame > 0) {
            const cycle = frame * 0.22;
            walkY = -Math.abs(Math.sin(cycle)) * 8; // 上下にピョンピョン跳ねる
            // 着地時に少し潰れる（Squish & Stretch）
            const bounceSquash = 1 + Math.sin(cycle - Math.PI/2) * 0.12;
            squashY *= bounceSquash;
            walkRot = Math.sin(cycle) * 0.08; // 左右にわずかに傾く
        }

        ctx.translate(0, walkY);
        ctx.rotate(walkRot);
        ctx.scale(dir * (1 / squashY), squashY);

        const sz = Math.min(w, h) * 0.95;

        // 1. Shadow (Simplified)
        ctx.fillStyle = 'rgba(0,0,0,0.15)';
        ctx.beginPath();
        ctx.ellipse(0, 0, sz * 0.5, sz * 0.12, 0, 0, Math.PI * 2);
        ctx.fill();

        // 2. Body Shape
        ctx.beginPath();
        ctx.moveTo(0, -sz);
        ctx.bezierCurveTo(sz * 0.5, -sz * 0.9, sz * 0.6, -sz * 0.2, sz * 0.4, 0);
        ctx.bezierCurveTo(sz * 0.2, sz * 0.1, -sz * 0.2, sz * 0.1, -sz * 0.4, 0);
        ctx.bezierCurveTo(-sz * 0.6, -sz * 0.2, -sz * 0.5, -sz * 0.9, 0, -sz);
        ctx.closePath();

        // 3. Coloring & Shading (Cached Radial Gradient)
        // ※ createRadialGradient を毎フレーム生成すると重いためキャッシュ利用
        const safeDarkColor = (typeof darkColor === 'string' && darkColor.length > 1) ? darkColor : '#1B5E20';
        const gradKey = `slime_${color}_${safeDarkColor}_${sz | 0}`;
        const grad = _getCachedGradient(ctx, gradKey, () => {
            const g = ctx.createRadialGradient(-sz * 0.1, -sz * 0.5, 0, -sz * 0.1, -sz * 0.5, sz);
            g.addColorStop(0, this._lighten(color, 40));
            g.addColorStop(1, safeDarkColor);
            return g;
        });
        ctx.fillStyle = grad;
        ctx.fill();
        // プレイヤー: 輪郭線でキャラらしさUP
        if (slimeType === 'player') {
            ctx.strokeStyle = safeDarkColor;
            ctx.lineWidth = 1.8;
            ctx.stroke();
        }

        // (glossy reflection removed for performance)

        // 5. Face (Cute style)
        // Eye Position calculation
        const faceY = -sz * 0.45;
        const eyeSpace = sz * 0.28; // 目の間隔を広げてより目を解消

        // Eyes - プレイヤーは丸い目（●●）、その他は丸みのある目
        const eyeW = sz * 0.13;
        const eyeH = sz * 0.11;
        if (color === CONFIG.COLORS.PLAYER || slimeType === 'player') {
            // プレイヤー専用: 大きな丸い目（方向追従瞳 + 眉毛）
            const eyeR = sz * 0.12;
            if (frame % 120 > 115) {
                // Blink: 横線（まつ毛なし）
                ctx.strokeStyle = '#111';
                ctx.lineWidth = 2.5;
                ctx.lineCap = 'round';
                ctx.beginPath();
                ctx.moveTo(-eyeSpace - eyeR, faceY); ctx.lineTo(-eyeSpace + eyeR, faceY);
                ctx.moveTo(eyeSpace - eyeR, faceY); ctx.lineTo(eyeSpace + eyeR, faceY);
                ctx.stroke();
            } else {
                // 方向に合わせて瞳が少し動く
                const pupilShift = dir * eyeR * 0.22;
                // 白目（縁取り付き）
                ctx.fillStyle = '#FFF';
                ctx.strokeStyle = 'rgba(0,0,0,0.15)';
                ctx.lineWidth = 1;
                ctx.beginPath(); ctx.arc(-eyeSpace, faceY, eyeR, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
                ctx.beginPath(); ctx.arc(eyeSpace, faceY, eyeR, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
                // 黒目（方向追従）
                ctx.fillStyle = '#1A1A2E';
                ctx.beginPath(); ctx.arc(-eyeSpace + pupilShift, faceY + eyeR * 0.1, eyeR * 0.62, 0, Math.PI * 2); ctx.fill();
                ctx.beginPath(); ctx.arc(eyeSpace + pupilShift, faceY + eyeR * 0.1, eyeR * 0.62, 0, Math.PI * 2); ctx.fill();
                // 大ハイライト
                ctx.fillStyle = '#FFF';
                ctx.beginPath(); ctx.arc(-eyeSpace + pupilShift - eyeR * 0.22, faceY - eyeR * 0.25, eyeR * 0.28, 0, Math.PI * 2); ctx.fill();
                ctx.beginPath(); ctx.arc(eyeSpace + pupilShift - eyeR * 0.22, faceY - eyeR * 0.25, eyeR * 0.28, 0, Math.PI * 2); ctx.fill();
                // 小ハイライト
                ctx.fillStyle = 'rgba(255,255,255,0.65)';
                ctx.beginPath(); ctx.arc(-eyeSpace + pupilShift + eyeR * 0.12, faceY + eyeR * 0.18, eyeR * 0.13, 0, Math.PI * 2); ctx.fill();
                ctx.beginPath(); ctx.arc(eyeSpace + pupilShift + eyeR * 0.12, faceY + eyeR * 0.18, eyeR * 0.13, 0, Math.PI * 2); ctx.fill();
            }
            // 眉毛なし（シンプルかわいいスライム）
        } else {
            ctx.strokeStyle = '#111';
            ctx.lineWidth = 2.5;
            ctx.lineJoin = 'round';
            ctx.lineCap = 'round';
            ctx.beginPath();
            if (frame % 120 > 115) {
                // Blink: 横線
                ctx.moveTo(-eyeSpace - eyeW, faceY); ctx.lineTo(-eyeSpace + eyeW, faceY);
                ctx.moveTo(eyeSpace - eyeW, faceY); ctx.lineTo(eyeSpace + eyeW, faceY);
                ctx.stroke();
            } else {
                ctx.stroke(); // strokeを先に終了してfillに切り替え
                // 丸くて可愛い目（白目+黒目）
                const eyeR = eyeW * 0.9;
                // 白目
                ctx.fillStyle = '#FFF';
                ctx.beginPath(); ctx.arc(-eyeSpace, faceY, eyeR, 0, Math.PI * 2); ctx.fill();
                ctx.beginPath(); ctx.arc(eyeSpace, faceY, eyeR, 0, Math.PI * 2); ctx.fill();
                // 黒目
                ctx.fillStyle = '#1A1A2E';
                ctx.beginPath(); ctx.arc(-eyeSpace, faceY + eyeR * 0.1, eyeR * 0.6, 0, Math.PI * 2); ctx.fill();
                ctx.beginPath(); ctx.arc(eyeSpace, faceY + eyeR * 0.1, eyeR * 0.6, 0, Math.PI * 2); ctx.fill();
                // ハイライト
                ctx.fillStyle = '#FFF';
                ctx.beginPath(); ctx.arc(-eyeSpace - eyeR * 0.2, faceY - eyeR * 0.2, eyeR * 0.22, 0, Math.PI * 2); ctx.fill();
                ctx.beginPath(); ctx.arc(eyeSpace - eyeR * 0.2, faceY - eyeR * 0.2, eyeR * 0.22, 0, Math.PI * 2); ctx.fill();
            }
        }

        // Mouth (Small smile) - タイプ別
        ctx.strokeStyle = '#111';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        if (slimeType === 'devil') {
            // 悪魔：邪悪な笑み
            ctx.arc(0, faceY + 3, 5, 0.1, Math.PI - 0.1);
        } else if (slimeType === 'ninja') {
            // 忍者：口は隠れている（描画なし）
        } else if (slimeType === 'player') {
            // Player: 元気な笑顔（少し開いた口 + 歯）
            ctx.fillStyle = '#C84B6A';
            ctx.beginPath();
            ctx.arc(0, faceY + sz * 0.14, sz * 0.09, 0.15, Math.PI - 0.15);
            ctx.fill();
            ctx.strokeStyle = '#111';
            ctx.lineWidth = 1.5;
            ctx.stroke();
            // 歯
            ctx.fillStyle = '#FFF';
            ctx.fillRect(-sz * 0.06, faceY + sz * 0.1, sz * 0.12, sz * 0.06);
            ctx.beginPath(); // 二重ストローク防止：パスをリセット
        } else {
            // 通常の笑顔
            ctx.arc(0, faceY + 5, 4, 0.2, Math.PI - 0.2);
        }
        ctx.stroke();

        // 6. Accessories / Role Indicators - 大幅拡張
        // ★バグ修正: bounce が未定義のまま王冠・兜などのアクセサリ描画で使われ
        //   ReferenceError になっていた。drawSlime スコープ内で定義する。
        const bounce = Math.abs(Math.sin(frame * 0.15)) * 2;
        if (color === CONFIG.COLORS.PLAYER || slimeType === 'player') {
            // Player: シンプルかわいいスライム（頬赤みのみ）
            ctx.fillStyle = 'rgba(255,130,130,0.45)';
            ctx.beginPath();
            ctx.ellipse(-sz * 0.30, -sz * 0.26, sz * 0.13, sz * 0.09, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
            ctx.ellipse(sz * 0.30, -sz * 0.26, sz * 0.13, sz * 0.09, 0, 0, Math.PI * 2);
            ctx.fill();
        } else if (color === CONFIG.COLORS.BOSS || slimeType === 'kingslime') {
            // Boss/King: Gold Crown
            ctx.fillStyle = '#FFD700'; // Gold
            ctx.beginPath();
            ctx.moveTo(-sz * 0.3, -sz * 0.8 + bounce);
            ctx.lineTo(-sz * 0.15, -sz * 1.1 + bounce);
            ctx.lineTo(0, -sz * 0.8 + bounce);
            ctx.lineTo(sz * 0.15, -sz * 1.1 + bounce);
            ctx.lineTo(sz * 0.3, -sz * 0.8 + bounce);
            ctx.lineTo(sz * 0.3, -sz * 0.5 + bounce);
            ctx.lineTo(-sz * 0.3, -sz * 0.5 + bounce);
            ctx.fill();
            ctx.strokeStyle = '#DAA520'; ctx.lineWidth = 1; ctx.stroke();
            // 宝石追加
            ctx.fillStyle = '#FF0000';
            ctx.beginPath(); ctx.arc(0, -sz * 0.9 + bounce, 4, 0, Math.PI * 2); ctx.fill();
        } else if (slimeType === 'defender' || slimeType === 'golem' || slimeType === 'defender_golem' || slimeType === 'defender_elite' || slimeType === 'fortress_golem' || slimeType === 'titan_golem' || slimeType === 'platinum_golem' || slimeType === 'golem_sand' || slimeType === 'royal_guard') {
            // Defender/Golem family: Iron Helmet + Shield
            ctx.fillStyle = (slimeType === 'royal_guard') ? '#FFD700' : '#607D8B';
            ctx.beginPath();
            ctx.arc(0, -sz * 0.5 + bounce, sz * 0.42, Math.PI, 0); // Helmet Dome
            ctx.lineTo(sz * 0.42, -sz * 0.5 + bounce);
            ctx.lineTo(-sz * 0.42, -sz * 0.5 + bounce);
            ctx.fill();
            // Horn
            ctx.fillStyle = (slimeType === 'royal_guard') ? '#FBC02D' : '#CFD8DC';
            ctx.beginPath(); ctx.moveTo(0, -sz * 0.9 + bounce); ctx.lineTo(5, -sz * 1.3 + bounce); ctx.lineTo(10, -sz * 0.9 + bounce); ctx.fill();

            // Shield emblem on body
            ctx.strokeStyle = (slimeType === 'royal_guard') ? '#FFF' : '#FFD700';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(0, -sz * 0.3);
            ctx.lineTo(-sz * 0.15, -sz * 0.15);
            ctx.lineTo(-sz * 0.15, 0);
            ctx.lineTo(0, sz * 0.1);
            ctx.lineTo(sz * 0.15, 0);
            ctx.lineTo(sz * 0.15, -sz * 0.15);
            ctx.closePath();
            ctx.stroke();
        } else if (slimeType === 'slime_metal') {
            // Metal Slime: Sparkles + Metallic sheen
            if (frame % 20 < 10) {
                ctx.fillStyle = '#FFF';

                ctx.beginPath(); ctx.arc(sz * 0.3, -sz * 0.8 + bounce, 3, 0, Math.PI * 2); ctx.fill();
                ctx.beginPath(); ctx.arc(-sz * 0.25, -sz * 0.65 + bounce, 2, 0, Math.PI * 2); ctx.fill();

            }
            // Metallic lines
            ctx.strokeStyle = 'rgba(255,255,255,0.4)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(-sz * 0.3, -sz * 0.7); ctx.lineTo(sz * 0.25, -sz * 0.5);
            ctx.moveTo(-sz * 0.25, -sz * 0.4); ctx.lineTo(sz * 0.3, -sz * 0.25);
            ctx.stroke();
        } else if (slimeType === 'slime_gold') {
            // Gold Slime: Crown (shadowBlurを確実にリセット)
            ctx.save();
            _setShadowBlur(ctx, 0); // バグ修正: shadowBlurを確実に0にする
            ctx.fillStyle = '#FFD700';

            ctx.beginPath();
            ctx.moveTo(-sz * 0.25, -sz * 0.7 + bounce);
            ctx.lineTo(-sz * 0.15, -sz * 0.9 + bounce);
            ctx.lineTo(-sz * 0.05, -sz * 0.75 + bounce);
            ctx.lineTo(sz * 0.05, -sz * 0.9 + bounce);
            ctx.lineTo(sz * 0.15, -sz * 0.75 + bounce);
            ctx.lineTo(sz * 0.25, -sz * 0.9 + bounce);
            ctx.lineTo(sz * 0.25, -sz * 0.65 + bounce);
            ctx.lineTo(-sz * 0.25, -sz * 0.65 + bounce);
            ctx.closePath();
            ctx.fill();
            ctx.restore();
        } else if (slimeType === 'ninja' || slimeType === 'ninja_hanzo' || slimeType === 'ninja_merman' || slimeType === 'steel_ninja') {
            // Ninja variants: Headband + Mask
            // Headband
            ctx.fillStyle = (slimeType === 'ninja_merman') ? '#0D47A1' : '#212121';
            ctx.fillRect(-sz * 0.35, -sz * 0.55 + bounce, sz * 0.7, sz * 0.12);
            // Knot
            ctx.fillStyle = (slimeType === 'ninja_merman') ? '#2196F3' : '#424242';
            ctx.beginPath();
            ctx.arc(sz * 0.4, -sz * 0.49 + bounce, sz * 0.08, 0, Math.PI * 2);
            ctx.fill();
            // Mask (covering mouth)
            ctx.fillStyle = (slimeType === 'ninja_merman') ? '#1565C0' : '#212121';
            ctx.beginPath();
            ctx.moveTo(-sz * 0.3, faceY + sz * 0.1);
            ctx.lineTo(sz * 0.3, faceY + sz * 0.1);
            ctx.lineTo(sz * 0.25, faceY + sz * 0.25);
            ctx.lineTo(-sz * 0.25, faceY + sz * 0.25);
            ctx.closePath();
            ctx.fill();
        } else if (slimeType === 'wizard' || slimeType === 'shadow_mage') {
            // Wizard variants: Pointed Hat + Stars
            ctx.fillStyle = (slimeType === 'shadow_mage') ? '#311B92' : '#4A148C';
            ctx.beginPath();
            ctx.moveTo(0, -sz * 1.2 + bounce);
            ctx.lineTo(-sz * 0.35, -sz * 0.6 + bounce);
            ctx.lineTo(sz * 0.35, -sz * 0.6 + bounce);
            ctx.closePath();
            ctx.fill();
            // Hat brim
            ctx.fillStyle = (slimeType === 'shadow_mage') ? '#5E35B1' : '#6A1B9A';
            ctx.beginPath();
            ctx.ellipse(0, -sz * 0.6 + bounce, sz * 0.4, sz * 0.08, 0, 0, Math.PI * 2);
            ctx.fill();
            // Stars on hat
            ctx.fillStyle = '#FFD700';
            for (let i = 0; i < 3; i++) {
                const starX = (i - 1) * sz * 0.15;
                const starY = -sz * 0.85 + bounce - i * sz * 0.05;
                this._drawStar(ctx, starX, starY, 4, 2, 1.5);
            }
        } else if (slimeType === 'god_king') {
            // God King: Ultimate Crown + Aura
            ctx.save();
            ctx.fillStyle = '#FFD700';
            ctx.beginPath();
            ctx.moveTo(-sz * 0.5, -sz * 0.8 + bounce);
            for (let i = 0; i < 5; i++) {
                const step = -sz * 0.5 + (i * sz * 0.25);
                ctx.lineTo(step + sz * 0.125, -sz * 1.3 + bounce);
                ctx.lineTo(step + sz * 0.25, -sz * 0.8 + bounce);
            }
            ctx.fill();
            ctx.fillStyle = '#2196F3';
            ctx.beginPath(); ctx.arc(0, -sz * 0.95 + bounce, sz * 0.12, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = 'rgba(255, 215, 0, 0.4)';
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.arc(0, -sz * 0.5 + bounce, sz * 0.9 + Math.sin(frame * 0.1) * 5, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
        } else if (slimeType === 'slime_king_god') {
            // 👑 スライム王 (Slime King God): 究極の神々しさを演出
            ctx.save();
            const t = frame * 0.1;

            // ★改善②: 歩きモーション変数（walkY/walkRot をアクセサリにも反映）
            // ★バグ修正: walkY は body translate に既に適用済みのためアクセサリへの重複適用を防ぐ
            // bounce（浮遊）に加えてアクセサリ独自の揺れだけを追加する
            const _kRot      = frame > 0 ? Math.sin(frame * 0.22) * 0.06 : 0;    // 左右傾き
            const _kWingFlap = frame > 0 ? Math.sin(frame * 0.22) * 0.12 : 0;    // 翼のはばたき
            const kingBounce = bounce;                                              // bodyと同期（walkYは既に適用済み）

            // 1. 背後の神聖な光輪 (Divine Halo)
            ctx.save();
            ctx.translate(0, -sz * 0.5 + kingBounce);
            ctx.rotate(t * 0.5 + _kRot);
            ctx.strokeStyle = '#FFD700';
            ctx.lineWidth = 6;
            ctx.setLineDash([sz * 0.2, sz * 0.1]);
            ctx.beginPath();
            ctx.arc(0, 0, sz * 1.2, 0, Math.PI * 2);
            ctx.stroke();
            // 光の粒子
            for (let i = 0; i < 4; i++) {
                const ang = t + i * Math.PI * 0.5;
                ctx.fillStyle = '#FFF59D';
                ctx.beginPath();
                ctx.arc(Math.cos(ang) * sz * 1.2, Math.sin(ang) * sz * 1.2, 5, 0, Math.PI * 2);
                ctx.fill();
            }
            ctx.restore();

            // 2. 五層・六翼の大翼 (Six Wings) ★歩きに合わせてはばたく
            ctx.fillStyle = 'rgba(255, 255, 230, 0.85)';
            for (let s = -1; s <= 1; s += 2) {
                for (let i = 0; i < 3; i++) {
                    ctx.save();
                    const offY = -sz * 0.3 - i * sz * 0.25;
                    // ★はばたき: 歩行フレームに応じて翼角度が変わる
                    const rot = s * (0.3 + i * 0.2) + Math.sin(t + i) * 0.1 + s * _kWingFlap * (1 + i * 0.3);
                    ctx.translate(s * sz * 0.4, offY + kingBounce);
                    ctx.rotate(rot);
                    ctx.beginPath();
                    ctx.ellipse(0, 0, sz * 0.2, sz * (0.5 + i * 0.15), 0, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.restore();
                }
            }

            // 3. 王冠 (The Sovereign Crown) ★歩きに合わせてボブ
            ctx.save();
            ctx.rotate(_kRot * 0.5); // 王冠も少し傾く
            ctx.fillStyle = '#FFD700';
            ctx.beginPath();
            ctx.moveTo(-sz * 0.6, -sz * 0.8 + kingBounce);
            for (let i = 0; i < 5; i++) {
                const step = -sz * 0.6 + (i * sz * 0.3);
                ctx.lineTo(step + sz * 0.15, -sz * 1.5 + kingBounce);
                ctx.lineTo(step + sz * 0.3, -sz * 0.8 + kingBounce);
            }
            ctx.fill();
            ctx.strokeStyle = '#B8860B'; ctx.lineWidth = 2; ctx.stroke();
            ctx.restore();

            // 4. 三種の至宝 (The Three Jewels) ★王冠と同期して動く
            // 中央: 真紅 (火・破壊・創造)
            ctx.fillStyle = '#FF1744';
            ctx.beginPath(); ctx.arc(0, -sz * 1.1 + kingBounce, sz * 0.16, 0, Math.PI * 2); ctx.fill();
            // 左: 蒼天 (氷・叡智)
            ctx.fillStyle = '#29B6F6';
            ctx.beginPath(); ctx.arc(-sz * 0.3, -sz * 1.0 + kingBounce, sz * 0.12, 0, Math.PI * 2); ctx.fill();
            // 右: 翠風 (技術・技巧)
            ctx.fillStyle = '#76FF03';
            ctx.beginPath(); ctx.arc(sz * 0.3, -sz * 1.0 + kingBounce, sz * 0.12, 0, Math.PI * 2); ctx.fill();

            // 5. 神の威光 (Aura Glow)
            const g = ctx.createRadialGradient(0, -sz*0.5+kingBounce, sz*0.5, 0, -sz*0.5+kingBounce, sz*1.6);
            g.addColorStop(0, 'rgba(255,215,0,0)');
            g.addColorStop(0.5, 'rgba(255,215,0,0.25)');
            g.addColorStop(1, 'rgba(255,215,0,0)');
            ctx.fillStyle = g;
            ctx.beginPath(); ctx.arc(0, -sz * 0.5 + bounce, sz * 1.6, 0, Math.PI * 2); ctx.fill();

            ctx.restore();
        } else if (slimeType === 'angel' || slimeType === 'angel_seraph' || slimeType === 'angel_legend' || slimeType === 'arch_angel') {
            // Angel variants: Halo + Wings
            // Halo
            ctx.strokeStyle = (slimeType === 'angel_legend') ? '#FFEA00' : '#FFD700';
            ctx.lineWidth = (slimeType === 'arch_angel') ? 5 : 3;

            ctx.beginPath();
            ctx.arc(0, -sz * 1.1 + bounce, sz * (slimeType === 'arch_angel' ? 0.35 : 0.25), 0, Math.PI * 2);
            ctx.stroke();

            // Wings
            ctx.fillStyle = (slimeType === 'angel_legend') ? 'rgba(255,255,200,0.9)' : 'rgba(255,255,255,0.8)';
            // Left wing
            ctx.beginPath();
            ctx.ellipse(-sz * 0.5, -sz * 0.3, sz * 0.2, sz * 0.3, -0.3, 0, Math.PI * 2);
            ctx.fill();
            // Right wing
            ctx.beginPath();
            ctx.ellipse(sz * 0.5, -sz * 0.3, sz * 0.2, sz * 0.3, 0.3, 0, Math.PI * 2);
            ctx.fill();
            // Wing details
            ctx.strokeStyle = 'rgba(255,255,255,0.6)';
            ctx.lineWidth = 1;
            for (let i = 0; i < 3; i++) {
                ctx.beginPath();
                ctx.arc(-sz * 0.5, -sz * 0.3, sz * 0.1 + i * sz * 0.05, 0.5, Math.PI - 0.5);
                ctx.stroke();
                ctx.beginPath();
                ctx.arc(sz * 0.5, -sz * 0.3, sz * 0.1 + i * sz * 0.05, 0.5, Math.PI - 0.5);
                ctx.stroke();
            }
        } else if (slimeType === 'devil') {
            // Devil: Demon Horns + Wings
            // Horns
            ctx.fillStyle = '#8B0000';
            ctx.beginPath();
            // Left horn
            ctx.moveTo(-sz * 0.3, -sz * 0.7 + bounce);
            ctx.quadraticCurveTo(-sz * 0.4, -sz * 1.1 + bounce, -sz * 0.25, -sz * 1.2 + bounce);
            ctx.quadraticCurveTo(-sz * 0.2, -sz * 1.0 + bounce, -sz * 0.25, -sz * 0.7 + bounce);
            ctx.closePath();
            ctx.fill();
            // Right horn
            ctx.beginPath();
            ctx.moveTo(sz * 0.3, -sz * 0.7 + bounce);
            ctx.quadraticCurveTo(sz * 0.4, -sz * 1.1 + bounce, sz * 0.25, -sz * 1.2 + bounce);
            ctx.quadraticCurveTo(sz * 0.2, -sz * 1.0 + bounce, sz * 0.25, -sz * 0.7 + bounce);
            ctx.closePath();
            ctx.fill();

            // Devil wings (bat-like)
            ctx.fillStyle = 'rgba(139,0,0,0.6)';
            // Left wing
            ctx.beginPath();
            ctx.moveTo(-sz * 0.35, -sz * 0.2);
            ctx.quadraticCurveTo(-sz * 0.7, -sz * 0.3, -sz * 0.65, -sz * 0.05);
            ctx.quadraticCurveTo(-sz * 0.6, sz * 0.05, -sz * 0.35, 0);
            ctx.closePath();
            ctx.fill();
            // Right wing
            ctx.beginPath();
            ctx.moveTo(sz * 0.35, -sz * 0.2);
            ctx.quadraticCurveTo(sz * 0.7, -sz * 0.3, sz * 0.65, -sz * 0.05);
            ctx.quadraticCurveTo(sz * 0.6, sz * 0.05, sz * 0.35, 0);
            ctx.closePath();
            ctx.fill();
        } else if (slimeType === 'healer' || slimeType === 'healer_recov') {
            // Healer variants: Cross Hat
            ctx.fillStyle = (slimeType === 'healer_recov') ? '#42A5F5' : '#E91E63'; 
            ctx.beginPath();
            ctx.arc(0, -sz * 0.5 + bounce, sz * 0.45, Math.PI, 0);
            ctx.fill();
            // White Cross
            ctx.fillStyle = '#FFF';
            ctx.fillRect(-sz * 0.05, -sz * 0.8 + bounce, sz * 0.1, sz * 0.2);
            ctx.fillRect(-sz * 0.1, -sz * 0.75 + bounce, sz * 0.2, sz * 0.1);
        } else if (slimeType === 'ghost' || slimeType === 'ghost_kai' || slimeType === 'phantom') {
            // Ghost family: Transparent + Spooky
            ctx.save();
            ctx.globalAlpha *= 0.6;
            // Spooky eyes (large white orbs)
            ctx.fillStyle = (slimeType === 'phantom') ? '#FFEA00' : '#FFF';
            ctx.beginPath(); ctx.arc(-sz * 0.2, faceY, 6, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(sz * 0.2, faceY, 6, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#000';
            ctx.beginPath(); ctx.arc(-sz * 0.2, faceY, 2, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(sz * 0.2, faceY, 2, 0, Math.PI * 2); ctx.fill();
            ctx.restore();
        } else if (slimeType === 'metalking' || slimeType === 'metalking_ex' || slimeType === 'legend_metal') {
            // Metal King variants: Large Crown + Shiny
            ctx.fillStyle = (slimeType === 'legend_metal') ? '#FFD700' : '#FFC107';
            ctx.beginPath();
            ctx.moveTo(-sz * 0.4, -sz * 0.8 + bounce);
            ctx.lineTo(-sz * 0.2, -sz * 1.2 + bounce);
            ctx.lineTo(0, -sz * 0.9 + bounce);
            ctx.lineTo(sz * 0.2, -sz * 1.2 + bounce);
            ctx.lineTo(sz * 0.4, -sz * 0.8 + bounce);
            ctx.fill();
            // Sparkles
            if (frame % 20 < 10) {
                ctx.fillStyle = '#FFF';
                ctx.beginPath(); ctx.arc(sz * 0.5, -sz * 0.5, 4, 0, Math.PI * 2); ctx.fill();
            }
        } else if (slimeType === 'ultimate') {
            // Ultimate: Rainbow Glow + Wings + Crown
            const hue = (frame * 5) % 360;

            // Halo + Wings ensemble
            ctx.strokeStyle = `hsl(${hue}, 100%, 70%)`;
            ctx.lineWidth = 4;
            ctx.beginPath(); ctx.arc(0, -sz * 1.2 + bounce, sz * 0.3, 0, Math.PI * 2); ctx.stroke();

        } else if (slimeType === 'special' || slimeType === 'devil_jr' || slimeType === 'demon_jr') {
            // Special: シンプルな角と翼
            // 角
            ctx.fillStyle = '#880E4F';
            ctx.lineWidth = 1.5;
            for (let i = -1; i <= 1; i += 2) {
                ctx.beginPath();
                ctx.moveTo(i * sz * 0.2, -sz * 0.8 + bounce);
                ctx.quadraticCurveTo(i * sz * 0.4, -sz * 1.2 + bounce, i * sz * 0.6, -sz * 1.1 + bounce);
                ctx.lineTo(i * sz * 0.3, -sz * 0.8 + bounce);
                ctx.fill();
            }
            // 翼
            ctx.fillStyle = 'rgba(136,14,79,0.7)';
            for (let i = -1; i <= 1; i += 2) {
                ctx.save();
                ctx.translate(i * sz * 0.4, -sz * 0.3);
                ctx.scale(i, 1);
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.quadraticCurveTo(sz * 0.5, -sz * 0.5, sz * 0.8, 0);
                ctx.quadraticCurveTo(sz * 0.4, sz * 0.2, 0, 0);
                ctx.fill();
                ctx.restore();
            }
        } else if (slimeType === 'drone') {
            // Drone: シンプルな十字プロペラ（4回のsave/restoreをなくす）
            const propAngle = frame * 0.3;
            const hubY = -sz * 0.9 + bounce;
            const bladeLen = sz * 0.2;
            ctx.strokeStyle = '#757575';
            ctx.lineWidth = 3;
            ctx.lineCap = 'round';
            ctx.save();
            ctx.translate(0, hubY);
            ctx.rotate(propAngle);
            ctx.beginPath();
            ctx.moveTo(-bladeLen, 0); ctx.lineTo(bladeLen, 0);
            ctx.moveTo(0, -bladeLen); ctx.lineTo(0, bladeLen);
            ctx.stroke();
            ctx.restore();
            ctx.fillStyle = '#424242';
            ctx.beginPath();
            ctx.arc(0, hubY, sz * 0.07, 0, Math.PI * 2); ctx.fill();
        } else if (slimeType === 'dragon') {
            // Dragon: 完全なドラゴンの姿！
            ctx.save();
            ctx.translate(0, -sz * 0.2); // 少し上に

            // === 体の本体（長い首と胴体） ===
            // 胴体
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.ellipse(0, sz * 0.2, sz * 0.5, sz * 0.35, 0, 0, Math.PI * 2);
            ctx.fill();

            // 首（長くてしなやか）
            const neckCurve = Math.sin(frame * 0.08) * 0.1;
            ctx.beginPath();
            ctx.moveTo(-sz * 0.2, sz * 0.1);
            ctx.quadraticCurveTo(neckCurve * sz, -sz * 0.3, 0, -sz * 0.6);
            ctx.quadraticCurveTo(-neckCurve * sz, -sz * 0.3, sz * 0.2, sz * 0.1);
            ctx.closePath();
            ctx.fill();

            // 頭部（竜らしい形）
            ctx.fillStyle = this._lighten(color, 20);
            ctx.beginPath();
            ctx.ellipse(0, -sz * 0.7, sz * 0.25, sz * 0.2, 0, 0, Math.PI * 2);
            ctx.fill();

            // 口（開いた口）
            ctx.fillStyle = '#8B0000';
            ctx.beginPath();
            ctx.arc(0, -sz * 0.65, sz * 0.15, 0.2, Math.PI - 0.2);
            ctx.fill();

            // 牙（上下）
            ctx.fillStyle = '#FFF';
            for (let i = -1; i <= 1; i += 2) {
                ctx.beginPath();
                ctx.moveTo(i * sz * 0.08, -sz * 0.65);
                ctx.lineTo(i * sz * 0.05, -sz * 0.55);
                ctx.lineTo(i * sz * 0.11, -sz * 0.65);
                ctx.closePath();
                ctx.fill();
            }

            // 目（鋭い竜の目）
            ctx.fillStyle = '#FFD700';

            for (let i = -1; i <= 1; i += 2) {
                ctx.beginPath();
                ctx.ellipse(i * sz * 0.12, -sz * 0.75, sz * 0.06, sz * 0.08, i * 0.2, 0, Math.PI * 2);
                ctx.fill();

                // 瞳孔（縦長）
                ctx.fillStyle = '#000';
                ctx.fillRect(i * sz * 0.12 - 1, -sz * 0.8, 2, sz * 0.1);
            }

            ctx.fillStyle = color;

            // 角（大きく威厳のある）
            ctx.fillStyle = '#FFD700';
            ctx.strokeStyle = '#B8860B';
            ctx.lineWidth = 2;
            for (let i = -1; i <= 1; i += 2) {
                ctx.beginPath();
                ctx.moveTo(i * sz * 0.15, -sz * 0.85);
                ctx.quadraticCurveTo(i * sz * 0.25, -sz * 1.2, i * sz * 0.2, -sz * 1.35);
                ctx.lineTo(i * sz * 0.15, -sz * 1.3);
                ctx.quadraticCurveTo(i * sz * 0.2, -sz * 1.15, i * sz * 0.12, -sz * 0.85);
                ctx.closePath();
                ctx.fill();
                ctx.stroke();
            }

            // === 翼（巨大で力強い） ===
            const wingFlap = Math.sin(frame * 0.08) * 0.06; // ★修正: 自然な羽ばたきに
            ctx.fillStyle = 'rgba(139,0,0,0.9)';
            ctx.strokeStyle = '#8B0000';
            ctx.lineWidth = 3;

            // 左翼
            ctx.save();
            ctx.translate(-sz * 0.3, -sz * 0.1);
            ctx.rotate(-0.25 + wingFlap); // ★修正: 角度を緩やかに
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.bezierCurveTo(-sz * 0.6, -sz * 0.3, -sz * 0.9, -sz * 0.2, -sz * 1.0, sz * 0.1);
            ctx.bezierCurveTo(-sz * 0.85, sz * 0.25, -sz * 0.5, sz * 0.2, 0, 0);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
            ctx.restore();

            // 右翼
            ctx.save();
            ctx.translate(sz * 0.3, -sz * 0.1);
            ctx.rotate(0.25 - wingFlap); // ★修正: 角度を緩やかに
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.bezierCurveTo(sz * 0.6, -sz * 0.3, sz * 0.9, -sz * 0.2, sz * 1.0, sz * 0.1);
            ctx.bezierCurveTo(sz * 0.85, sz * 0.25, sz * 0.5, sz * 0.2, 0, 0);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
            ctx.restore();

            // === 尻尾（長くて先が尖っている） ===
            ctx.fillStyle = color;
            const tailSway = Math.sin(frame * 0.1) * 0.2;
            ctx.beginPath();
            ctx.moveTo(0, sz * 0.5);
            ctx.quadraticCurveTo(tailSway * sz, sz * 0.8, 0, sz * 1.1);
            ctx.lineTo(sz * 0.05, sz * 1.05);
            ctx.quadraticCurveTo(tailSway * sz * 0.9, sz * 0.75, sz * 0.05, sz * 0.5);
            ctx.closePath();
            ctx.fill();

            // 尻尾の先端（矢じり型）
            ctx.fillStyle = '#8B0000';
            ctx.beginPath();
            ctx.moveTo(0, sz * 1.1);
            ctx.lineTo(-sz * 0.1, sz * 1.0);
            ctx.lineTo(sz * 0.1, sz * 1.0);
            ctx.closePath();
            ctx.fill();

            // === 炎のオーラ（簡略版: 4点のみ） ===
            for (let i = 0; i < 4; i++) {
                const angle = (frame * 0.05 + i * Math.PI / 2);
                ctx.fillStyle = i % 2 === 0 ? '#FF4500' : '#FFA500';
                ctx.beginPath();
                ctx.arc(Math.cos(angle) * sz * 0.65, Math.sin(angle) * sz * 0.45 - sz * 0.3, sz * 0.07, 0, Math.PI * 2);
                ctx.fill();
            }

            ctx.restore();
        } else if (slimeType === 'titan' || slimeType === 'titan_golem') {
            // Titan: 巨人の特徴（岩のような体、筋肉質） - 「破壊者」バージョンへ強化
            // 岩のような強固な体（基本形状）

            // 巨大な岩の肩（より鋭く、トゲトゲしく）
            ctx.fillStyle = '#424242';
            ctx.strokeStyle = '#212121';
            ctx.lineWidth = 3;
            for (let i = -1; i <= 1; i += 2) {
                ctx.save();
                ctx.translate(i * sz * 0.6, -sz * 0.3);
                ctx.rotate(i * 0.4);
                // 肩の岩
                ctx.beginPath();
                ctx.moveTo(-sz * 0.2, -sz * 0.2);
                ctx.lineTo(sz * 0.2, -sz * 0.2);
                ctx.lineTo(sz * 0.3, sz * 0.2);
                ctx.lineTo(-sz * 0.3, sz * 0.2);
                ctx.closePath();
                ctx.fill();
                ctx.stroke();

                // 肩から生えるトゲ（破壊者！）
                ctx.fillStyle = '#C62828'; // 赤いトゲ
                ctx.beginPath();
                ctx.moveTo(-sz * 0.1, -sz * 0.2);
                ctx.lineTo(0, -sz * 0.5);
                ctx.lineTo(sz * 0.1, -sz * 0.2);
                ctx.fill();
                ctx.restore();
            }

            // 巨大な拳
            ctx.fillStyle = '#B71C1C';

            // 左拳
            ctx.beginPath(); ctx.arc(-sz * 0.7, 0, sz * 0.2, 0, Math.PI * 2); ctx.fill();
            // 右拳
            ctx.beginPath(); ctx.arc(sz * 0.7, 0, sz * 0.2, 0, Math.PI * 2); ctx.fill();

            // 破壊のヘルメット（角がさらに大きく）
            ctx.fillStyle = '#1B5E20';
            ctx.beginPath();
            ctx.arc(0, -sz * 0.6 + bounce, sz * 0.5, Math.PI, 0);
            ctx.lineTo(sz * 0.5, -sz * 0.4 + bounce);
            ctx.lineTo(-sz * 0.5, -sz * 0.4 + bounce);
            ctx.closePath();
            ctx.fill();

            // 巨大な2本の角（赤黒い、より威圧的）
            ctx.fillStyle = '#212121';
            ctx.strokeStyle = '#D32F2F';
            ctx.lineWidth = 3;
            for (let i = -1; i <= 1; i += 2) {
                ctx.beginPath();
                ctx.moveTo(i * sz * 0.35, -sz * 0.7 + bounce);
                ctx.quadraticCurveTo(i * sz * 0.6, -sz * 1.3 + bounce, i * sz * 0.5, -sz * 1.6 + bounce);
                ctx.lineTo(i * sz * 0.25, -sz * 0.7 + bounce);
                ctx.fill();
                ctx.stroke();
            }

            // 体のヒビ割れ（溶岩が流れているような）
            ctx.strokeStyle = '#FF3D00';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-sz * 0.2, -sz * 0.1); ctx.lineTo(-sz * 0.4, sz * 0.2); ctx.lineTo(-sz * 0.2, sz * 0.4);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(sz * 0.1, -sz * 0.2); ctx.lineTo(sz * 0.3, 0); ctx.lineTo(sz * 0.1, sz * 0.2);
            ctx.stroke();

            // 足元の破壊オーラ（簡略）
            ctx.fillStyle = 'rgba(255, 61, 0, 0.3)';
            ctx.beginPath();
            ctx.ellipse(0, sz * 0.5, sz * 0.8, sz * 0.18, 0, 0, Math.PI * 2);
            ctx.fill();


        } else if (slimeType === 'slime_king_god') {
            // 👑 スライム王 — プラチナゴーレム×ゴッドキングの究極合成・ストーリーの王様そのもの
            const t = Date.now() * 0.001;

            // ── 王の後光（プラチナ×金・二重リング）──
            [2.2, 1.6].forEach((mul, ri) => {
                const rayCount = 24 - ri * 8;
                for (let r = 0; r < rayCount; r++) {
                    const angle = (r / rayCount) * Math.PI * 2 + t * (0.25 - ri * 0.1);
                    const innerR = sz * 0.95;
                    const outerR = sz * (mul + Math.sin(t * 1.5 + r) * 0.12);
                    const alpha = 0.15 + 0.08 * Math.sin(t * 2 + r);
                    ctx.strokeStyle = ri === 0
                        ? `rgba(220,200,255,${alpha})`   // プラチナ
                        : `rgba(255,215,0,${alpha * 1.2})`;  // 金
                    ctx.lineWidth = ri === 0 ? sz * 0.1 : sz * 0.07;
                    ctx.lineCap = 'round';
                    ctx.beginPath();
                    ctx.moveTo(Math.cos(angle) * innerR, Math.sin(angle) * innerR - sz * 0.15);
                    ctx.lineTo(Math.cos(angle) * outerR, Math.sin(angle) * outerR - sz * 0.15);
                    ctx.stroke();
                }
            });

            // ── オーラ（プラチナ→金グロー）──
            const auraG = ctx.createRadialGradient(0, -sz * 0.15, sz * 0.2, 0, -sz * 0.15, sz * 1.5);
            auraG.addColorStop(0, `hsla(${50 + Math.sin(t) * 20}, 100%, 90%, 0.28)`);
            auraG.addColorStop(0.5, `hsla(${270 + Math.sin(t * 0.7) * 30}, 60%, 80%, 0.10)`);
            auraG.addColorStop(1, 'rgba(255,215,0,0)');
            ctx.fillStyle = auraG;
            ctx.beginPath(); ctx.ellipse(0, -sz * 0.15, sz * 1.5, sz * 1.2, 0, 0, Math.PI * 2); ctx.fill();

            // ── 豪華マント（プラチナ白×金縁）──
            const mantleG = ctx.createLinearGradient(0, -sz * 0.6, 0, sz * 0.5);
            mantleG.addColorStop(0, '#E8E0F8');
            mantleG.addColorStop(0.4, '#CFD8DC');
            mantleG.addColorStop(1, '#90A4AE');
            ctx.fillStyle = mantleG;
            ctx.beginPath();
            ctx.moveTo(-sz * 0.62, -sz * 0.45);
            ctx.quadraticCurveTo(-sz * 0.85, sz * 0.1, -sz * 0.7, sz * 0.55);
            ctx.lineTo(-sz * 0.15, sz * 0.6);
            ctx.lineTo(sz * 0.15, sz * 0.6);
            ctx.lineTo(sz * 0.7, sz * 0.55);
            ctx.quadraticCurveTo(sz * 0.85, sz * 0.1, sz * 0.62, -sz * 0.45);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 2.5; ctx.stroke();
            // マントの紋章ライン
            ctx.strokeStyle = 'rgba(255,215,0,0.35)'; ctx.lineWidth = 1.5;
            [-sz*0.4, -sz*0.15, sz*0.15, sz*0.4].forEach(mx => {
                ctx.beginPath(); ctx.moveTo(mx, -sz*0.2); ctx.lineTo(mx*0.9, sz*0.5); ctx.stroke();
            });
            // 毛皮飾り（白ドット）
            ctx.fillStyle = 'rgba(255,255,255,0.7)';
            for (let d = 0; d < 16; d++) {
                const da = (d / 16) * Math.PI * 2;
                const dr = sz * 0.68;
                ctx.beginPath(); ctx.arc(Math.cos(da) * dr * 0.7, sz * 0.52 + Math.sin(da) * sz * 0.04, sz * 0.04, 0, Math.PI * 2); ctx.fill();
            }

            // ── 体（プラチナ白×金虹グラデ）──
            const bodyG = ctx.createRadialGradient(-sz * 0.28, -sz * 0.42, sz * 0.05, 0, -sz * 0.12, sz * 0.82);
            bodyG.addColorStop(0, '#FFFFFF');
            bodyG.addColorStop(0.2, '#F0ECFF');
            bodyG.addColorStop(0.5, '#D4C8F0');
            bodyG.addColorStop(0.8, color || '#C0B0E8');
            bodyG.addColorStop(1, darkColor || '#8B6914');
            ctx.fillStyle = bodyG;
            ctx.beginPath(); ctx.ellipse(0, -sz * 0.15, sz * 0.75, sz * 0.68, 0, 0, Math.PI * 2); ctx.fill();
            // 虹縁取り（王の輝き）
            const rimHue = (t * 35) % 360;
            ctx.strokeStyle = `hsl(${rimHue}, 100%, 72%)`;
            ctx.lineWidth = 3;
            ctx.beginPath(); ctx.ellipse(0, -sz * 0.15, sz * 0.75, sz * 0.68, 0, 0, Math.PI * 2); ctx.stroke();

            // ── 腕（王笏を持つ）──
            [-1, 1].forEach(s => {
                const armG = ctx.createLinearGradient(s*sz*0.45, -sz*0.35, s*sz*0.82, sz*0.15);
                armG.addColorStop(0, '#D4C8F0'); armG.addColorStop(1, '#9090C8');
                ctx.fillStyle = armG;
                ctx.beginPath(); ctx.ellipse(s*sz*0.66, -sz*0.07, sz*0.13, sz*0.25, s*0.22, 0, Math.PI*2); ctx.fill();
                ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 1.5; ctx.stroke();
                // 手
                const handG = ctx.createRadialGradient(s*sz*0.76, sz*0.2, 0, s*sz*0.76, sz*0.2, sz*0.16);
                handG.addColorStop(0, '#FFFFFF'); handG.addColorStop(1, '#D4C8F0');
                ctx.fillStyle = handG;
                ctx.beginPath(); ctx.arc(s*sz*0.76, sz*0.2, sz*0.15, 0, Math.PI*2); ctx.fill();
                ctx.strokeStyle = '#B8A0D0'; ctx.lineWidth = 1; ctx.stroke();
            });

            // ── 王笏（右手・光り輝く）──
            const staffX = sz * 0.76, staffY = sz * 0.18;
            // 柄
            const staffG = ctx.createLinearGradient(staffX, staffY, staffX, staffY - sz*0.85);
            staffG.addColorStop(0, '#8B6914'); staffG.addColorStop(0.5, '#FFD700'); staffG.addColorStop(1, '#FFF8DC');
            ctx.strokeStyle = staffG; ctx.lineWidth = sz*0.065; ctx.lineCap = 'round';
            ctx.beginPath(); ctx.moveTo(staffX, staffY); ctx.lineTo(staffX - sz*0.08, staffY - sz*0.82); ctx.stroke();
            // 宝珠（頂上）
            const orbY = staffY - sz*0.84;
            const orbA = 0.8 + 0.2 * Math.sin(t * 4);
            const orbG = ctx.createRadialGradient(staffX-sz*0.12, orbY, 0, staffX-sz*0.1, orbY, sz*0.16);
            orbG.addColorStop(0, `rgba(255,255,255,${orbA})`);
            orbG.addColorStop(0.4, `hsla(${(t*60)%360},100%,75%,${orbA*0.9})`);
            orbG.addColorStop(1, `rgba(100,50,200,${orbA*0.5})`);
            ctx.fillStyle = orbG;
            ctx.beginPath(); ctx.arc(staffX-sz*0.1, orbY, sz*0.16, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 2; ctx.stroke();
            // 宝珠の星型光芒
            for (let r = 0; r < 6; r++) {
                const ra = (r/6)*Math.PI*2 + t*0.8;
                ctx.strokeStyle = `hsla(${(r*60+t*40)%360},100%,80%,0.6)`;
                ctx.lineWidth = 1.2;
                ctx.beginPath();
                ctx.moveTo(staffX-sz*0.1, orbY);
                ctx.lineTo(staffX-sz*0.1 + Math.cos(ra)*sz*0.26, orbY + Math.sin(ra)*sz*0.26);
                ctx.stroke();
            }

            // ── 白銀の長髪（王様スタイル）──
            [-1, 1].forEach(s => {
                const hG = ctx.createLinearGradient(s*sz*0.3, -sz*0.62, s*sz*0.65, sz*0.3);
                hG.addColorStop(0, '#FFFFFF'); hG.addColorStop(0.6, '#E8E0F8'); hG.addColorStop(1, '#C0B0E8');
                ctx.fillStyle = hG;
                ctx.beginPath();
                ctx.moveTo(s*sz*0.32, -sz*0.62+bounce);
                ctx.quadraticCurveTo(s*sz*0.78, -sz*0.05+bounce, s*sz*0.62, sz*0.28+bounce);
                ctx.quadraticCurveTo(s*sz*0.52, sz*0.32+bounce, s*sz*0.38, -sz*0.58+bounce);
                ctx.closePath(); ctx.fill();
            });
            for (let i = -2; i <= 2; i++) {
                ctx.fillStyle = i===0 ? '#FFFFFF' : '#EAE4FC';
                ctx.beginPath(); ctx.ellipse(i*sz*0.11, -sz*0.68+bounce, sz*0.07, sz*0.16, i*0.08, 0, Math.PI*2); ctx.fill();
            }

            // ── 特大王冠（5本タワー・プラチナ×金）──
            const crownY = -sz * 0.88 + bounce;
            const crownBandG = ctx.createLinearGradient(-sz*0.55, crownY, sz*0.55, crownY+sz*0.2);
            crownBandG.addColorStop(0, '#90A4AE');
            crownBandG.addColorStop(0.4, '#CFD8DC');
            crownBandG.addColorStop(0.6, '#FFD700');
            crownBandG.addColorStop(1, '#90A4AE');
            ctx.fillStyle = crownBandG;
            this._roundRect(ctx, -sz*0.54, crownY, sz*1.08, sz*0.2, 6); ctx.fill();
            ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 2; ctx.stroke();
            // 冠の宝石埋め込み（3個）
            [-sz*0.25, 0, sz*0.25].forEach((bx, bi) => {
                const gemColors = ['#FF4444', '#FFD700', '#4499FF'];
                const gemG = ctx.createRadialGradient(bx, crownY+sz*0.1, 0, bx, crownY+sz*0.1, sz*0.07);
                gemG.addColorStop(0, '#FFFFFF');
                gemG.addColorStop(0.5, gemColors[bi]);
                gemG.addColorStop(1, 'rgba(0,0,0,0.3)');
                ctx.fillStyle = gemG;
                ctx.beginPath(); ctx.arc(bx, crownY+sz*0.1, sz*0.07, 0, Math.PI*2); ctx.fill();
                ctx.strokeStyle = '#FFF8DC'; ctx.lineWidth = 1; ctx.stroke();
            });
            // タワー（5本・中央が最高）
            [[0,1.3,'#FF1744'],[-sz*0.26,0.9,'#4499FF'],[sz*0.26,0.9,'#4499FF'],
             [-sz*0.46,0.65,'#AB47BC'],[sz*0.46,0.65,'#AB47BC']].forEach(([tx,h,gc]) => {
                const tH = sz*0.36*h;
                const tG2 = ctx.createLinearGradient(0, crownY-tH, 0, crownY);
                tG2.addColorStop(0, '#FFFDE7'); tG2.addColorStop(0.5, '#CFD8DC'); tG2.addColorStop(1, '#FFD700');
                ctx.fillStyle = tG2;
                ctx.beginPath();
                ctx.moveTo(tx-sz*0.075, crownY);
                ctx.lineTo(tx-sz*0.04, crownY-tH);
                ctx.lineTo(tx, crownY-tH-sz*0.09);
                ctx.lineTo(tx+sz*0.04, crownY-tH);
                ctx.lineTo(tx+sz*0.075, crownY);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#B8860B'; ctx.lineWidth = 1.2; ctx.stroke();
                const gPulse = 0.7 + 0.3*Math.sin(t*2.5+tx*0.1);
                const gemG2 = ctx.createRadialGradient(tx, crownY-tH-sz*0.03, 0, tx, crownY-tH-sz*0.03, sz*0.08);
                gemG2.addColorStop(0, '#FFFFFF');
                gemG2.addColorStop(0.5, gc);
                gemG2.addColorStop(1, 'rgba(0,0,0,0.2)');
                ctx.fillStyle = gemG2; ctx.globalAlpha = gPulse;
                ctx.beginPath(); ctx.arc(tx, crownY-tH-sz*0.03, sz*0.08, 0, Math.PI*2); ctx.fill();
                ctx.globalAlpha = 1;
            });

            // ── 眉（威厳のある太眉）──
            ctx.strokeStyle = '#888'; ctx.lineWidth = 3; ctx.lineCap = 'round';
            [-1, 1].forEach(s => {
                ctx.save();
                ctx.translate(s*sz*0.22, -sz*0.38+bounce);
                ctx.rotate(s*-0.18);
                ctx.beginPath(); ctx.moveTo(-sz*0.15, 0); ctx.lineTo(sz*0.15, sz*0.02); ctx.stroke();
                ctx.restore();
            });

            // ── 目（王者の金色の目）──
            [-1, 1].forEach(s => {
                const ex = s*sz*0.23, ey = -sz*0.26+bounce;
                ctx.fillStyle = '#FFF';
                ctx.beginPath(); ctx.ellipse(ex, ey, sz*0.12, sz*0.09, 0, 0, Math.PI*2); ctx.fill();
                // プラチナ×金の瞳
                const eyeG = ctx.createRadialGradient(ex, ey, 0, ex, ey, sz*0.085);
                eyeG.addColorStop(0, '#FFFFFF');
                eyeG.addColorStop(0.3, '#FFD700');
                eyeG.addColorStop(0.7, '#B070E0');
                eyeG.addColorStop(1, '#4A0090');
                ctx.fillStyle = eyeG;
                ctx.beginPath(); ctx.ellipse(ex, ey, sz*0.085, sz*0.085, 0, 0, Math.PI*2); ctx.fill();
                // 十字光芒（神の目）
                ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = 1.2;
                ctx.beginPath(); ctx.moveTo(ex-sz*0.045, ey); ctx.lineTo(ex+sz*0.045, ey); ctx.stroke();
                ctx.beginPath(); ctx.moveTo(ex, ey-sz*0.045); ctx.lineTo(ex, ey+sz*0.045); ctx.stroke();
                ctx.fillStyle = 'rgba(255,255,255,0.9)';
                ctx.beginPath(); ctx.arc(ex-sz*0.022, ey-sz*0.024, sz*0.022, 0, Math.PI*2); ctx.fill();
            });

            // ── 第三の目（額の王の宝眼）──
            const te3Y = -sz*0.5+bounce;
            const te3P = 0.6 + 0.4*Math.sin(t*3.5);
            // ひし形の宝石台座
            ctx.fillStyle = '#FFD700';
            ctx.beginPath(); ctx.moveTo(0, te3Y-sz*0.13); ctx.lineTo(sz*0.09, te3Y); ctx.lineTo(0, te3Y+sz*0.13); ctx.lineTo(-sz*0.09, te3Y); ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#FFF8DC'; ctx.lineWidth = 1.5; ctx.stroke();
            // 宝眼本体
            const te3G = ctx.createRadialGradient(0, te3Y, 0, 0, te3Y, sz*0.09);
            te3G.addColorStop(0, `hsla(${(t*50)%360},100%,90%,1)`);
            te3G.addColorStop(0.5, '#B070E0');
            te3G.addColorStop(1, '#4A0090');
            ctx.fillStyle = te3G; ctx.globalAlpha = te3P;
            ctx.beginPath(); ctx.arc(0, te3Y, sz*0.09, 0, Math.PI*2); ctx.fill();
            ctx.globalAlpha = 1;
            ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.arc(0, te3Y, sz*0.09, 0, Math.PI*2); ctx.stroke();

            // ── 鼻 ──
            ctx.fillStyle = darkColor || '#8B6914';
            ctx.beginPath(); ctx.ellipse(0, -sz*0.1+bounce, sz*0.06, sz*0.05, 0, 0, Math.PI*2); ctx.fill();

            // ── 口（王の威厳ある微笑み）──
            ctx.strokeStyle = '#6A3090'; ctx.lineWidth = 2.5; ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(-sz*0.13, sz*0.04+bounce);
            ctx.quadraticCurveTo(0, sz*0.1+bounce, sz*0.13, sz*0.04+bounce);
            ctx.stroke();

            // ── 長ひげ（白銀・王様の象徴）──
            const bG = ctx.createLinearGradient(0, sz*0.12, 0, sz*0.72);
            bG.addColorStop(0, '#FFFFFF'); bG.addColorStop(0.6, '#E8E0F8'); bG.addColorStop(1, 'rgba(200,180,240,0)');
            ctx.fillStyle = bG;
            ctx.beginPath();
            ctx.moveTo(-sz*0.18, sz*0.12+bounce);
            ctx.quadraticCurveTo(-sz*0.28, sz*0.42+bounce, -sz*0.14, sz*0.72+bounce);
            ctx.quadraticCurveTo(0, sz*0.78+bounce, sz*0.14, sz*0.72+bounce);
            ctx.quadraticCurveTo(sz*0.28, sz*0.42+bounce, sz*0.18, sz*0.12+bounce);
            ctx.quadraticCurveTo(0, sz*0.2+bounce, -sz*0.18, sz*0.12+bounce);
            ctx.fill();
            ctx.strokeStyle = 'rgba(180,160,220,0.5)'; ctx.lineWidth = 1.2;
            [-sz*0.07, 0, sz*0.07].forEach(bx => {
                ctx.beginPath();
                ctx.moveTo(bx, sz*0.18+bounce);
                ctx.quadraticCurveTo(bx*1.3, sz*0.48+bounce, bx*0.9, sz*0.7+bounce);
                ctx.stroke();
            });

            // ── 浮遊する星パーティクル（王の輝き）──
            for (let p = 0; p < 8; p++) {
                const pa = t*0.7 + p*Math.PI/4;
                const pr = sz*(1.0 + Math.sin(t+p*1.4)*0.18);
                const ppx = Math.cos(pa)*pr, ppy = Math.sin(pa)*pr*0.55 - sz*0.15;
                const pps = sz*(0.055 + 0.03*Math.sin(t*2.5+p));
                // 星型
                ctx.fillStyle = `hsla(${(p*45+t*25)%360},100%,85%,0.9)`;
                ctx.beginPath();
                for (let sp = 0; sp < 5; sp++) {
                    const sa = (sp*4*Math.PI/5) - Math.PI/2 + pa*0.3;
                    const sa2 = sa + Math.PI/5;
                    if (sp===0) ctx.moveTo(ppx+Math.cos(sa)*pps, ppy+Math.sin(sa)*pps);
                    else ctx.lineTo(ppx+Math.cos(sa)*pps, ppy+Math.sin(sa)*pps);
                    ctx.lineTo(ppx+Math.cos(sa2)*pps*0.4, ppy+Math.sin(sa2)*pps*0.4);
                }
                ctx.closePath(); ctx.fill();
            }

        } else if (slimeType === 'god_king') {
            // ✨ ゴッドキングスライム — 神様デザイン（後光・袈裟・第三の目・神聖光輪）
            const t = Date.now() * 0.001;

            // ── 後光（神の光輪・放射光線）──
            const rayCount = 16;
            for (let r = 0; r < rayCount; r++) {
                const angle = (r / rayCount) * Math.PI * 2 + t * 0.3;
                const innerR = sz * 0.9;
                const outerR = sz * (1.8 + Math.sin(t * 1.5 + r) * 0.15);
                const alpha = 0.12 + 0.08 * Math.sin(t * 2 + r * 0.8);
                ctx.strokeStyle = r % 2 === 0
                    ? `rgba(255,220,100,${alpha})`
                    : `rgba(255,255,200,${alpha * 0.7})`;
                ctx.lineWidth = r % 2 === 0 ? sz * 0.12 : sz * 0.06;
                ctx.lineCap = 'round';
                ctx.beginPath();
                ctx.moveTo(Math.cos(angle) * innerR, Math.sin(angle) * innerR - sz * 0.2);
                ctx.lineTo(Math.cos(angle) * outerR, Math.sin(angle) * outerR - sz * 0.2);
                ctx.stroke();
            }

            // ── 神聖オーラ（虹色グロー）──
            const auraR = sz * 1.4 + Math.sin(t * 1.8) * sz * 0.06;
            const auraG = ctx.createRadialGradient(0, -sz * 0.2, sz * 0.3, 0, -sz * 0.2, auraR);
            auraG.addColorStop(0, `hsla(${(t * 30) % 360}, 100%, 90%, 0.22)`);
            auraG.addColorStop(0.6, `hsla(${(t * 30 + 180) % 360}, 100%, 70%, 0.08)`);
            auraG.addColorStop(1, 'rgba(255,220,100,0)');
            ctx.fillStyle = auraG;
            ctx.beginPath();
            ctx.ellipse(0, -sz * 0.2, auraR, auraR * 0.8, 0, 0, Math.PI * 2);
            ctx.fill();

            // ── 袈裟・法衣（赤と金の神官装束）──
            // 下部の衣（スカート状）
            const robeG = ctx.createLinearGradient(0, -sz * 0.1, 0, sz * 0.55);
            robeG.addColorStop(0, '#CC2200');
            robeG.addColorStop(0.5, '#991100');
            robeG.addColorStop(1, '#660000');
            ctx.fillStyle = robeG;
            ctx.beginPath();
            ctx.ellipse(0, sz * 0.25, sz * 0.72, sz * 0.38, 0, 0, Math.PI * 2);
            ctx.fill();
            // 金の装飾帯
            ctx.strokeStyle = '#FFD700';
            ctx.lineWidth = sz * 0.05;
            ctx.beginPath();
            ctx.ellipse(0, sz * 0.05, sz * 0.65, sz * 0.15, 0, 0, Math.PI * 2);
            ctx.stroke();
            // 模様（縦線）
            ctx.strokeStyle = 'rgba(255,215,0,0.35)';
            ctx.lineWidth = 1.5;
            for (let i = -2; i <= 2; i++) {
                ctx.beginPath();
                ctx.moveTo(i * sz * 0.15, sz * 0.1);
                ctx.lineTo(i * sz * 0.18, sz * 0.55);
                ctx.stroke();
            }

            // ── 体（白に近い神聖な玉体）──
            const bodyG = ctx.createRadialGradient(-sz * 0.25, -sz * 0.45, sz * 0.05, 0, -sz * 0.1, sz * 0.82);
            bodyG.addColorStop(0, '#FFFFFF');
            bodyG.addColorStop(0.3, '#FFFCE0');
            bodyG.addColorStop(0.7, color || '#FFD700');
            bodyG.addColorStop(1, darkColor || '#B8860B');
            ctx.fillStyle = bodyG;
            ctx.beginPath();
            ctx.ellipse(0, -sz * 0.18, sz * 0.75, sz * 0.68, 0, 0, Math.PI * 2);
            ctx.fill();
            // 神聖な光の縁取り（虹色）
            ctx.strokeStyle = `hsl(${(t * 40) % 360}, 100%, 70%)`;
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.ellipse(0, -sz * 0.18, sz * 0.75, sz * 0.68, 0, 0, Math.PI * 2);
            ctx.stroke();

            // ── 腕（神の慈悲の手・合掌ポーズ）──
            [-1, 1].forEach(s => {
                // 上腕
                const armG = ctx.createLinearGradient(s * sz * 0.5, -sz * 0.3, s * sz * 0.85, sz * 0.1);
                armG.addColorStop(0, '#CC2200');
                armG.addColorStop(1, '#880000');
                ctx.fillStyle = armG;
                ctx.beginPath();
                ctx.ellipse(s * sz * 0.68, -sz * 0.08, sz * 0.14, sz * 0.26, s * 0.25, 0, Math.PI * 2);
                ctx.fill();
                // 手首の金飾り
                ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.ellipse(s * sz * 0.74, sz * 0.14, sz * 0.11, sz * 0.06, s * 0.1, 0, Math.PI * 2);
                ctx.stroke();
                // 手（白く光る神の手）
                const handG = ctx.createRadialGradient(s * sz * 0.78, sz * 0.22, 0, s * sz * 0.78, sz * 0.22, sz * 0.18);
                handG.addColorStop(0, '#FFFFFF');
                handG.addColorStop(1, '#FFE082');
                ctx.fillStyle = handG;
                ctx.beginPath();
                ctx.arc(s * sz * 0.78, sz * 0.22, sz * 0.15, 0, Math.PI * 2);
                ctx.fill();
                // 手から出る神聖な光
                ctx.fillStyle = `hsla(${(t*60+s*90)%360},100%,80%,0.4)`;
                ctx.beginPath();
                ctx.arc(s * sz * 0.78, sz * 0.22, sz * 0.2 + Math.sin(t*3+s)*sz*0.03, 0, Math.PI * 2);
                ctx.fill();
            });

            // ── 頭の装飾（神冠・宝冠）──
            const crownY = -sz * 0.82 + bounce;
            // 台座（金の帯）
            const crownBandG = ctx.createLinearGradient(-sz*0.5, crownY, sz*0.5, crownY+sz*0.15);
            crownBandG.addColorStop(0, '#B8860B');
            crownBandG.addColorStop(0.5, '#FFD700');
            crownBandG.addColorStop(1, '#B8860B');
            ctx.fillStyle = crownBandG;
            Renderer._roundRect(ctx, -sz * 0.48, crownY, sz * 0.96, sz * 0.18, 5);
            ctx.fill();
            // 装飾（神紋・蓮の花模様）
            ctx.strokeStyle = '#FFF8DC'; ctx.lineWidth = 1;
            for (let i = -2; i <= 2; i++) {
                ctx.beginPath();
                ctx.arc(i * sz * 0.16, crownY + sz * 0.09, sz * 0.06, 0, Math.PI * 2);
                ctx.stroke();
            }
            // 5本のタワー（中央最高・神聖数）
            [[0,1.1,'#FF1744'], [-sz*0.22,0.8,'#29B6F6'], [sz*0.22,0.8,'#29B6F6'],
             [-sz*0.4,0.6,'#AB47BC'], [sz*0.4,0.6,'#AB47BC']].forEach(([tx,h,gc]) => {
                const tH = sz * 0.3 * h;
                const tG = ctx.createLinearGradient(0, crownY-tH, 0, crownY);
                tG.addColorStop(0, '#FFFDE7'); tG.addColorStop(1, '#FFD700');
                ctx.fillStyle = tG;
                ctx.beginPath();
                ctx.moveTo(tx - sz*0.07, crownY);
                ctx.lineTo(tx - sz*0.04, crownY - tH);
                ctx.lineTo(tx, crownY - tH - sz*0.07);
                ctx.lineTo(tx + sz*0.04, crownY - tH);
                ctx.lineTo(tx + sz*0.07, crownY);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#B8860B'; ctx.lineWidth = 1; ctx.stroke();
                // 宝石（点滅）
                const gem = Math.abs(Math.sin(t * 1.5 + tx));
                ctx.fillStyle = gc;
                ctx.globalAlpha = 0.7 + gem * 0.3;
                ctx.beginPath(); ctx.arc(tx, crownY - tH - sz*0.02, sz*0.065, 0, Math.PI*2); ctx.fill();
                ctx.globalAlpha = 1;
            });

            // ── 白髪（神々しい白銀の長髪）──
            ctx.fillStyle = '#F0F0F0';
            // 左右に流れる長髪
            [-1, 1].forEach(s => {
                const hairG = ctx.createLinearGradient(s*sz*0.3, -sz*0.65, s*sz*0.7, sz*0.2);
                hairG.addColorStop(0, '#FFFFFF');
                hairG.addColorStop(1, '#CCCCCC');
                ctx.fillStyle = hairG;
                ctx.beginPath();
                ctx.moveTo(s*sz*0.35, -sz*0.65 + bounce);
                ctx.quadraticCurveTo(s*sz*0.8, -sz*0.1+bounce, s*sz*0.65, sz*0.25+bounce);
                ctx.quadraticCurveTo(s*sz*0.55, sz*0.28+bounce, s*sz*0.42, -sz*0.6+bounce);
                ctx.closePath(); ctx.fill();
            });
            // 前髪
            for (let i = -2; i <= 2; i++) {
                ctx.fillStyle = i===0 ? '#FFFFFF' : '#E8E8E8';
                ctx.beginPath();
                ctx.ellipse(i*sz*0.12, -sz*0.7+bounce, sz*0.08, sz*0.18, i*0.1, 0, Math.PI*2);
                ctx.fill();
            }

            // ── 顔：眉毛（凛々しく）──
            ctx.strokeStyle = '#888'; ctx.lineWidth = 2.5; ctx.lineCap = 'round';
            [-1, 1].forEach(s => {
                ctx.save();
                ctx.translate(s * sz * 0.22, -sz * 0.40 + bounce);
                ctx.rotate(s * -0.2);
                ctx.beginPath();
                ctx.moveTo(-sz * 0.14, 0);
                ctx.lineTo(sz * 0.14, sz * 0.02);
                ctx.stroke();
                ctx.restore();
            });

            // ── 目（神の瞳・金色に輝く）──
            [-1, 1].forEach(s => {
                const ex = s * sz * 0.23;
                const ey = -sz * 0.28 + bounce;
                ctx.fillStyle = '#FFF';
                ctx.beginPath(); ctx.ellipse(ex, ey, sz*0.12, sz*0.09, 0, 0, Math.PI*2); ctx.fill();
                // 金色の瞳
                const eyeG = ctx.createRadialGradient(ex, ey, 0, ex, ey, sz*0.08);
                eyeG.addColorStop(0, '#FFD700');
                eyeG.addColorStop(0.6, '#FF8C00');
                eyeG.addColorStop(1, '#8B4500');
                ctx.fillStyle = eyeG;
                ctx.beginPath(); ctx.ellipse(ex, ey, sz*0.08, sz*0.08, 0, 0, Math.PI*2); ctx.fill();
                // 瞳孔（十字形・神の目）
                ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = 1;
                ctx.beginPath(); ctx.moveTo(ex-sz*0.04, ey); ctx.lineTo(ex+sz*0.04, ey); ctx.stroke();
                ctx.beginPath(); ctx.moveTo(ex, ey-sz*0.04); ctx.lineTo(ex, ey+sz*0.04); ctx.stroke();
                // ハイライト
                ctx.fillStyle = 'rgba(255,255,255,0.9)';
                ctx.beginPath(); ctx.arc(ex-sz*0.02, ey-sz*0.025, sz*0.022, 0, Math.PI*2); ctx.fill();
            });

            // ── 第三の目（額の神眼）──
            const thirdEyeY = -sz * 0.52 + bounce;
            const thirdEyePulse = 0.6 + 0.4 * Math.sin(t * 3);
            ctx.fillStyle = `rgba(255,200,50,${thirdEyePulse * 0.3})`;
            ctx.beginPath(); ctx.arc(0, thirdEyeY, sz * 0.14, 0, Math.PI * 2); ctx.fill();
            // 目本体
            const teG = ctx.createRadialGradient(0, thirdEyeY, 0, 0, thirdEyeY, sz * 0.085);
            teG.addColorStop(0, `hsla(${(t*60)%360},100%,80%,1)`);
            teG.addColorStop(0.5, '#FFD700');
            teG.addColorStop(1, '#FF8C00');
            ctx.fillStyle = teG;
            ctx.beginPath(); ctx.arc(0, thirdEyeY, sz * 0.085, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#FFF'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.arc(0, thirdEyeY, sz * 0.085, 0, Math.PI * 2); ctx.stroke();

            // ── 鼻 ──
            ctx.fillStyle = (darkColor || '#B8860B');
            ctx.beginPath(); ctx.ellipse(0, -sz*0.12+bounce, sz*0.06, sz*0.05, 0, 0, Math.PI*2); ctx.fill();

            // ── 口（穏やかな微笑み）──
            ctx.strokeStyle = '#8B4500'; ctx.lineWidth = 2; ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(-sz * 0.12, sz * 0.02 + bounce);
            ctx.quadraticCurveTo(0, sz * 0.08 + bounce, sz * 0.12, sz * 0.02 + bounce);
            ctx.stroke();

            // ── 白ひげ（神様らしい長い顎ひげ）──
            const beardG = ctx.createLinearGradient(0, sz*0.1, 0, sz*0.6);
            beardG.addColorStop(0, '#FFFFFF');
            beardG.addColorStop(1, 'rgba(220,220,220,0)');
            ctx.fillStyle = beardG;
            ctx.beginPath();
            ctx.moveTo(-sz*0.16, sz*0.1+bounce);
            ctx.quadraticCurveTo(-sz*0.22, sz*0.35+bounce, -sz*0.12, sz*0.6+bounce);
            ctx.quadraticCurveTo(0, sz*0.65+bounce, sz*0.12, sz*0.6+bounce);
            ctx.quadraticCurveTo(sz*0.22, sz*0.35+bounce, sz*0.16, sz*0.1+bounce);
            ctx.quadraticCurveTo(0, sz*0.16+bounce, -sz*0.16, sz*0.1+bounce);
            ctx.fill();
            // ひげの線
            ctx.strokeStyle = 'rgba(200,200,200,0.5)'; ctx.lineWidth = 1;
            [-sz*0.06, 0, sz*0.06].forEach(bx => {
                ctx.beginPath();
                ctx.moveTo(bx, sz*0.15+bounce);
                ctx.quadraticCurveTo(bx*1.2, sz*0.4+bounce, bx*0.8, sz*0.58+bounce);
                ctx.stroke();
            });

            // ── 浮遊する神聖な光粒子 ──
            for (let p = 0; p < 6; p++) {
                const pa = t * 0.8 + p * Math.PI / 3;
                const pr = sz * (0.95 + Math.sin(t + p * 1.2) * 0.15);
                const px2 = Math.cos(pa) * pr;
                const py2 = Math.sin(pa) * pr * 0.6 - sz * 0.2;
                const ps = sz * (0.05 + 0.03 * Math.sin(t * 2 + p));
                ctx.fillStyle = `hsla(${(p*60+t*30)%360},100%,80%,0.8)`;
                ctx.beginPath(); ctx.arc(px2, py2, ps, 0, Math.PI*2); ctx.fill();
            }

        }


        // 7. プレイヤースライムスキン帽子描画
        if (slimeType === 'player') {
            const custom = window.game?.saveData?.tankCustom;
            const pSkinId = custom?.playerSkin || 'pslime_default';
            const pSkins = window.TANK_PARTS?.playerSkins;
            const pSkin = pSkins?.find(s => s.id === pSkinId);
            if (pSkin && pSkin.hat) {
                this._drawPlayerHat(ctx, sz, pSkin, frame, bounce);
            }
        }

        ctx.restore();
    },

    // プレイヤースライムの帽子を描画
    _drawPlayerHat(ctx, sz, skinDef, frame, bounce) {
        const hat = skinDef.hat;
        const topY = -sz * 1.0; // スライム頭頂部のY座標

        ctx.save();
        if (hat === 'wizard') {
            // 🧙 とんがり魔法帽子
            const brimW = sz * 0.55, brimH = sz * 0.1;
            const hatH = sz * 0.75;
            const by2 = topY + bounce * 0.8;
            // 帽子本体（三角）
            ctx.fillStyle = skinDef.hatColor;
            ctx.beginPath();
            ctx.moveTo(0, by2 - hatH);
            ctx.lineTo(-brimW * 0.55, by2);
            ctx.lineTo(brimW * 0.55, by2);
            ctx.closePath();
            ctx.fill();
            ctx.strokeStyle = skinDef.hatBrim;
            ctx.lineWidth = 1.5;
            ctx.stroke();
            // ブリム（つば）
            ctx.fillStyle = skinDef.hatBrim;
            ctx.beginPath();
            ctx.ellipse(0, by2, brimW, brimH, 0, 0, Math.PI * 2);
            ctx.fill();
            // 星
            ctx.fillStyle = skinDef.hatStar;
            this._drawStar(ctx, 0, by2 - hatH * 0.4, 5, sz * 0.1, sz * 0.05);
            ctx.fill();

        } else if (hat === 'knight') {
            // ⚔️ 騎士の兜
            const by2 = topY + bounce * 0.6;
            ctx.fillStyle = skinDef.hatColor;
            // 兜ドーム
            ctx.beginPath();
            ctx.arc(0, by2 + sz * 0.12, sz * 0.42, Math.PI, 0);
            ctx.lineTo(sz * 0.42, by2 + sz * 0.12);
            ctx.lineTo(-sz * 0.42, by2 + sz * 0.12);
            ctx.fill();
            // トサカ
            ctx.fillStyle = skinDef.hatAccent;
            ctx.beginPath();
            ctx.moveTo(-sz * 0.08, by2 - sz * 0.32);
            ctx.quadraticCurveTo(0, by2 - sz * 0.55, sz * 0.08, by2 - sz * 0.32);
            ctx.lineTo(sz * 0.06, by2 + sz * 0.1);
            ctx.lineTo(-sz * 0.06, by2 + sz * 0.1);
            ctx.closePath();
            ctx.fill();
            // 金のライン
            ctx.strokeStyle = skinDef.hatBrim;
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, by2 + sz * 0.12, sz * 0.42, Math.PI, 0);
            ctx.stroke();

        } else if (hat === 'party') {
            // 🎉 パーティーハット
            const by2 = topY + bounce;
            const hatH = sz * 0.7;
            // 本体
            ctx.fillStyle = skinDef.hatColor;
            ctx.beginPath();
            ctx.moveTo(0, by2 - hatH);
            ctx.lineTo(-sz * 0.38, by2);
            ctx.lineTo(sz * 0.38, by2);
            ctx.closePath();
            ctx.fill();
            // ストライプ
            ctx.strokeStyle = skinDef.hatStripe;
            ctx.lineWidth = 3;
            ctx.save();
            ctx.clip();
            for (let i = -2; i <= 2; i++) {
                ctx.beginPath();
                ctx.moveTo(i * sz * 0.2, by2 - hatH);
                ctx.lineTo(i * sz * 0.2 + sz * 0.4, by2);
                ctx.stroke();
            }
            ctx.restore();
            // ポンポン
            ctx.fillStyle = '#FFD700';
            ctx.beginPath();
            ctx.arc(0, by2 - hatH, sz * 0.1, 0, Math.PI * 2);
            ctx.fill();

        } else if (hat === 'chef') {
            // 👨‍🍳 コック帽
            const by2 = topY + bounce * 0.5;
            const hatH = sz * 0.55;
            // 膨らんだ白い帽子
            ctx.fillStyle = skinDef.hatColor;
            ctx.beginPath();
            ctx.ellipse(0, by2 - hatH * 0.6, sz * 0.38, hatH * 0.65, 0, 0, Math.PI * 2);
            ctx.fill();
            // 土台バンド
            ctx.fillStyle = skinDef.hatBrim;
            ctx.fillRect(-sz * 0.38, by2 - sz * 0.08, sz * 0.76, sz * 0.14);
            // ハイライト
            ctx.strokeStyle = 'rgba(255,255,255,0.6)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.ellipse(-sz * 0.1, by2 - hatH * 0.7, sz * 0.15, sz * 0.22, -0.3, 0, Math.PI * 2);
            ctx.stroke();

        } else if (hat === 'crown') {
            // 👑 王冠
            const by2 = topY + bounce * 0.7;
            const crownH = sz * 0.4;
            ctx.fillStyle = skinDef.hatColor;
            ctx.beginPath();
            ctx.moveTo(-sz * 0.38, by2);
            ctx.lineTo(-sz * 0.38, by2 - crownH * 0.5);
            ctx.lineTo(-sz * 0.24, by2 - crownH);
            ctx.lineTo(-sz * 0.12, by2 - crownH * 0.4);
            ctx.lineTo(0, by2 - crownH * 1.1);
            ctx.lineTo(sz * 0.12, by2 - crownH * 0.4);
            ctx.lineTo(sz * 0.24, by2 - crownH);
            ctx.lineTo(sz * 0.38, by2 - crownH * 0.5);
            ctx.lineTo(sz * 0.38, by2);
            ctx.closePath();
            ctx.fill();
            ctx.strokeStyle = skinDef.hatAccent;
            ctx.lineWidth = 1.5;
            ctx.stroke();
            // 宝石
            ctx.fillStyle = skinDef.hatGem;
            ctx.beginPath(); ctx.arc(0, by2 - crownH * 0.9, sz * 0.09, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#FF8A80';
            ctx.beginPath(); ctx.arc(-sz * 0.24, by2 - crownH * 0.8, sz * 0.07, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(sz * 0.24, by2 - crownH * 0.8, sz * 0.07, 0, Math.PI * 2); ctx.fill();

        } else if (hat === 'santa') {
            // 🎅 サンタ帽子
            const by2 = topY + bounce;
            const hatH = sz * 0.65;
            // 本体（赤）
            ctx.fillStyle = skinDef.hatColor;
            ctx.beginPath();
            ctx.moveTo(sz * 0.12, by2 - hatH * 0.1);
            ctx.quadraticCurveTo(sz * 0.35, by2 - hatH * 0.5, sz * 0.08, by2 - hatH);
            ctx.quadraticCurveTo(sz * 0.0, by2 - hatH * 1.15, -sz * 0.05, by2 - hatH);
            ctx.lineTo(-sz * 0.38, by2 - sz * 0.08);
            ctx.lineTo(sz * 0.12, by2 - sz * 0.08);
            ctx.closePath();
            ctx.fill();
            // ブリム（白フワフワ）
            ctx.fillStyle = skinDef.hatBrim;
            ctx.beginPath();
            ctx.ellipse(0, by2 - sz * 0.06, sz * 0.42, sz * 0.12, 0, 0, Math.PI * 2);
            ctx.fill();
            // ポンポン
            ctx.fillStyle = skinDef.hatPom;
            ctx.beginPath();
            ctx.arc(-sz * 0.05 + sz * 0.08, by2 - hatH * 1.05, sz * 0.11, 0, Math.PI * 2);
            ctx.fill();

        } else if (hat === 'halo') {
            // 😇 天使の輪（光る）
            const haloY = topY - sz * 0.1 + bounce * 0.5;
            const haloR = sz * 0.32;
            // 輝き（外側）
            ctx.strokeStyle = 'rgba(255,220,50,0.35)';
            ctx.lineWidth = sz * 0.14;
            ctx.beginPath();
            ctx.arc(0, haloY, haloR, 0, Math.PI * 2);
            ctx.stroke();
            // 本体
            ctx.strokeStyle = skinDef.hatColor;
            ctx.lineWidth = sz * 0.09;
            ctx.beginPath();
            ctx.arc(0, haloY, haloR, 0, Math.PI * 2);
            ctx.stroke();
            // ハイライト
            ctx.strokeStyle = 'rgba(255,255,255,0.8)';
            ctx.lineWidth = sz * 0.03;
            ctx.beginPath();
            ctx.arc(-haloR * 0.3, haloY - haloR * 0.2, haloR * 0.35, Math.PI * 0.8, Math.PI * 1.6);
            ctx.stroke();
        }
        ctx.restore();
    },

    // Helper function for drawing stars
    _drawStar(ctx, cx, cy, spikes, outerRadius, innerRadius) {
        let rot = Math.PI / 2 * 3;
        let x = cx;
        let y = cy;
        const step = Math.PI / spikes;

        ctx.beginPath();
        ctx.moveTo(cx, cy - outerRadius);
        for (let i = 0; i < spikes; i++) {
            x = cx + Math.cos(rot) * outerRadius;
            y = cy + Math.sin(rot) * outerRadius;
            ctx.lineTo(x, y);
            rot += step;

            x = cx + Math.cos(rot) * innerRadius;
            y = cy + Math.sin(rot) * innerRadius;
            ctx.lineTo(x, y);
            rot += step;
        }
        ctx.lineTo(cx, cy - outerRadius);
        ctx.closePath();
        ctx.fill();
    },

    drawAttackSwing(ctx, x, y, w, h, dir, progress) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        ctx.beginPath();
        const startAng = -Math.PI * 0.6;
        const endAng = Math.PI * 0.6;
        const radius = 45;

        const alpha = Math.sin(progress * Math.PI);
        ctx.strokeStyle = `rgba(255, 255, 255, ${alpha * 0.6})`;
        ctx.lineWidth = 8;
        ctx.lineCap = 'round';

        ctx.arc(10, 0, radius, startAng, endAng);
        ctx.stroke();

        // Inner sharp line
        ctx.strokeStyle = `rgba(255, 255, 255, ${alpha * 0.9})`;
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.restore();
    },


    // === Character Aliases (To ensure correct visualization in UI/Gacha) ===
    // --- END RENDERER ---

    // === HELD ITEM ===
    drawHeldItem(ctx, x, y, ammoType) {
        if (!ammoType) return;
        const type = (typeof ammoType === 'object') ? ammoType.type : ammoType;
        const info = CONFIG.AMMO_TYPES[type];
        if (!info) return;

        // Glow behind item
        ctx.fillStyle = info.color;
        ctx.beginPath(); ctx.arc(x, y - 12, 12, 0, Math.PI * 2); ctx.fill();

        // Ammo Name
        const name = info.name; // Assuming 'name' property exists in info
        ctx.font = 'bold 11px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle'; // Set textBaseline here for both name and icon
        ctx.fillStyle = 'rgba(0,0,0,0.8)';
        ctx.fillText(name, x + 1, y - 9); // Shadow
        ctx.fillStyle = '#FFF';
        ctx.fillText(name, x, y - 10);

        ctx.font = '16px Arial'; // Reset font for icon
        ctx.fillStyle = '#FFF'; // Reset fillStyle for icon
        ctx.fillText(info.icon, x, y - 12);

    },

    // === AMMO ITEM ON GROUND (3D glow) ===
    drawAmmoItem(ctx, item) {
        let info = CONFIG.AMMO_TYPES[item.type];
        if (!info) {
            // Fallback for unknown types to prevent crash
            info = { icon: '❓', color: '#FFF' };
        }
        const bob = Math.sin(_getFrameNow() * 0.004 + item.x) * 2;
        const py = item.y + bob;

        // Shadow on ground
        ctx.fillStyle = 'rgba(0,0,0,0.15)';
        ctx.beginPath(); ctx.ellipse(item.x, item.y + 6, 10, 3, 0, 0, Math.PI * 2); ctx.fill();

        // Outer glow (★キャッシュ: item.x/py が変わるたびに作り直すのは高コスト → 固定サイズで1種だけキャッシュ)
        const glow = _getCachedGradient(ctx, 'ammo_glow_18', () => {
            const g = ctx.createRadialGradient(0, 0, 0, 0, 0, 18);
            g.addColorStop(0, 'rgba(255,255,200,0.3)');
            g.addColorStop(1, 'rgba(255,255,200,0)');
            return g;
        });
        ctx.save();
        ctx.translate(item.x, py);
        ctx.fillStyle = glow;
        ctx.beginPath(); ctx.arc(0, 0, 18, 0, Math.PI * 2); ctx.fill();
        ctx.restore();

        // Icon
        ctx.font = '18px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = '#FFF';
        ctx.fillText(info.icon, item.x, py);
    },

    drawTankExterior(ctx, tx, ty, tw, th, isEnemy, dmgFlash, showInterior = true, tankType = 'NORMAL', battle = null) {
        this._drawSlimeTank(ctx, tx, ty, tw, th, isEnemy, dmgFlash, showInterior, tankType, battle);
    },

    // === SLIME TANK (Hyper Detail) ===
    // ========================================================
    // スキン別戦車描画
    // ========================================================
    _drawSkinTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, skinId, battle, isEnemy = false) {
        switch (skinId) {
            case 'skin_ninja':   return this._drawNinjaTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_crab':    return this._drawCrabTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_maou':    return this._drawMaouTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_mecha':   return this._drawMechaTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_ghost':       return this._drawGhostTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_shakkin':     return this._drawShakkinTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle, isEnemy);
            case 'skin_true_maou':   return this._drawTrueMaouTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_legend_titan':return this._drawLegendTitanTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_dragon_knight':return this._drawDragonKnightTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_dragon':  return this._drawDragonTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_seraph':  return this._drawSeraphTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_abyss':   return this._drawAbyssTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_lumen':   return this._drawLumenTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_pirate':  return this._drawPirateTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_steam':   return this._drawSteamTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_samurai': return this._drawSamuraiTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            case 'skin_slime_king': return this._drawSlimeKingBossTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            // ★バグ修正: skin_omega の描画が未実装だった（全クリア報酬なのに見た目が変わらなかった）
            case 'skin_omega':    return this._drawOmegaTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy);
            default: break;
        }
    },

    // ============================================================
    // 👑 スライム王ボス専用戦車（黄金×紫の王者スライム）
    // ============================================================
    // =====================================================
    // 🌌 オメガタンク描画（全ステージクリア報酬・究極フォーム）
    // 宇宙の終焉と始まりをイメージした深宇宙カラー＋Ωマーク
    // =====================================================
    _drawOmegaTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const t = _getFrameNow() * 0.001;
        ctx.save();

        // --- 外装: 深宇宙ベース（濃紺→黒） ---
        const bodyGrad = ctx.createLinearGradient(tx, ty, tx + tw, ty + th);
        bodyGrad.addColorStop(0,   '#0D0221');
        bodyGrad.addColorStop(0.4, '#1A0A3C');
        bodyGrad.addColorStop(1,   '#0A0A1A');
        ctx.fillStyle = bodyGrad;
        ctx.strokeStyle = dmgFlash ? '#FF4444' : '#6A00FF';
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.roundRect(tx, ty, tw, th, 8);
        ctx.fill(); ctx.stroke();

        // --- 星屑パーティクル（内部） ---
        const stars = [[0.15,0.2],[0.7,0.15],[0.4,0.5],[0.85,0.4],[0.25,0.75],[0.6,0.8],[0.9,0.65]];
        stars.forEach(([sx, sy], i) => {
            const pulse = 0.5 + 0.5 * Math.sin(t * 2 + i * 1.2);
            ctx.fillStyle = `rgba(200,180,255,${0.4 + pulse * 0.5})`;
            ctx.beginPath();
            ctx.arc(tx + tw * sx, ty + th * sy, 1.5 + pulse, 0, Math.PI * 2);
            ctx.fill();
        });

        // --- ネビュラグロウ（紫オーラ） ---
        const aura = ctx.createRadialGradient(
            tx + tw * 0.5, ty + th * 0.5, tw * 0.1,
            tx + tw * 0.5, ty + th * 0.5, tw * 0.8
        );
        aura.addColorStop(0,   'rgba(120,0,255,0.18)');
        aura.addColorStop(0.5, 'rgba(60,0,180,0.10)');
        aura.addColorStop(1,   'rgba(0,0,0,0)');
        ctx.fillStyle = aura;
        ctx.beginPath(); ctx.ellipse(tx + tw*0.5, ty + th*0.5, tw*0.9, th*0.9, 0, 0, Math.PI*2);
        ctx.fill();

        // --- 砲塔：Ωシンボル入り ---
        const cx = tx + tw * 0.5, cy = ty + th * 0.38;
        const turretR = Math.min(tw, th) * 0.22;
        // 外枠
        ctx.strokeStyle = dmgFlash ? '#FF4444' : '#9B30FF';
        ctx.lineWidth = 3;
        ctx.fillStyle = '#160030';
        ctx.beginPath(); ctx.arc(cx, cy, turretR, 0, Math.PI * 2);
        ctx.fill(); ctx.stroke();
        // Ωマーク
        ctx.strokeStyle = '#C77DFF';
        ctx.lineWidth = 2.5;
        ctx.lineCap = 'round';
        const or = turretR * 0.55;
        // 上部アーク
        ctx.beginPath();
        ctx.arc(cx, cy - or * 0.1, or, Math.PI * 0.85, Math.PI * 0.15, false);
        ctx.stroke();
        // 左脚
        ctx.beginPath();
        ctx.moveTo(cx - or * Math.cos(Math.PI * 0.85), cy - or * 0.1 + or * Math.sin(Math.PI * 0.85));
        ctx.lineTo(cx - or * 0.7, cy + or * 0.5);
        ctx.lineTo(cx - or * 0.4, cy + or * 0.5);
        ctx.stroke();
        // 右脚
        ctx.beginPath();
        ctx.moveTo(cx + or * Math.cos(Math.PI * 0.85), cy - or * 0.1 + or * Math.sin(Math.PI * 0.85));
        ctx.lineTo(cx + or * 0.7, cy + or * 0.5);
        ctx.lineTo(cx + or * 0.4, cy + or * 0.5);
        ctx.stroke();

        // --- 砲身（エネルギーキャノン） ---
        const barrelLen = tw * 0.45;
        const bx = cx, by2 = ty + th * 0.06;
        ctx.fillStyle = '#2D0060';
        ctx.strokeStyle = '#9B30FF';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.roundRect(bx - 5, by2, 10, barrelLen, 4);
        ctx.fill(); ctx.stroke();
        // 先端グロウ
        const glowPulse = 0.6 + 0.4 * Math.sin(t * 3);
        const barrelGlow = ctx.createRadialGradient(bx, by2, 0, bx, by2, 14);
        barrelGlow.addColorStop(0, `rgba(180,100,255,${glowPulse})`);
        barrelGlow.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = barrelGlow;
        ctx.beginPath(); ctx.arc(bx, by2, 14, 0, Math.PI * 2); ctx.fill();

        // --- 履帯（宇宙合金） ---
        [[tx, ty + th*0.72], [tx + tw*0.6, ty + th*0.72]].forEach(([wx, wy]) => {
            ctx.fillStyle = '#1A0040';
            ctx.strokeStyle = '#6A00FF';
            ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.roundRect(wx, wy, tw * 0.38, th * 0.22, 5);
            ctx.fill(); ctx.stroke();
        });

        // --- ダメージフラッシュ ---
        if (dmgFlash) {
            ctx.fillStyle = 'rgba(255,0,100,0.25)';
            ctx.beginPath(); ctx.roundRect(tx, ty, tw, th, 8); ctx.fill();
        }

        if (showInterior) this._drawInterior(ctx, tx, ty, tw, th);
        ctx.restore();
    },

    _drawSlimeKingBossTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const cx = tx + tw / 2;
        const t  = Date.now() * 0.001;
        const fl = dmgFlash > 0 ? Math.min(1, dmgFlash / 10) : 0;
        const battle  = window.game?.battle;
        const skPhase = battle?.skPhase || 1;
        const skInfil = battle?.skInfiltrating || false;

        // ── フェーズ別カラーテーマ ──────────────────────────────────────
        // Phase1: 黄金×深紫  Phase2: 烈火オレンジ×暗紫  Phase3: 深紅×黒焔
        const theme = fl
            ? { main:'#FFFFFF', dark:'#FFD700', deep:'#FF4444', bg:'#550000', bg2:'#220000' }
            : skPhase >= 3
            ? { main:'#FF3300', dark:'#CC1100', deep:'#FF6600', bg:'#3A0000', bg2:'#1A0000' }
            : skPhase === 2
            ? { main:'#FF8800', dark:'#CC5500', deep:'#FFBB00', bg:'#5A0080', bg2:'#2E0050' }
            : { main:'#FFD700', dark:'#B8960C', deep:'#FFF8DC', bg:'#4A0080', bg2:'#2E0050' };

        ctx.save();
        // 被弾時の横振動
        if (fl > 0) ctx.translate(Math.sin(t * 50) * 6 * fl, Math.cos(t * 37) * 2 * fl);

        // ════════════════════════════════════════════════════════
        // ① 全体オーラ（後光・フェーズで色変化）
        // ════════════════════════════════════════════════════════
        const auraPulse = 0.18 + Math.sin(t * (skPhase >= 3 ? 6 : skPhase === 2 ? 4 : 2.5)) * 0.09;
        const auraR = tw * (skPhase >= 3 ? 1.0 : skPhase === 2 ? 0.85 : 0.72);
        ctx.save();
        ctx.globalAlpha = auraPulse;
        const auraG = ctx.createRadialGradient(cx, ty + th * 0.45, 0, cx, ty + th * 0.45, auraR);
        auraG.addColorStop(0,   theme.main + 'AA');
        auraG.addColorStop(0.5, theme.bg   + '66');
        auraG.addColorStop(1,   'rgba(0,0,0,0)');
        ctx.fillStyle = auraG;
        ctx.fillRect(tx - auraR, ty - auraR * 0.3, auraR * 2 + tw, auraR * 1.8);
        ctx.restore();

        // Phase2/3: 放射光線（王者の威光）
        if (skPhase >= 2) {
            const rayCount = skPhase >= 3 ? 16 : 10;
            const rayAlpha = (0.10 + Math.sin(t * 3) * 0.04) * (skPhase >= 3 ? 1.3 : 1.0);
            ctx.save();
            ctx.globalAlpha = rayAlpha;
            for (let r = 0; r < rayCount; r++) {
                const angle = (r / rayCount) * Math.PI * 2 + t * (skPhase >= 3 ? 0.4 : 0.25);
                const len = tw * 1.6;
                ctx.strokeStyle = r % 2 === 0 ? theme.main : theme.deep;
                ctx.lineWidth = r % 3 === 0 ? 4 : 2;
                ctx.beginPath();
                ctx.moveTo(cx, ty + th * 0.38);
                ctx.lineTo(cx + Math.cos(angle) * len, ty + th * 0.38 + Math.sin(angle) * len);
                ctx.stroke();
            }
            ctx.restore();
        }

        // ════════════════════════════════════════════════════════
        // ② キャタピラ（巨大・王紋彫刻・回転ホイール）
        // ════════════════════════════════════════════════════════
        const treadH = Math.round(th * 0.22);
        const treadW = tw * 0.96;
        const treadX = cx - treadW / 2;
        const treadY = ty + th - treadH;
        // キャタピラ本体
        const treadG = ctx.createLinearGradient(treadX, treadY, treadX, treadY + treadH);
        treadG.addColorStop(0,   theme.bg);
        treadG.addColorStop(0.5, theme.bg2);
        treadG.addColorStop(1,   '#050008');
        ctx.fillStyle = treadG;
        ctx.beginPath();
        ctx.moveTo(treadX - 14, treadY + 8);
        ctx.lineTo(treadX + treadW + 14, treadY + 8);
        ctx.lineTo(treadX + treadW + 20, treadY + treadH);
        ctx.lineTo(treadX - 20, treadY + treadH);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = theme.main; ctx.lineWidth = 3.5; ctx.stroke();
        // セグメント線
        ctx.strokeStyle = theme.main + '55'; ctx.lineWidth = 1.5;
        for (let seg = 1; seg < 8; seg++) {
            const segX = treadX + (treadW / 8) * seg;
            ctx.beginPath(); ctx.moveTo(segX, treadY + 6); ctx.lineTo(segX, treadY + treadH); ctx.stroke();
        }
        // キャタピラスタッド（小釘）
        ctx.fillStyle = theme.dark;
        for (let s = 0; s < 9; s++) {
            const sx = treadX + 10 + (treadW - 20) / 8 * s;
            ctx.beginPath(); ctx.arc(sx, treadY + treadH * 0.28, 3, 0, Math.PI * 2); ctx.fill();
        }
        // 駆動輪（7個・三重リング＋スポーク）
        const wheelCount = 7;
        for (let i = 0; i < wheelCount; i++) {
            const wx = treadX + 16 + i * ((treadW - 32) / (wheelCount - 1));
            const wy = treadY + treadH * 0.52;
            const wr = Math.round(treadH * 0.52);
            // 外輪
            const wG = ctx.createRadialGradient(wx - wr * 0.2, wy - wr * 0.2, 0, wx, wy, wr);
            wG.addColorStop(0, theme.bg);
            wG.addColorStop(0.65, theme.bg2);
            wG.addColorStop(1, '#050008');
            ctx.fillStyle = wG;
            ctx.beginPath(); ctx.arc(wx, wy, wr, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = theme.main; ctx.lineWidth = 2.5;
            ctx.beginPath(); ctx.arc(wx, wy, wr, 0, Math.PI * 2); ctx.stroke();
            // 中輪
            ctx.strokeStyle = theme.dark + 'AA'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.arc(wx, wy, wr * 0.65, 0, Math.PI * 2); ctx.stroke();
            // スポーク（6本・回転アニメ）
            ctx.strokeStyle = theme.main; ctx.lineWidth = 2;
            for (let sp = 0; sp < 6; sp++) {
                const sa = (sp / 6) * Math.PI * 2 + t * (skPhase >= 3 ? 1.2 : skPhase === 2 ? 0.8 : 0.5);
                ctx.beginPath();
                ctx.moveTo(wx + Math.cos(sa) * wr * 0.25, wy + Math.sin(sa) * wr * 0.25);
                ctx.lineTo(wx + Math.cos(sa) * (wr - 3),  wy + Math.sin(sa) * (wr - 3));
                ctx.stroke();
            }
            // 中心ハブ（宝石風）
            const hubG = ctx.createRadialGradient(wx - 2, wy - 2, 0, wx, wy, wr * 0.22);
            hubG.addColorStop(0, theme.deep);
            hubG.addColorStop(1, theme.dark);
            ctx.fillStyle = hubG;
            ctx.beginPath(); ctx.arc(wx, wy, wr * 0.22, 0, Math.PI * 2); ctx.fill();
        }

        // ════════════════════════════════════════════════════════
        // ③ メインボディ（スライム型装甲・三重シールド外装）
        // ════════════════════════════════════════════════════════
        const bodyH = Math.round(th * 0.44);
        const bodyW = tw * 0.92;
        const bodyY = treadY - bodyH + 12;
        const bodyX = cx - bodyW / 2;

        // 地面影
        ctx.fillStyle = 'rgba(0,0,0,0.4)';
        ctx.beginPath();
        ctx.ellipse(cx + 10, treadY + treadH - 4, bodyW * 0.5, 12, 0, 0, Math.PI * 2);
        ctx.fill();

        // 外側シールド光輪（Phase2以上）
        if (skPhase >= 2) {
            const shieldPulse = 0.25 + Math.sin(t * (skPhase >= 3 ? 8 : 5)) * 0.12;
            ctx.save();
            ctx.globalAlpha = shieldPulse;
            ctx.strokeStyle = theme.main;
            ctx.lineWidth = 6;
            ctx.beginPath();
            this._roundRect(ctx, bodyX - 8, bodyY - 6, bodyW + 16, bodyH + 12, 26);
            ctx.stroke();
            ctx.lineWidth = 2;
            ctx.globalAlpha = shieldPulse * 0.5;
            ctx.beginPath();
            this._roundRect(ctx, bodyX - 16, bodyY - 12, bodyW + 32, bodyH + 24, 32);
            ctx.stroke();
            ctx.restore();
        }

        // ボディ本体（スライム型ラジアルグラデ）
        const coreColor  = fl ? '#FFFFFF'
            : skPhase >= 3 ? '#AA2200'
            : skPhase === 2 ? '#7700BB'
            : '#5500AA';
        const bodyG = ctx.createRadialGradient(
            cx - bodyW * 0.18, bodyY + bodyH * 0.3, bodyH * 0.04,
            cx,                bodyY + bodyH * 0.5, bodyH * 0.82
        );
        bodyG.addColorStop(0,   fl ? '#FFFFFF' : (skPhase >= 3 ? '#FF5500' : skPhase === 2 ? '#9900CC' : '#7700CC'));
        bodyG.addColorStop(0.45, coreColor);
        bodyG.addColorStop(0.82, theme.bg);
        bodyG.addColorStop(1,    theme.bg2);
        ctx.fillStyle = bodyG;
        ctx.beginPath();
        this._roundRect(ctx, bodyX, bodyY, bodyW, bodyH, 20);
        ctx.fill();
        // 装甲縁取り（二重）
        ctx.strokeStyle = theme.main; ctx.lineWidth = 4; ctx.stroke();
        ctx.strokeStyle = theme.deep + '77'; ctx.lineWidth = 1.5;
        ctx.beginPath();
        this._roundRect(ctx, bodyX + 4, bodyY + 4, bodyW - 8, bodyH - 8, 16);
        ctx.stroke();

        // 装甲パネル（縦区切り線）
        ctx.strokeStyle = theme.main + '44'; ctx.lineWidth = 1;
        for (let p = 1; p < 4; p++) {
            const px = bodyX + bodyW * (p / 4);
            ctx.beginPath();
            ctx.moveTo(px, bodyY + 8); ctx.lineTo(px, bodyY + bodyH - 8); ctx.stroke();
        }

        // 王紋エンブレム（ボディ中央）
        ctx.save();
        ctx.globalAlpha = fl ? 0.9 : 0.5 + Math.sin(t * 2) * 0.1;
        ctx.font = `bold ${Math.round(bodyH * 0.55)}px serif`;
        ctx.textAlign = 'center';
        ctx.fillStyle = fl ? '#FF4444' : theme.main + 'CC';
        ctx.fillText('♛', cx, bodyY + bodyH * 0.68);
        ctx.restore();

        // 金色スライムドリップ（ボディ下部からキャタピラへ）
        const dripCount = skPhase >= 3 ? 8 : 6;
        for (let d = 0; d < dripCount; d++) {
            const dx    = bodyX + bodyW * ((d + 0.5) / dripCount);
            const dBase = bodyY + bodyH - 2;
            const dLen  = (12 + Math.sin(t * 2.2 + d * 1.3) * 8) * (skPhase >= 3 ? 1.5 : 1);
            const dripG = ctx.createLinearGradient(dx, dBase, dx, dBase + dLen);
            dripG.addColorStop(0, theme.main + 'DD');
            dripG.addColorStop(1, theme.main + '00');
            ctx.fillStyle = dripG;
            ctx.beginPath();
            ctx.ellipse(dx, dBase + dLen * 0.5, 4.5, dLen * 0.5 + 3, 0, 0, Math.PI * 2);
            ctx.fill();
            // 滴の先端
            ctx.fillStyle = theme.main + 'BB';
            ctx.beginPath(); ctx.arc(dx, dBase + dLen, 4, 0, Math.PI * 2); ctx.fill();
        }

        // Phase3: 装甲亀裂（赤熱した亀裂が走る）
        if (skPhase >= 3) {
            ctx.save();
            const crackAlpha = 0.55 + Math.sin(t * 9) * 0.35;
            ctx.strokeStyle = '#FF4400'; ctx.lineWidth = 2.5;
            ctx.globalAlpha = crackAlpha;
            const cracks = [
                [bodyX + bodyW*0.15, bodyY + bodyH*0.15, bodyX + bodyW*0.35, bodyY + bodyH*0.7],
                [bodyX + bodyW*0.55, bodyY + bodyH*0.05, bodyX + bodyW*0.72, bodyY + bodyH*0.55],
                [cx - 12, bodyY + 5, cx + 18, bodyY + bodyH*0.45],
                [bodyX + bodyW*0.78, bodyY + bodyH*0.3, bodyX + bodyW*0.95, bodyY + bodyH*0.8],
            ];
            cracks.forEach(([x1,y1,x2,y2]) => {
                const mx = (x1+x2)/2 + (Math.random()-0.5)*12;
                const my = (y1+y2)/2 + (Math.random()-0.5)*12;
                ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(mx,my); ctx.lineTo(x2,y2); ctx.stroke();
                // 亀裂グロー
                ctx.strokeStyle = '#FF8800'; ctx.lineWidth = 1; ctx.globalAlpha = crackAlpha * 0.5;
                ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(mx,my); ctx.lineTo(x2,y2); ctx.stroke();
                ctx.strokeStyle = '#FF4400'; ctx.lineWidth = 2.5; ctx.globalAlpha = crackAlpha;
            });
            // 亀裂から漏れる炎の粒
            ctx.globalAlpha = 0.4 + Math.sin(t * 7) * 0.3;
            ctx.fillStyle = '#FF6600';
            cracks.forEach(([x1,y1,x2,y2]) => {
                const fx = (x1+x2)/2; const fy = (y1+y2)/2;
                ctx.beginPath(); ctx.arc(fx, fy - Math.sin(t*5)*4, 4, 0, Math.PI*2); ctx.fill();
            });
            ctx.restore();
        }

        // ════════════════════════════════════════════════════════
        // ④ 砲塔（重厚型・ダブルリング装甲）
        // ════════════════════════════════════════════════════════
        const turretW  = Math.round(tw * 0.46);
        const turretH  = Math.round(th * 0.24);
        const turretX  = cx - turretW / 2;
        const turretY  = bodyY - turretH + 10;

        // 砲塔外装シールド（楕円）
        ctx.save();
        ctx.globalAlpha = 0.3 + Math.sin(t * 3) * 0.1;
        const tShG = ctx.createRadialGradient(cx, turretY + turretH*0.5, 0, cx, turretY + turretH*0.5, turretW*0.75);
        tShG.addColorStop(0, theme.main + 'AA');
        tShG.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = tShG;
        ctx.fillRect(turretX - turretW*0.2, turretY - turretH*0.1, turretW*1.4, turretH*1.2);
        ctx.restore();

        // 砲塔本体
        const turretG = ctx.createLinearGradient(turretX, turretY, turretX, turretY + turretH);
        turretG.addColorStop(0, theme.main);
        turretG.addColorStop(0.45, theme.dark);
        turretG.addColorStop(1, '#6A4800');
        ctx.fillStyle = turretG;
        ctx.beginPath();
        this._roundRect(ctx, turretX, turretY, turretW, turretH, 12);
        ctx.fill();
        ctx.strokeStyle = fl ? '#FF8888' : theme.bg; ctx.lineWidth = 3; ctx.stroke();
        // 内側二重縁
        ctx.strokeStyle = theme.deep + '88'; ctx.lineWidth = 1.5;
        ctx.beginPath();
        this._roundRect(ctx, turretX + 5, turretY + 4, turretW - 10, turretH - 8, 8);
        ctx.stroke();

        // 砲塔上のリベット（左右）
        [[turretX + 10, turretY + turretH*0.5], [turretX + turretW - 10, turretY + turretH*0.5]].forEach(([rx,ry]) => {
            ctx.fillStyle = theme.dark; ctx.beginPath(); ctx.arc(rx, ry, 5, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = theme.main; ctx.lineWidth = 1.5; ctx.stroke();
        });

        // ════════════════════════════════════════════════════════
        // ⑤ 砲身（Phase別：P1=シングル P2=ダブル P3=トリプル）
        // ════════════════════════════════════════════════════════
        const dir = isEnemy ? -1 : 1;
        const barrelBaseX = isEnemy ? turretX : turretX + turretW;
        const barrelCY    = turretY + turretH * 0.5;

        const drawBarrel = (offsetY, len, thick, alpha = 1) => {
            const bx  = isEnemy ? barrelBaseX - len : barrelBaseX;
            const bEndX = isEnemy ? barrelBaseX - len : barrelBaseX + len;
            ctx.save();
            ctx.globalAlpha = alpha;
            const bG = ctx.createLinearGradient(bx, barrelCY, bEndX, barrelCY);
            bG.addColorStop(0,   theme.main);
            bG.addColorStop(0.65, theme.dark);
            bG.addColorStop(1,   '#3A2800');
            ctx.fillStyle = bG;
            ctx.beginPath();
            this._roundRect(ctx, bx, barrelCY + offsetY - thick/2, len, thick, Math.round(thick/3));
            ctx.fill();
            ctx.strokeStyle = theme.bg2; ctx.lineWidth = 1.5; ctx.stroke();
            // 砲身リング（装飾リング2本）
            ctx.strokeStyle = theme.deep + 'AA'; ctx.lineWidth = 2;
            [0.3, 0.65].forEach(rp => {
                const rx = isEnemy ? bx + len*(1-rp) : bx + len*rp;
                ctx.beginPath(); ctx.moveTo(rx, barrelCY + offsetY - thick/2 - 2); ctx.lineTo(rx, barrelCY + offsetY + thick/2 + 2); ctx.stroke();
            });
            // 砲口（グロー）
            const muzzleG = ctx.createRadialGradient(bEndX, barrelCY + offsetY, 0, bEndX, barrelCY + offsetY, thick * 1.1);
            muzzleG.addColorStop(0, theme.deep);
            muzzleG.addColorStop(0.5, theme.main + 'AA');
            muzzleG.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = muzzleG;
            ctx.beginPath(); ctx.arc(bEndX, barrelCY + offsetY, thick * 1.1, 0, Math.PI*2); ctx.fill();
            // 砲口キャップ
            ctx.fillStyle = theme.dark;
            ctx.beginPath(); ctx.arc(bEndX, barrelCY + offsetY, thick * 0.55, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = theme.main; ctx.lineWidth = 2; ctx.stroke();
            ctx.restore();
        };

        const barrelLen1 = Math.round(tw * 0.52);
        if (skPhase === 1) {
            drawBarrel(0, barrelLen1, 18);
        } else if (skPhase === 2) {
            drawBarrel(-11, barrelLen1, 14, 0.9);
            drawBarrel( 11, barrelLen1, 14, 0.9);
        } else {
            // Phase3: トリプル砲身（中央が最大）
            drawBarrel(-14, barrelLen1 * 1.08, 13, 0.85);
            drawBarrel(  0, barrelLen1 * 1.15, 18);           // 中央・最長
            drawBarrel( 14, barrelLen1 * 1.08, 13, 0.85);
        }

        // ════════════════════════════════════════════════════════
        // ⑥ 王冠（大型・フェーズで形状変化）
        // ════════════════════════════════════════════════════════
        const crownBaseY = turretY + 4;
        const crownH     = Math.round(th * 0.21);
        const crownW     = turretW * (skPhase >= 3 ? 0.94 : skPhase === 2 ? 0.88 : 0.80);
        const crownX     = cx - crownW / 2;

        // 王冠グロー（後光）
        ctx.save();
        ctx.globalAlpha = 0.28 + Math.sin(t * (skPhase >= 3 ? 7 : 3)) * 0.12;
        const crownGlowR = crownW * 0.75;
        const cgG = ctx.createRadialGradient(cx, crownBaseY - crownH*0.3, 0, cx, crownBaseY - crownH*0.3, crownGlowR);
        cgG.addColorStop(0, theme.main + 'FF');
        cgG.addColorStop(0.4, theme.main + '55');
        cgG.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = cgG;
        ctx.fillRect(cx - crownGlowR, crownBaseY - crownH*1.2, crownGlowR*2, crownGlowR*1.5);
        ctx.restore();

        // 王冠本体（フェーズで山の数が増える）
        const toothCount = skPhase >= 3 ? 7 : skPhase === 2 ? 6 : 5;
        const crownG2 = ctx.createLinearGradient(crownX, crownBaseY - crownH, crownX, crownBaseY);
        crownG2.addColorStop(0,   theme.main);
        crownG2.addColorStop(0.35, theme.dark);
        crownG2.addColorStop(1,   '#7A5800');
        ctx.fillStyle = crownG2;
        ctx.beginPath();
        ctx.moveTo(crownX, crownBaseY);
        ctx.lineTo(crownX, crownBaseY - crownH * 0.42);
        for (let tooth = 0; tooth < toothCount; tooth++) {
            const prog = tooth / (toothCount - 1);
            // 谷
            const vx = crownX + crownW * prog;
            const vy = crownBaseY - crownH * 0.42;
            // 山頂（中央が最高）
            const peakRatio = 1 - Math.abs(prog - 0.5) * 1.6;
            const peakH = crownH * (0.55 + Math.max(0, peakRatio) * 0.45);
            const px = crownX + crownW * (prog + 0.5 / (toothCount - 1));
            const py = crownBaseY - peakH;
            if (tooth === 0) { ctx.lineTo(vx, vy); }
            if (tooth < toothCount - 1) {
                ctx.lineTo((vx + px) / 2, vy);
                ctx.lineTo(px, py);
                ctx.lineTo((px + crownX + crownW * ((tooth+1) / (toothCount-1))) / 2, vy);
            }
        }
        ctx.lineTo(crownX + crownW, crownBaseY - crownH * 0.42);
        ctx.lineTo(crownX + crownW, crownBaseY);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = fl ? '#FF4444' : theme.bg2; ctx.lineWidth = 2.5; ctx.stroke();

        // 王冠の宝石（フェーズで数と色が変化）
        const gemDefs = skPhase >= 3
            ? [
                { rx: 0.12, ry: 0.58, r: 5.5, c: '#FF0000', glow: '#FF4400' },
                { rx: 0.30, ry: 0.40, r: 5,   c: '#FF6600', glow: '#FFAA00' },
                { rx: 0.50, ry: 0.28, r: 8,   c: '#FF2200', glow: '#FF0000' }, // 中央最大
                { rx: 0.70, ry: 0.40, r: 5,   c: '#FF6600', glow: '#FFAA00' },
                { rx: 0.88, ry: 0.58, r: 5.5, c: '#FF0000', glow: '#FF4400' },
              ]
            : skPhase === 2
            ? [
                { rx: 0.16, ry: 0.60, r: 5,   c: '#E040FB', glow: '#AA00FF' },
                { rx: 0.42, ry: 0.38, r: 6.5, c: '#FF8800', glow: '#FFD700' },
                { rx: 0.58, ry: 0.38, r: 6.5, c: '#FF8800', glow: '#FFD700' },
                { rx: 0.84, ry: 0.60, r: 5,   c: '#00B0FF', glow: '#0080FF' },
              ]
            : [
                { rx: 0.16, ry: 0.62, r: 5,   c: '#E040FB', glow: '#AA00FF' },
                { rx: 0.50, ry: 0.32, r: 8,   c: '#FF1744', glow: '#FF0000' }, // 中央大
                { rx: 0.84, ry: 0.62, r: 5,   c: '#00B0FF', glow: '#0080FF' },
              ];

        gemDefs.forEach((g, gi) => {
            const gx = crownX + crownW * g.rx;
            const gy = crownBaseY - crownH * g.ry;
            const pulse = 0.7 + Math.sin(t * (3 + gi * 0.7)) * 0.3;
            // グロー
            ctx.save();
            ctx.globalAlpha = pulse * 0.5;
            const gGlow = ctx.createRadialGradient(gx, gy, 0, gx, gy, g.r * 2.4);
            gGlow.addColorStop(0, g.glow + 'FF');
            gGlow.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = gGlow;
            ctx.beginPath(); ctx.arc(gx, gy, g.r * 2.4, 0, Math.PI*2); ctx.fill();
            ctx.restore();
            // 宝石本体
            const gemG = ctx.createRadialGradient(gx - g.r*0.3, gy - g.r*0.3, 0, gx, gy, g.r);
            gemG.addColorStop(0, '#FFFFFF');
            gemG.addColorStop(0.3, g.c);
            gemG.addColorStop(1, g.glow);
            ctx.fillStyle = gemG;
            ctx.beginPath(); ctx.arc(gx, gy, g.r, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 1.2;
            ctx.beginPath(); ctx.arc(gx, gy, g.r, 0, Math.PI*2); ctx.stroke();
            // ハイライト
            ctx.fillStyle = 'rgba(255,255,255,0.8)';
            ctx.beginPath(); ctx.arc(gx - g.r*0.28, gy - g.r*0.28, g.r*0.32, 0, Math.PI*2); ctx.fill();
        });

        // ════════════════════════════════════════════════════════
        // ⑦ 眼（スライム王の顔・フェーズで表情変化）
        // ════════════════════════════════════════════════════════
        const eyeY    = bodyY + bodyH * 0.32;
        const eyeSpan = bodyW * 0.28;
        const eyeR    = Math.round(th * 0.060);

        [-1, 1].forEach(side => {
            const ex = cx + side * eyeSpan;
            // 眼窩（黒い凹み）
            ctx.fillStyle = '#080010';
            ctx.beginPath(); ctx.ellipse(ex, eyeY, eyeR * 1.3, eyeR * 1.1, 0, 0, Math.PI*2); ctx.fill();
            // 虹彩（フェーズ別カラー）
            const irisColor  = fl ? '#FFFFFF'
                : skPhase >= 3 ? '#FF2200'
                : skPhase === 2 ? '#FF8800'
                : '#FFD700';
            const eyeGlow = ctx.createRadialGradient(ex, eyeY, 0, ex, eyeY, eyeR);
            eyeGlow.addColorStop(0, fl ? '#FFAAAA' : (skPhase >= 3 ? '#FF6600' : skPhase === 2 ? '#FFBB44' : '#FFFFAA'));
            eyeGlow.addColorStop(0.5, irisColor);
            eyeGlow.addColorStop(1, theme.bg2);
            ctx.fillStyle = eyeGlow;
            ctx.beginPath(); ctx.ellipse(ex, eyeY, eyeR, eyeR * 0.85, 0, 0, Math.PI*2); ctx.fill();
            // 瞳孔（縦スリット）
            ctx.fillStyle = '#000008';
            ctx.beginPath(); ctx.ellipse(ex, eyeY, eyeR * 0.2, eyeR * 0.65, 0, 0, Math.PI*2); ctx.fill();
            // 眼の輝き
            ctx.fillStyle = 'rgba(255,255,255,0.85)';
            ctx.beginPath(); ctx.arc(ex - eyeR*0.22, eyeY - eyeR*0.2, eyeR*0.25, 0, Math.PI*2); ctx.fill();
            // Phase2/3: 眼のオーラ（怒りの赤炎）
            if (skPhase >= 2) {
                const eyePulse = 0.5 + Math.sin(t * (skPhase >= 3 ? 10 : 6) + side * 1.2) * 0.4;
                ctx.save();
                ctx.globalAlpha = eyePulse * 0.65;
                const eOG = ctx.createRadialGradient(ex, eyeY, 0, ex, eyeY, eyeR * 2.5);
                eOG.addColorStop(0, irisColor + 'CC');
                eOG.addColorStop(1, 'rgba(0,0,0,0)');
                ctx.fillStyle = eOG;
                ctx.beginPath(); ctx.arc(ex, eyeY, eyeR * 2.5, 0, Math.PI*2); ctx.fill();
                ctx.restore();
            }
        });

        // ════════════════════════════════════════════════════════
        // ⑧ エネルギーオーブ（フェーズ別浮遊装飾）
        // ════════════════════════════════════════════════════════
        const orbCount = skPhase >= 3 ? 6 : skPhase === 2 ? 4 : 3;
        const orbRadius = tw * (skPhase >= 3 ? 0.62 : skPhase === 2 ? 0.55 : 0.48);
        const orbCY     = bodyY + bodyH * 0.4;
        const orbSpeed  = skPhase >= 3 ? 1.5 : skPhase === 2 ? 1.0 : 0.6;
        for (let o = 0; o < orbCount; o++) {
            const angle  = (o / orbCount) * Math.PI * 2 + t * orbSpeed;
            const ox     = cx + Math.cos(angle) * orbRadius;
            const oy     = orbCY + Math.sin(angle) * orbRadius * 0.35;
            const orbR   = 7 + Math.sin(t * 3 + o * 1.1) * 2.5;
            const orbHue = skPhase >= 3 ? (o%2===0?'#FF2200':'#FF8800') : skPhase===2 ? (o%2===0?'#FF8800':'#CC00FF') : (o%3===0?'#FFD700':o%3===1?'#FF69B4':'#00B0FF');
            ctx.save();
            ctx.globalAlpha = 0.85;
            const oG = ctx.createRadialGradient(ox - orbR*0.2, oy - orbR*0.2, 0, ox, oy, orbR);
            oG.addColorStop(0, '#FFFFFF');
            oG.addColorStop(0.4, orbHue);
            oG.addColorStop(1, theme.bg2);
            ctx.fillStyle = oG;
            ctx.beginPath(); ctx.arc(ox, oy, orbR, 0, Math.PI*2); ctx.fill();
            // オーブグロー
            ctx.globalAlpha = 0.3 + Math.sin(t * 4 + o) * 0.15;
            const ogG = ctx.createRadialGradient(ox, oy, 0, ox, oy, orbR * 2.2);
            ogG.addColorStop(0, orbHue + 'BB');
            ogG.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = ogG;
            ctx.beginPath(); ctx.arc(ox, oy, orbR * 2.2, 0, Math.PI*2); ctx.fill();
            ctx.restore();
        }

        // ════════════════════════════════════════════════════════
        // ⑨ Phase3専用：爆炎エフェクト（装甲から吹き出す炎）
        // ════════════════════════════════════════════════════════
        if (skPhase >= 3) {
            const flameCount = 5;
            for (let f2 = 0; f2 < flameCount; f2++) {
                const fx  = bodyX + bodyW * ((f2 + 0.5) / flameCount);
                const fBaseY = bodyY - 4;
                const fh  = (22 + Math.sin(t * 8 + f2 * 1.7) * 14);
                const fw  = 8 + Math.sin(t * 5 + f2) * 3;
                ctx.save();
                ctx.globalAlpha = 0.65 + Math.sin(t * 6 + f2) * 0.25;
                const flG = ctx.createLinearGradient(fx, fBaseY, fx, fBaseY - fh);
                flG.addColorStop(0,   '#FF6600FF');
                flG.addColorStop(0.4, '#FF2200AA');
                flG.addColorStop(1,   '#FF000000');
                ctx.fillStyle = flG;
                ctx.beginPath();
                ctx.ellipse(fx, fBaseY - fh * 0.5, fw, fh * 0.5, Math.sin(t + f2) * 0.3, 0, Math.PI*2);
                ctx.fill();
                ctx.restore();
            }
        }

        ctx.restore();
    },

    // ============================================================
    // 👑 潜り込みオーバーレイ（プレイヤー戦車がスライム王に侵食される）
    // ============================================================
    _drawInfiltrationOverlay(ctx, tx, ty, tw, th, battle) {
        const t = Date.now() * 0.002;
        const progress = battle.skInfilDuration > 0
            ? 1 - (battle.skInfilDuration / (battle.skPhase === 3 ? 360 : 480))
            : 1;
        ctx.save();
        // 金色スライムの侵食（端から中央へじわじわ）
        const alpha = 0.15 + Math.sin(t * 3) * 0.1;
        ctx.globalAlpha = alpha;
        const infG = ctx.createRadialGradient(tx + tw * 0.5, ty + th * 0.5, 0, tx + tw * 0.5, ty + th * 0.5, tw * 0.7);
        infG.addColorStop(0, 'transparent');
        infG.addColorStop(0.6 - progress * 0.3, 'transparent');
        infG.addColorStop(1, '#FFD700');
        ctx.fillStyle = infG;
        ctx.fillRect(tx, ty, tw, th);

        // スライム垂れエフェクト（上から）
        ctx.globalAlpha = 0.5 * (0.5 + Math.sin(t * 2) * 0.2);
        ctx.fillStyle = '#FFD700';
        for (let i = 0; i < 4; i++) {
            const dx = tx + tw * (0.15 + i * 0.23);
            const dLen = (8 + Math.sin(t * 3 + i) * 6) * (1 + progress);
            ctx.beginPath();
            ctx.ellipse(dx, ty + dLen * 0.5, 3.5, dLen * 0.5, 0, 0, Math.PI * 2);
            ctx.fill();
        }
        // 警告テキスト（点滅）
        if (Math.sin(t * 5) > 0) {
            ctx.globalAlpha = 0.85;
            ctx.font = `bold ${Math.round(tw * 0.11)}px sans-serif`;
            ctx.textAlign = 'center';
            ctx.fillStyle = '#FF8C00';
            ctx.fillText('👑 侵食中…', tx + tw / 2, ty + th * 0.42);
        }
        ctx.globalAlpha = 1.0;
        ctx.restore();
    },

    // 🗡️ 竜騎士スキン（第2章ボス用: 赤と銀の竜騎士装甲）
    _drawDragonKnightTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        const t = Date.now() * 0.001;

        ctx.save();
        ctx.translate(cx, ty + th);
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(Date.now() * 0.05) * 3, 0); }
        ctx.translate(-cx, -(ty + th));

        const treadH = 46, treadW = tw * 0.84;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;

        // ── キャタピラ（銀黒）──
        const tG = ctx.createLinearGradient(0, treadY, 0, treadY + treadH);
        tG.addColorStop(0, '#2A2A35'); tG.addColorStop(0.4, '#4A4A55'); tG.addColorStop(1, '#0D0D15');
        ctx.fillStyle = tG;
        this._roundRect(ctx, treadX, treadY, treadW, treadH, 10); ctx.fill();
        ctx.strokeStyle = '#B71C1C'; ctx.lineWidth = 2; ctx.stroke();
        for (let i = 0; i < 4; i++) {
            const wx = treadX + 22 + i * ((treadW - 44) / 3), wY = treadY + treadH * 0.55;
            const wG = ctx.createRadialGradient(wx, wY, 0, wx, wY, 14);
            wG.addColorStop(0, '#B71C1C'); wG.addColorStop(0.5, '#4A1C1C'); wG.addColorStop(1, '#2A1515');
            ctx.fillStyle = wG; ctx.beginPath(); ctx.arc(wx, wY, 13, 0, Math.PI * 2); ctx.fill();
        }

        // ── ドーム本体（赤銀・竜頭型）──
        const dRX = tw * 0.52, dRY = th * 0.48;
        const dCX = cx, dCY = treadY - dRY * 0.88;

        const domeG = ctx.createRadialGradient(dCX - dRX * 0.28, dCY - dRY * 0.28, dRX * 0.05, dCX, dCY, dRX * 1.1);
        domeG.addColorStop(0, '#F44336'); domeG.addColorStop(0.45, '#B71C1C'); domeG.addColorStop(1, '#4A0000');
        ctx.beginPath(); ctx.ellipse(dCX + 6, dCY + 6, dRX, dRY, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0,0,0,0.2)'; ctx.fill();
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI * 2);
        ctx.fillStyle = domeG; ctx.fill();
        ctx.strokeStyle = '#FFCDD2'; ctx.lineWidth = 2.5; ctx.stroke();

        if (!showInterior) {
            // ── メカ竜翼（銀）──
            const wBaseY = dCY - dRY * 0.08, wTipY = dCY - dRY * 0.65;
            const wingSwing = Math.sin(t * 2.5) * 5;
            [-1, 1].forEach(s => {
                ctx.fillStyle = '#CFD8DC';
                ctx.beginPath();
                ctx.moveTo(dCX + s * (dRX - 4), wBaseY + 12);
                ctx.lineTo(dCX + s * (dRX + 20), wTipY + 10 + wingSwing * s);
                ctx.lineTo(dCX + s * (dRX + 32), wTipY - 4 + wingSwing * s);
                ctx.lineTo(dCX + s * (dRX + 16), wBaseY - 22);
                ctx.lineTo(dCX + s * (dRX - 4), wBaseY - 14);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#546E7A'; ctx.lineWidth = 1.5; ctx.stroke();
            });

            // ── 騎士城塔（銀）──
            const tW = 80, tH = 80;
            const tX = dCX - tW / 2, tY = dCY - dRY * 0.5 - tH;
            ctx.fillStyle = '#90A4AE';
            ctx.fillRect(tX, tY, tW, tH); ctx.strokeRect(tX, tY, tW, tH);
            ctx.fillStyle = '#B71C1C';
            ctx.fillRect(tX, tY, tW, 10);
            
            // ── 槍型砲身 ──
            const cY = tY + 40, cX = dCX + dir * tW * 0.45;
            const gunH = 20, gunW = 80;
            ctx.fillStyle = '#CFD8DC';
            this._roundRect(ctx, dir > 0 ? cX : cX - gunW, cY - gunH / 2, gunW, gunH, 8); ctx.fill();
            ctx.strokeStyle = '#546E7A'; ctx.lineWidth = 2; ctx.stroke();
            ctx.fillStyle = '#EF5350';
            ctx.beginPath();
            ctx.moveTo(cX + dir * (gunW - 10), cY - 15);
            ctx.lineTo(cX + dir * (gunW + 30), cY);
            ctx.lineTo(cX + dir * (gunW - 10), cY + 15);
            ctx.closePath(); ctx.fill(); ctx.stroke();
        }
        ctx.restore();
    },

    // 🐉 ドラゴン機械スキン（最終ボス専用: 黒金の龍機装甲・炎顎砲）
    _drawDragonTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        // ★ブラッシュアップ: DQ2メカドラゴン風ピクセルアート（青灰×オレンジ×赤）
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        const t = Date.now() * 0.001;
        const fl = dmgFlash > 0 ? Math.min(1, dmgFlash / 10) : 0;

        ctx.save();
        if (fl > 0) {
            ctx.translate(Math.sin(t * 40) * 4 * fl, 0);
        }

        // ── キャタピラ（ピクセル風・青灰×オレンジ縁）──
        const treadH = 52, treadW = tw * 0.92;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;
        const treadG = ctx.createLinearGradient(treadX, treadY, treadX, treadY + treadH);
        treadG.addColorStop(0, fl ? '#FF8C00' : '#2A3A5A');
        treadG.addColorStop(0.45, fl ? '#CC5500' : '#1A2640');
        treadG.addColorStop(1, '#0D1420');
        ctx.fillStyle = treadG;
        // ピクセル風に角張ったキャタピラ
        ctx.beginPath();
        ctx.moveTo(treadX - 8, treadY + 6);
        ctx.lineTo(treadX + treadW + 8, treadY + 6);
        ctx.lineTo(treadX + treadW + 14, treadY + treadH);
        ctx.lineTo(treadX - 14, treadY + treadH);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = fl ? '#FF4500' : '#FF8C00';
        ctx.lineWidth = 3; ctx.stroke();

        // キャタピラのセグメント線（ピクセルアート風）
        ctx.strokeStyle = 'rgba(255,140,0,0.25)'; ctx.lineWidth = 1.5;
        for (let seg = 1; seg < 6; seg++) {
            const segX = treadX + (treadW / 6) * seg;
            ctx.beginPath();
            ctx.moveTo(segX, treadY + 6); ctx.lineTo(segX, treadY + treadH);
            ctx.stroke();
        }

        // 大型駆動輪（5個・ピクセルアート風・オレンジスポーク）
        for (let i = 0; i < 5; i++) {
            const wx = treadX + 18 + i * ((treadW - 36) / 4);
            const wy = treadY + treadH * 0.52;
            const wr = 17;
            // 外リング（ピクセル風・オレンジ縁）
            ctx.strokeStyle = fl ? '#FFFFFF' : '#FF8C00'; ctx.lineWidth = 3;
            ctx.fillStyle = fl ? '#FF4500' : '#1E2F55';
            ctx.beginPath(); ctx.arc(wx, wy, wr, 0, Math.PI * 2);
            ctx.fill(); ctx.stroke();
            // 内リング
            ctx.fillStyle = fl ? '#FF8C00' : '#2A3F7A';
            ctx.beginPath(); ctx.arc(wx, wy, wr * 0.6, 0, Math.PI * 2); ctx.fill();
            // スポーク（4本・ピクセル風）
            ctx.strokeStyle = fl ? '#FFD700' : 'rgba(255,140,0,0.8)'; ctx.lineWidth = 2;
            for (let s = 0; s < 4; s++) {
                const sa = (s / 4) * Math.PI * 2 + t * 0.7;
                ctx.beginPath();
                ctx.moveTo(wx + Math.cos(sa) * (wr * 0.55), wy + Math.sin(sa) * (wr * 0.55));
                ctx.lineTo(wx + Math.cos(sa) * (wr - 2), wy + Math.sin(sa) * (wr - 2));
                ctx.stroke();
            }
            // 中心ボルト
            ctx.fillStyle = fl ? '#FFD700' : '#FF8C00';
            ctx.beginPath(); ctx.arc(wx, wy, 4, 0, Math.PI * 2); ctx.fill();
        }

        // ── メイン装甲ボディ（ピクセル風・青灰×段差装甲）──
        const bodyH = th * 0.52;
        const bodyY = treadY - bodyH + 8;
        const bodyW = tw * 0.84;
        const bodyX = cx - bodyW / 2;

        // 影
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.fillRect(bodyX + 6, bodyY + 6, bodyW, bodyH);

        // ボディ本体（ピクセルアート風3段階装甲）
        const plateColors = [
            fl ? '#FF6600' : '#3A5080',
            fl ? '#CC4400' : '#2A3D6A',
            fl ? '#AA3300' : '#1E2F55',
        ];
        const plateHeights = [bodyH * 0.32, bodyH * 0.34, bodyH * 0.34];
        let plateY = bodyY;
        plateColors.forEach((col, pi) => {
            const pH = plateHeights[pi];
            const pW = bodyW - pi * 12;
            const pX = cx - pW / 2;
            ctx.fillStyle = col;
            ctx.fillRect(pX, plateY, pW, pH);
            // 装甲縁（オレンジ）
            ctx.strokeStyle = fl ? '#FFFFFF' : (pi === 0 ? '#FF8C00' : 'rgba(255,140,0,0.4)');
            ctx.lineWidth = pi === 0 ? 2.5 : 1.5;
            ctx.strokeRect(pX, plateY, pW, pH);
            plateY += pH;
        });

        // 装甲リベット（ピクセル風）
        const rivetPositions = [
            [bodyX + 16, bodyY + 12], [bodyX + bodyW - 16, bodyY + 12],
            [bodyX + 16, bodyY + bodyH * 0.5], [bodyX + bodyW - 16, bodyY + bodyH * 0.5],
            [cx, bodyY + 8],
        ];
        rivetPositions.forEach(([rx, ry]) => {
            ctx.fillStyle = fl ? '#FFD700' : '#FF8C00';
            ctx.beginPath(); ctx.arc(rx, ry, 4, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#000'; ctx.lineWidth = 1;
            ctx.beginPath(); ctx.arc(rx, ry, 4, 0, Math.PI * 2); ctx.stroke();
        });

        // ── サイドスカート装甲（ピクセル風）──
        [-1, 1].forEach(side => {
            const skX = side === -1 ? bodyX - 20 : bodyX + bodyW;
            const skY = bodyY + bodyH * 0.25;
            const skW = 20, skH = bodyH * 0.6;
            ctx.fillStyle = fl ? '#CC4400' : '#253060';
            ctx.fillRect(skX, skY, skW * side < 0 ? -skW : skW, skH);
            ctx.strokeStyle = fl ? '#FF6600' : '#FF8C00'; ctx.lineWidth = 2;
            ctx.strokeRect(skX, skY, skW * side < 0 ? -skW : skW, skH);
            // スカートのスリット
            ctx.strokeStyle = 'rgba(255,140,0,0.3)'; ctx.lineWidth = 1;
            for (let sl = 1; sl < 3; sl++) {
                ctx.beginPath();
                ctx.moveTo(skX, skY + skH * (sl / 3));
                ctx.lineTo(skX + (side < 0 ? -skW : skW), skY + skH * (sl / 3));
                ctx.stroke();
            }
        });

        if (!showInterior) {
            // ── ドラゴン翼（ピクセルアート風・大型・オレンジ膜）──
            const wingBaseY = bodyY + bodyH * 0.2;
            const wingTipY  = bodyY - bodyH * 0.5;
            const wingFlap  = Math.sin(t * 2.0) * 10;

            [-1, 1].forEach(side => {
                const baseX = side < 0 ? bodyX - 5 : bodyX + bodyW + 5;
                const tipX  = side < 0 ? bodyX - 65 : bodyX + bodyW + 65;

                // 翼膜（ピクセルアート風ポリゴン）
                const wG = ctx.createLinearGradient(baseX, wingTipY, tipX, wingBaseY);
                wG.addColorStop(0, fl ? 'rgba(255,200,0,0.9)' : 'rgba(220,80,0,0.88)');
                wG.addColorStop(0.5, fl ? 'rgba(255,120,0,0.7)' : 'rgba(160,40,0,0.72)');
                wG.addColorStop(1, 'rgba(80,10,0,0.5)');
                ctx.fillStyle = wG;
                ctx.beginPath();
                ctx.moveTo(baseX, wingBaseY);
                ctx.lineTo(baseX + side * 20, wingBaseY - 20);
                ctx.lineTo(tipX + side * 25, wingTipY + 30 + wingFlap * side * 0.5);
                ctx.lineTo(tipX + side * 10, wingTipY + wingFlap * side);
                ctx.lineTo(tipX - side * 5, wingTipY + 20 + wingFlap * side * 0.3);
                ctx.lineTo(baseX + side * 5, wingBaseY + 10);
                ctx.closePath();
                ctx.fill();

                // 翼の骨格（オレンジ）
                ctx.strokeStyle = fl ? '#FFD700' : '#FF6600'; ctx.lineWidth = 2.5;
                ctx.beginPath();
                ctx.moveTo(baseX, wingBaseY);
                ctx.lineTo(tipX + side * 10, wingTipY + wingFlap * side);
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(baseX, wingBaseY);
                ctx.lineTo(tipX + side * 25, wingTipY + 30 + wingFlap * side * 0.5);
                ctx.stroke();

                // 翼の骨格筋（細）
                ctx.strokeStyle = 'rgba(255,100,0,0.45)'; ctx.lineWidth = 1.2;
                for (let b = 1; b < 4; b++) {
                    const bRatio = b / 4;
                    const bx1 = baseX + side * b * 4;
                    const by1 = wingBaseY - b * 12;
                    const bx2 = baseX + side * (20 + b * 12);
                    const by2 = wingTipY + 30 - b * 8 + wingFlap * side * bRatio;
                    ctx.beginPath(); ctx.moveTo(bx1, by1); ctx.lineTo(bx2, by2); ctx.stroke();
                }

                // 翼の爪（3本・ピクセル風）
                [[0, 0], [0.4, 0.3], [0.75, 0.6]].forEach(([r1, r2]) => {
                    const clawX = tipX + side * (10 + r1 * 15);
                    const clawY = wingTipY + r1 * 30 + wingFlap * side * r2;
                    ctx.fillStyle = fl ? '#FFD700' : '#FF4500';
                    ctx.beginPath();
                    ctx.moveTo(clawX, clawY);
                    ctx.lineTo(clawX + side * 14, clawY - 8);
                    ctx.lineTo(clawX + side * 4, clawY + 6);
                    ctx.closePath(); ctx.fill();
                    ctx.strokeStyle = '#000'; ctx.lineWidth = 1; ctx.stroke();
                });
            });

            // ── ドラゴン首・頭部（ピクセルアート風・大型）──
            const neckBaseX = cx, neckBaseY = bodyY - 2;
            const neckTipX  = cx + dir * 30, neckTipY = bodyY - 52;

            // 首（ピクセル風台形）
            const neckW1 = 30, neckW2 = 22;
            const neckG = ctx.createLinearGradient(neckBaseX, neckBaseY, neckTipX, neckTipY);
            neckG.addColorStop(0, fl ? '#FF6600' : '#3A5080');
            neckG.addColorStop(1, fl ? '#CC3300' : '#2A3D6A');
            ctx.fillStyle = neckG;
            ctx.beginPath();
            ctx.moveTo(neckBaseX - neckW1/2, neckBaseY);
            ctx.lineTo(neckBaseX + neckW1/2, neckBaseY);
            ctx.lineTo(neckTipX + neckW2/2, neckTipY);
            ctx.lineTo(neckTipX - neckW2/2, neckTipY);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = fl ? '#FFFFFF' : '#FF8C00'; ctx.lineWidth = 2; ctx.stroke();

            // 首の鱗ライン（ピクセル風）
            ctx.strokeStyle = 'rgba(255,140,0,0.35)'; ctx.lineWidth = 1;
            for (let sc = 1; sc < 4; sc++) {
                const ratio = sc / 4;
                const sx = neckBaseX + (neckTipX - neckBaseX) * ratio;
                const sy = neckBaseY + (neckTipY - neckBaseY) * ratio;
                ctx.beginPath();
                ctx.moveTo(sx - neckW1/2 * (1-ratio) - neckW2/2 * ratio, sy);
                ctx.lineTo(sx + neckW1/2 * (1-ratio) + neckW2/2 * ratio, sy);
                ctx.stroke();
            }

            // ドラゴン頭部（大型・ピクセルアート風横長）
            const headCX = neckTipX + dir * 46;
            const headCY = neckTipY - 10;
            const headW = 54, headH = 34;

            // 頭部メイン装甲
            const headG = ctx.createLinearGradient(headCX - headW, headCY - headH/2, headCX + headW, headCY + headH/2);
            headG.addColorStop(0, fl ? '#FF7700' : '#4A6090');
            headG.addColorStop(0.4, fl ? '#CC4400' : '#3A5080');
            headG.addColorStop(1, fl ? '#881100' : '#1A2A50');
            ctx.fillStyle = headG;
            ctx.beginPath();
            ctx.moveTo(headCX - headW, headCY - headH * 0.3);
            ctx.lineTo(headCX - headW * 0.5, headCY - headH * 0.85);
            ctx.lineTo(headCX + headW * 0.4, headCY - headH * 0.9);
            ctx.lineTo(headCX + headW, headCY - headH * 0.2);
            ctx.lineTo(headCX + headW * 1.1, headCY + headH * 0.15);
            ctx.lineTo(headCX + headW * 0.6, headCY + headH * 0.55);
            ctx.lineTo(headCX - headW * 0.7, headCY + headH * 0.55);
            ctx.lineTo(headCX - headW, headCY - headH * 0.3);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = fl ? '#FFD700' : '#FF8C00'; ctx.lineWidth = 2.5; ctx.stroke();

            // 額の装甲プレート（ピクセル風）
            ctx.fillStyle = fl ? '#FF4500' : '#2A4070';
            ctx.fillRect(headCX - headW * 0.35, headCY - headH * 0.82, headW * 0.7, headH * 0.32);
            ctx.strokeStyle = fl ? '#FFD700' : '#FF8C00'; ctx.lineWidth = 1.5;
            ctx.strokeRect(headCX - headW * 0.35, headCY - headH * 0.82, headW * 0.7, headH * 0.32);

            // ドラゴンの目（赤い炎の目・ピクセル風）
            const eyeX = headCX + dir * 16;
            const eyeY = headCY - headH * 0.2;
            const eyePulse = 0.8 + Math.sin(t * 6) * 0.2;
            // 目の外枠
            ctx.fillStyle = '#1A0000';
            ctx.fillRect(eyeX - 10, eyeY - 7, 20, 14);
            // 赤い眼光
            const eyeG = ctx.createRadialGradient(eyeX, eyeY, 0, eyeX, eyeY, 9);
            eyeG.addColorStop(0, `rgba(255,255,0,${eyePulse})`);
            eyeG.addColorStop(0.35, `rgba(255,80,0,${eyePulse * 0.9})`);
            eyeG.addColorStop(1, 'rgba(180,0,0,0)');
            ctx.fillStyle = eyeG;
            ctx.beginPath(); ctx.ellipse(eyeX, eyeY, 9, 6, 0, 0, Math.PI * 2); ctx.fill();
            // 眼の輝き
            ctx.fillStyle = `rgba(255,255,200,${eyePulse * 0.7})`;
            ctx.beginPath(); ctx.arc(eyeX - 2, eyeY - 2, 2.5, 0, Math.PI * 2); ctx.fill();
            // 目のグロー
            ctx.strokeStyle = `rgba(255,100,0,${eyePulse * 0.5})`; ctx.lineWidth = 4;
            ctx.beginPath(); ctx.ellipse(eyeX, eyeY, 11, 8, 0, 0, Math.PI * 2); ctx.stroke();

            // 龍の鼻孔（炎の噴出）
            const nostrilX = headCX + dir * (headW * 0.9);
            const nostrilY = headCY + headH * 0.05;
            const flameA = 0.6 + Math.sin(t * 8) * 0.3;
            ctx.fillStyle = `rgba(255,140,0,${flameA})`;
            ctx.beginPath();
            ctx.ellipse(nostrilX, nostrilY, 6, 4, dir * 0.3, 0, Math.PI * 2);
            ctx.fill();
            // 炎エフェクト
            if (!fl) {
                const fG = ctx.createRadialGradient(nostrilX, nostrilY, 0, nostrilX + dir * 10, nostrilY - 8, 16);
                fG.addColorStop(0, `rgba(255,200,0,${flameA * 0.8})`);
                fG.addColorStop(0.5, `rgba(255,60,0,${flameA * 0.4})`);
                fG.addColorStop(1, 'rgba(255,0,0,0)');
                ctx.fillStyle = fG;
                ctx.beginPath();
                ctx.ellipse(nostrilX + dir * 10, nostrilY - 8, 14, 10, 0, 0, Math.PI * 2);
                ctx.fill();
            }

            // 龍の角（2本・ピクセル風鋭角）
            [[dir * -8, -headH * 0.7, dir * -22, -headH * 1.3, '#FF4500'],
             [dir * 8, -headH * 0.65, dir * 20, -headH * 1.15, '#CC3300']].forEach(([ox, oy, tx2, ty2, col]) => {
                ctx.fillStyle = col;
                ctx.beginPath();
                ctx.moveTo(headCX + ox - 6, headCY + oy);
                ctx.lineTo(headCX + tx2, headCY + ty2);
                ctx.lineTo(headCX + ox + 6, headCY + oy);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 1.5; ctx.stroke();
            });

            // 角のベース装飾（ピクセル風）
            ctx.fillStyle = fl ? '#FFD700' : '#FF8C00';
            ctx.fillRect(headCX - headW * 0.25, headCY - headH * 0.9, headW * 0.5, 8);
            ctx.strokeStyle = '#000'; ctx.lineWidth = 1;
            ctx.strokeRect(headCX - headW * 0.25, headCY - headH * 0.9, headW * 0.5, 8);

            // ── 砲台（ピクセル風・2門）──
            [-1, 1].forEach((side, ci) => {
                const canX = cx + side * bodyW * 0.28;
                const canY = bodyY + bodyH * 0.12;
                const canLen = 38, canW = 12;

                // 砲身ベース
                ctx.fillStyle = fl ? '#FF6600' : '#1A2A50';
                ctx.fillRect(canX - canW/2, canY, canW, canLen);
                ctx.strokeStyle = fl ? '#FFD700' : '#FF8C00'; ctx.lineWidth = 2;
                ctx.strokeRect(canX - canW/2, canY, canW, canLen);

                // 砲口のグロー
                const muzzleA = 0.5 + Math.sin(t * 5 + ci * 2) * 0.4;
                const muzzleG = ctx.createRadialGradient(canX, canY, 0, canX, canY, 10);
                muzzleG.addColorStop(0, `rgba(255,200,0,${muzzleA})`);
                muzzleG.addColorStop(1, 'rgba(255,60,0,0)');
                ctx.fillStyle = muzzleG;
                ctx.beginPath(); ctx.arc(canX, canY, 10, 0, Math.PI * 2); ctx.fill();

                // エネルギーリング
                ctx.strokeStyle = `rgba(255,140,0,${muzzleA * 0.7})`; ctx.lineWidth = 2;
                ctx.beginPath(); ctx.arc(canX, canY, 7, 0, Math.PI * 2); ctx.stroke();
            });

            // ── 胸の紋章（ピクセル風・ドラゴンシンボル）──
            const embX = cx - (dir < 0 ? 10 : -10), embY = bodyY + bodyH * 0.45;
            const embR = 18;
            // 外円
            ctx.strokeStyle = fl ? '#FFD700' : '#FF8C00'; ctx.lineWidth = 2.5;
            ctx.fillStyle = fl ? 'rgba(255,100,0,0.4)' : 'rgba(26,42,80,0.8)';
            ctx.beginPath(); ctx.arc(embX, embY, embR, 0, Math.PI * 2);
            ctx.fill(); ctx.stroke();
            // 龍の紋章（簡略ピクセルアート）
            ctx.fillStyle = fl ? '#FFD700' : '#FF6600';
            // 縦棒
            ctx.fillRect(embX - 2, embY - embR * 0.6, 4, embR * 1.2);
            // 横棒
            ctx.fillRect(embX - embR * 0.6, embY - 2, embR * 1.2, 4);
            // 斜め装飾
            ctx.save(); ctx.translate(embX, embY);
            ctx.rotate(Math.PI / 4 + t * 0.3);
            ctx.fillStyle = `rgba(255,140,0,${0.4 + Math.sin(t*3)*0.2})`;
            ctx.fillRect(-embR * 0.4, -2, embR * 0.8, 4);
            ctx.restore();
        }

        // ダメージフラッシュオーバーレイ
        if (fl > 0) {
            ctx.save();
            ctx.globalAlpha = fl * 0.35;
            ctx.fillStyle = '#FF4500';
            ctx.fillRect(tx - 20, ty - 20, tw + 40, th + 20);
            ctx.restore();
        }

        ctx.restore();
    },
    // 🥷 忍者スキン（強化版: 黒鉄城塔・手裏剣翼・細目）
    _drawNinjaTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        ctx.save();
        ctx.translate(cx, ty + th);
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(Date.now()*0.05)*2, 0); }
        ctx.translate(-cx, -(ty + th));

        const treadH = 42, treadW = tw * 0.80;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;

        // キャタピラ（黒鉄）
        const tG = ctx.createLinearGradient(0, treadY, 0, treadY+treadH);
        tG.addColorStop(0,'#2A2A2A'); tG.addColorStop(0.5,'#3A3A3A'); tG.addColorStop(1,'#0A0A0A');
        ctx.fillStyle = tG;
        this._roundRect(ctx, treadX, treadY, treadW, treadH, 10); ctx.fill();
        ctx.strokeStyle = '#111'; ctx.lineWidth = 2; ctx.stroke();
        ctx.strokeStyle = '#111'; ctx.lineWidth = 1.2; ctx.setLineDash([4,5]);
        ctx.beginPath(); ctx.moveTo(treadX+8, treadY+treadH*0.5); ctx.lineTo(treadX+treadW-8, treadY+treadH*0.5); ctx.stroke();
        ctx.setLineDash([]);
        for (let i = 0; i < 4; i++) {
            const wx = treadX + 22 + i * ((treadW-44)/3), wY = treadY+treadH*0.55;
            ctx.fillStyle = '#222'; ctx.beginPath(); ctx.arc(wx, wY, 13, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#0A0A0A'; ctx.lineWidth = 1.2; ctx.stroke();
            ctx.fillStyle = '#444'; ctx.beginPath(); ctx.arc(wx, wY, 7, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#666'; ctx.beginPath(); ctx.arc(wx, wY, 3, 0, Math.PI*2); ctx.fill();
        }

        // ドーム本体（漆黒）
        const dRX = tw * 0.50, dRY = th * 0.47;
        const dCX = cx, dCY = treadY - dRY * 0.90;
        const domeG = ctx.createRadialGradient(dCX-dRX*0.3, dCY-dRY*0.3, dRX*0.05, dCX, dCY, dRX*1.1);
        domeG.addColorStop(0,'#2A2A3A'); domeG.addColorStop(0.45,'#141420'); domeG.addColorStop(1,'#080810');
        ctx.beginPath(); ctx.ellipse(dCX+5, dCY+5, dRX, dRY, 0, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(0,0,0,0.15)'; ctx.fill();
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI*2);
        ctx.fillStyle = domeG; ctx.fill();
        ctx.strokeStyle = '#4A4A6A'; ctx.lineWidth = 2; ctx.stroke();
        ctx.beginPath(); ctx.ellipse(dCX-dRX*0.18, dCY-dRY*0.28, dRX*0.28, dRY*0.16, -0.3, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(255,255,255,0.08)'; ctx.fill();

        if (!showInterior) {
            // 翼（手裏剣型の薄い黒翼）
            const wBaseY = dCY - dRY*0.1, wTipY = dCY - dRY*0.6;
            [[-1],[1]].forEach(([s]) => {
                ctx.fillStyle = '#1A1A2A';
                ctx.beginPath();
                ctx.moveTo(dCX + s*(dRX-4), wBaseY+10);
                ctx.lineTo(dCX + s*(dRX+20), wTipY+5);
                ctx.lineTo(dCX + s*(dRX+30), wTipY-10);
                ctx.lineTo(dCX + s*(dRX+14), wBaseY-18);
                ctx.lineTo(dCX + s*(dRX-4),  wBaseY-12);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#3A3A5A'; ctx.lineWidth = 1.5; ctx.stroke();
                ctx.fillStyle = '#444';
                ctx.beginPath();
                ctx.moveTo(dCX + s*(dRX+26), wTipY+2);
                ctx.lineTo(dCX + s*(dRX+40), wTipY-8);
                ctx.lineTo(dCX + s*(dRX+24), wTipY-12);
                ctx.closePath(); ctx.fill();
            });

            // 城塔（黒鉄）
            const drawNinjaTower = (tcx) => {
                const tRad=20, tH=th*0.52, tTopY=treadY-tH;
                const tG2 = ctx.createLinearGradient(tcx-tRad,0,tcx+tRad,0);
                tG2.addColorStop(0,'#1A1A1A'); tG2.addColorStop(0.4,'#2A2A2A'); tG2.addColorStop(1,'#111');
                ctx.fillStyle = tG2;
                ctx.beginPath(); ctx.rect(tcx-tRad, tTopY, tRad*2, tH); ctx.fill();
                ctx.strokeStyle = 'rgba(100,100,150,0.3)'; ctx.lineWidth = 1;
                for (let r=1;r<=6;r++){const ly=tTopY+r*(tH/7);ctx.beginPath();ctx.moveTo(tcx-tRad+2,ly);ctx.lineTo(tcx+tRad-2,ly);ctx.stroke();}
                ctx.strokeStyle = '#333'; ctx.lineWidth = 1.8; ctx.strokeRect(tcx-tRad, tTopY, tRad*2, tH);
                ctx.fillStyle = 'rgba(255,50,0,0.4)';
                ctx.fillRect(tcx-3, tTopY+tH*0.38, 6, 14);
                for(let i=0;i<3;i++){
                    ctx.fillStyle='#1A1A1A'; ctx.strokeStyle='#444'; ctx.lineWidth=0.8;
                    ctx.beginPath(); ctx.rect(tcx-14+i*11, tTopY-11, 7,12); ctx.fill(); ctx.stroke();
                }
                ctx.strokeStyle='#333'; ctx.lineWidth=1.5;
                ctx.beginPath(); ctx.moveTo(tcx-tRad, tTopY); ctx.lineTo(tcx+tRad, tTopY); ctx.stroke();
                ctx.fillStyle='#1A1A2A';
                ctx.beginPath(); ctx.moveTo(tcx-tRad-3, tTopY-11); ctx.lineTo(tcx, tTopY-11-30); ctx.lineTo(tcx+tRad+3, tTopY-11); ctx.closePath(); ctx.fill();
                ctx.strokeStyle='rgba(100,100,150,0.4)'; ctx.lineWidth=1.5; ctx.stroke();
                ctx.strokeStyle='#555'; ctx.lineWidth=1.5;
                ctx.beginPath(); ctx.moveTo(tcx, tTopY-42); ctx.lineTo(tcx, tTopY-60); ctx.stroke();
                ctx.fillStyle='#E8E8E0';
                ctx.beginPath(); ctx.moveTo(tcx, tTopY-60); ctx.lineTo(tcx+12, tTopY-54); ctx.lineTo(tcx, tTopY-48); ctx.closePath(); ctx.fill();
            };
            drawNinjaTower(dCX - dRX*0.86);
            drawNinjaTower(dCX + dRX*0.86);

            // 頂上：苦無
            ctx.strokeStyle='#888'; ctx.lineWidth=2;
            ctx.beginPath(); ctx.moveTo(dCX, dCY-dRY-2); ctx.lineTo(dCX, dCY-dRY-32); ctx.stroke();
            ctx.fillStyle='#B0B0B0';
            ctx.beginPath(); ctx.moveTo(dCX-3, dCY-dRY-28); ctx.lineTo(dCX, dCY-dRY-48); ctx.lineTo(dCX+3, dCY-dRY-28); ctx.closePath(); ctx.fill();

            // 砲口（黒・二重リング）
            const cX=dCX+dir*dRX*0.28, cY=dCY+dRY*0.10, cR=dRX*0.20;
            ctx.fillStyle='#1A1A1A'; ctx.beginPath(); ctx.arc(cX, cY, cR+9, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle='#444'; ctx.lineWidth=2; ctx.stroke();
            ctx.fillStyle='#2A2A2A'; ctx.beginPath(); ctx.arc(cX, cY, cR+5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle='#050505'; ctx.beginPath(); ctx.arc(cX, cY, cR, 0, Math.PI*2); ctx.fill();
            const bR=cR*0.62, bLen=44;
            ctx.fillStyle='#444'; ctx.strokeStyle='rgba(0,0,0,0.4)'; ctx.lineWidth=1.5;
            ctx.beginPath(); ctx.ellipse(cX+dir*bLen*0.5, cY, Math.abs(dir*bLen)*0.55, bR, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            const ringX2 = cX + dir*bLen*0.65;
            ctx.fillStyle='#2A2A2A'; ctx.beginPath(); ctx.ellipse(ringX2, cY, 5, bR+3, 0, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle='#2A2A2A'; ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR+5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle='#050505'; ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR, 0, Math.PI*2); ctx.fill();

            // 目（赤スリット）
            const eY=dCY-dRY*0.28;
            ctx.fillStyle='#CC3300'; ctx.fillRect(dCX-dRX*0.45, eY-4, 16, 8); ctx.fillRect(dCX+dRX*0.10, eY-4, 16, 8);
            ctx.fillStyle='rgba(255,80,0,0.5)'; ctx.fillRect(dCX-dRX*0.44, eY-2, 14, 4); ctx.fillRect(dCX+dRX*0.11, eY-2, 14, 4);

            // エンブレム（手裏剣型）
            const emX=dCX-dRX*0.28, emY=dCY+dRY*0.36;
            ctx.save(); ctx.translate(emX, emY);
            ctx.fillStyle='#1A1A2A'; ctx.strokeStyle='#555'; ctx.lineWidth=1.5;
            ctx.beginPath(); ctx.arc(0,0,17,0,Math.PI*2); ctx.fill(); ctx.stroke();
            ctx.fillStyle='#888';
            for(let i=0;i<4;i++){
                ctx.save(); ctx.rotate(i*Math.PI/2);
                ctx.beginPath(); ctx.moveTo(0,-12); ctx.lineTo(4,-4); ctx.lineTo(12,0); ctx.lineTo(4,4); ctx.lineTo(0,12); ctx.lineTo(-4,4); ctx.lineTo(-12,0); ctx.lineTo(-4,-4);
                ctx.closePath(); ctx.fill(); ctx.restore();
            }
            ctx.fillStyle='#AAA'; ctx.beginPath(); ctx.arc(0,0,4,0,Math.PI*2); ctx.fill();
            ctx.restore();
        }
        ctx.restore();
    },

    // 🦀 カニスキン（強化版: 甲羅城塔・ハサミ翼・触角）
    _drawCrabTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        ctx.save();
        ctx.translate(cx, ty + th);
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(Date.now()*0.05)*2, 0); }
        ctx.translate(-cx, -(ty + th));

        const treadH = 42, treadW = tw * 0.80;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;

        // キャタピラ（赤甲殻）
        const tG = ctx.createLinearGradient(0, treadY, 0, treadY+treadH);
        tG.addColorStop(0,'#C62828'); tG.addColorStop(0.5,'#E53935'); tG.addColorStop(1,'#7F0000');
        ctx.fillStyle = tG;
        this._roundRect(ctx, treadX, treadY, treadW, treadH, 10); ctx.fill();
        ctx.strokeStyle = '#4A0000'; ctx.lineWidth = 2; ctx.stroke();
        ctx.strokeStyle = '#4A0000'; ctx.lineWidth = 1.2; ctx.setLineDash([4,5]);
        ctx.beginPath(); ctx.moveTo(treadX+8, treadY+treadH*0.5); ctx.lineTo(treadX+treadW-8, treadY+treadH*0.5); ctx.stroke();
        ctx.setLineDash([]);
        for (let i = 0; i < 4; i++) {
            const wx = treadX + 22 + i * ((treadW-44)/3), wY = treadY+treadH*0.55;
            ctx.fillStyle = '#B71C1C'; ctx.beginPath(); ctx.arc(wx, wY, 13, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#4A0000'; ctx.lineWidth = 1.2; ctx.stroke();
            ctx.fillStyle = '#EF5350'; ctx.beginPath(); ctx.arc(wx, wY, 7, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#FF8A80'; ctx.beginPath(); ctx.arc(wx, wY, 3, 0, Math.PI*2); ctx.fill();
        }

        // ドーム（甲羅）
        const dRX = tw * 0.50, dRY = th * 0.47;
        const dCX = cx, dCY = treadY - dRY * 0.90;
        const domeG = ctx.createRadialGradient(dCX-dRX*0.3, dCY-dRY*0.3, dRX*0.05, dCX, dCY, dRX*1.1);
        domeG.addColorStop(0,'#EF5350'); domeG.addColorStop(0.45,'#C62828'); domeG.addColorStop(1,'#7F0000');
        ctx.beginPath(); ctx.ellipse(dCX+5, dCY+5, dRX, dRY, 0, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(0,0,0,0.15)'; ctx.fill();
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI*2);
        ctx.fillStyle = domeG; ctx.fill();
        ctx.strokeStyle = '#4A0000'; ctx.lineWidth = 2.2; ctx.stroke();
        // 甲羅の年輪模様
        for (let i=1;i<=3;i++){
            ctx.strokeStyle='rgba(0,0,0,0.12)'; ctx.lineWidth=1.5;
            ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX*0.28*i, dRY*0.28*i, 0, 0, Math.PI*2); ctx.stroke();
        }
        ctx.beginPath(); ctx.ellipse(dCX-dRX*0.18, dCY-dRY*0.28, dRX*0.28, dRY*0.16, -0.3, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fill();

        if (!showInterior) {
            // ハサミ翼（動的に揺れる）
            const swing = Math.sin(Date.now()*0.003) * 6;
            const clawBaseY = dCY - dRY*0.05;
            [[-1],[1]].forEach(([s]) => {
                const bx = dCX + s*(dRX+4);
                // ハサミ腕（翼の代わり）
                ctx.fillStyle = '#C62828';
                ctx.beginPath();
                ctx.moveTo(bx, clawBaseY-8);
                ctx.quadraticCurveTo(bx+s*25, clawBaseY-15+swing*s, bx+s*48, clawBaseY-25+swing*s);
                ctx.lineTo(bx+s*44, clawBaseY-12+swing*s);
                ctx.quadraticCurveTo(bx+s*18, clawBaseY-6, bx, clawBaseY+8);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#7F0000'; ctx.lineWidth = 1.5; ctx.stroke();
                // ハサミの刃
                ctx.fillStyle = '#EF5350';
                ctx.beginPath(); ctx.arc(bx+s*48, clawBaseY-25+swing*s, 9, 0, Math.PI*2); ctx.fill();
                ctx.strokeStyle = '#7F0000'; ctx.lineWidth = 1; ctx.stroke();
                ctx.fillStyle = '#C62828';
                ctx.beginPath();
                ctx.moveTo(bx+s*42, clawBaseY-22+swing*s);
                ctx.lineTo(bx+s*56, clawBaseY-20+swing*s);
                ctx.lineTo(bx+s*46, clawBaseY-32+swing*s);
                ctx.closePath(); ctx.fill();
            });

            // 城塔（赤甲殻）
            const drawCrabTower = (tcx) => {
                const tRad=21, tH=th*0.52, tTopY=treadY-tH;
                const tG2 = ctx.createLinearGradient(tcx-tRad,0,tcx+tRad,0);
                tG2.addColorStop(0,'#A52020'); tG2.addColorStop(0.4,'#C62828'); tG2.addColorStop(1,'#8A1818');
                ctx.fillStyle = tG2;
                ctx.beginPath(); ctx.rect(tcx-tRad, tTopY, tRad*2, tH); ctx.fill();
                ctx.strokeStyle = 'rgba(0,0,0,0.2)'; ctx.lineWidth = 1;
                for(let r=1;r<=6;r++){const ly=tTopY+r*(tH/7);ctx.beginPath();ctx.moveTo(tcx-tRad+2,ly);ctx.lineTo(tcx+tRad-2,ly);ctx.stroke();}
                ctx.strokeStyle='#4A0000'; ctx.lineWidth=1.8; ctx.strokeRect(tcx-tRad, tTopY, tRad*2, tH);
                // アーチ窓
                ctx.fillStyle='rgba(8,8,25,0.85)';
                ctx.beginPath(); ctx.moveTo(tcx-6, tTopY+tH*0.52); ctx.lineTo(tcx-6, tTopY+tH*0.42); ctx.quadraticCurveTo(tcx-6, tTopY+tH*0.28, tcx, tTopY+tH*0.24); ctx.quadraticCurveTo(tcx+6, tTopY+tH*0.28, tcx+6, tTopY+tH*0.42); ctx.lineTo(tcx+6, tTopY+tH*0.52); ctx.closePath(); ctx.fill();
                ctx.strokeStyle='#8A3030'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(tcx-5, tTopY+tH*0.42); ctx.quadraticCurveTo(tcx-5, tTopY+tH*0.30, tcx, tTopY+tH*0.26); ctx.quadraticCurveTo(tcx+5, tTopY+tH*0.30, tcx+5, tTopY+tH*0.42); ctx.stroke();
                // 銃眼3個
                for(let i=0;i<3;i++){
                    ctx.fillStyle='#8A1818'; ctx.strokeStyle='#4A0000'; ctx.lineWidth=0.8;
                    ctx.beginPath(); ctx.rect(tcx-14+i*11, tTopY-11, 7,12); ctx.fill(); ctx.stroke();
                }
                ctx.strokeStyle='#4A0000'; ctx.lineWidth=1.5;
                ctx.beginPath(); ctx.moveTo(tcx-tRad, tTopY); ctx.lineTo(tcx+tRad, tTopY); ctx.stroke();
                // 屋根（甲羅色三角）
                ctx.fillStyle='#A52020';
                ctx.beginPath(); ctx.moveTo(tcx-tRad-3, tTopY-11); ctx.lineTo(tcx, tTopY-11-32); ctx.lineTo(tcx+tRad+3, tTopY-11); ctx.closePath(); ctx.fill();
                ctx.strokeStyle='#4A0000'; ctx.lineWidth=1.5; ctx.stroke();
                ctx.strokeStyle='rgba(255,255,255,0.15)'; ctx.lineWidth=2;
                ctx.beginPath(); ctx.moveTo(tcx, tTopY-42); ctx.lineTo(tcx-tRad*0.4, tTopY-14); ctx.stroke();
                // 旗ポール + 触角風の旗
                ctx.strokeStyle='#8A3030'; ctx.lineWidth=1.5;
                ctx.beginPath(); ctx.moveTo(tcx, tTopY-43); ctx.lineTo(tcx, tTopY-60); ctx.stroke();
                ctx.fillStyle='#E53935';
                ctx.beginPath(); ctx.moveTo(tcx, tTopY-60); ctx.lineTo(tcx+13, tTopY-54); ctx.lineTo(tcx, tTopY-48); ctx.closePath(); ctx.fill();
            };
            drawCrabTower(dCX - dRX*0.86);
            drawCrabTower(dCX + dRX*0.86);

            // 触角（頂上）
            ctx.strokeStyle='#E53935'; ctx.lineWidth=2;
            ctx.beginPath(); ctx.moveTo(dCX-14, dCY-dRY+4); ctx.quadraticCurveTo(dCX-24, dCY-dRY-20, dCX-8, dCY-dRY-34); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(dCX+14, dCY-dRY+4); ctx.quadraticCurveTo(dCX+24, dCY-dRY-20, dCX+8, dCY-dRY-34); ctx.stroke();
            ctx.fillStyle='#FF1744'; ctx.beginPath(); ctx.arc(dCX-8, dCY-dRY-34, 5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle='#FF1744'; ctx.beginPath(); ctx.arc(dCX+8, dCY-dRY-34, 5, 0, Math.PI*2); ctx.fill();

            // 砲口（赤・二重リング）
            const cX=dCX+dir*dRX*0.28, cY=dCY+dRY*0.12, cR=dRX*0.20;
            ctx.fillStyle='#8A1818'; ctx.beginPath(); ctx.arc(cX, cY, cR+9, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle='#4A0000'; ctx.lineWidth=2; ctx.stroke();
            ctx.fillStyle='#C62828'; ctx.beginPath(); ctx.arc(cX, cY, cR+5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle='#050505'; ctx.beginPath(); ctx.arc(cX, cY, cR, 0, Math.PI*2); ctx.fill();
            const bR=cR*0.62, bLen=44;
            const bG = ctx.createLinearGradient(cX, cY-bR, cX, cY+bR);
            bG.addColorStop(0,'#90A4AE'); bG.addColorStop(0.4,'#B0BEC5'); bG.addColorStop(1,'#455A64');
            ctx.fillStyle=bG; ctx.strokeStyle='rgba(0,0,0,0.35)'; ctx.lineWidth=1.5;
            ctx.beginPath(); ctx.ellipse(cX+dir*bLen*0.5, cY, Math.abs(dir*bLen)*0.55, bR, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            ctx.fillStyle='#8A1818'; ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR+5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle='#050505'; ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR, 0, Math.PI*2); ctx.fill();

            // 目（飛び出るカニ目）
            const eY=dCY-dRY*0.28;
            [[-1],[1]].forEach(([s]) => {
                const ex=dCX+s*dRX*0.28;
                ctx.strokeStyle='#8A1818'; ctx.lineWidth=2;
                ctx.beginPath(); ctx.moveTo(ex, eY+4); ctx.lineTo(ex, eY-8); ctx.stroke();
                ctx.fillStyle='#111'; ctx.beginPath(); ctx.arc(ex, eY-8, 9, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle='#FF1744'; ctx.beginPath(); ctx.arc(ex, eY-8, 5, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle='rgba(255,255,255,0.5)'; ctx.beginPath(); ctx.arc(ex-2, eY-10, 2, 0, Math.PI*2); ctx.fill();
            });

            // エンブレム（甲羅模様）
            const emX=dCX-dRX*0.28, emY=dCY+dRY*0.36;
            ctx.fillStyle='#7F0000'; ctx.strokeStyle='#C62828'; ctx.lineWidth=2;
            ctx.beginPath(); ctx.arc(emX, emY, 17, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            ctx.fillStyle='#C62828'; ctx.strokeStyle='#EF5350'; ctx.lineWidth=1;
            ctx.beginPath(); ctx.arc(emX, emY, 11, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            for(let i=1;i<=2;i++){ctx.strokeStyle='rgba(0,0,0,0.2)'; ctx.lineWidth=1.5; ctx.beginPath(); ctx.arc(emX, emY, 4*i, 0, Math.PI*2); ctx.stroke();}
            ctx.fillStyle='#FF5252'; ctx.beginPath(); ctx.arc(emX, emY, 4, 0, Math.PI*2); ctx.fill();
        }
        ctx.restore();
    },

    // 👿 魔王スキン（強化版: 禍々しい城塔・翼・角・紫オーラ）
    _drawMaouTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        ctx.save();
        ctx.translate(cx, ty + th);
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(Date.now()*0.05)*2, 0); }
        ctx.translate(-cx, -(ty + th));

        const treadH = 44, treadW = tw * 0.82;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;

        // キャタピラ（紫黒）
        const tG = ctx.createLinearGradient(0, treadY, 0, treadY+treadH);
        tG.addColorStop(0,'#2A0A4A'); tG.addColorStop(0.5,'#3A0A5A'); tG.addColorStop(1,'#100020');
        ctx.fillStyle = tG;
        this._roundRect(ctx, treadX, treadY, treadW, treadH, 10); ctx.fill();
        ctx.strokeStyle = '#4A0080'; ctx.lineWidth = 2; ctx.stroke();
        ctx.strokeStyle = '#4A0080'; ctx.lineWidth = 1.2; ctx.setLineDash([4,5]);
        ctx.beginPath(); ctx.moveTo(treadX+8, treadY+treadH*0.5); ctx.lineTo(treadX+treadW-8, treadY+treadH*0.5); ctx.stroke();
        ctx.setLineDash([]);
        for (let i = 0; i < 4; i++) {
            const wx = treadX + 22 + i * ((treadW-44)/3), wY = treadY+treadH*0.55;
            ctx.fillStyle = '#3A0060'; ctx.beginPath(); ctx.arc(wx, wY, 14, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#200040'; ctx.lineWidth = 1.2; ctx.stroke();
            ctx.fillStyle = '#6A00B0'; ctx.beginPath(); ctx.arc(wx, wY, 8, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#9A00E0'; ctx.beginPath(); ctx.arc(wx, wY, 3, 0, Math.PI*2); ctx.fill();
        }

        // ドーム本体（紫黒）
        const dRX = tw * 0.50, dRY = th * 0.47;
        const dCX = cx, dCY = treadY - dRY * 0.90;
        const aura = 0.10 + Math.sin(Date.now()*0.004)*0.06;
        ctx.strokeStyle = `rgba(180,0,255,${aura})`; ctx.lineWidth = 8;
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX+12, dRY+12, 0, 0, Math.PI*2); ctx.stroke();
        const domeG = ctx.createRadialGradient(dCX-dRX*0.28, dCY-dRY*0.28, dRX*0.05, dCX, dCY, dRX*1.1);
        domeG.addColorStop(0,'#5A0090'); domeG.addColorStop(0.45,'#2A0050'); domeG.addColorStop(1,'#100020');
        ctx.beginPath(); ctx.ellipse(dCX+5, dCY+5, dRX, dRY, 0, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(0,0,0,0.18)'; ctx.fill();
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI*2);
        ctx.fillStyle = domeG; ctx.fill();
        ctx.strokeStyle = '#7700CC'; ctx.lineWidth = 2; ctx.stroke();
        ctx.beginPath(); ctx.ellipse(dCX-dRX*0.18, dCY-dRY*0.28, dRX*0.28, dRY*0.16, -0.3, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(180,0,255,0.12)'; ctx.fill();

        if (!showInterior) {
            // 悪魔翼（骨翼）
            const wBaseY = dCY - dRY*0.08, wTipY = dCY - dRY*0.62;
            [[-1],[1]].forEach(([s]) => {
                ctx.fillStyle = '#1A0030';
                ctx.beginPath();
                ctx.moveTo(dCX + s*(dRX-4), wBaseY+10);
                ctx.lineTo(dCX + s*(dRX+25), wTipY+15);
                ctx.lineTo(dCX + s*(dRX+38), wTipY-5);
                ctx.lineTo(dCX + s*(dRX+20), wBaseY-22);
                ctx.lineTo(dCX + s*(dRX-4), wBaseY-14);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#5A0090'; ctx.lineWidth = 1.5; ctx.stroke();
                // 骨のラインと先端トゲ
                ctx.strokeStyle = '#7700CC'; ctx.lineWidth = 1;
                ctx.beginPath(); ctx.moveTo(dCX+s*(dRX+2), wBaseY-5); ctx.lineTo(dCX+s*(dRX+30), wTipY+4); ctx.stroke();
                ctx.beginPath(); ctx.moveTo(dCX+s*(dRX+2), wBaseY+3); ctx.lineTo(dCX+s*(dRX+22), wTipY+12); ctx.stroke();
                ctx.fillStyle = '#4A0080';
                ctx.beginPath(); ctx.moveTo(dCX+s*(dRX+34), wTipY-2); ctx.lineTo(dCX+s*(dRX+48), wTipY-14); ctx.lineTo(dCX+s*(dRX+32), wTipY-16); ctx.closePath(); ctx.fill();
            });

            // 魔王城塔（禍々しい）
            const drawMaouTower = (tcx) => {
                const tRad=21, tH=th*0.54, tTopY=treadY-tH;
                const tG2 = ctx.createLinearGradient(tcx-tRad,0,tcx+tRad,0);
                tG2.addColorStop(0,'#1A0A2A'); tG2.addColorStop(0.4,'#2A0A4A'); tG2.addColorStop(1,'#100020');
                ctx.fillStyle = tG2;
                ctx.beginPath(); ctx.rect(tcx-tRad, tTopY, tRad*2, tH); ctx.fill();
                ctx.strokeStyle = 'rgba(120,0,200,0.25)'; ctx.lineWidth = 1;
                for(let r=1;r<=6;r++){const ly=tTopY+r*(tH/7);ctx.beginPath();ctx.moveTo(tcx-tRad+2,ly);ctx.lineTo(tcx+tRad-2,ly);ctx.stroke();}
                ctx.strokeStyle='#5A0090'; ctx.lineWidth=1.8; ctx.strokeRect(tcx-tRad, tTopY, tRad*2, tH);
                // 魔法の窓（光る）
                const winA = 0.4+Math.sin(Date.now()*0.004)*0.2;
                ctx.fillStyle=`rgba(160,0,255,${winA})`;
                ctx.beginPath(); ctx.moveTo(tcx-5, tTopY+tH*0.52); ctx.lineTo(tcx-5, tTopY+tH*0.40); ctx.quadraticCurveTo(tcx-5, tTopY+tH*0.26, tcx, tTopY+tH*0.22); ctx.quadraticCurveTo(tcx+5, tTopY+tH*0.26, tcx+5, tTopY+tH*0.40); ctx.lineTo(tcx+5, tTopY+tH*0.52); ctx.closePath(); ctx.fill();
                // 銃眼3個（スパイク型）
                for(let i=0;i<3;i++){
                    const mx=tcx-14+i*11, mTopY=tTopY-12;
                    ctx.fillStyle='#1A0030'; ctx.strokeStyle='#5A0090'; ctx.lineWidth=0.8;
                    ctx.beginPath(); ctx.moveTo(mx, mTopY+12); ctx.lineTo(mx, mTopY+4); ctx.lineTo(mx+3.5, mTopY); ctx.lineTo(mx+7, mTopY+4); ctx.lineTo(mx+7, mTopY+12); ctx.closePath(); ctx.fill(); ctx.stroke();
                }
                ctx.strokeStyle='#5A0090'; ctx.lineWidth=1.5;
                ctx.beginPath(); ctx.moveTo(tcx-tRad, tTopY); ctx.lineTo(tcx+tRad, tTopY); ctx.stroke();
                // 禍々しい屋根（逆三角スパイク付き）
                ctx.fillStyle='#2A0050';
                ctx.beginPath(); ctx.moveTo(tcx-tRad-3, tTopY-12); ctx.lineTo(tcx, tTopY-12-36); ctx.lineTo(tcx+tRad+3, tTopY-12); ctx.closePath(); ctx.fill();
                ctx.strokeStyle='#7700CC'; ctx.lineWidth=1.5; ctx.stroke();
                ctx.strokeStyle='rgba(180,0,255,0.3)'; ctx.lineWidth=1.5;
                ctx.beginPath(); ctx.moveTo(tcx, tTopY-46); ctx.lineTo(tcx-tRad*0.4, tTopY-14); ctx.stroke();
                // 旗（骸骨旗）
                ctx.strokeStyle='#5A0090'; ctx.lineWidth=1.5;
                ctx.beginPath(); ctx.moveTo(tcx, tTopY-48); ctx.lineTo(tcx, tTopY-66); ctx.stroke();
                ctx.fillStyle='#1A0030';
                ctx.fillRect(tcx, tTopY-66, 20, 14);
                ctx.strokeStyle='#7700CC'; ctx.lineWidth=1; ctx.strokeRect(tcx, tTopY-66, 20, 14);
                ctx.fillStyle='#AA00FF';
                ctx.beginPath(); ctx.arc(tcx+7, tTopY-60, 4, 0, Math.PI*2); ctx.fill();
                // ドクロ目
                ctx.fillStyle='rgba(0,0,0,0.8)';
                ctx.beginPath(); ctx.arc(tcx+5, tTopY-61, 1.5, 0, Math.PI*2); ctx.fill();
                ctx.beginPath(); ctx.arc(tcx+9, tTopY-61, 1.5, 0, Math.PI*2); ctx.fill();
            };
            drawMaouTower(dCX - dRX*0.86);
            drawMaouTower(dCX + dRX*0.86);

            // 角2本（大きく・トゲ付き）
            const hornY = dCY - dRY;
            ctx.fillStyle = '#3A0060';
            ctx.beginPath(); ctx.moveTo(dCX-32, hornY+8); ctx.lineTo(dCX-22, hornY-42); ctx.lineTo(dCX-13, hornY+8); ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#7700CC'; ctx.lineWidth = 1.5; ctx.stroke();
            ctx.beginPath(); ctx.moveTo(dCX+32, hornY+8); ctx.lineTo(dCX+22, hornY-42); ctx.lineTo(dCX+13, hornY+8); ctx.closePath(); ctx.fill();
            ctx.stroke();
            // 角のトゲ
            ctx.fillStyle = '#5A0090';
            ctx.beginPath(); ctx.moveTo(dCX-32, hornY+6); ctx.lineTo(dCX-42, hornY-10); ctx.lineTo(dCX-30, hornY-8); ctx.closePath(); ctx.fill();
            ctx.beginPath(); ctx.moveTo(dCX+32, hornY+6); ctx.lineTo(dCX+42, hornY-10); ctx.lineTo(dCX+30, hornY-8); ctx.closePath(); ctx.fill();

            // 頂上の魔法水晶
            ctx.strokeStyle='#5A0090'; ctx.lineWidth=1.5;
            ctx.beginPath(); ctx.moveTo(dCX, dCY-dRY-2); ctx.lineTo(dCX, dCY-dRY-22); ctx.stroke();
            ctx.fillStyle='#7700CC';
            ctx.beginPath(); ctx.moveTo(dCX-8, dCY-dRY-22); ctx.lineTo(dCX, dCY-dRY-38); ctx.lineTo(dCX+8, dCY-dRY-22); ctx.lineTo(dCX, dCY-dRY-10); ctx.closePath(); ctx.fill();
            ctx.strokeStyle='#AA00FF'; ctx.lineWidth=1; ctx.stroke();
            const cryA = 0.5+Math.sin(Date.now()*0.006)*0.3;
            ctx.fillStyle=`rgba(180,0,255,${cryA})`;
            ctx.beginPath(); ctx.moveTo(dCX-6, dCY-dRY-24); ctx.lineTo(dCX, dCY-dRY-36); ctx.lineTo(dCX+6, dCY-dRY-24); ctx.lineTo(dCX, dCY-dRY-12); ctx.closePath(); ctx.fill();

            // 砲口（紫魔法砲）
            const cX=dCX+dir*dRX*0.28, cY=dCY+dRY*0.12, cR=dRX*0.20;
            ctx.fillStyle='#1A0030'; ctx.beginPath(); ctx.arc(cX, cY, cR+9, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle='#7700CC'; ctx.lineWidth=2; ctx.stroke();
            ctx.fillStyle='#2A0050'; ctx.beginPath(); ctx.arc(cX, cY, cR+5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle='#050505'; ctx.beginPath(); ctx.arc(cX, cY, cR, 0, Math.PI*2); ctx.fill();
            const mA = 0.4+Math.sin(Date.now()*0.005)*0.2;
            ctx.fillStyle=`rgba(160,0,255,${mA})`; ctx.beginPath(); ctx.arc(cX, cY, cR*0.6, 0, Math.PI*2); ctx.fill();
            const bR=cR*0.62, bLen=44;
            ctx.fillStyle='#2A0050'; ctx.strokeStyle='rgba(100,0,180,0.4)'; ctx.lineWidth=1.5;
            ctx.beginPath(); ctx.ellipse(cX+dir*bLen*0.5, cY, Math.abs(dir*bLen)*0.55, bR, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            const ringX3 = cX + dir*bLen*0.65;
            ctx.fillStyle='#3A0060'; ctx.beginPath(); ctx.ellipse(ringX3, cY, 5, bR+3, 0, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle='#1A0030'; ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR+5, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle='#7700CC'; ctx.lineWidth=1.5; ctx.stroke();
            ctx.fillStyle='#050505'; ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR, 0, Math.PI*2); ctx.fill();
            const tipA = 0.5+Math.sin(Date.now()*0.005)*0.3;
            ctx.fillStyle=`rgba(140,0,220,${tipA})`; ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR*0.6, 0, Math.PI*2); ctx.fill();

            // 目（赤スリット）
            const eY=dCY-dRY*0.28;
            [[-1],[1]].forEach(([s]) => {
                const ex = dCX+s*dRX*0.28;
                ctx.fillStyle='#C8C8D8'; ctx.beginPath(); ctx.ellipse(ex, eY, 10, 6, 0, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle='#1A0020'; ctx.beginPath(); ctx.ellipse(ex, eY, 9, 5, 0, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle='#FF0000'; ctx.beginPath(); ctx.ellipse(ex, eY, 2.5, 4.5, 0, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle='rgba(255,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(ex, eY, 8, 3, 0, 0, Math.PI*2); ctx.fill();
            });

            // エンブレム（魔法陣）
            const emX=dCX-dRX*0.28, emY=dCY+dRY*0.36;
            ctx.fillStyle='#0A0015'; ctx.strokeStyle='#5A0090'; ctx.lineWidth=2;
            ctx.beginPath(); ctx.arc(emX, emY, 17, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            ctx.strokeStyle='#7700CC'; ctx.lineWidth=1;
            ctx.beginPath(); ctx.arc(emX, emY, 12, 0, Math.PI*2); ctx.stroke();
            // 五芒星
            ctx.strokeStyle='#AA00FF'; ctx.lineWidth=1.2;
            for(let i=0;i<5;i++){
                const a1=(i*4*Math.PI/5)-Math.PI/2, a2=(i*4*Math.PI/5+2*Math.PI/5)-Math.PI/2;
                if(i===0){ctx.beginPath(); ctx.moveTo(emX+Math.cos(a1)*10, emY+Math.sin(a1)*10);}
                ctx.lineTo(emX+Math.cos(a2)*10, emY+Math.sin(a2)*10);
            }
            ctx.closePath(); ctx.stroke();
            ctx.fillStyle='#7700CC'; ctx.beginPath(); ctx.arc(emX, emY, 4, 0, Math.PI*2); ctx.fill();
        }
        ctx.restore();
    },

    // 🤖 メカスキン（強化版: SF金属城塔・ブレード翼・スキャンライン）
    _drawMechaTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        ctx.save();
        ctx.translate(cx, ty + th);
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(Date.now()*0.05)*2, 0); }
        ctx.translate(-cx, -(ty + th));

        const treadH = 44, treadW = tw * 0.82;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;

        // キャタピラ（メタリック）
        const tG = ctx.createLinearGradient(0, treadY, 0, treadY+treadH);
        tG.addColorStop(0,'#546E7A'); tG.addColorStop(0.5,'#78909C'); tG.addColorStop(1,'#263238');
        ctx.fillStyle = tG;
        this._roundRect(ctx, treadX, treadY, treadW, treadH, 10); ctx.fill();
        ctx.strokeStyle = '#1A252A'; ctx.lineWidth = 2; ctx.stroke();
        ctx.strokeStyle = '#37474F'; ctx.lineWidth = 1.5; ctx.setLineDash([6,4]);
        ctx.beginPath(); ctx.moveTo(treadX+8, treadY+treadH*0.5); ctx.lineTo(treadX+treadW-8, treadY+treadH*0.5); ctx.stroke();
        ctx.setLineDash([]);
        for (let i = 0; i < 4; i++) {
            const wx = treadX + 22 + i * ((treadW-44)/3), wY = treadY+treadH*0.55;
            ctx.fillStyle = '#37474F'; ctx.beginPath(); ctx.arc(wx, wY, 14, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#1A252A'; ctx.lineWidth = 1.2; ctx.stroke();
            ctx.fillStyle = '#607D8B'; ctx.beginPath(); ctx.arc(wx, wY, 8, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#90A4AE'; ctx.beginPath(); ctx.arc(wx, wY, 3.5, 0, Math.PI*2); ctx.fill();
        }

        // ドーム本体（メカ角ばった楕円）
        const dRX = tw * 0.50, dRY = th * 0.47;
        const dCX = cx, dCY = treadY - dRY * 0.90;
        const domeG = ctx.createRadialGradient(dCX-dRX*0.28, dCY-dRY*0.28, dRX*0.05, dCX, dCY, dRX*1.1);
        domeG.addColorStop(0,'#546E7A'); domeG.addColorStop(0.45,'#37474F'); domeG.addColorStop(1,'#1C313A');
        ctx.beginPath(); ctx.ellipse(dCX+5, dCY+5, dRX, dRY, 0, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(0,0,0,0.15)'; ctx.fill();
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI*2);
        ctx.fillStyle = domeG; ctx.fill();
        ctx.strokeStyle = '#78909C'; ctx.lineWidth = 2; ctx.stroke();
        // パネルライン
        ctx.strokeStyle = 'rgba(144,164,174,0.28)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(dCX-dRX*0.4, dCY-dRY*0.6); ctx.lineTo(dCX-dRX*0.4, dCY+dRY*0.6); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(dCX+dRX*0.4, dCY-dRY*0.6); ctx.lineTo(dCX+dRX*0.4, dCY+dRY*0.6); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(dCX-dRX*0.7, dCY); ctx.lineTo(dCX+dRX*0.7, dCY); ctx.stroke();
        // スキャンライン
        const scanY = dCY - dRY + ((Date.now()*0.05) % (dRY*2));
        ctx.strokeStyle = 'rgba(0,200,255,0.22)'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(dCX-dRX*0.6, scanY); ctx.lineTo(dCX+dRX*0.6, scanY); ctx.stroke();
        ctx.beginPath(); ctx.ellipse(dCX-dRX*0.18, dCY-dRY*0.28, dRX*0.28, dRY*0.16, -0.3, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(255,255,255,0.1)'; ctx.fill();

        if (!showInterior) {
            // ブレード翼（SF薄板）
            const wBaseY = dCY - dRY*0.1, wTipY = dCY - dRY*0.65;
            [[-1],[1]].forEach(([s]) => {
                ctx.fillStyle = '#37474F';
                ctx.beginPath();
                ctx.moveTo(dCX + s*(dRX-4), wBaseY+8);
                ctx.lineTo(dCX + s*(dRX+22), wTipY+8);
                ctx.lineTo(dCX + s*(dRX+34), wTipY-6);
                ctx.lineTo(dCX + s*(dRX+18), wBaseY-18);
                ctx.lineTo(dCX + s*(dRX-4), wBaseY-12);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#78909C'; ctx.lineWidth = 1.5; ctx.stroke();
                // 光沢ライン
                ctx.strokeStyle = 'rgba(0,200,255,0.25)'; ctx.lineWidth = 1.5;
                ctx.beginPath(); ctx.moveTo(dCX+s*(dRX+4), wBaseY-4); ctx.lineTo(dCX+s*(dRX+26), wTipY+1); ctx.stroke();
                // SF先端
                ctx.fillStyle = '#546E7A';
                ctx.beginPath(); ctx.moveTo(dCX+s*(dRX+30), wTipY-3); ctx.lineTo(dCX+s*(dRX+44), wTipY-10); ctx.lineTo(dCX+s*(dRX+28), wTipY-14); ctx.closePath(); ctx.fill();
                const antA = 0.4+Math.sin(Date.now()*0.008)*0.4;
                ctx.fillStyle=`rgba(0,200,255,${antA})`;
                ctx.beginPath(); ctx.arc(dCX+s*(dRX+44), wTipY-10, 3, 0, Math.PI*2); ctx.fill();
            });

            // SFメカ城塔
            const drawMechaTower = (tcx) => {
                const tRad=21, tH=th*0.54, tTopY=treadY-tH;
                const tG2 = ctx.createLinearGradient(tcx-tRad,0,tcx+tRad,0);
                tG2.addColorStop(0,'#37474F'); tG2.addColorStop(0.4,'#546E7A'); tG2.addColorStop(1,'#2A3A42');
                ctx.fillStyle = tG2;
                ctx.beginPath(); ctx.rect(tcx-tRad, tTopY, tRad*2, tH); ctx.fill();
                ctx.strokeStyle = 'rgba(144,164,174,0.3)'; ctx.lineWidth = 1;
                for(let r=1;r<=6;r++){const ly=tTopY+r*(tH/7);ctx.beginPath();ctx.moveTo(tcx-tRad+2,ly);ctx.lineTo(tcx+tRad-2,ly);ctx.stroke();}
                // パネルライン縦
                ctx.beginPath(); ctx.moveTo(tcx, tTopY+tH*0.1); ctx.lineTo(tcx, tTopY+tH*0.9); ctx.stroke();
                ctx.strokeStyle='#78909C'; ctx.lineWidth=1.8; ctx.strokeRect(tcx-tRad, tTopY, tRad*2, tH);
                // カメラ眼
                const blink = Math.floor(Date.now()/3000)%5===0 ? 2 : 8;
                ctx.fillStyle='#00BCD4'; ctx.beginPath(); ctx.arc(tcx, tTopY+tH*0.40, 9, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle='#0A0A14'; ctx.beginPath(); ctx.arc(tcx, tTopY+tH*0.40, blink, 0, Math.PI*2); ctx.fill();
                const cA2 = 0.5+Math.sin(Date.now()*0.006)*0.3;
                ctx.fillStyle=`rgba(0,200,255,${cA2})`; ctx.beginPath(); ctx.arc(tcx+2, tTopY+tH*0.40-2, 2.5, 0, Math.PI*2); ctx.fill();
                // 銃眼3個（SF型）
                for(let i=0;i<3;i++){
                    ctx.fillStyle='#263238'; ctx.strokeStyle='#607D8B'; ctx.lineWidth=0.8;
                    ctx.beginPath(); ctx.rect(tcx-14+i*11, tTopY-11, 7,12); ctx.fill(); ctx.stroke();
                }
                ctx.strokeStyle='#607D8B'; ctx.lineWidth=1.5;
                ctx.beginPath(); ctx.moveTo(tcx-tRad, tTopY); ctx.lineTo(tcx+tRad, tTopY); ctx.stroke();
                // 角ばった屋根
                ctx.fillStyle='#37474F';
                ctx.beginPath(); ctx.moveTo(tcx-tRad-2, tTopY-11); ctx.lineTo(tcx-tRad*0.3, tTopY-11-20); ctx.lineTo(tcx+tRad*0.3, tTopY-11-20); ctx.lineTo(tcx+tRad+2, tTopY-11); ctx.closePath(); ctx.fill();
                ctx.strokeStyle='#78909C'; ctx.lineWidth=1.5; ctx.stroke();
                // アンテナ
                const antA2 = 0.5+Math.sin(Date.now()*0.007)*0.4;
                ctx.strokeStyle='#00BCD4'; ctx.lineWidth=1.5;
                ctx.beginPath(); ctx.moveTo(tcx, tTopY-31); ctx.lineTo(tcx, tTopY-52); ctx.stroke();
                ctx.fillStyle=`rgba(0,200,255,${antA2})`;
                ctx.beginPath(); ctx.arc(tcx, tTopY-52, 4, 0, Math.PI*2); ctx.fill();
            };
            drawMechaTower(dCX - dRX*0.86);
            drawMechaTower(dCX + dRX*0.86);

            // 頂上：回転レーダー
            ctx.strokeStyle='#607D8B'; ctx.lineWidth=1.5;
            ctx.beginPath(); ctx.moveTo(dCX, dCY-dRY-2); ctx.lineTo(dCX, dCY-dRY-20); ctx.stroke();
            const radAng = (Date.now()*0.003) % (Math.PI*2);
            ctx.strokeStyle='rgba(0,200,255,0.7)'; ctx.lineWidth=2;
            ctx.beginPath(); ctx.moveTo(dCX, dCY-dRY-20); ctx.lineTo(dCX+Math.cos(radAng)*18, dCY-dRY-20+Math.sin(radAng)*6); ctx.stroke();
            ctx.strokeStyle='rgba(0,200,255,0.3)'; ctx.lineWidth=1;
            ctx.beginPath(); ctx.ellipse(dCX, dCY-dRY-20, 18, 6, 0, 0, Math.PI*2); ctx.stroke();

            // 砲口（SF・シアン）
            const cX=dCX+dir*dRX*0.28, cY=dCY+dRY*0.12, cR=dRX*0.20;
            ctx.fillStyle='#263238'; ctx.beginPath(); ctx.arc(cX, cY, cR+9, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle='#607D8B'; ctx.lineWidth=2; ctx.stroke();
            ctx.fillStyle='#37474F'; ctx.beginPath(); ctx.arc(cX, cY, cR+5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle='#050810'; ctx.beginPath(); ctx.arc(cX, cY, cR, 0, Math.PI*2); ctx.fill();
            const bR=cR*0.62, bLen=44;
            const bG = ctx.createLinearGradient(cX, cY-bR, cX, cY+bR);
            bG.addColorStop(0,'#90A4AE'); bG.addColorStop(0.4,'#B0BEC5'); bG.addColorStop(1,'#455A64');
            ctx.fillStyle=bG; ctx.strokeStyle='rgba(0,0,0,0.35)'; ctx.lineWidth=1.5;
            ctx.beginPath(); ctx.ellipse(cX+dir*bLen*0.5, cY, Math.abs(dir*bLen)*0.55, bR, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            ctx.fillStyle='#263238'; ctx.beginPath(); ctx.ellipse(cX+bLen*0.65, cY, 5, bR+3, 0, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle='#263238'; ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR+5, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle='#607D8B'; ctx.lineWidth=1.5; ctx.stroke();
            const glA = 0.5+Math.sin(Date.now()*0.005)*0.3;
            ctx.fillStyle=`rgba(0,200,255,${glA})`; ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR*0.7, 0, Math.PI*2); ctx.fill();

            // 目（カメラ）
            const blink2 = Math.floor(Date.now()/3000)%5===0 ? 2 : 9;
            const eY=dCY-dRY*0.28;
            [[-1],[1]].forEach(([s]) => {
                const ex=dCX+s*dRX*0.28;
                ctx.fillStyle='#00BCD4'; ctx.beginPath(); ctx.arc(ex, eY, 11, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle='#0A0A14'; ctx.beginPath(); ctx.arc(ex, eY, blink2, 0, Math.PI*2); ctx.fill();
                const cA3 = 0.5+Math.sin(Date.now()*0.007)*0.3;
                ctx.fillStyle=`rgba(0,200,255,${cA3})`; ctx.beginPath(); ctx.arc(ex+3, eY-3, 3, 0, Math.PI*2); ctx.fill();
            });

            // エンブレム（回路基板風）
            const emX=dCX-dRX*0.28, emY=dCY+dRY*0.36;
            ctx.fillStyle='#1C313A'; ctx.strokeStyle='#607D8B'; ctx.lineWidth=2;
            ctx.beginPath(); ctx.arc(emX, emY, 17, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            ctx.strokeStyle='rgba(0,200,255,0.5)'; ctx.lineWidth=1;
            ctx.beginPath(); ctx.arc(emX, emY, 12, 0, Math.PI*2); ctx.stroke();
            // 回路ライン
            ctx.strokeStyle='rgba(0,200,255,0.6)'; ctx.lineWidth=1.2;
            [-8,0,8].forEach(x => { ctx.beginPath(); ctx.moveTo(emX+x, emY-10); ctx.lineTo(emX+x, emY+10); ctx.stroke(); });
            [-8,0,8].forEach(y => { ctx.beginPath(); ctx.moveTo(emX-10, emY+y); ctx.lineTo(emX+10, emY+y); ctx.stroke(); });
            ctx.fillStyle='#00BCD4'; ctx.beginPath(); ctx.arc(emX, emY, 4, 0, Math.PI*2); ctx.fill();
        }
        ctx.restore();
    },

    // 👻 ゴーストスキン（強化版: 半透明城塔・霊体翼・浮遊）
    _drawGhostTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        ctx.save();
        const ghostAlpha = 0.72 + Math.sin(Date.now()*0.003)*0.14;
        ctx.globalAlpha = ghostAlpha;
        ctx.translate(cx, ty + th);
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(Date.now()*0.05)*2, 0); }
        ctx.translate(-cx, -(ty + th));

        const treadH = 40, treadW = tw * 0.78;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;
        const float = Math.sin(Date.now()*0.002)*7;

        // キャタピラ（半透明）
        ctx.fillStyle = 'rgba(180,190,220,0.45)';
        this._roundRect(ctx, treadX, treadY, treadW, treadH, 10); ctx.fill();
        ctx.strokeStyle = 'rgba(150,160,200,0.3)'; ctx.lineWidth = 1.5; ctx.stroke();
        for (let i = 0; i < 4; i++) {
            const wx = treadX + 22 + i * ((treadW-44)/3), wY = treadY+treadH*0.55;
            ctx.fillStyle = 'rgba(160,170,210,0.5)'; ctx.beginPath(); ctx.arc(wx, wY, 12, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = 'rgba(200,210,240,0.4)'; ctx.beginPath(); ctx.arc(wx, wY, 6, 0, Math.PI*2); ctx.fill();
        }

        // ドーム（幽霊船型・ひらひら）
        const dRX = tw * 0.50, dRY = th * 0.46;
        const dCX = cx, dCY = treadY - dRY * 0.88 + float;
        const ripple = Math.sin(Date.now()*0.005);
        const dG = ctx.createRadialGradient(dCX-dRX*0.2, dCY-dRY*0.3, dRX*0.05, dCX, dCY, dRX);
        dG.addColorStop(0,'rgba(220,230,255,0.88)');
        dG.addColorStop(0.5,'rgba(160,170,210,0.78)');
        dG.addColorStop(1,'rgba(80,90,150,0.62)');
        ctx.beginPath();
        ctx.moveTo(dCX-dRX, dCY);
        ctx.bezierCurveTo(dCX-dRX, dCY-dRY*1.15, dCX-dRX*0.28, dCY-dRY*1.32, dCX, dCY-dRY*1.22);
        ctx.bezierCurveTo(dCX+dRX*0.28, dCY-dRY*1.32, dCX+dRX, dCY-dRY*1.15, dCX+dRX, dCY);
        ctx.bezierCurveTo(dCX+dRX*0.78, dCY+dRY*0.52+ripple*9, dCX+dRX*0.38, dCY+dRY*0.30, dCX, dCY+dRY*0.54+ripple*7);
        ctx.bezierCurveTo(dCX-dRX*0.38, dCY+dRY*0.30, dCX-dRX*0.78, dCY+dRY*0.52+ripple*9, dCX-dRX, dCY);
        ctx.closePath();
        ctx.fillStyle = dG; ctx.fill();
        ctx.strokeStyle = 'rgba(200,210,255,0.35)'; ctx.lineWidth = 2; ctx.stroke();

        if (!showInterior) {
            // 霊体翼（半透明のヴェール）
            [[-1],[1]].forEach(([s]) => {
                const wBaseY = dCY - dRY*0.05, wTipY = dCY - dRY*0.58;
                const veilRipple = Math.sin(Date.now()*0.004+s)*5;
                ctx.fillStyle = 'rgba(200,210,255,0.25)';
                ctx.beginPath();
                ctx.moveTo(dCX+s*(dRX-2), wBaseY+8);
                ctx.bezierCurveTo(dCX+s*(dRX+16), wTipY+12+veilRipple, dCX+s*(dRX+28), wTipY+4, dCX+s*(dRX+32), wTipY-8);
                ctx.bezierCurveTo(dCX+s*(dRX+22), wBaseY-16+veilRipple, dCX+s*(dRX+8), wBaseY-14, dCX+s*(dRX-2), wBaseY-10);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = 'rgba(200,220,255,0.2)'; ctx.lineWidth = 1; ctx.stroke();
            });

            // 幽霊城塔（霧の中に浮かぶ）
            const drawGhostTower = (tcx) => {
                const tRad=20, tH=th*0.50, tTopY=treadY-tH+float;
                const tG2 = ctx.createLinearGradient(tcx-tRad,0,tcx+tRad,0);
                tG2.addColorStop(0,'rgba(130,140,180,0.55)');
                tG2.addColorStop(0.4,'rgba(180,190,230,0.65)');
                tG2.addColorStop(1,'rgba(110,120,160,0.55)');
                ctx.fillStyle = tG2;
                ctx.beginPath(); ctx.rect(tcx-tRad, tTopY, tRad*2, tH); ctx.fill();
                ctx.strokeStyle='rgba(180,190,230,0.25)'; ctx.lineWidth=1;
                for(let r=1;r<=5;r++){const ly=tTopY+r*(tH/6);ctx.beginPath();ctx.moveTo(tcx-tRad+2,ly);ctx.lineTo(tcx+tRad-2,ly);ctx.stroke();}
                ctx.strokeStyle='rgba(200,210,255,0.3)'; ctx.lineWidth=1.5; ctx.strokeRect(tcx-tRad, tTopY, tRad*2, tH);
                // 窓（光る）
                const wA = 0.3+Math.sin(Date.now()*0.003+tcx)*0.2;
                ctx.fillStyle=`rgba(220,240,255,${wA})`;
                ctx.beginPath(); ctx.moveTo(tcx-5, tTopY+tH*0.52); ctx.lineTo(tcx-5, tTopY+tH*0.40); ctx.quadraticCurveTo(tcx-5, tTopY+tH*0.27, tcx, tTopY+tH*0.23); ctx.quadraticCurveTo(tcx+5, tTopY+tH*0.27, tcx+5, tTopY+tH*0.40); ctx.lineTo(tcx+5, tTopY+tH*0.52); ctx.closePath(); ctx.fill();
                // 銃眼3個
                for(let i=0;i<3;i++){
                    ctx.fillStyle='rgba(80,90,140,0.6)'; ctx.strokeStyle='rgba(160,170,210,0.4)'; ctx.lineWidth=0.8;
                    ctx.beginPath(); ctx.rect(tcx-13+i*10, tTopY-10, 6,10); ctx.fill(); ctx.stroke();
                }
                ctx.strokeStyle='rgba(180,190,230,0.3)'; ctx.lineWidth=1.5;
                ctx.beginPath(); ctx.moveTo(tcx-tRad, tTopY); ctx.lineTo(tcx+tRad, tTopY); ctx.stroke();
                // 幽霊三角屋根
                ctx.fillStyle='rgba(140,150,200,0.5)';
                ctx.beginPath(); ctx.moveTo(tcx-tRad-3, tTopY-10); ctx.lineTo(tcx, tTopY-10-28); ctx.lineTo(tcx+tRad+3, tTopY-10); ctx.closePath(); ctx.fill();
                ctx.strokeStyle='rgba(200,210,255,0.3)'; ctx.lineWidth=1.5; ctx.stroke();
                // 旗（霧の旗）
                ctx.strokeStyle='rgba(150,160,200,0.5)'; ctx.lineWidth=1.5;
                ctx.beginPath(); ctx.moveTo(tcx, tTopY-38); ctx.lineTo(tcx, tTopY-56); ctx.stroke();
                ctx.fillStyle='rgba(220,230,255,0.55)';
                ctx.beginPath(); ctx.moveTo(tcx, tTopY-56); ctx.lineTo(tcx+13, tTopY-50); ctx.lineTo(tcx, tTopY-44); ctx.closePath(); ctx.fill();
            };
            drawGhostTower(dCX - dRX*0.86);
            drawGhostTower(dCX + dRX*0.86);

            // 頂上：幽霊の炎
            for(let i=0;i<3;i++){
                const fA = 0.3+Math.sin(Date.now()*0.005+i)*0.2;
                const fOff = Math.sin(Date.now()*0.003+i*1.1)*4;
                ctx.fillStyle=`rgba(200,220,255,${fA})`;
                ctx.beginPath(); ctx.moveTo(dCX-5+i*5, dCY-dRY*1.20+float); ctx.quadraticCurveTo(dCX-4+i*5+fOff, dCY-dRY*1.30+float, dCX-2+i*5, dCY-dRY*1.40+float); ctx.quadraticCurveTo(dCX+i*5+fOff, dCY-dRY*1.32+float, dCX+3+i*5, dCY-dRY*1.20+float); ctx.closePath(); ctx.fill();
            }

            // 砲口（霧砲）
            const cX=dCX+dir*dRX*0.28, cY=dCY+dRY*0.12, cR=dRX*0.20;
            ctx.fillStyle='rgba(130,140,190,0.5)'; ctx.beginPath(); ctx.arc(cX, cY, cR+9, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle='rgba(180,190,230,0.3)'; ctx.lineWidth=2; ctx.stroke();
            ctx.fillStyle='rgba(160,170,220,0.55)'; ctx.beginPath(); ctx.arc(cX, cY, cR+5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle='rgba(20,20,60,0.7)'; ctx.beginPath(); ctx.arc(cX, cY, cR, 0, Math.PI*2); ctx.fill();
            const bR=cR*0.62, bLen=44;
            ctx.fillStyle='rgba(180,190,230,0.45)'; ctx.strokeStyle='rgba(200,210,255,0.2)'; ctx.lineWidth=1.5;
            ctx.beginPath(); ctx.ellipse(cX+dir*bLen*0.5, cY, Math.abs(dir*bLen)*0.55, bR, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            ctx.fillStyle='rgba(130,140,190,0.5)'; ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR+5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle='rgba(20,20,60,0.7)'; ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR, 0, Math.PI*2); ctx.fill();

            // 目（大きな丸目・ゆらゆら）
            const eY=dCY-dRY*0.26;
            [[-1],[1]].forEach(([s]) => {
                const ex=dCX+s*dRX*0.28;
                ctx.fillStyle='rgba(15,15,40,0.9)'; ctx.beginPath(); ctx.arc(ex, eY, 11, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle='rgba(255,255,255,0.75)'; ctx.beginPath(); ctx.arc(ex-3, eY-3, 4, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle='rgba(200,220,255,0.9)'; ctx.beginPath(); ctx.arc(ex, eY, 5, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle='rgba(15,15,40,0.9)'; ctx.beginPath(); ctx.arc(ex+1, eY+1, 3, 0, Math.PI*2); ctx.fill();
            });

            // 幽霊パーティクル
            for (let i = 0; i < 6; i++) {
                const px = dCX + Math.sin(Date.now()*0.002 + i*1.05)*dRX*0.72;
                const py = dCY - dRY*0.45 + Math.cos(Date.now()*0.002 + i*1.05)*dRY*0.52 + float;
                const pa = 0.25 + Math.sin(Date.now()*0.004 + i)*0.18;
                ctx.fillStyle = `rgba(200,220,255,${pa})`;
                ctx.beginPath(); ctx.arc(px, py, 3.5, 0, Math.PI*2); ctx.fill();
            }

            // エンブレム（幽霊紋章）
            const emX=dCX-dRX*0.28, emY=dCY+dRY*0.34;
            ctx.fillStyle='rgba(60,70,120,0.5)'; ctx.strokeStyle='rgba(180,190,230,0.4)'; ctx.lineWidth=2;
            ctx.beginPath(); ctx.arc(emX, emY, 17, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            ctx.fillStyle='rgba(100,110,170,0.45)'; ctx.beginPath(); ctx.arc(emX, emY, 11, 0, Math.PI*2); ctx.fill();
            // 幽霊シルエット
            ctx.fillStyle='rgba(200,220,255,0.6)';
            ctx.beginPath(); ctx.arc(emX, emY-3, 6, Math.PI, 0); ctx.lineTo(emX+6, emY+5); ctx.quadraticCurveTo(emX+3, emY+2, emX, emY+5); ctx.quadraticCurveTo(emX-3, emY+2, emX-6, emY+5); ctx.closePath(); ctx.fill();
        }
        ctx.restore();
    },

    // 💰 借金王スキン（隠し＆中ボス共用）
    _drawShakkinTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle, isEnemy = false) {
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        ctx.save();
        ctx.translate(cx, ty + th);
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(Date.now()*0.05)*3, Math.sin(Date.now()*0.07)*2); }
        // 傾いてるボロ戦車
        ctx.rotate(Math.sin(Date.now()*0.001)*0.03);
        ctx.translate(-cx, -(ty + th));

        const treadH = 40, treadW = tw * 0.78;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;

        // キャタピラ（ボロいゴールド）
        const tG = ctx.createLinearGradient(0, treadY, 0, treadY+treadH);
        tG.addColorStop(0, '#B8860B'); tG.addColorStop(1, '#6B4C00');
        ctx.fillStyle = tG;
        this._roundRect(ctx, treadX, treadY, treadW, treadH, 8); ctx.fill();
        ctx.strokeStyle = '#4A3000'; ctx.lineWidth = 2; ctx.stroke();
        // キズ
        ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(treadX+20, treadY+5); ctx.lineTo(treadX+40, treadY+30); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(treadX+treadW-30, treadY+8); ctx.lineTo(treadX+treadW-10, treadY+25); ctx.stroke();
        for (let i = 0; i < 4; i++) {
            const wx = treadX + 20 + i * ((treadW-40)/3);
            ctx.fillStyle = '#9A7A00'; ctx.beginPath(); ctx.arc(wx, treadY+treadH*0.55, 13, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#C8A000'; ctx.beginPath(); ctx.arc(wx, treadY+treadH*0.55, 6, 0, Math.PI*2); ctx.fill();
        }

        // 本体（ボコボコゴールドドーム）
        const dCY = treadY - th*0.37;
        const dRX = tw*0.47, dRY = th*0.41;
        const dG = ctx.createRadialGradient(cx-dRX*0.25, dCY-dRY*0.25, dRX*0.05, cx, dCY, dRX);
        dG.addColorStop(0, '#FFD740'); dG.addColorStop(0.4, '#FFA000'); dG.addColorStop(1, '#6B4C00');
        ctx.fillStyle = dG;
        ctx.beginPath(); ctx.ellipse(cx, dCY, dRX, dRY, 0, 0, Math.PI*2); ctx.fill();
        ctx.strokeStyle = '#4A3000'; ctx.lineWidth = 2.5; ctx.stroke();

        // ヒビ・キズ
        ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(cx-20, dCY-dRY*0.5); ctx.lineTo(cx-5, dCY-dRY*0.1); ctx.lineTo(cx-15, dCY+dRY*0.3); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx+15, dCY-dRY*0.3); ctx.lineTo(cx+25, dCY+dRY*0.2); ctx.stroke();

        // お金のマーク貼り付け
        ctx.fillStyle = '#FFD700';
        ctx.font = 'bold 22px serif';
        ctx.textAlign = 'center';
        ctx.fillText('💰', cx-5, dCY+8);

        if (!showInterior) {
            // 目（ギラギラお金目）
            ctx.fillStyle = '#FFD700';
            ctx.beginPath(); ctx.arc(cx-18, dCY-dRY*0.22, 10, 0, Math.PI*2); ctx.fill();
            ctx.beginPath(); ctx.arc(cx+18, dCY-dRY*0.22, 10, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#1A0000';
            ctx.beginPath(); ctx.arc(cx-18, dCY-dRY*0.22, 6, 0, Math.PI*2); ctx.fill();
            ctx.beginPath(); ctx.arc(cx+18, dCY-dRY*0.22, 6, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#FFD700'; ctx.font = 'bold 7px serif'; ctx.textAlign = 'center';
            ctx.fillText('$', cx-18, dCY-dRY*0.22+3);
            ctx.fillText('$', cx+18, dCY-dRY*0.22+3);

            // 砲身（借用書ランチャー）
            ctx.fillStyle = '#B8860B';
            ctx.fillRect(dir>0 ? cx + tw*0.1 : cx - tw*0.1 - 48, dCY + dRY*0.12, 48, 13);
            ctx.fillStyle = '#FFD700';
            ctx.fillRect(dir>0 ? cx + tw*0.1 + 43 : cx - tw*0.1 - 53, dCY + dRY*0.12 - 2, 10, 17);
            // 📝マーク
            ctx.font = '12px serif'; ctx.fillText('📝', dir>0 ? cx + tw*0.1 + 47 : cx - tw*0.1 - 43, dCY + dRY*0.12 + 10);

            // 旗（履歴書）
            ctx.strokeStyle = '#8B6914'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.moveTo(cx-5, dCY-dRY-5); ctx.lineTo(cx-5, dCY-dRY-38); ctx.stroke();
            ctx.fillStyle = '#FFFFF0';
            ctx.fillRect(cx-5, dCY-dRY-38, 28, 20);
            ctx.strokeStyle = '#CCC'; ctx.lineWidth = 1;
            ctx.strokeRect(cx-5, dCY-dRY-38, 28, 20);
            ctx.fillStyle = '#888'; ctx.font = '7px sans-serif'; ctx.textAlign = 'left';
            ctx.fillText('履歴書', cx-2, dCY-dRY-25);
        }
        ctx.restore();
    },

    // === 敵タイプ別専用描画（スキン流用） ===

    // SCOUT：素早い軽量型 → enemyColorベースの明るい配色で独自描画
    _drawEnemyScout(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle) {
        const cx = tx + tw / 2;
        const dir = -1;
        const variant = this._getStageEnemyVariant(battle);
        const baseColor = variant.base;
        const lighten = (hex, amt) => {
            const n = parseInt(hex.replace('#',''), 16);
            const r = Math.min(255, ((n>>16)&0xff) + amt);
            const g = Math.min(255, ((n>>8)&0xff) + amt);
            const b = Math.min(255, (n&0xff) + amt);
            return `rgb(${r},${g},${b})`;
        };
        const darken = (hex, amt) => lighten(hex, -amt);
        const bodyBase   = baseColor;
        const bodyHigh   = variant.high;
        const bodyShadow = variant.shadow;
        const accentColor = variant.accent;

        ctx.save();
        ctx.translate(cx, ty + th);
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(Date.now()*0.05)*2, 0); }
        ctx.scale(0.92, 1.0);
        ctx.translate(-cx, -(ty + th));

        const treadH = 38, treadW = tw * 0.78;
        const treadX = cx - treadW/2, treadY = ty + th - treadH;
        const tG = ctx.createLinearGradient(0, treadY, 0, treadY+treadH);
        tG.addColorStop(0, darken(baseColor, 40));
        tG.addColorStop(0.5, darken(baseColor, 20));
        tG.addColorStop(1, darken(baseColor, 70));
        ctx.fillStyle = tG;
        this._roundRect(ctx, treadX, treadY, treadW, treadH, 8); ctx.fill();
        ctx.strokeStyle = darken(baseColor, 80); ctx.lineWidth = 1.5; ctx.stroke();
        for (let i = 0; i < 4; i++) {
            const wx = treadX + 18 + i * ((treadW-36)/3), wY = treadY + treadH*0.55;
            ctx.fillStyle = darken(baseColor, 50); ctx.beginPath(); ctx.arc(wx, wY, 11, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = darken(baseColor, 80); ctx.lineWidth = 1.2; ctx.stroke();
            ctx.fillStyle = darken(baseColor, 20); ctx.beginPath(); ctx.arc(wx, wY, 6, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = accentColor; ctx.beginPath(); ctx.arc(wx, wY, 2.5, 0, Math.PI*2); ctx.fill();
        }
        const dRX = tw * 0.50, dRY = th * 0.40;
        const dCX = cx, dCY = treadY - dRY * 0.88;
        const domeG = ctx.createRadialGradient(dCX-dRX*0.3, dCY-dRY*0.35, dRX*0.05, dCX, dCY, dRX*1.1);
        domeG.addColorStop(0, bodyHigh);
        domeG.addColorStop(0.45, bodyBase);
        domeG.addColorStop(1, bodyShadow);
        ctx.beginPath(); ctx.ellipse(dCX+4, dCY+4, dRX, dRY, 0, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(0,0,0,0.15)'; ctx.fill();
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI*2);
        ctx.fillStyle = domeG; ctx.fill();
        ctx.strokeStyle = darken(baseColor, 30); ctx.lineWidth = 2; ctx.stroke();
        ctx.beginPath(); ctx.ellipse(dCX-dRX*0.2, dCY-dRY*0.3, dRX*0.3, dRY*0.15, -0.3, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.fill();

        if (!showInterior) {
            ctx.strokeStyle = accentColor; ctx.lineWidth = 1.8; ctx.globalAlpha = 0.5;
            for (let i = 0; i < 3; i++) {
                const lY = dCY - dRY*0.1 + i*10;
                ctx.beginPath(); ctx.moveTo(dCX-dRX*0.9, lY); ctx.lineTo(dCX-dRX*0.3, lY); ctx.stroke();
                ctx.beginPath(); ctx.moveTo(dCX+dRX*0.3, lY); ctx.lineTo(dCX+dRX*0.9, lY); ctx.stroke();
            }
            ctx.globalAlpha = 1.0;
            [[dCX-dRX*0.78], [dCX+dRX*0.78]].forEach(([tcx]) => {
                const tR=14, tH=th*0.45, tTopY=treadY-tH;
                const tG2 = ctx.createLinearGradient(tcx-tR, 0, tcx+tR, 0);
                tG2.addColorStop(0, bodyShadow); tG2.addColorStop(0.5, bodyBase); tG2.addColorStop(1, bodyShadow);
                ctx.fillStyle = tG2; ctx.beginPath(); ctx.rect(tcx-tR, tTopY, tR*2, tH); ctx.fill();
                ctx.strokeStyle = darken(baseColor, 20); ctx.lineWidth = 1.5; ctx.strokeRect(tcx-tR, tTopY, tR*2, tH);
                ctx.strokeStyle = darken(baseColor, 30); ctx.lineWidth = 1.5;
                ctx.beginPath(); ctx.moveTo(tcx, tTopY-2); ctx.lineTo(tcx, tTopY-22); ctx.stroke();
                ctx.fillStyle = accentColor;
                ctx.beginPath(); ctx.moveTo(tcx, tTopY-22); ctx.lineTo(tcx+10, tTopY-17); ctx.lineTo(tcx, tTopY-12); ctx.closePath(); ctx.fill();
            });
            const cX = dCX+dir*dRX*0.3, cY = dCY+dRY*0.12, cR = dRX*0.19;
            ctx.fillStyle = bodyShadow; ctx.beginPath(); ctx.arc(cX, cY, cR+7, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = darken(baseColor, 20); ctx.lineWidth = 1.5; ctx.stroke();
            ctx.fillStyle = darken(baseColor, 40); ctx.beginPath(); ctx.arc(cX, cY, cR, 0, Math.PI*2); ctx.fill();
            const bR = cR*0.6, bLen = 42;
            ctx.fillStyle = darken(baseColor, 30);
            ctx.beginPath(); ctx.ellipse(cX+dir*bLen*0.5, cY, Math.abs(dir*bLen)*0.52, bR, 0, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = darken(baseColor, 50); ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR+4, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = darken(baseColor, 80); ctx.beginPath(); ctx.arc(cX+dir*bLen, cY, bR, 0, Math.PI*2); ctx.fill();
            const eY = dCY - dRY*0.25;
            ctx.fillStyle = accentColor;
            ctx.beginPath(); ctx.arc(dCX-dRX*0.26, eY, 6, 0, Math.PI*2); ctx.fill();
            ctx.beginPath(); ctx.arc(dCX+dRX*0.10, eY, 6, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = darken(baseColor, 60);
            ctx.beginPath(); ctx.arc(dCX-dRX*0.26, eY, 3, 0, Math.PI*2); ctx.fill();
            ctx.beginPath(); ctx.arc(dCX+dRX*0.10, eY, 3, 0, Math.PI*2); ctx.fill();
        }
        this._drawStageEnemyOverlay(ctx, tx, ty, tw, th, battle, 0.95);
        ctx.restore();
    },

    // ========================================================
    // 第二形態専用スキン
    // ========================================================

    // 真・魔王タンク 覚醒形態（stage8 第二形態）
    // 魔王スキンをベースに黒×金オーラ・3本角・紅の目・炎翼を追加
    _drawTrueMaouTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        const t = Date.now();
        ctx.save();
        ctx.translate(cx, ty + th);
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(t * 0.05) * 3, 0); }
        ctx.translate(-cx, -(ty + th));

        const treadH = 46, treadW = tw * 0.84;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;

        // ── 地面オーラ（黒炎の輪）──
        const auraR = 0.06 + Math.sin(t * 0.003) * 0.04;
        const auraG = ctx.createRadialGradient(cx, treadY + treadH, 0, cx, treadY + treadH, treadW * 0.7);
        auraG.addColorStop(0, `rgba(180,0,255,${auraR * 3})`);
        auraG.addColorStop(0.5, `rgba(80,0,120,${auraR})`);
        auraG.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = auraG;
        ctx.beginPath(); ctx.ellipse(cx, treadY + treadH * 0.8, treadW * 0.7, treadH * 0.4, 0, 0, Math.PI * 2); ctx.fill();

        // ── キャタピラ（黒×金）──
        const tG = ctx.createLinearGradient(0, treadY, 0, treadY + treadH);
        tG.addColorStop(0, '#0A0000'); tG.addColorStop(0.5, '#1A0A00'); tG.addColorStop(1, '#000000');
        ctx.fillStyle = tG;
        this._roundRect(ctx, treadX, treadY, treadW, treadH, 10); ctx.fill();
        ctx.strokeStyle = '#AA7700'; ctx.lineWidth = 2.5; ctx.stroke();
        for (let i = 0; i < 4; i++) {
            const wx = treadX + 22 + i * ((treadW - 44) / 3), wY = treadY + treadH * 0.55;
            ctx.fillStyle = '#1A0A00'; ctx.beginPath(); ctx.arc(wx, wY, 14, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#AA7700'; ctx.lineWidth = 1.5; ctx.stroke();
            ctx.fillStyle = '#CC9900'; ctx.beginPath(); ctx.arc(wx, wY, 7, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#FFD700'; ctx.beginPath(); ctx.arc(wx, wY, 3, 0, Math.PI * 2); ctx.fill();
        }

        // ── ドーム本体（黒×紫×金グロー）──
        const dRX = tw * 0.52, dRY = th * 0.49;
        const dCX = cx, dCY = treadY - dRY * 0.90;
        // 外側金オーラ（脈動）
        const outerA = 0.18 + Math.sin(t * 0.005) * 0.10;
        ctx.strokeStyle = `rgba(255,180,0,${outerA})`; ctx.lineWidth = 12;
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX + 16, dRY + 16, 0, 0, Math.PI * 2); ctx.stroke();
        ctx.strokeStyle = `rgba(220,0,255,${outerA * 0.6})`; ctx.lineWidth = 6;
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX + 8, dRY + 8, 0, 0, Math.PI * 2); ctx.stroke();
        // ドーム本体
        const domeG = ctx.createRadialGradient(dCX - dRX * 0.25, dCY - dRY * 0.28, dRX * 0.05, dCX, dCY, dRX * 1.1);
        domeG.addColorStop(0, '#3A0A00'); domeG.addColorStop(0.4, '#1A0000'); domeG.addColorStop(1, '#050000');
        ctx.beginPath(); ctx.ellipse(dCX + 6, dCY + 6, dRX, dRY, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fill();
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI * 2);
        ctx.fillStyle = domeG; ctx.fill();
        ctx.strokeStyle = '#CC8800'; ctx.lineWidth = 2.5; ctx.stroke();

        if (!showInterior) {
            // ── 炎翼（金と赤）──
            const wFlap = Math.sin(t * 0.006) * 8;
            [[-1], [1]].forEach(([s]) => {
                // 外翼（炎色）
                ctx.fillStyle = `rgba(220,80,0,0.65)`;
                ctx.beginPath();
                ctx.moveTo(dCX + s * (dRX - 2), dCY + dRY * 0.08);
                ctx.bezierCurveTo(dCX + s * (dRX + 30), dCY - dRY * 0.5 + wFlap, dCX + s * (dRX + 55), dCY - dRY * 0.7 + wFlap, dCX + s * (dRX + 60), dCY - dRY * 0.9 + wFlap);
                ctx.bezierCurveTo(dCX + s * (dRX + 38), dCY - dRY * 0.55, dCX + s * (dRX + 14), dCY - dRY * 0.25, dCX + s * (dRX - 2), dCY - dRY * 0.12);
                ctx.closePath(); ctx.fill();
                // 内翼（金）
                ctx.fillStyle = `rgba(255,200,0,0.50)`;
                ctx.beginPath();
                ctx.moveTo(dCX + s * (dRX - 2), dCY + dRY * 0.05);
                ctx.bezierCurveTo(dCX + s * (dRX + 20), dCY - dRY * 0.4 + wFlap * 0.7, dCX + s * (dRX + 38), dCY - dRY * 0.58 + wFlap * 0.7, dCX + s * (dRX + 42), dCY - dRY * 0.75 + wFlap * 0.7);
                ctx.bezierCurveTo(dCX + s * (dRX + 26), dCY - dRY * 0.44, dCX + s * (dRX + 8), dCY - dRY * 0.2, dCX + s * (dRX - 2), dCY - dRY * 0.1);
                ctx.closePath(); ctx.fill();
            });

            // ── 3本角（中央大 + 左右小）──
            // 中央の大角
            const hornPulse = Math.sin(t * 0.008) * 3;
            ctx.fillStyle = '#FFD700';
            ctx.beginPath();
            ctx.moveTo(dCX - 9, dCY - dRY * 0.90);
            ctx.lineTo(dCX, dCY - dRY * 1.55 + hornPulse);
            ctx.lineTo(dCX + 9, dCY - dRY * 0.90);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#FF8800'; ctx.lineWidth = 1.5; ctx.stroke();
            // 左右の角
            for (const [sx, sy] of [[-22, -dRY * 0.78], [22, -dRY * 0.78]]) {
                ctx.fillStyle = '#CC8800';
                ctx.beginPath();
                ctx.moveTo(dCX + sx - 6, dCY + sy);
                ctx.lineTo(dCX + sx + (sx < 0 ? -8 : 8), dCY + sy - dRY * 0.35 + hornPulse * 0.6);
                ctx.lineTo(dCX + sx + 6, dCY + sy);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#FF8800'; ctx.lineWidth = 1; ctx.stroke();
            }

            // ── 紅の目（2つ、強く光る）──
            const eyeY = dCY - dRY * 0.26;
            const eyeGlow = 0.7 + Math.sin(t * 0.008) * 0.25;
            [[-1], [1]].forEach(([s]) => {
                const ex = dCX + s * dRX * 0.30;
                // 外グロー
                ctx.fillStyle = `rgba(255,0,0,${eyeGlow * 0.35})`;
                ctx.beginPath(); ctx.arc(ex, eyeY, 18, 0, Math.PI * 2); ctx.fill();
                // 眼球
                ctx.fillStyle = '#0A0000';
                ctx.beginPath(); ctx.arc(ex, eyeY, 11, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = `rgba(255,30,0,${eyeGlow})`;
                ctx.beginPath(); ctx.arc(ex, eyeY, 7, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#FF6600';
                ctx.beginPath(); ctx.arc(ex, eyeY, 3.5, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#FFFFFF';
                ctx.beginPath(); ctx.arc(ex - 2, eyeY - 2, 1.8, 0, Math.PI * 2); ctx.fill();
            });

            // ── 砲口（黒炎砲）──
            const cX = dCX + dir * dRX * 0.30, cY = dCY + dRY * 0.14, cR = dRX * 0.22;
            ctx.fillStyle = 'rgba(80,0,0,0.6)'; ctx.beginPath(); ctx.arc(cX, cY, cR + 10, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#CC8800'; ctx.lineWidth = 2; ctx.stroke();
            ctx.fillStyle = '#1A0000'; ctx.beginPath(); ctx.arc(cX, cY, cR + 5, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#050000'; ctx.beginPath(); ctx.arc(cX, cY, cR, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = `rgba(255,80,0,${0.25 + Math.sin(t * 0.01) * 0.15})`;
            ctx.beginPath(); ctx.arc(cX, cY, cR * 0.55, 0, Math.PI * 2); ctx.fill();
            const bR = cR * 0.60, bLen = 50;
            ctx.fillStyle = '#1A0A00'; ctx.strokeStyle = '#AA7700'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.ellipse(cX + dir * bLen * 0.5, cY, Math.abs(dir * bLen) * 0.55, bR, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
            ctx.fillStyle = '#0A0000'; ctx.beginPath(); ctx.arc(cX + dir * bLen, cY, bR + 5, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#050000'; ctx.beginPath(); ctx.arc(cX + dir * bLen, cY, bR, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = `rgba(255,60,0,${0.4 + Math.sin(t * 0.01) * 0.2})`;
            ctx.beginPath(); ctx.arc(cX + dir * bLen, cY, bR * 0.45, 0, Math.PI * 2); ctx.fill();

            // ── 魔王紋章（金の星章）──
            const emX = dCX - dir * dRX * 0.28, emY = dCY + dRY * 0.30;
            ctx.fillStyle = '#1A0000'; ctx.strokeStyle = '#CC8800'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(emX, emY, 18, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
            // 五芒星
            ctx.fillStyle = '#FFD700';
            ctx.beginPath();
            for (let i = 0; i < 5; i++) {
                const a = i * Math.PI * 2 / 5 - Math.PI / 2;
                const b = (i + 0.5) * Math.PI * 2 / 5 - Math.PI / 2;
                if (i === 0) ctx.moveTo(emX + Math.cos(a) * 11, emY + Math.sin(a) * 11);
                else ctx.lineTo(emX + Math.cos(a) * 11, emY + Math.sin(a) * 11);
                ctx.lineTo(emX + Math.cos(b) * 5, emY + Math.sin(b) * 5);
            }
            ctx.closePath(); ctx.fill();

            // ── 黒炎パーティクル ──
            for (let i = 0; i < 5; i++) {
                const px = dCX + Math.sin(t * 0.002 + i * 1.26) * dRX * 0.68;
                const py = dCY - dRY * 0.3 + Math.cos(t * 0.003 + i * 1.26) * dRY * 0.45;
                const pa = 0.22 + Math.sin(t * 0.005 + i) * 0.15;
                ctx.fillStyle = `rgba(220,80,0,${pa})`;
                ctx.beginPath(); ctx.arc(px, py, 4, 0, Math.PI * 2); ctx.fill();
            }
        }
        ctx.restore();
    },

    // レジェンドタイタン 覚醒形態（stage_ex2 第二形態）
    // メカスキンをベースに金×白発光・巨大砲身・プラズマオーラを追加
    _drawLegendTitanTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        const t = Date.now();
        ctx.save();
        ctx.translate(cx, ty + th);
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(t * 0.05) * 3, 0); }
        ctx.translate(-cx, -(ty + th));

        const treadH = 48, treadW = tw * 0.86;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;

        // ── 地面プラズマ輝光 ──
        const plasmaA = 0.08 + Math.sin(t * 0.004) * 0.05;
        const plasmaG = ctx.createRadialGradient(cx, treadY + treadH, 0, cx, treadY + treadH, treadW * 0.8);
        plasmaG.addColorStop(0, `rgba(255,220,0,${plasmaA * 4})`);
        plasmaG.addColorStop(0.5, `rgba(255,255,120,${plasmaA})`);
        plasmaG.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = plasmaG;
        ctx.beginPath(); ctx.ellipse(cx, treadY + treadH * 0.8, treadW * 0.75, treadH * 0.45, 0, 0, Math.PI * 2); ctx.fill();

        // ── キャタピラ（金属×金）──
        const tG = ctx.createLinearGradient(0, treadY, 0, treadY + treadH);
        tG.addColorStop(0, '#2A2000'); tG.addColorStop(0.5, '#3A3000'); tG.addColorStop(1, '#100A00');
        ctx.fillStyle = tG;
        this._roundRect(ctx, treadX, treadY, treadW, treadH, 10); ctx.fill();
        ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 2.5; ctx.stroke();
        for (let i = 0; i < 5; i++) {
            const wx = treadX + 20 + i * ((treadW - 40) / 4), wY = treadY + treadH * 0.55;
            ctx.fillStyle = '#2A2200'; ctx.beginPath(); ctx.arc(wx, wY, 13, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 1.5; ctx.stroke();
            ctx.fillStyle = '#AA8800'; ctx.beginPath(); ctx.arc(wx, wY, 7, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#FFEE88'; ctx.beginPath(); ctx.arc(wx, wY, 3, 0, Math.PI * 2); ctx.fill();
        }

        // ── ドーム（金属×白金グロー）──
        const dRX = tw * 0.52, dRY = th * 0.50;
        const dCX = cx, dCY = treadY - dRY * 0.92;
        // 白金オーラ（多重リング）
        for (let ring = 3; ring >= 1; ring--) {
            const rA = (0.06 + Math.sin(t * 0.004 + ring) * 0.04) / ring;
            ctx.strokeStyle = ring === 1 ? `rgba(255,240,100,${rA * 2.5})` : `rgba(200,200,255,${rA})`;
            ctx.lineWidth = ring === 1 ? 8 : 4;
            ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX + 8 * ring, dRY + 8 * ring, 0, 0, Math.PI * 2); ctx.stroke();
        }
        // ドーム本体
        const domeG = ctx.createRadialGradient(dCX - dRX * 0.22, dCY - dRY * 0.25, dRX * 0.05, dCX, dCY, dRX * 1.1);
        domeG.addColorStop(0, '#4A3A00'); domeG.addColorStop(0.35, '#2A2200'); domeG.addColorStop(0.7, '#1A1400'); domeG.addColorStop(1, '#0A0800');
        ctx.beginPath(); ctx.ellipse(dCX + 5, dCY + 5, dRX, dRY, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0,0,0,0.2)'; ctx.fill();
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI * 2);
        ctx.fillStyle = domeG; ctx.fill();
        ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 3; ctx.stroke();
        // 金属ライン
        ctx.strokeStyle = 'rgba(255,220,80,0.25)'; ctx.lineWidth = 1;
        for (let i = 1; i <= 3; i++) {
            ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX * (0.3 + i * 0.22), dRY * (0.3 + i * 0.22), 0, 0, Math.PI * 2); ctx.stroke();
        }

        if (!showInterior) {
            // ── プラズマ翼（エネルギーウィング）──
            const wFlap = Math.sin(t * 0.007) * 10;
            [[-1], [1]].forEach(([s]) => {
                // 外翼グロー
                const wingAlpha = 0.30 + Math.sin(t * 0.005 + s) * 0.12;
                const wingG = ctx.createLinearGradient(dCX, dCY, dCX + s * (dRX + 70), dCY - dRY * 0.8);
                wingG.addColorStop(0, `rgba(255,200,0,${wingAlpha})`);
                wingG.addColorStop(0.5, `rgba(255,255,150,${wingAlpha * 0.6})`);
                wingG.addColorStop(1, 'rgba(255,255,255,0)');
                ctx.fillStyle = wingG;
                ctx.beginPath();
                ctx.moveTo(dCX + s * (dRX - 2), dCY + dRY * 0.05);
                ctx.bezierCurveTo(dCX + s * (dRX + 28), dCY - dRY * 0.35 + wFlap, dCX + s * (dRX + 52), dCY - dRY * 0.55 + wFlap, dCX + s * (dRX + 68), dCY - dRY * 0.80 + wFlap);
                ctx.bezierCurveTo(dCX + s * (dRX + 40), dCY - dRY * 0.42, dCX + s * (dRX + 16), dCY - dRY * 0.20, dCX + s * (dRX - 2), dCY - dRY * 0.10);
                ctx.closePath(); ctx.fill();
                // エネルギーライン
                ctx.strokeStyle = `rgba(255,230,80,${0.55 + Math.sin(t * 0.006 + s) * 0.25})`;
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(dCX + s * (dRX), dCY);
                ctx.quadraticCurveTo(dCX + s * (dRX + 38), dCY - dRY * 0.45 + wFlap, dCX + s * (dRX + 68), dCY - dRY * 0.80 + wFlap);
                ctx.stroke();
            });

            // ── 頭頂の王冠（伝説の証）──
            const crownY = dCY - dRY * 1.05;
            const crownGlow = 0.6 + Math.sin(t * 0.006) * 0.3;
            ctx.fillStyle = `rgba(255,200,0,${crownGlow * 0.3})`;
            ctx.beginPath(); ctx.arc(dCX, crownY - 10, 28, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#FFD700';
            ctx.beginPath();
            ctx.moveTo(dCX - 22, crownY);
            ctx.lineTo(dCX - 22, crownY - 14);
            ctx.lineTo(dCX - 12, crownY - 7);
            ctx.lineTo(dCX, crownY - 22);
            ctx.lineTo(dCX + 12, crownY - 7);
            ctx.lineTo(dCX + 22, crownY - 14);
            ctx.lineTo(dCX + 22, crownY);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 1.5; ctx.stroke();
            // 宝石3つ
            for (const [bx, bc] of [[dCX - 12, '#00FFFF'], [dCX, '#FF4444'], [dCX + 12, '#00FFFF']]) {
                ctx.fillStyle = `rgba(255,255,255,${crownGlow * 0.5})`;
                ctx.beginPath(); ctx.arc(bx, crownY - 7, 5, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = bc;
                ctx.beginPath(); ctx.arc(bx, crownY - 7, 3.5, 0, Math.PI * 2); ctx.fill();
            }

            // ── 目（白く輝く）──
            const eyeY = dCY - dRY * 0.22;
            const eyeGlow = 0.75 + Math.sin(t * 0.007) * 0.22;
            [[-1], [1]].forEach(([s]) => {
                const ex = dCX + s * dRX * 0.28;
                ctx.fillStyle = `rgba(255,240,100,${eyeGlow * 0.4})`;
                ctx.beginPath(); ctx.arc(ex, eyeY, 18, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#0A0800';
                ctx.beginPath(); ctx.arc(ex, eyeY, 11, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = `rgba(255,230,80,${eyeGlow})`;
                ctx.beginPath(); ctx.arc(ex, eyeY, 7, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#FFFFFF';
                ctx.beginPath(); ctx.arc(ex, eyeY, 3.5, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#FFEE00';
                ctx.beginPath(); ctx.arc(ex - 1, eyeY - 1, 1.5, 0, Math.PI * 2); ctx.fill();
            });

            // ── 巨大砲身（二連装・金属）──
            const cX = dCX + dir * dRX * 0.28, cY = dCY + dRY * 0.14, cR = dRX * 0.24;
            // 砲台リング
            ctx.fillStyle = '#2A2200'; ctx.beginPath(); ctx.arc(cX, cY, cR + 12, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 2.5; ctx.stroke();
            ctx.fillStyle = '#1A1400'; ctx.beginPath(); ctx.arc(cX, cY, cR + 6, 0, Math.PI * 2); ctx.fill();
            // 上下2本の砲身
            for (const oy of [-7, 7]) {
                const bLen = 58, bR = cR * 0.42;
                ctx.fillStyle = '#2A2200'; ctx.strokeStyle = '#AA8800'; ctx.lineWidth = 1.5;
                ctx.beginPath(); ctx.ellipse(cX + dir * bLen * 0.5, cY + oy, Math.abs(dir * bLen) * 0.55, bR, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
                ctx.fillStyle = '#0A0800'; ctx.beginPath(); ctx.arc(cX + dir * bLen, cY + oy, bR + 4, 0, Math.PI * 2); ctx.fill();
                ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 1.5; ctx.stroke();
                ctx.fillStyle = '#050500'; ctx.beginPath(); ctx.arc(cX + dir * bLen, cY + oy, bR, 0, Math.PI * 2); ctx.fill();
                // チャージグロー
                ctx.fillStyle = `rgba(255,220,0,${0.4 + Math.sin(t * 0.01 + oy) * 0.25})`;
                ctx.beginPath(); ctx.arc(cX + dir * bLen, cY + oy, bR * 0.5, 0, Math.PI * 2); ctx.fill();
            }

            // ── プラズマパーティクル ──
            for (let i = 0; i < 7; i++) {
                const px = dCX + Math.sin(t * 0.003 + i * 0.9) * dRX * 0.72;
                const py = dCY - dRY * 0.25 + Math.cos(t * 0.003 + i * 0.9) * dRY * 0.50;
                const pa = 0.18 + Math.sin(t * 0.005 + i) * 0.14;
                ctx.fillStyle = i % 2 === 0 ? `rgba(255,200,0,${pa})` : `rgba(200,255,255,${pa})`;
                ctx.beginPath(); ctx.arc(px, py, 3.5, 0, Math.PI * 2); ctx.fill();
            }
        }
        ctx.restore();
    },

    // 🐉 竜騎士スキン（Ch.2クリア報酬）DSスタイル強化版
    _drawDragonKnightTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        // 🐉 竜騎士スキン 完全版 ― 溶岩鱗装甲・炎翼・竜角タワー・赤スリット目
        const dir = isEnemy ? -1 : 1;
        const cx  = tx + tw / 2;
        ctx.save();
        const fl = dmgFlash > 0 ? Math.min(1, dmgFlash / 10) : 0;
        const t  = Date.now() * 0.001;
        const tH = Math.round(th * 0.27);
        const bH = th - tH;

        // ── 地面溶岩オーラ ──
        const aG = ctx.createRadialGradient(cx, ty+th, 0, cx, ty+th, tw*0.8);
        aG.addColorStop(0, 'rgba(255,80,0,0.25)');
        aG.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = aG;
        ctx.beginPath(); ctx.ellipse(cx, ty+th, tw*0.75, tH*0.4, 0, 0, Math.PI*2); ctx.fill();

        // ── キャタピラ（溶岩鉄甲）──
        const tg = ctx.createLinearGradient(tx, ty+bH, tx, ty+th);
        tg.addColorStop(0, fl?'#FF4400':'#3A0800');
        tg.addColorStop(1, fl?'#991100':'#100200');
        ctx.fillStyle = tg;
        ctx.beginPath();
        ctx.moveTo(tx-14,ty+bH+2); ctx.lineTo(tx+tw+14,ty+bH+2);
        ctx.lineTo(tx+tw+18,ty+th); ctx.lineTo(tx-18,ty+th);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle='#0A0000'; ctx.lineWidth=2.5; ctx.stroke();
        ctx.strokeStyle='rgba(255,100,0,0.4)'; ctx.lineWidth=1.5; ctx.setLineDash([5,7]);
        ctx.beginPath(); ctx.moveTo(tx-10,ty+bH+tH*0.5); ctx.lineTo(tx+tw+10,ty+bH+tH*0.5); ctx.stroke();
        ctx.setLineDash([]);
        for (let i=0;i<4;i++) {
            const wx=tx+16+(tw-32)/3*i, wy=ty+bH+tH*0.55;
            ctx.fillStyle='#2A0400'; ctx.beginPath(); ctx.arc(wx,wy,13,0,Math.PI*2); ctx.fill();
            ctx.strokeStyle='#CC4400'; ctx.lineWidth=3; ctx.beginPath(); ctx.arc(wx,wy,13,0,Math.PI*2); ctx.stroke();
            ctx.strokeStyle='#FF6600'; ctx.lineWidth=2;
            for (let s=0;s<5;s++){const a=s*Math.PI*2/5+t*0.4;ctx.beginPath();ctx.moveTo(wx,wy);ctx.lineTo(wx+Math.cos(a)*10,wy+Math.sin(a)*10);ctx.stroke();}
            ctx.fillStyle='#FF4400'; ctx.beginPath(); ctx.arc(wx,wy,5,0,Math.PI*2); ctx.fill();
            ctx.fillStyle='#FFAA00'; ctx.beginPath(); ctx.arc(wx,wy,2.5,0,Math.PI*2); ctx.fill();
        }

        // ── 本体（深紅×黒・溶岩鱗）──
        const bg = ctx.createLinearGradient(tx,ty,tx,ty+bH);
        bg.addColorStop(0, fl?'#FF6633':'#4A0A00');
        bg.addColorStop(0.4, fl?'#FF3300':'#7A1200');
        bg.addColorStop(1, fl?'#AA1100':'#2A0400');
        ctx.fillStyle=bg; Renderer._roundRect(ctx,tx,ty,tw,bH,10); ctx.fill();
        ctx.strokeStyle='#050000'; ctx.lineWidth=4; Renderer._roundRect(ctx,tx,ty,tw,bH,10); ctx.stroke();
        ctx.shadowBlur=10; ctx.shadowColor='rgba(255,80,0,0.6)';
        ctx.strokeStyle='rgba(255,100,0,0.45)'; ctx.lineWidth=2;
        Renderer._roundRect(ctx,tx+4,ty+4,tw-8,bH-8,7); ctx.stroke(); ctx.shadowBlur=0;
        // 竜鱗（菱形タイル）
        ctx.strokeStyle='rgba(255,60,0,0.25)'; ctx.lineWidth=1;
        for (let r=0;r<5;r++) for (let c=0;c<7;c++) {
            const sx=tx+10+c*(tw-20)/6+(r%2)*((tw-20)/12), sy=ty+8+r*(bH-16)/4;
            ctx.beginPath(); ctx.moveTo(sx,sy-5); ctx.lineTo(sx+8,sy); ctx.lineTo(sx,sy+5); ctx.lineTo(sx-8,sy); ctx.closePath(); ctx.stroke();
        }

        // ── 炎翼（両肩）──
        const wBaseY=ty+bH*0.10, wHt=bH*0.58;
        [[-1,tx],[1,tx+tw]].forEach(([sd,bx]) => {
            const wg=ctx.createLinearGradient(bx,wBaseY,bx+sd*65,wBaseY+wHt);
            wg.addColorStop(0,fl?'rgba(255,100,30,0.9)':'rgba(120,20,0,0.85)');
            wg.addColorStop(0.5,fl?'rgba(200,50,0,0.6)':'rgba(70,8,0,0.5)');
            wg.addColorStop(1,'rgba(0,0,0,0)');
            ctx.fillStyle=wg;
            ctx.beginPath();
            ctx.moveTo(bx,wBaseY+10);
            ctx.lineTo(bx+sd*20,wBaseY-12);
            ctx.lineTo(bx+sd*52,wBaseY+wHt*0.2);
            ctx.bezierCurveTo(bx+sd*65,wBaseY+wHt*0.4,bx+sd*62,wBaseY+wHt*0.72,bx+sd*42,wBaseY+wHt);
            ctx.lineTo(bx+sd*8,wBaseY+wHt*0.85);
            ctx.lineTo(bx,wBaseY+wHt*0.5);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle='rgba(255,90,0,0.45)'; ctx.lineWidth=1.5; ctx.stroke();
            // 翼骨
            ctx.strokeStyle='rgba(255,150,0,0.55)'; ctx.lineWidth=1.5;
            [[0.15,0.28],[0.35,0.48],[0.55,0.65]].forEach(([fy,ty2])=>{
                ctx.beginPath(); ctx.moveTo(bx,wBaseY+wHt*fy); ctx.lineTo(bx+sd*55,wBaseY+wHt*ty2); ctx.stroke();
            });
            // 竜爪
            ctx.fillStyle='#CC3300';
            for (let c=0;c<3;c++){const cx2=bx+sd*(44+c*5),cy2=wBaseY+wHt*(0.2+c*0.28);
                ctx.beginPath();ctx.moveTo(cx2,cy2-4);ctx.lineTo(cx2+sd*13,cy2);ctx.lineTo(cx2,cy2+3);ctx.closePath();ctx.fill();}
        });

        if (!showInterior) {
            // ── 竜頭タワー（左右）──
            const drawDragonTower = tcx => {
                const tR=22,tTH=bH*0.54,tTopY=ty+bH-tTH;
                const tg2=ctx.createLinearGradient(tcx-tR,0,tcx+tR,0);
                tg2.addColorStop(0,'#3A0600');tg2.addColorStop(0.45,'#6A1200');tg2.addColorStop(1,'#2A0400');
                ctx.fillStyle=tg2; ctx.beginPath(); ctx.rect(tcx-tR,tTopY,tR*2,tTH); ctx.fill();
                ctx.strokeStyle='rgba(0,0,0,0.2)'; ctx.lineWidth=1;
                for(let r=1;r<=6;r++){const ly=tTopY+r*(tTH/7);ctx.beginPath();ctx.moveTo(tcx-tR+2,ly);ctx.lineTo(tcx+tR-2,ly);ctx.stroke();}
                ctx.strokeStyle='#1A0000'; ctx.lineWidth=2; ctx.strokeRect(tcx-tR,tTopY,tR*2,tTH);
                // 炎窓
                ctx.fillStyle='rgba(255,80,0,0.55)';
                ctx.beginPath();ctx.moveTo(tcx-6,tTopY+tTH*0.52);ctx.lineTo(tcx-6,tTopY+tTH*0.36);
                ctx.quadraticCurveTo(tcx,tTopY+tTH*0.2,tcx+6,tTopY+tTH*0.36);ctx.lineTo(tcx+6,tTopY+tTH*0.52);ctx.closePath();ctx.fill();
                // 銃眼
                for(let i=0;i<3;i++){ctx.fillStyle='#2A0000';ctx.beginPath();ctx.rect(tcx-14+i*11,tTopY-11,7,12);ctx.fill();ctx.strokeStyle='#CC3300';ctx.lineWidth=0.8;ctx.stroke();}
                // 竜角屋根
                ctx.fillStyle='#880000';
                ctx.beginPath();ctx.moveTo(tcx-tR-3,tTopY-11);ctx.lineTo(tcx,tTopY-46);ctx.lineTo(tcx+tR+3,tTopY-11);ctx.closePath();ctx.fill();
                ctx.strokeStyle='#CC2200';ctx.lineWidth=1.5;ctx.stroke();
                // 2本の角
                ctx.strokeStyle='#FF4400';ctx.lineWidth=3;ctx.lineCap='round';
                ctx.beginPath();ctx.moveTo(tcx-9,tTopY-43);ctx.lineTo(tcx-18,tTopY-64);ctx.stroke();
                ctx.beginPath();ctx.moveTo(tcx+9,tTopY-43);ctx.lineTo(tcx+18,tTopY-64);ctx.stroke();
                const fa=0.35+Math.sin(t*3.2)*0.3;
                ctx.fillStyle=`rgba(255,150,0,${fa})`;
                ctx.beginPath();ctx.arc(tcx-18,tTopY-64,5,0,Math.PI*2);ctx.fill();
                ctx.beginPath();ctx.arc(tcx+18,tTopY-64,5,0,Math.PI*2);ctx.fill();
                // 旗
                ctx.strokeStyle='#CC3300';ctx.lineWidth=2;
                ctx.beginPath();ctx.moveTo(tcx,tTopY-45);ctx.lineTo(tcx,tTopY-62);ctx.stroke();
                ctx.fillStyle='#FF4400';
                ctx.beginPath();ctx.moveTo(tcx,tTopY-62);ctx.lineTo(tcx+15,tTopY-55);ctx.lineTo(tcx,tTopY-48);ctx.closePath();ctx.fill();
            };
            drawDragonTower(cx-(tw/2)*0.85); drawDragonTower(cx+(tw/2)*0.85);

            // ── 溶岩二連砲口（中央）──
            const canX=cx+dir*(tw*0.28), canY=ty+bH*0.48, canR=tw*0.105;
            ctx.fillStyle='#1A0000'; ctx.beginPath();ctx.arc(canX,canY,canR+12,0,Math.PI*2);ctx.fill();
            ctx.strokeStyle='#CC3300';ctx.lineWidth=2;ctx.stroke();
            ctx.fillStyle='#3A0600';ctx.beginPath();ctx.arc(canX,canY,canR+7,0,Math.PI*2);ctx.fill();
            ctx.shadowBlur=12;ctx.shadowColor='rgba(255,80,0,0.8)';
            ctx.fillStyle='#FF3300';ctx.beginPath();ctx.arc(canX,canY,canR,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
            const bLen=52,bR=canR*0.55;
            const bbg=ctx.createLinearGradient(canX,canY-bR,canX,canY+bR);
            bbg.addColorStop(0,'#993300');bbg.addColorStop(0.4,'#CC4400');bbg.addColorStop(1,'#551100');
            ctx.fillStyle=bbg;
            ctx.beginPath();ctx.ellipse(canX+dir*bLen*0.5,canY,Math.abs(bLen)*0.52,bR,0,0,Math.PI*2);ctx.fill();
            const fe=0.3+Math.sin(t*4)*0.2;
            ctx.fillStyle=`rgba(255,140,0,${fe})`;ctx.beginPath();ctx.arc(canX+dir*bLen,canY,bR+6,0,Math.PI*2);ctx.fill();
            ctx.fillStyle=`rgba(255,230,0,${fe*0.8})`;ctx.beginPath();ctx.arc(canX+dir*bLen,canY,bR+2,0,Math.PI*2);ctx.fill();

            // ── 竜の縦スリット赤目 ──
            const eBaseX=cx+dir*tw*0.12, eY=ty+bH*0.30, eR=tw*0.085;
            for (let e=0;e<2;e++) {
                const ex=eBaseX+dir*(e-0.5)*eR*2.8;
                ctx.fillStyle='#FFCCAA';ctx.beginPath();ctx.ellipse(ex,eY,eR+1.5,eR+1.5,0,0,Math.PI*2);ctx.fill();
                ctx.fillStyle='#BB0000';ctx.beginPath();ctx.ellipse(ex,eY,eR,eR,0,0,Math.PI*2);ctx.fill();
                ctx.fillStyle='#200000';ctx.beginPath();ctx.ellipse(ex,eY,eR*0.25,eR*0.92,0,0,Math.PI*2);ctx.fill();
                ctx.fillStyle='rgba(255,100,0,0.6)';ctx.beginPath();ctx.arc(ex-eR*0.3,eY-eR*0.3,eR*0.25,0,Math.PI*2);ctx.fill();
            }

            // ── 竜紋エンブレム ──
            const embX=cx-dir*tw*0.26, embY=ty+bH*0.63;
            ctx.fillStyle='#1A0000';ctx.strokeStyle='#FF4400';ctx.lineWidth=2;
            ctx.beginPath();ctx.arc(embX,embY,17,0,Math.PI*2);ctx.fill();ctx.stroke();
            ctx.fillStyle='#CC2200';ctx.beginPath();ctx.arc(embX,embY,11,0,Math.PI*2);ctx.fill();
            ctx.fillStyle='#FF6600';ctx.beginPath();ctx.arc(embX,embY,6,0,Math.PI*2);ctx.fill();
            ctx.fillStyle='rgba(255,220,0,0.9)';ctx.beginPath();ctx.arc(embX,embY,2.5,0,Math.PI*2);ctx.fill();

            // ── ドーム頂上の竜角 ──
            ctx.fillStyle='#CC2200';
            ctx.beginPath();ctx.moveTo(cx-7,ty+3);ctx.lineTo(cx,ty-22);ctx.lineTo(cx+7,ty+3);ctx.closePath();ctx.fill();
            ctx.strokeStyle='#FF4400';ctx.lineWidth=1.2;ctx.stroke();
        }
        if (isEnemy) this._drawStageEnemyOverlay(ctx,tx,ty,tw,th,null,0.5);
        ctx.restore();
    },

    _drawSeraphTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        // ✨ 天門騎士スキン ― ふわふわ天使・虹オーラ・ぱっちり瞳・ハートタワー
        const dir = isEnemy ? -1 : 1;
        const cx  = tx + tw / 2;
        ctx.save();
        const fl = dmgFlash > 0 ? Math.min(1, dmgFlash / 10) : 0;
        const t  = Date.now() * 0.001;
        const tH = Math.round(th * 0.27);
        const bH = th - tH;
        const hue = (t * 55) % 360;

        // ── 虹オーラ ──
        const aA=0.11+Math.sin(t*2)*0.05;
        const aG=ctx.createRadialGradient(cx,ty+th*0.4,0,cx,ty+th*0.4,tw*0.85);
        aG.addColorStop(0,`rgba(255,230,255,${aA*2})`);aG.addColorStop(0.55,`rgba(200,180,255,${aA})`);aG.addColorStop(1,'rgba(0,0,0,0)');
        ctx.fillStyle=aG;ctx.beginPath();ctx.ellipse(cx,ty+th*0.4,tw*0.85,th*0.55,0,0,Math.PI*2);ctx.fill();

        // ── キャタピラ（パステルパープル）──
        const tg=ctx.createLinearGradient(tx,ty+bH,tx,ty+th);
        tg.addColorStop(0,fl?'#FFE0F8':'#B8A0D8');tg.addColorStop(1,fl?'#EEB8E8':'#504060');
        ctx.fillStyle=tg;
        ctx.beginPath();ctx.moveTo(tx-8,ty+bH+2);ctx.lineTo(tx+tw+8,ty+bH+2);ctx.lineTo(tx+tw+12,ty+th);ctx.lineTo(tx-12,ty+th);ctx.closePath();ctx.fill();
        ctx.strokeStyle='#7050A8';ctx.lineWidth=2;ctx.stroke();
        ctx.strokeStyle='rgba(255,220,255,0.5)';ctx.lineWidth=1.5;
        for(let i=1;i<8;i++){const wx=tx-8+(tw+16)/8*i;ctx.beginPath();ctx.moveTo(wx,ty+bH+2);ctx.lineTo(wx+1,ty+th);ctx.stroke();}
        // 天使車輪
        for(let i=0;i<4;i++){
            const wx=tx+14+(tw-28)/3*i,wy=ty+bH+tH*0.52;
            ctx.fillStyle='#5038A0';ctx.beginPath();ctx.arc(wx,wy,12,0,Math.PI*2);ctx.fill();
            ctx.strokeStyle='#FFD0FF';ctx.lineWidth=2.5;ctx.beginPath();ctx.arc(wx,wy,12,0,Math.PI*2);ctx.stroke();
            ctx.strokeStyle=`hsl(${(hue+i*30)%360},70%,75%)`;ctx.lineWidth=1.5;
            for(let s=0;s<6;s++){const a=s*Math.PI/3+t*0.5;ctx.beginPath();ctx.moveTo(wx,wy);ctx.lineTo(wx+Math.cos(a)*9,wy+Math.sin(a)*9);ctx.stroke();}
            ctx.fillStyle='#FFD0FF';ctx.beginPath();ctx.arc(wx,wy,5,0,Math.PI*2);ctx.fill();
            ctx.fillStyle='#FFF';ctx.beginPath();ctx.arc(wx,wy,2.5,0,Math.PI*2);ctx.fill();
        }

        // ── 本体（純白×淡紫）──
        const bg=ctx.createLinearGradient(tx,ty,tx,ty+bH);
        bg.addColorStop(0,fl?'#FFF':'#FFF5FF');bg.addColorStop(0.3,fl?'#FFF0FF':'#F0DEFF');
        bg.addColorStop(0.7,fl?'#FFE0FF':'#D8C4F8');bg.addColorStop(1,fl?'#FFCCFF':'#B0A0E8');
        ctx.fillStyle=bg; Renderer._roundRect(ctx,tx,ty,tw,bH,12); ctx.fill();
        ctx.strokeStyle='#5838A0';ctx.lineWidth=3; Renderer._roundRect(ctx,tx,ty,tw,bH,12);ctx.stroke();
        ctx.strokeStyle=`hsla(${hue},75%,78%,0.75)`;ctx.lineWidth=2;
        Renderer._roundRect(ctx,tx+4,ty+4,tw-8,bH-8,8);ctx.stroke();
        // キラキラ水玉
        ctx.fillStyle='rgba(255,255,255,0.3)';
        [[0.18,0.14],[0.72,0.11],[0.44,0.33],[0.14,0.53],[0.78,0.5],[0.36,0.68]].forEach(([rx2,ry2])=>{
            ctx.beginPath();ctx.arc(tx+tw*rx2,ty+bH*ry2,3.5+Math.sin(t*2+rx2*10)*1.5,0,Math.PI*2);ctx.fill();
        });
        // ハート模様
        const hx=cx,hy=ty+bH*0.60;
        ctx.fillStyle='rgba(255,180,220,0.45)';ctx.strokeStyle='rgba(255,120,180,0.65)';ctx.lineWidth=1.5;
        ctx.beginPath();ctx.moveTo(hx,hy+5);ctx.bezierCurveTo(hx-13,hy-9,hx-21,hy-4,hx,hy+9);
        ctx.bezierCurveTo(hx+21,hy-4,hx+13,hy-9,hx,hy+5);ctx.closePath();ctx.fill();ctx.stroke();

        if (!showInterior) {
            // ── ハートタワー（左右）──
            const drawSeraphTower = tcx => {
                const tR=20,tTH=bH*0.54,tTopY=ty+bH-tTH;
                const tg2=ctx.createLinearGradient(tcx-tR,0,tcx+tR,0);
                tg2.addColorStop(0,'#C8A8E8');tg2.addColorStop(0.5,'#F0E0FF');tg2.addColorStop(1,'#C0A0E0');
                ctx.fillStyle=tg2;ctx.beginPath();ctx.rect(tcx-tR,tTopY,tR*2,tTH);ctx.fill();
                ctx.strokeStyle='rgba(160,120,200,0.35)';ctx.lineWidth=1;
                for(let r=1;r<=6;r++){const ly=tTopY+r*(tTH/7);ctx.beginPath();ctx.moveTo(tcx-tR+2,ly);ctx.lineTo(tcx+tR-2,ly);ctx.stroke();}
                ctx.strokeStyle='#7858C8';ctx.lineWidth=1.8;ctx.strokeRect(tcx-tR,tTopY,tR*2,tTH);
                // ハート窓
                ctx.fillStyle='rgba(255,180,255,0.7)';
                const winY=tTopY+tTH*0.4;
                ctx.beginPath();ctx.moveTo(tcx,winY+8);ctx.bezierCurveTo(tcx-9,winY-5,tcx-13,winY+1,tcx,winY+7);
                ctx.bezierCurveTo(tcx+13,winY+1,tcx+9,winY-5,tcx,winY+8);ctx.closePath();ctx.fill();
                // 銃眼（丸型）
                for(let i=0;i<3;i++){ctx.fillStyle='#E0C0FF';ctx.beginPath();ctx.arc(tcx-10+i*10,tTopY-7,4,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#7858C8';ctx.lineWidth=0.8;ctx.stroke();}
                // 尖塔（パステルパープル）
                ctx.fillStyle='#8860D0';ctx.beginPath();ctx.moveTo(tcx-tR-2,tTopY-8);ctx.lineTo(tcx,tTopY-48);ctx.lineTo(tcx+tR+2,tTopY-8);ctx.closePath();ctx.fill();
                ctx.strokeStyle='#C0A0FF';ctx.lineWidth=1.5;ctx.stroke();
                // 星
                const sa=0.55+Math.sin(t*3+tcx)*0.4;
                ctx.fillStyle=`rgba(255,255,200,${sa})`;ctx.beginPath();ctx.arc(tcx,tTopY-52,5,0,Math.PI*2);ctx.fill();
                // 旗
                ctx.strokeStyle='#C080E0';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(tcx,tTopY-50);ctx.lineTo(tcx,tTopY-64);ctx.stroke();
                ctx.fillStyle='#FF88CC';ctx.beginPath();ctx.moveTo(tcx,tTopY-64);ctx.lineTo(tcx+14,tTopY-58);ctx.lineTo(tcx,tTopY-52);ctx.closePath();ctx.fill();
            };
            drawSeraphTower(cx-(tw/2)*0.84); drawSeraphTower(cx+(tw/2)*0.84);

            // ── 天使砲口 ──
            const canX=cx+dir*(tw*0.28),canY=ty+bH*0.48,canR=tw*0.11;
            ctx.fillStyle='#5838A0';ctx.beginPath();ctx.arc(canX,canY,canR+10,0,Math.PI*2);ctx.fill();
            ctx.strokeStyle='#FFD0FF';ctx.lineWidth=2;ctx.stroke();
            ctx.shadowBlur=10;ctx.shadowColor='rgba(220,180,255,0.85)';
            ctx.fillStyle='#E0A0FF';ctx.beginPath();ctx.arc(canX,canY,canR,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
            const bLen=48,bR=canR*0.52;
            ctx.fillStyle=`hsl(${hue},55%,62%)`;
            ctx.beginPath();ctx.ellipse(canX+dir*bLen*0.5,canY,Math.abs(bLen)*0.52,bR,0,0,Math.PI*2);ctx.fill();
            const fe2=0.28+Math.sin(t*4)*0.2;
            ctx.fillStyle=`rgba(255,200,255,${fe2})`;ctx.beginPath();ctx.arc(canX+dir*bLen,canY,bR+5,0,Math.PI*2);ctx.fill();

            // ── ぱっちり大きな目（まつ毛付き）──
            const eBaseX=cx+dir*tw*0.12,eY=ty+bH*0.30,eR=tw*0.092;
            for(let e=0;e<2;e++){
                const ex=eBaseX+dir*(e-0.5)*eR*2.8;
                ctx.fillStyle='rgba(0,0,0,0.12)';ctx.beginPath();ctx.ellipse(ex+1.5,eY+1.5,eR+2,eR+2,0,0,Math.PI*2);ctx.fill();
                ctx.fillStyle='#FFEEFF';ctx.beginPath();ctx.ellipse(ex,eY,eR+1.5,eR+1.5,0,0,Math.PI*2);ctx.fill();
                ctx.fillStyle='#7850C0';ctx.beginPath();ctx.ellipse(ex,eY,eR,eR,0,0,Math.PI*2);ctx.fill();
                ctx.fillStyle='rgba(255,255,255,0.75)';ctx.beginPath();ctx.arc(ex-eR*0.3,eY-eR*0.35,eR*0.38,0,Math.PI*2);ctx.fill();
                ctx.fillStyle='rgba(255,255,255,0.5)';ctx.beginPath();ctx.arc(ex+eR*0.25,eY+eR*0.2,eR*0.18,0,Math.PI*2);ctx.fill();
                ctx.strokeStyle='#4830A0';ctx.lineWidth=2;ctx.lineCap='round';
                for(let l=0;l<4;l++){const lx=ex-eR*0.6+l*eR*0.4;ctx.beginPath();ctx.moveTo(lx,eY-eR*0.85);ctx.lineTo(lx+l*0.5-1,eY-eR*1.32);ctx.stroke();}
            }

            // ── 天使の輪 ──
            const hA=0.55+Math.sin(t*2)*0.22;
            ctx.strokeStyle=`rgba(255,235,0,${hA})`;ctx.lineWidth=4;
            ctx.shadowBlur=8;ctx.shadowColor='rgba(255,220,0,0.75)';
            ctx.beginPath();ctx.ellipse(cx,ty+6,tw*0.26,th*0.04,0,0,Math.PI*2);ctx.stroke();ctx.shadowBlur=0;

            // ── 天使の翼（大・ふわふわ）──
            [[-1,tx],[1,tx+tw]].forEach(([sd,bx])=>{
                const wy2=ty+bH*0.08,wH2=bH*0.65;
                const wg2=ctx.createLinearGradient(bx,wy2,bx+sd*72,wy2+wH2);
                wg2.addColorStop(0,'rgba(255,242,255,0.88)');wg2.addColorStop(0.5,'rgba(230,205,255,0.5)');wg2.addColorStop(1,'rgba(200,165,255,0)');
                ctx.fillStyle=wg2;
                ctx.beginPath();ctx.moveTo(bx,wy2+12);
                ctx.quadraticCurveTo(bx+sd*42,wy2-12,bx+sd*70,wy2+wH2*0.22);
                ctx.quadraticCurveTo(bx+sd*74,wy2+wH2*0.52,bx+sd*56,wy2+wH2);
                ctx.quadraticCurveTo(bx+sd*30,wy2+wH2*0.82,bx,wy2+wH2*0.5);
                ctx.closePath();ctx.fill();
                ctx.strokeStyle='rgba(200,165,255,0.55)';ctx.lineWidth=1.5;
                for(let r=0;r<6;r++){const ry3=wy2+wH2*r*0.14;ctx.beginPath();ctx.moveTo(bx,ry3+15);ctx.quadraticCurveTo(bx+sd*42,ry3,bx+sd*62,ry3+12);ctx.stroke();}
                for(let r=0;r<4;r++){const sa2=0.35+Math.sin(t*3+r)*0.4;ctx.fillStyle=`rgba(255,255,200,${sa2})`;ctx.beginPath();ctx.arc(bx+sd*62,wy2+wH2*(0.12+r*0.26),3,0,Math.PI*2);ctx.fill();}
            });

            // ── 星エンブレム ──
            const embX=cx-dir*tw*0.26,embY2=ty+bH*0.62;
            ctx.fillStyle='#4828A0';ctx.strokeStyle='#FFD0FF';ctx.lineWidth=2;
            ctx.beginPath();ctx.arc(embX,embY2,16,0,Math.PI*2);ctx.fill();ctx.stroke();
            ctx.fillStyle=`hsl(${(hue+120)%360},70%,78%)`;
            ctx.beginPath();
            for(let s=0;s<10;s++){const a=s*Math.PI/5-Math.PI/2;const r2=s%2===0?12:5;
                if(s===0)ctx.moveTo(embX+Math.cos(a)*r2,embY2+Math.sin(a)*r2);else ctx.lineTo(embX+Math.cos(a)*r2,embY2+Math.sin(a)*r2);}
            ctx.closePath();ctx.fill();
            ctx.fillStyle='#FFF';ctx.beginPath();ctx.arc(embX,embY2,3,0,Math.PI*2);ctx.fill();
        }
        if (isEnemy) this._drawStageEnemyOverlay(ctx,tx,ty,tw,th,null,0.5);
        ctx.restore();
    },

    _drawAbyssTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        // 🌑 深淵の主スキン = エリスグール完全再現
        // 特徴: 深紺鋼鉄装甲 / 両肩六角盾 / 中央大歯車砲口(三日月コア)
        //        赤目×緑目のスライム垂れ目 / 黄三日月ホイール / 青尖塔タワー / バトメント冠
        const dir = isEnemy ? -1 : 1;
        const cx  = tx + tw / 2;
        ctx.save();
        const fl = dmgFlash > 0 ? Math.min(1, dmgFlash / 10) : 0;
        const t  = Date.now() * 0.001;
        const tH = Math.round(th * 0.27);
        const bH = th - tH;

        // ── 暗い海底オーラ ──
        const aG=ctx.createRadialGradient(cx,ty+th*0.5,0,cx,ty+th*0.5,tw*0.9);
        aG.addColorStop(0,'rgba(0,30,90,0.20)');aG.addColorStop(1,'rgba(0,0,0,0)');
        ctx.fillStyle=aG;ctx.beginPath();ctx.ellipse(cx,ty+th*0.5,tw*0.9,th*0.55,0,0,Math.PI*2);ctx.fill();

        // ── キャタピラ（深紺鋼）──
        const tg=ctx.createLinearGradient(tx,ty+bH,tx,ty+th);
        tg.addColorStop(0,fl?'#2255AA':'#0A1830');
        tg.addColorStop(0.5,fl?'#1840AA':'#060E1E');
        tg.addColorStop(1,fl?'#102060':'#030810');
        ctx.fillStyle=tg;
        ctx.beginPath();ctx.moveTo(tx-14,ty+bH+2);ctx.lineTo(tx+tw+14,ty+bH+2);ctx.lineTo(tx+tw+18,ty+th);ctx.lineTo(tx-18,ty+th);ctx.closePath();ctx.fill();
        ctx.strokeStyle='#010810';ctx.lineWidth=2.5;ctx.stroke();
        ctx.strokeStyle='rgba(50,120,220,0.38)';ctx.lineWidth=1.5;
        for(let i=1;i<8;i++){const wx=tx-10+(tw+20)/8*i;ctx.beginPath();ctx.moveTo(wx,ty+bH+2);ctx.lineTo(wx+2,ty+th);ctx.stroke();}

        // ── 三日月ホイール（4個）──  エリスグール特徴：黄色三日月
        for(let i=0;i<4;i++){
            const wx=tx+14+(tw-28)/3*i, wy=ty+bH+tH*0.52;
            // 外枠
            ctx.fillStyle='#040E28'; ctx.beginPath();ctx.arc(wx,wy,13,0,Math.PI*2);ctx.fill();
            ctx.strokeStyle='#1A4080';ctx.lineWidth=3;ctx.beginPath();ctx.arc(wx,wy,13,0,Math.PI*2);ctx.stroke();
            // 六角スポーク
            ctx.strokeStyle='rgba(60,140,255,0.65)';ctx.lineWidth=1.5;
            for(let s=0;s<6;s++){const a=s*Math.PI/3;ctx.beginPath();ctx.moveTo(wx,wy);ctx.lineTo(wx+Math.cos(a)*10,wy+Math.sin(a)*10);ctx.stroke();}
            // 黄色三日月
            ctx.fillStyle='#DDAA00';ctx.beginPath();ctx.arc(wx,wy,5,0,Math.PI*2);ctx.fill();
            ctx.fillStyle='#040E28';ctx.beginPath();ctx.arc(wx+3,wy,4,0,Math.PI*2);ctx.fill();
        }

        // ── 本体（深紺装甲）──
        const bg=ctx.createLinearGradient(tx,ty,tx,ty+bH);
        bg.addColorStop(0,fl?'#4477CC':'#0C1C42');
        bg.addColorStop(0.35,fl?'#3366BB':'#0A1840');
        bg.addColorStop(0.7,fl?'#2255AA':'#07122A');
        bg.addColorStop(1,fl?'#1844AA':'#040C1E');
        ctx.fillStyle=bg; Renderer._roundRect(ctx,tx,ty,tw,bH,10);ctx.fill();
        ctx.strokeStyle='#010810';ctx.lineWidth=4;Renderer._roundRect(ctx,tx,ty,tw,bH,10);ctx.stroke();
        ctx.shadowBlur=10;ctx.shadowColor='rgba(30,120,255,0.6)';
        ctx.strokeStyle='rgba(40,100,220,0.55)';ctx.lineWidth=2;
        Renderer._roundRect(ctx,tx+4,ty+4,tw-8,bH-8,7);ctx.stroke();ctx.shadowBlur=0;

        // 六角ハニカムパターン
        ctx.strokeStyle='rgba(50,100,200,0.22)';ctx.lineWidth=1;
        const hS=14;
        for(let row=0;row<5;row++) for(let col=0;col<6;col++){
            const hx2=tx+16+col*hS*1.75+(row%2)*hS*0.87, hy2=ty+10+row*hS*1.5;
            ctx.beginPath();
            for(let s=0;s<6;s++){const a=s*Math.PI/3-Math.PI/6;
                if(s===0)ctx.moveTo(hx2+Math.cos(a)*hS*0.6,hy2+Math.sin(a)*hS*0.6);
                else ctx.lineTo(hx2+Math.cos(a)*hS*0.6,hy2+Math.sin(a)*hS*0.6);}
            ctx.closePath();ctx.stroke();
        }

        // ── 両肩六角盾（エリスグール最大の特徴）──
        const shY=ty+bH*0.10, shH=bH*0.58;
        [[-1,tx],[1,tx+tw]].forEach(([sd,bx])=>{
            const sCx=bx+sd*22, sCy=shY+shH*0.42, sR=24;
            const sg=ctx.createLinearGradient(sCx,sCy-sR,sCx,sCy+sR);
            sg.addColorStop(0,fl?'#3366CC':'#14244A');sg.addColorStop(1,fl?'#1A4080':'#080E22');
            ctx.fillStyle=sg;
            ctx.beginPath();
            for(let s=0;s<6;s++){const a=s*Math.PI/3;if(s===0)ctx.moveTo(sCx+Math.cos(a)*sR,sCy+Math.sin(a)*sR);else ctx.lineTo(sCx+Math.cos(a)*sR,sCy+Math.sin(a)*sR);}
            ctx.closePath();ctx.fill();
            // 盾の縁（明るい青）
            ctx.strokeStyle='#3080FF';ctx.lineWidth=2.5;ctx.stroke();
            // 内側ひし形
            ctx.strokeStyle='rgba(100,180,255,0.55)';ctx.lineWidth=1.5;
            ctx.beginPath();ctx.moveTo(sCx,sCy-sR*0.58);ctx.lineTo(sCx+sR*0.52,sCy);ctx.lineTo(sCx,sCy+sR*0.58);ctx.lineTo(sCx-sR*0.52,sCy);ctx.closePath();ctx.stroke();
            // 三日月マーク（黄）
            ctx.fillStyle='#DDAA00';ctx.beginPath();ctx.arc(sCx,sCy,sR*0.30,0,Math.PI*2);ctx.fill();
            ctx.fillStyle='#14244A';ctx.beginPath();ctx.arc(sCx+sR*0.13,sCy,sR*0.23,0,Math.PI*2);ctx.fill();
        });

        if (!showInterior) {
            // ── 青い尖塔タワー（左右）── エリスグール特徴的な青塔
            const drawAbyssTower = tcx => {
                const tR=20,tTH=bH*0.56,tTopY=ty+bH-tTH;
                const tg2=ctx.createLinearGradient(tcx-tR,0,tcx+tR,0);
                tg2.addColorStop(0,'#050E22');tg2.addColorStop(0.5,'#0C1E42');tg2.addColorStop(1,'#040A1A');
                ctx.fillStyle=tg2;ctx.beginPath();ctx.rect(tcx-tR,tTopY,tR*2,tTH);ctx.fill();
                ctx.strokeStyle='rgba(50,100,200,0.22)';ctx.lineWidth=1;
                for(let r=1;r<=6;r++){const ly=tTopY+r*(tTH/7);ctx.beginPath();ctx.moveTo(tcx-tR+2,ly);ctx.lineTo(tcx+tR-2,ly);ctx.stroke();}
                ctx.strokeStyle='#1A4080';ctx.lineWidth=2;ctx.strokeRect(tcx-tR,tTopY,tR*2,tTH);
                // 菱形窓（青発光）
                ctx.fillStyle='rgba(30,100,255,0.38)';
                const winY=tTopY+tTH*0.40;
                ctx.beginPath();ctx.moveTo(tcx,winY-10);ctx.lineTo(tcx+8,winY);ctx.lineTo(tcx,winY+10);ctx.lineTo(tcx-8,winY);ctx.closePath();ctx.fill();
                ctx.strokeStyle='rgba(80,160,255,0.8)';ctx.lineWidth=1;ctx.stroke();
                // 銃眼
                for(let i=0;i<3;i++){ctx.fillStyle='#0A1A32';ctx.beginPath();ctx.rect(tcx-14+i*11,tTopY-11,7,12);ctx.fill();ctx.strokeStyle='#2060C0';ctx.lineWidth=0.8;ctx.stroke();}
                // 青い尖塔本体（エリスグールの特徴的な青い尖り）
                ctx.fillStyle='#1A3A80';
                ctx.beginPath();ctx.moveTo(tcx-tR-3,tTopY-11);ctx.lineTo(tcx,tTopY-46);ctx.lineTo(tcx+tR+3,tTopY-11);ctx.closePath();ctx.fill();
                ctx.strokeStyle='#4080FF';ctx.lineWidth=2;ctx.stroke();
                ctx.shadowBlur=8;ctx.shadowColor='rgba(40,120,255,0.65)';
                ctx.fillStyle='rgba(60,140,255,0.85)';ctx.beginPath();ctx.arc(tcx,tTopY-50,4.5,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
                // 旗（濃紺×青）
                ctx.strokeStyle='#1A4080';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(tcx,tTopY-50);ctx.lineTo(tcx,tTopY-64);ctx.stroke();
                ctx.fillStyle='#1A3A80';ctx.beginPath();ctx.moveTo(tcx,tTopY-64);ctx.lineTo(tcx+14,tTopY-58);ctx.lineTo(tcx,tTopY-52);ctx.closePath();ctx.fill();
                ctx.strokeStyle='#4080FF';ctx.lineWidth=1;ctx.stroke();
            };
            drawAbyssTower(cx-(tw/2)*0.84); drawAbyssTower(cx+(tw/2)*0.84);

            // ── 大歯車砲口（エリスグール中央エンブレム）──
            const canX=cx+dir*(tw*0.26), canY=ty+bH*0.50, gR=tw*0.142;
            // 歯車外リング
            ctx.fillStyle='#081428';ctx.beginPath();ctx.arc(canX,canY,gR+16,0,Math.PI*2);ctx.fill();
            ctx.strokeStyle='#2060B0';ctx.lineWidth=2;ctx.stroke();
            // 歯（12本・回転）
            for(let tooth=0;tooth<12;tooth++){
                const a=tooth*Math.PI/6+t*0.7;
                const bx2=canX+Math.cos(a)*(gR+7);const by2=canY+Math.sin(a)*(gR+7);
                ctx.fillStyle='#1A3E78';
                ctx.beginPath();
                ctx.moveTo(bx2+Math.cos(a+0.3)*4.5,by2+Math.sin(a+0.3)*4.5);
                ctx.lineTo(bx2+Math.cos(a)*9,by2+Math.sin(a)*9);
                ctx.lineTo(bx2+Math.cos(a-0.3)*4.5,by2+Math.sin(a-0.3)*4.5);
                ctx.closePath();ctx.fill();
                ctx.strokeStyle='#3080CC';ctx.lineWidth=0.8;ctx.stroke();
            }
            // 歯車本体
            ctx.fillStyle='#0C1C3A';ctx.beginPath();ctx.arc(canX,canY,gR+5,0,Math.PI*2);ctx.fill();
            ctx.strokeStyle='#3070BB';ctx.lineWidth=2.5;ctx.stroke();
            // スポーク（8本・逆回転）
            ctx.strokeStyle='rgba(60,140,220,0.65)';ctx.lineWidth=2;
            for(let sp=0;sp<8;sp++){const a2=sp*Math.PI/4-t*0.4;
                ctx.beginPath();ctx.moveTo(canX,canY);ctx.lineTo(canX+Math.cos(a2)*gR,canY+Math.sin(a2)*gR);ctx.stroke();}
            // コアの三日月（エリスグールのシンボル）
            ctx.shadowBlur=10;ctx.shadowColor='rgba(60,160,255,0.9)';
            ctx.fillStyle='#DDAA00';ctx.beginPath();ctx.arc(canX,canY,gR*0.40,0,Math.PI*2);ctx.fill();
            ctx.fillStyle='#0C1C3A';ctx.beginPath();ctx.arc(canX+gR*0.17,canY,gR*0.32,0,Math.PI*2);ctx.fill();
            ctx.shadowBlur=0;
            // 砲身
            const bLen=50,bR=gR*0.46;
            const bbg=ctx.createLinearGradient(canX,canY-bR,canX,canY+bR);
            bbg.addColorStop(0,'#1A3A72');bbg.addColorStop(0.4,'#2A5AB2');bbg.addColorStop(1,'#0C1A42');
            ctx.fillStyle=bbg;
            ctx.beginPath();ctx.ellipse(canX+dir*bLen*0.5,canY,Math.abs(bLen)*0.52,bR,0,0,Math.PI*2);ctx.fill();
            ctx.strokeStyle='#3080CC';ctx.lineWidth=1.5;ctx.stroke();

            // ── スライム垂れ目（エリスグール最大の特徴：赤目×緑目）──
            const eBaseX=cx+dir*tw*0.12, eY=ty+bH*0.28, eR=tw*0.088;
            for(let e=0;e<2;e++){
                const ex=eBaseX+dir*(e-0.5)*eR*2.85;
                const eyeColor=e===0?'#CC0000':'#006600';
                const eyeColorBright=e===0?'#FF2200':'#00BB00';
                // スライム目の外輪（ぷるぷる感）
                ctx.fillStyle='rgba(0,0,0,0.35)';
                ctx.beginPath();ctx.ellipse(ex+1.5,eY+1.5,eR+3,eR+3,0,0,Math.PI*2);ctx.fill();
                ctx.fillStyle=eyeColor;
                ctx.beginPath();ctx.ellipse(ex,eY,eR+2,eR+2,0,0,Math.PI*2);ctx.fill();
                // 暗い瞳孔
                ctx.fillStyle='rgba(0,0,0,0.65)';
                ctx.beginPath();ctx.ellipse(ex,eY,eR,eR,0,0,Math.PI*2);ctx.fill();
                // 光の点
                ctx.fillStyle='rgba(255,255,255,0.85)';
                ctx.beginPath();ctx.arc(ex-eR*0.3,eY-eR*0.3,eR*0.32,0,Math.PI*2);ctx.fill();
                ctx.fillStyle='rgba(255,255,255,0.4)';
                ctx.beginPath();ctx.arc(ex+eR*0.2,eY+eR*0.15,eR*0.15,0,Math.PI*2);ctx.fill();
                // ★スライム垂れ（エリスグールの特徴的なドロドロ）
                ctx.fillStyle=eyeColor;
                ctx.beginPath();ctx.ellipse(ex,eY+eR*1.3,eR*0.38,eR*0.62,0,0,Math.PI*2);ctx.fill();
                ctx.fillStyle='rgba(0,0,0,0.5)';
                ctx.beginPath();ctx.ellipse(ex,eY+eR*1.3,eR*0.32,eR*0.55,0,0,Math.PI*2);ctx.fill();
                ctx.fillStyle=eyeColorBright;
                ctx.beginPath();ctx.arc(ex-eR*0.08,eY+eR*1.0,eR*0.16,0,Math.PI*2);ctx.fill();
            }

            // ── 大きな三日月マーク（胸元）──
            const moonX=cx-dir*tw*0.27, moonY=ty+bH*0.64;
            ctx.shadowBlur=6;ctx.shadowColor='rgba(220,170,0,0.6)';
            ctx.fillStyle='#DDAA00';ctx.beginPath();ctx.arc(moonX,moonY,15,0,Math.PI*2);ctx.fill();
            ctx.fillStyle='#0C1C3A';ctx.beginPath();ctx.arc(moonX+6.5,moonY-1,12,0,Math.PI*2);ctx.fill();
            ctx.shadowBlur=0;

            // ── 城壁冠（エリスグールの頭頂・バトルメント）──
            const crY=ty+4;
            ctx.fillStyle='#1A3A80';
            ctx.beginPath();
            // バトルメント形状（ギザギザ城壁）
            const cW=tw*0.68, cX=cx-cW/2;
            ctx.moveTo(cX,crY);
            const slots=7;
            for(let i=0;i<slots;i++){
                const x1=cX+i*(cW/slots), x2=cX+(i+0.4)*(cW/slots), x3=cX+(i+0.6)*(cW/slots), x4=cX+(i+1)*(cW/slots);
                ctx.lineTo(x1,crY); ctx.lineTo(x1,crY-8);
                ctx.lineTo(x2,crY-8); ctx.lineTo(x2,crY-14);
                ctx.lineTo(x3,crY-14); ctx.lineTo(x3,crY-8);
                ctx.lineTo(x4,crY-8);
            }
            ctx.lineTo(cX+cW,crY); ctx.closePath(); ctx.fill();
            ctx.strokeStyle='#3060CC';ctx.lineWidth=1.5;ctx.stroke();
        }
        if (isEnemy) this._drawStageEnemyOverlay(ctx,tx,ty,tw,th,null,0.5);
        ctx.restore();
    },

    // 🌟 原初の光スキン（第5章クリア報酬）
    // 特徴: 白金装甲 / 光翼 / 輝く十字コア / 虹色オーラ
    _drawLumenTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const dir = isEnemy ? -1 : 1;
        const cx  = tx + tw / 2;
        ctx.save();
        const fl = dmgFlash > 0 ? Math.min(1, dmgFlash / 10) : 0;
        const t  = Date.now() * 0.001;
        const tH = Math.round(th * 0.27);
        const bH = th - tH;

        // ── 虹色オーラ ──
        const aG = ctx.createRadialGradient(cx, ty+th*0.5, 0, cx, ty+th*0.5, tw*1.0);
        aG.addColorStop(0, `rgba(255,255,200,${0.15 + Math.sin(t*2)*0.05})`);
        aG.addColorStop(1, 'rgba(200,220,255,0)');
        ctx.fillStyle = aG;
        ctx.beginPath(); ctx.ellipse(cx, ty+th*0.5, tw*1.0, th*0.6, 0, 0, Math.PI*2); ctx.fill();

        // ── キャタピラ（白金）──
        const tg = ctx.createLinearGradient(tx, ty+bH, tx, ty+th);
        tg.addColorStop(0, fl ? '#FFFFFF' : '#C8D8F0');
        tg.addColorStop(0.5, fl ? '#E0EEFF' : '#A0B8D8');
        tg.addColorStop(1, fl ? '#C0D4FF' : '#6080A8');
        ctx.fillStyle = tg;
        ctx.beginPath(); ctx.moveTo(tx-14, ty+bH+2); ctx.lineTo(tx+tw+14, ty+bH+2);
        ctx.lineTo(tx+tw+18, ty+th); ctx.lineTo(tx-18, ty+th); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#8090B0'; ctx.lineWidth = 2; ctx.stroke();

        // ホイール（光る円）
        for (let i = 0; i < 4; i++) {
            const wx = tx+14+(tw-28)/3*i, wy = ty+bH+tH*0.52;
            const wg = ctx.createRadialGradient(wx, wy, 0, wx, wy, 13);
            wg.addColorStop(0, fl ? '#FFFFFF' : '#E8F4FF');
            wg.addColorStop(1, '#6090C0');
            ctx.fillStyle = wg; ctx.beginPath(); ctx.arc(wx, wy, 13, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#A0C0FF'; ctx.lineWidth = 2; ctx.stroke();
            // 十字スポーク
            ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = 1.5;
            for (let s = 0; s < 4; s++) {
                const a = s * Math.PI/2;
                ctx.beginPath(); ctx.moveTo(wx, wy); ctx.lineTo(wx+Math.cos(a)*10, wy+Math.sin(a)*10); ctx.stroke();
            }
        }

        // ── 本体（白金装甲）──
        const bg = ctx.createLinearGradient(tx, ty, tx, ty+bH);
        bg.addColorStop(0, fl ? '#FFFFFF' : '#E8F0FF');
        bg.addColorStop(0.4, fl ? '#F0F8FF' : '#C8D8F0');
        bg.addColorStop(1, fl ? '#D8E8FF' : '#A0B8D8');
        ctx.fillStyle = bg; Renderer._roundRect(ctx, tx, ty, tw, bH, 10); ctx.fill();
        ctx.shadowBlur = 12; ctx.shadowColor = `rgba(180,210,255,${0.6 + Math.sin(t*3)*0.2})`;
        ctx.strokeStyle = '#6090D0'; ctx.lineWidth = 3;
        Renderer._roundRect(ctx, tx, ty, tw, bH, 10); ctx.stroke();
        ctx.shadowBlur = 0;

        // パネルライン（金）
        ctx.strokeStyle = 'rgba(200,180,80,0.45)'; ctx.lineWidth = 1;
        for (let row = 0; row < 4; row++) for (let col = 0; col < 5; col++) {
            const hS = 15;
            const hx = tx+16+col*hS*1.8+(row%2)*hS*0.9, hy = ty+10+row*hS*1.5;
            ctx.beginPath();
            for (let s = 0; s < 6; s++) {
                const a = s*Math.PI/3-Math.PI/6;
                if(s===0) ctx.moveTo(hx+Math.cos(a)*hS*0.55, hy+Math.sin(a)*hS*0.55);
                else ctx.lineTo(hx+Math.cos(a)*hS*0.55, hy+Math.sin(a)*hS*0.55);
            }
            ctx.closePath(); ctx.stroke();
        }

        // ── 輝く十字コア（中央）──
        const coreCX = cx, coreCY = ty + bH*0.48;
        const coreR = 16 + Math.sin(t*4)*2;
        const coreG = ctx.createRadialGradient(coreCX, coreCY, 0, coreCX, coreCY, coreR);
        coreG.addColorStop(0, '#FFFFFF');
        coreG.addColorStop(0.4, `hsl(${(t*60)%360}, 100%, 80%)`);
        coreG.addColorStop(1, 'rgba(200,220,255,0)');
        ctx.fillStyle = coreG; ctx.beginPath(); ctx.arc(coreCX, coreCY, coreR, 0, Math.PI*2); ctx.fill();
        // 十字光
        ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 3;
        [[0,1],[1,0]].forEach(([dx,dy]) => {
            ctx.beginPath();
            ctx.moveTo(coreCX - dx*coreR*1.5, coreCY - dy*coreR*1.5);
            ctx.lineTo(coreCX + dx*coreR*1.5, coreCY + dy*coreR*1.5);
            ctx.stroke();
        });

        if (!showInterior) {
            // ── 光翼（左右）──
            const wingSwing = Math.sin(t*2)*6;
            [-1, 1].forEach(s => {
                const wBaseX = cx + s*(tw*0.46);
                const wBaseY = ty + bH*0.5;
                ctx.fillStyle = `rgba(200,230,255,${0.55 + Math.sin(t*3)*0.1})`;
                ctx.beginPath();
                ctx.moveTo(wBaseX, wBaseY);
                ctx.lineTo(wBaseX + s*36, wBaseY - 30 + wingSwing*s);
                ctx.lineTo(wBaseX + s*52, wBaseY - 10 + wingSwing*s);
                ctx.lineTo(wBaseX + s*38, wBaseY + 8);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = 'rgba(100,180,255,0.8)'; ctx.lineWidth = 1.5; ctx.stroke();
                // 羽の光脈
                ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 1;
                for (let f = 1; f <= 3; f++) {
                    const frac = f/4;
                    ctx.beginPath();
                    ctx.moveTo(wBaseX, wBaseY);
                    ctx.lineTo(wBaseX + s*(36*frac), wBaseY - 30*frac + wingSwing*s*frac);
                    ctx.stroke();
                }
            });

            // ── 砲塔（白金・虹光）──
            const turretW = tw*0.44, turretH = bH*0.40;
            const turretX = dir > 0 ? cx - turretW*0.4 : cx - turretW*0.6;
            const turretY = ty + bH*0.15;
            const turrG = ctx.createLinearGradient(turretX, turretY, turretX, turretY+turretH);
            turrG.addColorStop(0, fl ? '#FFFFFF' : '#DDE8FF');
            turrG.addColorStop(1, fl ? '#C8D8FF' : '#8AAAD0');
            ctx.fillStyle = turrG;
            Renderer._roundRect(ctx, turretX, turretY, turretW, turretH, 8); ctx.fill();
            ctx.shadowBlur = 8; ctx.shadowColor = `hsl(${(t*60+120)%360}, 100%, 70%)`;
            ctx.strokeStyle = '#6090D0'; ctx.lineWidth = 2;
            Renderer._roundRect(ctx, turretX, turretY, turretW, turretH, 8); ctx.stroke();
            ctx.shadowBlur = 0;

            // 砲口（虹色発光リング）
            const barrelX = dir > 0 ? turretX + turretW : turretX;
            const barrelY = turretY + turretH*0.5;
            const ringColor = `hsl(${(t*80)%360}, 100%, 70%)`;
            ctx.strokeStyle = ringColor; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.arc(barrelX, barrelY, 8, 0, Math.PI*2); ctx.stroke();
            ctx.fillStyle = 'rgba(255,255,255,0.9)';
            ctx.beginPath(); ctx.arc(barrelX, barrelY, 4, 0, Math.PI*2); ctx.fill();
        }

        // ── スライム目（星型・虹色）──
        const eyeY = ty + bH*0.34;
        [cx - tw*0.14, cx + tw*0.14].forEach((ex, ei) => {
            ctx.fillStyle = `hsl(${(t*80 + ei*120)%360}, 100%, 70%)`;
            ctx.shadowBlur = 6; ctx.shadowColor = 'rgba(255,255,255,0.9)';
            ctx.beginPath(); ctx.arc(ex, eyeY, 5, 0, Math.PI*2); ctx.fill();
            ctx.shadowBlur = 0;
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath(); ctx.arc(ex - 1.5, eyeY - 1.5, 2, 0, Math.PI*2); ctx.fill();
        });

        ctx.restore();
    },

    // 🏴‍☠️ 海賊スキン（c2_stage3 海賊戦車テンペスト改）
    _drawPirateTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        ctx.save();
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(Date.now()*0.05)*3, 0); }
        const t = Date.now() * 0.001;
        const wave = Math.sin(t * 1.2) * 3; // 船の揺れ

        const treadH = 38, treadW = tw * 0.80;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;

        // ── 波しぶきエフェクト ──
        for (let i = 0; i < 5; i++) {
            const wx = treadX + i * (treadW / 4) + Math.sin(t*2 + i)*4;
            const wA = 0.12 + Math.sin(t*3 + i*0.8)*0.06;
            ctx.fillStyle = `rgba(120,190,255,${wA})`;
            ctx.beginPath(); ctx.arc(wx, treadY + treadH * 0.8, 8, 0, Math.PI*2); ctx.fill();
        }

        // ── 船底キャタピラ（黒×茶木目）──
        const tg = ctx.createLinearGradient(tx, treadY, tx, ty+th);
        tg.addColorStop(0, dmgFlash > 0 ? '#FF8844' : '#4A2A0A');
        tg.addColorStop(0.5, dmgFlash > 0 ? '#FFAA66' : '#6B3D14');
        tg.addColorStop(1, dmgFlash > 0 ? '#DD6622' : '#3A1A05');
        ctx.fillStyle = tg;
        this._roundRect(ctx, treadX - 10, treadY, treadW + 20, treadH, 10); ctx.fill();
        ctx.strokeStyle = '#2A1A00'; ctx.lineWidth = 2; ctx.stroke();
        // 木目ライン
        for (let i = 0; i < 5; i++) {
            const lx = treadX + 14 + i * ((treadW - 8) / 4);
            ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(lx, treadY + 4); ctx.lineTo(lx, treadY + treadH - 4); ctx.stroke();
        }
        // 車輪（錨マーク付き）
        for (let i = 0; i < 4; i++) {
            const wx = treadX + 20 + i * ((treadW - 40) / 3), wY = treadY + treadH * 0.55;
            const wg = ctx.createRadialGradient(wx-3, wY-3, 1, wx, wY, 13);
            wg.addColorStop(0, '#8B6020'); wg.addColorStop(1, '#3A1A00');
            ctx.fillStyle = wg; ctx.beginPath(); ctx.arc(wx, wY, 13, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#1A0A00'; ctx.lineWidth = 1.5; ctx.stroke();
            ctx.fillStyle = '#C08040'; ctx.beginPath(); ctx.arc(wx, wY, 6, 0, Math.PI*2); ctx.fill();
        }

        // ── 船体ドーム（海賊船の甲板風）──
        const dCX = cx, dCY = treadY - th * 0.30 + wave;
        const dRX = tw * 0.46, dRY = th * 0.40;
        const dg = ctx.createLinearGradient(dCX - dRX, dCY - dRY, dCX + dRX, dCY + dRY * 0.5);
        dg.addColorStop(0, dmgFlash > 0 ? '#FF9966' : '#7A4010');
        dg.addColorStop(0.4, dmgFlash > 0 ? '#FFBB88' : '#9A5820');
        dg.addColorStop(1, dmgFlash > 0 ? '#CC6633' : '#4A2005');
        ctx.beginPath();
        ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI * 2);
        ctx.fillStyle = dg; ctx.fill();
        ctx.strokeStyle = '#2A1000'; ctx.lineWidth = 2.5; ctx.stroke();

        // ── 甲板の板目模様 ──
        ctx.save(); ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI*2); ctx.clip();
        for (let i = 0; i < 6; i++) {
            const ly = dCY - dRY * 0.9 + i * (dRY * 1.8 / 5);
            ctx.strokeStyle = 'rgba(0,0,0,0.18)'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.moveTo(dCX - dRX * 0.95, ly); ctx.lineTo(dCX + dRX * 0.95, ly); ctx.stroke();
        }
        ctx.restore();

        if (!showInterior) {
            // ── マスト（帆柱）2本 ──
            const masts = [dCX - dRX * 0.35, dCX + dRX * 0.25];
            masts.forEach((mx, mi) => {
                const mBot = dCY + dRY * 0.2, mTop = dCY - dRY * 1.55 - mi * 12 + wave;
                const mg = ctx.createLinearGradient(mx - 4, 0, mx + 4, 0);
                mg.addColorStop(0, '#5A3010'); mg.addColorStop(0.5, '#8A5020'); mg.addColorStop(1, '#4A2008');
                ctx.fillStyle = mg; ctx.fillRect(mx - 4, mTop, 8, mBot - mTop);
                ctx.strokeStyle = '#2A1000'; ctx.lineWidth = 1; ctx.strokeRect(mx - 4, mTop, 8, mBot - mTop);
                // 帆（翻る）
                const sailFlap = Math.sin(t * 1.5 + mi * 0.8) * 6;
                const sailH = (mi === 0) ? dRY * 1.1 : dRY * 0.75;
                const sailW = dRX * (mi === 0 ? 0.46 : 0.32);
                const sailTop = mTop + 6, sailBot = sailTop + sailH;
                ctx.fillStyle = dmgFlash > 0 ? 'rgba(255,180,120,0.85)' : 'rgba(240,230,200,0.9)';
                ctx.beginPath();
                ctx.moveTo(mx, sailTop);
                ctx.quadraticCurveTo(mx + dir * (sailW + sailFlap), sailTop + sailH * 0.5, mx, sailBot);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = 'rgba(80,40,0,0.5)'; ctx.lineWidth = 1; ctx.stroke();
                // 横桟
                const yardY = sailTop + sailH * 0.08;
                ctx.strokeStyle = '#5A3010'; ctx.lineWidth = 3;
                ctx.beginPath(); ctx.moveTo(mx - dir * sailW * 0.5, yardY); ctx.lineTo(mx + dir * sailW * 1.05, yardY); ctx.stroke();
            });

            // ── ドクロ旗（ジョリー・ロジャー）──
            const flagMx = masts[0], flagTop = dCY - dRY * 1.55 + wave - 8;
            const flapX = Math.sin(t * 2.0) * 5;
            ctx.fillStyle = 'rgba(15,10,5,0.92)';
            ctx.beginPath();
            ctx.moveTo(flagMx, flagTop);
            ctx.lineTo(flagMx + dir * (24 + flapX), flagTop - 2);
            ctx.lineTo(flagMx + dir * (22 + flapX), flagTop + 14);
            ctx.lineTo(flagMx, flagTop + 12);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = 'rgba(60,40,20,0.6)'; ctx.lineWidth = 0.8; ctx.stroke();
            // ドクロシルエット
            const skX = flagMx + dir * 11, skY = flagTop + 4;
            ctx.fillStyle = 'rgba(240,230,220,0.85)';
            ctx.beginPath(); ctx.arc(skX, skY, 5.5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = 'rgba(15,10,5,0.9)';
            ctx.beginPath(); ctx.arc(skX - 2, skY - 0.5, 1.4, 0, Math.PI*2); ctx.fill();
            ctx.beginPath(); ctx.arc(skX + 2, skY - 0.5, 1.4, 0, Math.PI*2); ctx.fill();
            // 骨
            [-2.5, 2.5].forEach(ox => {
                ctx.strokeStyle = 'rgba(240,230,220,0.85)'; ctx.lineWidth = 1.5;
                ctx.beginPath(); ctx.moveTo(skX - 4, skY + 3 + ox*0.3); ctx.lineTo(skX + 4, skY + 3 - ox*0.3); ctx.stroke();
            });

            // ── 大砲（船側砲口）──
            const cY = dCY + dRY * 0.05;
            const cX = dCX + dir * dRX * 0.55;
            ctx.fillStyle = '#2A1A00'; ctx.beginPath(); ctx.arc(cX, cY, 17, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#5A3A10'; ctx.beginPath(); ctx.arc(cX, cY, 13, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#1A0A00'; ctx.beginPath(); ctx.arc(cX, cY, 8, 0, Math.PI*2); ctx.fill();
            // 砲身
            const bLen = 42;
            ctx.fillStyle = '#3A2208';
            ctx.save(); ctx.translate(cX, cY); ctx.rotate(dir > 0 ? -0.1 : Math.PI + 0.1);
            ctx.fillRect(0, -5, bLen, 10); ctx.fillStyle = '#1A0A00'; ctx.fillRect(bLen - 6, -6, 10, 12);
            ctx.strokeStyle = '#2A1000'; ctx.lineWidth = 1; ctx.strokeRect(0, -5, bLen, 10);
            ctx.restore();

            // ── 錨エンブレム ──
            const emX = dCX - dir * dRX * 0.22, emY = dCY + dRY * 0.30;
            ctx.fillStyle = 'rgba(30,20,5,0.55)'; ctx.strokeStyle = 'rgba(180,130,60,0.55)'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(emX, emY, 16, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            // 錨シンボル
            ctx.strokeStyle = 'rgba(200,160,80,0.75)'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.moveTo(emX, emY - 9); ctx.lineTo(emX, emY + 9); ctx.stroke();
            ctx.beginPath(); ctx.arc(emX, emY - 5, 5, 0, Math.PI); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(emX - 7, emY + 9); ctx.lineTo(emX + 7, emY + 9); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(emX - 6, emY - 9); ctx.lineTo(emX + 6, emY - 9); ctx.stroke();

            // ── 目（海賊の鋭い眼）──
            const eY = dCY - dRY * 0.22;
            [[-1],[1]].forEach(([s]) => {
                const ex = dCX + s * dRX * 0.25;
                ctx.fillStyle = 'rgba(10,6,2,0.9)'; ctx.beginPath(); ctx.arc(ex, eY, 9, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = 'rgba(180,100,20,0.9)'; ctx.beginPath(); ctx.arc(ex, eY, 5, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = 'rgba(10,6,2,0.9)'; ctx.beginPath(); ctx.arc(ex + s, eY + 1, 3, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = 'rgba(255,220,150,0.6)'; ctx.beginPath(); ctx.arc(ex - 2, eY - 2, 2, 0, Math.PI*2); ctx.fill();
                // 眉（険しい）
                ctx.strokeStyle = 'rgba(60,30,10,0.8)'; ctx.lineWidth = 2.5;
                ctx.beginPath(); ctx.moveTo(ex - 7, eY - 10 - s*2); ctx.lineTo(ex + 7, eY - 8 + s*2); ctx.stroke();
            });
            // 傷跡（海賊らしさ）
            ctx.strokeStyle = 'rgba(150,60,20,0.5)'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.moveTo(dCX + dir * dRX * 0.28, dCY - dRY * 0.40); ctx.lineTo(dCX + dir * dRX * 0.12, dCY - dRY * 0.08); ctx.stroke();
        }
        ctx.restore();
    },

    // ♨️ 蒸気魔導士スキン（c2_stage4 湯けむり魔導士ステーミー）
    _drawSteamTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        ctx.save();
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(Date.now()*0.05)*3, 0); }
        const t = Date.now() * 0.001;

        const treadH = 38, treadW = tw * 0.82;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;

        // ── 蒸気パーティクル（背景）──
        for (let i = 0; i < 8; i++) {
            const sX = treadX + (i / 7) * treadW + Math.sin(t * 1.5 + i) * 10;
            const sY = treadY - 20 - i * 14 + Math.sin(t * 2 + i * 0.7) * 8;
            const sA = Math.max(0, 0.18 - i * 0.018) * (0.7 + Math.sin(t * 3 + i) * 0.3);
            const sR = 10 + i * 5;
            ctx.fillStyle = `rgba(200,230,255,${sA})`;
            ctx.beginPath(); ctx.arc(sX, sY, sR, 0, Math.PI * 2); ctx.fill();
        }

        // ── キャタピラ（銅・真鍮製）──
        const tg = ctx.createLinearGradient(tx, treadY, tx, ty + th);
        tg.addColorStop(0, dmgFlash > 0 ? '#FFCC88' : '#8B5A20');
        tg.addColorStop(0.4, dmgFlash > 0 ? '#FFDDAA' : '#B07830');
        tg.addColorStop(1, dmgFlash > 0 ? '#CC8844' : '#5A3010');
        ctx.fillStyle = tg;
        this._roundRect(ctx, treadX - 12, treadY, treadW + 24, treadH, 12); ctx.fill();
        ctx.strokeStyle = '#3A1A00'; ctx.lineWidth = 2.5; ctx.stroke();
        // リベット
        for (let i = 0; i < 6; i++) {
            const rx = treadX + 10 + i * ((treadW - 20) / 5), ry = treadY + 8;
            ctx.fillStyle = '#D0A050'; ctx.beginPath(); ctx.arc(rx, ry, 4, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#805010'; ctx.lineWidth = 1; ctx.stroke();
        }
        // 歯車ホイール
        for (let i = 0; i < 4; i++) {
            const wx = treadX + 18 + i * ((treadW - 36) / 3), wY = treadY + treadH * 0.58;
            const wg = ctx.createRadialGradient(wx-3, wY-3, 1, wx, wY, 14);
            wg.addColorStop(0, '#D0A050'); wg.addColorStop(1, '#5A3010');
            ctx.fillStyle = wg; ctx.beginPath(); ctx.arc(wx, wY, 14, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#2A1000'; ctx.lineWidth = 1.5; ctx.stroke();
            // 歯車の歯（8本）
            for (let j = 0; j < 8; j++) {
                const ang = (t * 0.8 + j * Math.PI/4) * (i%2 ? 1 : -1);
                const tx2 = wx + Math.cos(ang) * 14, ty2 = wY + Math.sin(ang) * 14;
                ctx.fillStyle = '#C09040';
                ctx.beginPath(); ctx.arc(tx2, ty2, 3, 0, Math.PI*2); ctx.fill();
            }
            ctx.fillStyle = '#D8B060'; ctx.beginPath(); ctx.arc(wx, wY, 5, 0, Math.PI*2); ctx.fill();
        }

        // ── 本体ドーム（魔導ボイラー型）──
        const dCX = cx, dCY = treadY - th * 0.28;
        const dRX = tw * 0.47, dRY = th * 0.42;
        // 外装グラデーション（紫×銅）
        const dg = ctx.createLinearGradient(dCX - dRX, dCY - dRY, dCX + dRX, dCY + dRY * 0.6);
        dg.addColorStop(0, dmgFlash > 0 ? '#FFCCEE' : '#6A1B9A');
        dg.addColorStop(0.35, dmgFlash > 0 ? '#FFAADD' : '#8B3AB8');
        dg.addColorStop(0.7, dmgFlash > 0 ? '#EE88CC' : '#4A1270');
        dg.addColorStop(1, dmgFlash > 0 ? '#CC66AA' : '#2A0840');
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI*2);
        ctx.fillStyle = dg; ctx.fill();
        // 銅色リング（ボイラー帯）
        for (let i = 0; i < 3; i++) {
            const ry = dCY - dRY * 0.5 + i * dRY * 0.5;
            const rW = Math.sqrt(Math.max(0, 1 - Math.pow((ry - dCY) / dRY, 2))) * dRX;
            ctx.strokeStyle = 'rgba(180,120,40,0.55)'; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.ellipse(dCX, ry, rW, dRY * 0.06, 0, 0, Math.PI*2); ctx.stroke();
        }
        ctx.strokeStyle = '#3A0060'; ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI*2); ctx.stroke();

        if (!showInterior) {
            // ── 蒸気パイプ3本（上から煙を出す）──
            const pipes = [
                { x: dCX - dRX * 0.45, top: dCY - dRY * 1.15, r: 8 },
                { x: dCX + dRX * 0.08, top: dCY - dRY * 1.30, r: 10 },
                { x: dCX + dRX * 0.48, top: dCY - dRY * 1.05, r: 7 },
            ];
            pipes.forEach(p => {
                // パイプ本体
                const pg = ctx.createLinearGradient(p.x - p.r, 0, p.x + p.r, 0);
                pg.addColorStop(0, '#5A3010'); pg.addColorStop(0.5, '#A06020'); pg.addColorStop(1, '#4A2008');
                ctx.fillStyle = pg;
                ctx.fillRect(p.x - p.r, p.top, p.r * 2, dCY - dRY * 0.6 - p.top);
                ctx.strokeStyle = '#2A1000'; ctx.lineWidth = 1.5;
                ctx.strokeRect(p.x - p.r, p.top, p.r * 2, dCY - dRY * 0.6 - p.top);
                // パイプ先端キャップ
                ctx.fillStyle = '#C09040'; ctx.beginPath();
                ctx.ellipse(p.x, p.top, p.r + 3, 5, 0, 0, Math.PI*2); ctx.fill();
                ctx.strokeStyle = '#5A3010'; ctx.lineWidth = 1; ctx.stroke();
                // 蒸気（上昇）
                for (let si = 0; si < 4; si++) {
                    const sOff = Math.sin(t * 2.0 + p.x * 0.01 + si * 1.5) * 7;
                    const sY = p.top - 15 - si * 20 + Math.sin(t * 1.8 + si) * 5;
                    const sA = Math.max(0, 0.3 - si * 0.06);
                    ctx.fillStyle = `rgba(220,200,255,${sA})`;
                    ctx.beginPath(); ctx.arc(p.x + sOff, sY, (si + 1) * 6, 0, Math.PI*2); ctx.fill();
                }
            });

            // ── 魔法陣（機体中央）──
            const sigR = dRX * 0.52;
            const sigA = 0.12 + Math.sin(t * 1.5) * 0.05;
            ctx.strokeStyle = `rgba(220,150,255,${sigA + 0.12})`; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.arc(dCX, dCY, sigR, 0, Math.PI*2); ctx.stroke();
            for (let i = 0; i < 6; i++) {
                const ang1 = t * 0.4 + i * Math.PI / 3;
                const ang2 = t * 0.4 + (i + 2) * Math.PI / 3;
                ctx.strokeStyle = `rgba(200,120,255,${sigA + 0.08})`; ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(dCX + Math.cos(ang1) * sigR, dCY + Math.sin(ang1) * sigR);
                ctx.lineTo(dCX + Math.cos(ang2) * sigR, dCY + Math.sin(ang2) * sigR);
                ctx.stroke();
            }

            // ── 砲口（蒸気噴射型）──
            const cY = dCY + dRY * 0.05;
            const cX = dCX + dir * dRX * 0.58;
            ctx.fillStyle = '#3A0060'; ctx.beginPath(); ctx.arc(cX, cY, 17, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#7A20A0'; ctx.beginPath(); ctx.arc(cX, cY, 12, 0, Math.PI*2); ctx.fill();
            // 銅リング
            ctx.strokeStyle = '#C09040'; ctx.lineWidth = 2.5;
            ctx.beginPath(); ctx.arc(cX, cY, 15, 0, Math.PI*2); ctx.stroke();
            ctx.fillStyle = '#1A0030'; ctx.beginPath(); ctx.arc(cX, cY, 7, 0, Math.PI*2); ctx.fill();
            // 砲身
            const bLen = 44;
            const bg = ctx.createLinearGradient(0, cY - 7, 0, cY + 7);
            bg.addColorStop(0, '#A06020'); bg.addColorStop(0.5, '#C88030'); bg.addColorStop(1, '#6A3A10');
            ctx.fillStyle = bg;
            ctx.save(); ctx.translate(cX, cY); ctx.rotate(dir > 0 ? -0.05 : Math.PI + 0.05);
            ctx.beginPath(); this._roundRect(ctx, 2, -6, bLen, 12, 4); ctx.fill();
            ctx.strokeStyle = '#3A1A00'; ctx.lineWidth = 1; ctx.stroke();
            // 蒸気孔
            for (let i = 1; i <= 3; i++) {
                ctx.fillStyle = 'rgba(200,150,255,0.35)';
                ctx.beginPath(); ctx.arc(i * 10, -7, 3, 0, Math.PI*2); ctx.fill();
            }
            ctx.restore();

            // ── 目（丸い魔法眼）──
            const eY = dCY - dRY * 0.24;
            [[-1],[1]].forEach(([s]) => {
                const ex = dCX + s * dRX * 0.26;
                const glowA = 0.3 + Math.sin(t * 2.5 + s) * 0.15;
                ctx.fillStyle = `rgba(220,160,255,${glowA * 0.5})`;
                ctx.beginPath(); ctx.arc(ex, eY, 14, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = 'rgba(30,10,50,0.92)'; ctx.beginPath(); ctx.arc(ex, eY, 10, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = `rgba(200,100,255,${0.7 + Math.sin(t*3+s)*0.2})`; ctx.beginPath(); ctx.arc(ex, eY, 6, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = 'rgba(30,10,50,0.92)'; ctx.beginPath(); ctx.arc(ex + s, eY + 1, 3.5, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = 'rgba(240,200,255,0.7)'; ctx.beginPath(); ctx.arc(ex - 2, eY - 2, 2, 0, Math.PI*2); ctx.fill();
            });

            // ── エンブレム（温泉♨マーク）──
            const emX = dCX - dir * dRX * 0.2, emY = dCY + dRY * 0.32;
            ctx.fillStyle = 'rgba(50,10,80,0.55)'; ctx.strokeStyle = 'rgba(180,100,255,0.5)'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(emX, emY, 16, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            // ♨ ウェーブ3本
            for (let i = 0; i < 3; i++) {
                const wX = emX - 6 + i * 6;
                ctx.strokeStyle = `rgba(200,160,255,0.8)`; ctx.lineWidth = 1.8;
                ctx.beginPath();
                ctx.moveTo(wX, emY + 5); ctx.quadraticCurveTo(wX - 4, emY - 1, wX, emY - 7);
                ctx.quadraticCurveTo(wX + 4, emY - 13, wX, emY - 14);
                ctx.stroke();
            }
        }
        ctx.restore();
    },

    // ⚔️ 侍スキン（c4_stage2 廃都の幻影兵ミラージュ）
    _drawSamuraiTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, isEnemy = false) {
        const cx = tx + tw / 2;
        const dir = isEnemy ? -1 : 1;
        ctx.save();
        if (dmgFlash > 0.5) { ctx.translate(Math.sin(Date.now()*0.05)*2, Math.sin(Date.now()*0.07)*1.5); }
        const t = Date.now() * 0.001;

        const treadH = 38, treadW = tw * 0.80;
        const treadX = cx - treadW / 2, treadY = ty + th - treadH;

        // ── 残像エフェクト（幻影系）──
        for (let i = 1; i <= 3; i++) {
            const ghostOff = Math.sin(t * 2 + i) * (i * 5);
            ctx.fillStyle = `rgba(80,0,160,${0.07 - i*0.02})`;
            ctx.beginPath();
            ctx.ellipse(cx + ghostOff, treadY - th * 0.28, tw * 0.44, th * 0.40, 0, 0, Math.PI*2);
            ctx.fill();
        }

        // ── キャタピラ（黒×紫金）──
        const tg = ctx.createLinearGradient(tx, treadY, tx, ty + th);
        tg.addColorStop(0, dmgFlash > 0 ? '#8866FF' : '#1A0030');
        tg.addColorStop(0.4, dmgFlash > 0 ? '#AA88FF' : '#2E0050');
        tg.addColorStop(1, dmgFlash > 0 ? '#6644CC' : '#0F0020');
        ctx.fillStyle = tg;
        this._roundRect(ctx, treadX - 10, treadY, treadW + 20, treadH, 8); ctx.fill();
        ctx.strokeStyle = '#0A0018'; ctx.lineWidth = 2; ctx.stroke();
        // 金線（装甲継ぎ目）
        for (let i = 0; i < 5; i++) {
            const lx = treadX + 14 + i * ((treadW - 8) / 4);
            ctx.strokeStyle = 'rgba(200,160,255,0.2)'; ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(lx, treadY + 3); ctx.lineTo(lx, treadY + treadH - 3); ctx.stroke();
        }
        // 車輪（六角形）
        for (let i = 0; i < 4; i++) {
            const wx = treadX + 18 + i * ((treadW - 36) / 3), wY = treadY + treadH * 0.55;
            const wg = ctx.createRadialGradient(wx-3, wY-3, 1, wx, wY, 13);
            wg.addColorStop(0, '#4A1080'); wg.addColorStop(1, '#0A0018');
            ctx.fillStyle = wg; ctx.beginPath(); ctx.arc(wx, wY, 13, 0, Math.PI*2); ctx.fill();
            // 六角形の縁
            ctx.strokeStyle = 'rgba(180,120,255,0.5)'; ctx.lineWidth = 1.5;
            ctx.beginPath();
            for (let j = 0; j < 6; j++) {
                const ang = j * Math.PI / 3 + t * 0.3 * (i%2 ? 1 : -1);
                j === 0 ? ctx.moveTo(wx + Math.cos(ang)*13, wY + Math.sin(ang)*13)
                        : ctx.lineTo(wx + Math.cos(ang)*13, wY + Math.sin(ang)*13);
            }
            ctx.closePath(); ctx.stroke();
            ctx.fillStyle = 'rgba(160,80,255,0.7)'; ctx.beginPath(); ctx.arc(wx, wY, 5, 0, Math.PI*2); ctx.fill();
        }

        // ── 本体ドーム（兜形・侍甲冑）──
        const dCX = cx, dCY = treadY - th * 0.29;
        const dRX = tw * 0.46, dRY = th * 0.42;
        // 本体
        const dg = ctx.createLinearGradient(dCX - dRX, dCY - dRY, dCX + dRX, dCY + dRY * 0.5);
        dg.addColorStop(0, dmgFlash > 0 ? '#CC88FF' : '#1E003A');
        dg.addColorStop(0.3, dmgFlash > 0 ? '#BB66EE' : '#2E0052');
        dg.addColorStop(0.7, dmgFlash > 0 ? '#AA44DD' : '#180028');
        dg.addColorStop(1, dmgFlash > 0 ? '#8833BB' : '#0A0015');
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI*2);
        ctx.fillStyle = dg; ctx.fill();
        // 金装飾線
        ctx.strokeStyle = 'rgba(200,160,255,0.4)'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI*2); ctx.stroke();
        // 装甲プレートライン
        for (let i = 0; i < 4; i++) {
            const ry = dCY - dRY * 0.6 + i * dRY * 0.45;
            const rW = Math.sqrt(Math.max(0, 1 - Math.pow((ry - dCY) / dRY, 2))) * dRX * 0.9;
            ctx.strokeStyle = 'rgba(160,80,255,0.2)'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.moveTo(dCX - rW, ry); ctx.lineTo(dCX + rW, ry); ctx.stroke();
        }

        if (!showInterior) {
            // ── 兜の角（鍬形・2本）──
            const kuwagataH = dRY * 1.6;
            [[- 1],[1]].forEach(([s]) => {
                const kBaseX = dCX + s * dRX * 0.18, kBaseY = dCY - dRY * 0.9;
                const kTipX = dCX + s * dRX * 0.65, kTipY = dCY - dRY * 1.0 - kuwagataH * 0.5;
                // 角の形（曲がった刀形）
                const kg = ctx.createLinearGradient(kBaseX, kBaseY, kTipX, kTipY);
                kg.addColorStop(0, 'rgba(180,100,255,0.9)');
                kg.addColorStop(0.5, 'rgba(220,180,255,0.85)');
                kg.addColorStop(1, 'rgba(120,60,200,0.7)');
                ctx.strokeStyle = kg; ctx.lineWidth = 6;
                ctx.lineCap = 'round';
                ctx.beginPath();
                ctx.moveTo(kBaseX, kBaseY);
                ctx.bezierCurveTo(
                    kBaseX + s * dRX * 0.28, kBaseY - kuwagataH * 0.4,
                    kTipX - s * dRX * 0.1, kTipY + kuwagataH * 0.3,
                    kTipX, kTipY
                );
                ctx.stroke();
                // 角の光（グロー）
                const glowA = 0.2 + Math.sin(t * 2 + s) * 0.1;
                ctx.strokeStyle = `rgba(220,160,255,${glowA})`;
                ctx.lineWidth = 14; ctx.beginPath();
                ctx.moveTo(kBaseX, kBaseY);
                ctx.bezierCurveTo(
                    kBaseX + s * dRX * 0.28, kBaseY - kuwagataH * 0.4,
                    kTipX - s * dRX * 0.1, kTipY + kuwagataH * 0.3,
                    kTipX, kTipY
                );
                ctx.stroke();
            });

            // ── 刀（背後に背負う）──
            const swordX = dCX - dir * dRX * 0.72, swordTop = dCY - dRY * 1.10;
            const swordBot = dCY + dRY * 0.60;
            const sAngle = dir > 0 ? -0.18 : Math.PI + 0.18;
            ctx.save();
            ctx.translate(swordX, (swordTop + swordBot) / 2);
            ctx.rotate(sAngle);
            // 鞘
            const shG = ctx.createLinearGradient(-5, 0, 5, 0);
            shG.addColorStop(0, '#0A0018'); shG.addColorStop(0.5, '#2A0050'); shG.addColorStop(1, '#0A0018');
            ctx.fillStyle = shG;
            this._roundRect(ctx, -5, -(swordBot - swordTop) / 2, 10, swordBot - swordTop, 4); ctx.fill();
            ctx.strokeStyle = 'rgba(160,80,255,0.5)'; ctx.lineWidth = 1; ctx.stroke();
            // 刀身（部分的に鞘から出ている）
            ctx.fillStyle = 'rgba(200,220,255,0.85)';
            this._roundRect(ctx, -2.5, -(swordBot - swordTop) / 2 - 18, 5, 22, 2); ctx.fill();
            ctx.strokeStyle = 'rgba(220,200,255,0.5)'; ctx.lineWidth = 0.8; ctx.stroke();
            // 鍔（鎬部）
            ctx.fillStyle = 'rgba(180,120,255,0.8)';
            ctx.beginPath(); ctx.ellipse(0, -(swordBot - swordTop)*0.3, 11, 4, 0, 0, Math.PI*2); ctx.fill();
            ctx.restore();

            // ── 砲口（刃型砲口）──
            const cY = dCY + dRY * 0.05;
            const cX = dCX + dir * dRX * 0.57;
            // 砲台リング（紋章付き）
            ctx.fillStyle = '#0A0018'; ctx.beginPath(); ctx.arc(cX, cY, 17, 0, Math.PI*2); ctx.fill();
            const cRingG = ctx.createRadialGradient(cX-4, cY-4, 1, cX, cY, 17);
            cRingG.addColorStop(0, 'rgba(120,50,200,0.9)'); cRingG.addColorStop(1, 'rgba(30,0,60,0.9)');
            ctx.fillStyle = cRingG; ctx.beginPath(); ctx.arc(cX, cY, 14, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = 'rgba(200,150,255,0.6)'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(cX, cY, 16, 0, Math.PI*2); ctx.stroke();
            ctx.fillStyle = '#0A0018'; ctx.beginPath(); ctx.arc(cX, cY, 7, 0, Math.PI*2); ctx.fill();
            // 砲身（刀身を模した形）
            const bLen = 46;
            ctx.save(); ctx.translate(cX, cY); ctx.rotate(dir > 0 ? -0.06 : Math.PI + 0.06);
            // 刃
            const bG2 = ctx.createLinearGradient(0, -7, 0, 7);
            bG2.addColorStop(0, 'rgba(180,140,255,0.85)');
            bG2.addColorStop(0.5, 'rgba(220,200,255,0.9)');
            bG2.addColorStop(1, 'rgba(100,50,180,0.85)');
            ctx.fillStyle = bG2;
            ctx.beginPath();
            ctx.moveTo(2, -5); ctx.lineTo(bLen - 10, -3); ctx.lineTo(bLen + 4, 0); ctx.lineTo(bLen - 10, 3); ctx.lineTo(2, 5);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = 'rgba(200,160,255,0.5)'; ctx.lineWidth = 1; ctx.stroke();
            // 刃光
            const glowA2 = 0.15 + Math.sin(t * 3) * 0.08;
            ctx.strokeStyle = `rgba(220,200,255,${glowA2})`; ctx.lineWidth = 8;
            ctx.beginPath(); ctx.moveTo(5, 0); ctx.lineTo(bLen + 4, 0); ctx.stroke();
            ctx.restore();

            // ── 目（切れ長の侍目）──
            const eY = dCY - dRY * 0.24;
            [[-1],[1]].forEach(([s]) => {
                const ex = dCX + s * dRX * 0.25;
                const glA = 0.5 + Math.sin(t * 2.5 + s) * 0.2;
                ctx.fillStyle = 'rgba(8,0,20,0.95)'; ctx.beginPath(); ctx.arc(ex, eY, 10, 0, Math.PI*2); ctx.fill();
                // 切れ長眼球（楕円形）
                ctx.fillStyle = `rgba(160,80,255,${glA})`;
                ctx.save(); ctx.translate(ex, eY);
                ctx.beginPath(); ctx.ellipse(0, 0, 8, 5, 0, 0, Math.PI*2); ctx.fill();
                ctx.restore();
                ctx.fillStyle = 'rgba(8,0,20,0.9)'; ctx.beginPath(); ctx.arc(ex + s*0.5, eY + 0.5, 3.5, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = 'rgba(220,200,255,0.65)'; ctx.beginPath(); ctx.arc(ex - 2, eY - 2.5, 1.8, 0, Math.PI*2); ctx.fill();
                // 鋭い眉
                ctx.strokeStyle = 'rgba(180,120,255,0.6)'; ctx.lineWidth = 2;
                ctx.beginPath(); ctx.moveTo(ex - 8, eY - 11 - s*3); ctx.lineTo(ex + 8, eY - 7 + s*3); ctx.stroke();
            });

            // ── エンブレム（家紋：三つ巴）──
            const emX = dCX - dir * dRX * 0.22, emY = dCY + dRY * 0.32;
            ctx.fillStyle = 'rgba(15,0,30,0.6)'; ctx.strokeStyle = 'rgba(180,120,255,0.55)'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(emX, emY, 16, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            // 三つ巴
            for (let i = 0; i < 3; i++) {
                const ang = i * Math.PI * 2 / 3 + t * 0.2;
                const gX = emX + Math.cos(ang) * 5, gY = emY + Math.sin(ang) * 5;
                ctx.strokeStyle = 'rgba(200,160,255,0.75)'; ctx.lineWidth = 2;
                ctx.beginPath(); ctx.arc(gX, gY, 5, ang + Math.PI * 0.5, ang - Math.PI * 0.5, true); ctx.stroke();
            }
        }
        ctx.restore();
    },

    // HEAVY / DEFENSE：重装甲型 → カニスキン流用（どっしり重厚感）
    _drawEnemyHeavy(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle, tankType) {
        this._drawCrabTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, true);
        this._drawStageEnemyOverlay(ctx, tx, ty, tw, th, battle, 0.9);
    },

    // MAGICAL：魔法使い型 → 魔王スキン流用
    _drawEnemyMagical(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle) {
        this._drawMaouTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, true);
        this._drawStageEnemyOverlay(ctx, tx, ty, tw, th, battle, 0.9);
    },

    // BOSS：ボス型 → メカスキン流用（機械的な威圧感）
    _drawEnemyBoss(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle) {
        this._drawMechaTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, true);
        this._drawStageEnemyOverlay(ctx, tx, ty, tw, th, battle, 0.95);
    },

    // TRUE_BOSS：真ラスボス型 → ゴーストスキン流用（禍々しさ）
    _drawEnemyTrueBoss(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle) {
        this._drawGhostTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, true);
        this._drawStageEnemyOverlay(ctx, tx, ty, tw, th, battle, 0.95);
    },

    // ============================================================
    // Chapter2: メカ戦車テーマ（角ばった装甲板・リベット・電気グロー）
    // ============================================================
    _drawMechaThemeTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, tankType, battle) {
        const isPhaseTwo = battle && battle.bossPhase === 2;
        const frame = _getFrameNow();
        const cx = tx + tw / 2;
        const variant = this._getStageEnemyVariant(battle);
        const stageId = battle && battle.stageData && battle.stageData.id;
        const accent = isPhaseTwo ? '#C080FF' : variant.trim;
        const glowColor = isPhaseTwo ? 'rgba(180,80,255,0.7)' : variant.glow;
        const pulse = (Math.sin(frame * 0.06) + 1) / 2;

        // ─── スケール（タイプ別）───
        let scaleX = 1.0;
        if (tankType === 'TRUE_BOSS') scaleX = isPhaseTwo ? 1.4 : 1.25;
        else if (tankType === 'BOSS' || tankType === 'HEAVY' || tankType === 'DEFENSE') scaleX = 1.15;
        else if (tankType === 'SCOUT') scaleX = 0.9;

        ctx.save();
        if (dmgFlash > 0.5) {
            const st = frame * 0.05;
            ctx.translate(Math.sin(st * 7.3) * 3, Math.sin(st * 11.7) * 2);
        }
        ctx.translate(cx, ty + th);
        ctx.scale(scaleX, 1.0);
        ctx.translate(-cx, -(ty + th));

        // ─── 寸法 ───
        const treadH = 38;
        const treadW = tw * 0.88;
        const treadX = cx - treadW / 2;
        const treadY = ty + th - treadH;

        const bodyH = th - treadH - 6;
        const bodyW = tw * 0.80;
        const bodyX = cx - bodyW / 2;
        const bodyY = treadY - bodyH;

        const domeRX = bodyW * 0.50;
        const domeRY = bodyH * 0.60;
        const domeCX = cx;
        const domeCY = bodyY - 2;

        // ──────────────────────────────────────────────────
        // 1. 地面グロー（足元オーラ）
        // ──────────────────────────────────────────────────
        const groundGlowAlpha = 0.18 + pulse * 0.12;
        ctx.fillStyle = isPhaseTwo ? `rgba(160,60,255,${groundGlowAlpha})` : `rgba(${parseInt(variant.trim.slice(1,3),16)},${parseInt(variant.trim.slice(3,5),16)},${parseInt(variant.trim.slice(5,7),16)},${groundGlowAlpha})`;
        ctx.beginPath();
        ctx.ellipse(cx, treadY + treadH - 4, treadW * 0.52, 8, 0, 0, Math.PI * 2);
        ctx.fill();

        // ──────────────────────────────────────────────────
        // 2. キャタピラ（角ばった装甲板・多段パネル）
        // ──────────────────────────────────────────────────
        // 外装甲
        const tG = ctx.createLinearGradient(treadX, treadY, treadX, treadY + treadH);
        tG.addColorStop(0, _lightenCached(variant.shadow, 18));
        tG.addColorStop(0.45, variant.base);
        tG.addColorStop(1, variant.shadow);
        ctx.fillStyle = tG;
        ctx.beginPath();
        ctx.moveTo(treadX + 8, treadY);
        ctx.lineTo(treadX + treadW - 8, treadY);
        ctx.lineTo(treadX + treadW + 4, treadY + treadH);
        ctx.lineTo(treadX - 4, treadY + treadH);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = isPhaseTwo ? '#9040CC' : variant.shadow;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // リベット線（装甲継ぎ目）
        ctx.strokeStyle = isPhaseTwo ? `rgba(180,100,255,0.5)` : `rgba(255,255,255,0.18)`;
        ctx.lineWidth = 1;
        ctx.setLineDash([5, 4]);
        ctx.beginPath();
        ctx.moveTo(treadX + 6, treadY + treadH * 0.38);
        ctx.lineTo(treadX + treadW - 6, treadY + treadH * 0.38);
        ctx.stroke();
        ctx.setLineDash([]);

        // 装甲板セグメント縦区切り
        const segCount = 8;
        ctx.strokeStyle = 'rgba(0,0,0,0.25)';
        ctx.lineWidth = 1.5;
        for (let i = 1; i < segCount; i++) {
            const sx = treadX + (treadW / segCount) * i;
            ctx.beginPath();
            ctx.moveTo(sx, treadY + 2);
            ctx.lineTo(sx + 3, treadY + treadH - 2);
            ctx.stroke();
        }

        // 発光下辺
        ctx.shadowColor = isPhaseTwo ? '#C080FF' : accent;
        ctx.shadowBlur = 6;
        ctx.strokeStyle = isPhaseTwo ? `rgba(180,80,255,${0.5 + pulse * 0.3})` : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},${0.5 + pulse * 0.35})`;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(treadX, treadY + treadH - 1);
        ctx.lineTo(treadX + treadW, treadY + treadH - 1);
        ctx.stroke();
        ctx.shadowBlur = 0;

        // ホイール（四角センサー）
        const wCount = 5;
        const wSize = 14;
        const wY = treadY + treadH * 0.55;
        for (let i = 0; i < wCount; i++) {
            const wx = treadX + 10 + (treadW - 20) / (wCount - 1) * i;
            ctx.fillStyle = _lightenCached(variant.shadow, 6);
            ctx.fillRect(wx - wSize / 2, wY - wSize / 2, wSize, wSize);
            ctx.strokeStyle = isPhaseTwo ? 'rgba(180,100,255,0.7)' : accent;
            ctx.lineWidth = 1.5;
            ctx.strokeRect(wx - wSize / 2, wY - wSize / 2, wSize, wSize);
            // センターLED（点滅）
            const ledBlink = (Math.sin(frame * 0.12 + i * 1.1) + 1) / 2;
            ctx.fillStyle = isPhaseTwo ? `rgba(200,120,255,${0.5 + ledBlink * 0.5})` : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},${0.4 + ledBlink * 0.6})`;
            ctx.fillRect(wx - 3, wY - 3, 6, 6);
        }

        // ──────────────────────────────────────────────────
        // 3. 車体（六角形装甲プレート）
        // ──────────────────────────────────────────────────
        const bodyG = ctx.createLinearGradient(bodyX, bodyY, bodyX + bodyW, bodyY + bodyH);
        bodyG.addColorStop(0, isPhaseTwo ? '#3A1A5E' : _lightenCached(variant.base, 14));
        bodyG.addColorStop(0.4, isPhaseTwo ? '#5A2A8E' : variant.high);
        bodyG.addColorStop(1, isPhaseTwo ? '#1A0A2E' : variant.shadow);
        ctx.fillStyle = bodyG;

        // 六角形ぽい台形ボディ
        ctx.beginPath();
        ctx.moveTo(bodyX + 16, bodyY);
        ctx.lineTo(bodyX + bodyW - 16, bodyY);
        ctx.lineTo(bodyX + bodyW + 8, bodyY + 16);
        ctx.lineTo(bodyX + bodyW + 8, bodyY + bodyH);
        ctx.lineTo(bodyX - 8, bodyY + bodyH);
        ctx.lineTo(bodyX - 8, bodyY + 16);
        ctx.closePath();
        ctx.fill();

        // ボディ外枠グロー
        ctx.shadowColor = isPhaseTwo ? '#9040FF' : accent;
        ctx.shadowBlur = 8 + pulse * 4;
        ctx.strokeStyle = isPhaseTwo ? `rgba(160,80,255,${0.5 + pulse * 0.3})` : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},${0.5 + pulse * 0.3})`;
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.shadowBlur = 0;

        // ボディ中央スキャンライン
        ctx.strokeStyle = isPhaseTwo ? `rgba(180,100,255,${0.25 + pulse * 0.2})` : `rgba(255,255,255,${0.14 + pulse * 0.1})`;
        ctx.lineWidth = 1;
        ctx.setLineDash([10, 6]);
        ctx.beginPath();
        ctx.moveTo(bodyX + 12, bodyY + bodyH * 0.5);
        ctx.lineTo(bodyX + bodyW - 12, bodyY + bodyH * 0.5);
        ctx.stroke();
        ctx.setLineDash([]);

        // リベット（四隅）
        const rivetPos = [
            [bodyX + 4, bodyY + 20], [bodyX + bodyW - 4, bodyY + 20],
            [bodyX + 4, bodyY + bodyH - 8], [bodyX + bodyW - 4, bodyY + bodyH - 8],
        ];
        rivetPos.forEach(([rx, ry]) => {
            ctx.fillStyle = _lightenCached(variant.base, 30);
            ctx.beginPath(); ctx.arc(rx, ry, 3.5, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = variant.shadow; ctx.lineWidth = 1; ctx.stroke();
        });

        // ──────────────────────────────────────────────────
        // 4. サイドブレード翼（ステージカラーで光る）
        // ──────────────────────────────────────────────────
        const wBaseY = domeCY - domeRY * 0.08;
        const wTipY  = domeCY - domeRY * 0.62;
        [[-1], [1]].forEach(([s]) => {
            // 翼本体
            ctx.fillStyle = isPhaseTwo ? '#2A0A4A' : _lightenCached(variant.shadow, 6);
            ctx.beginPath();
            ctx.moveTo(domeCX + s * (domeRX - 2), wBaseY + 8);
            ctx.lineTo(domeCX + s * (domeRX + 24), wTipY + 6);
            ctx.lineTo(domeCX + s * (domeRX + 38), wTipY - 8);
            ctx.lineTo(domeCX + s * (domeRX + 20), wBaseY - 22);
            ctx.lineTo(domeCX + s * (domeRX - 2), wBaseY - 14);
            ctx.closePath();
            ctx.fill();
            ctx.strokeStyle = isPhaseTwo ? 'rgba(140,60,255,0.6)' : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},0.55)`;
            ctx.lineWidth = 1.5;
            ctx.stroke();

            // 翼光沢ライン
            ctx.strokeStyle = isPhaseTwo ? `rgba(180,100,255,${0.35 + pulse * 0.25})` : `rgba(255,255,255,${0.22 + pulse * 0.18})`;
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(domeCX + s * (domeRX + 2), wBaseY - 6);
            ctx.lineTo(domeCX + s * (domeRX + 28), wTipY + 0);
            ctx.stroke();

            // 翼先端LED
            const wingLedAlpha = 0.6 + Math.sin(frame * 0.1 + s) * 0.3;
            ctx.shadowColor = isPhaseTwo ? '#C080FF' : accent;
            ctx.shadowBlur = 10;
            ctx.fillStyle = isPhaseTwo ? `rgba(200,120,255,${wingLedAlpha})` : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},${wingLedAlpha})`;
            ctx.beginPath(); ctx.arc(domeCX + s * (domeRX + 38), wTipY - 8, 4, 0, Math.PI * 2); ctx.fill();
            ctx.shadowBlur = 0;

            // セカンドトゲ
            ctx.fillStyle = isPhaseTwo ? '#3A1060' : variant.shadow;
            ctx.beginPath();
            ctx.moveTo(domeCX + s * (domeRX + 30), wTipY - 4);
            ctx.lineTo(domeCX + s * (domeRX + 48), wTipY - 14);
            ctx.lineTo(domeCX + s * (domeRX + 28), wTipY - 17);
            ctx.closePath(); ctx.fill();
        });

        // ──────────────────────────────────────────────────
        // 5. 左右サイドタワー（アンテナ式高層搭）
        // ──────────────────────────────────────────────────
        const towerOffsetX = domeRX * 0.84;
        const _drawMechaTowerNew = (tcx) => {
            const tW = 28;
            const tH = bodyH * 0.75;
            const tTopY = treadY - tH - 4;

            // タワー本体グラデ
            const tG2 = ctx.createLinearGradient(tcx - tW/2, tTopY, tcx + tW/2, tTopY + tH);
            tG2.addColorStop(0, isPhaseTwo ? '#2A0A48' : _lightenCached(variant.shadow, 10));
            tG2.addColorStop(0.5, isPhaseTwo ? '#3A1568' : variant.base);
            tG2.addColorStop(1, isPhaseTwo ? '#160830' : variant.shadow);
            ctx.fillStyle = tG2;
            ctx.beginPath();
            ctx.moveTo(tcx - tW/2, tTopY + 6);
            ctx.lineTo(tcx - tW/2 + 4, tTopY);
            ctx.lineTo(tcx + tW/2 - 4, tTopY);
            ctx.lineTo(tcx + tW/2, tTopY + 6);
            ctx.lineTo(tcx + tW/2, tTopY + tH);
            ctx.lineTo(tcx - tW/2, tTopY + tH);
            ctx.closePath();
            ctx.fill();

            // タワー外枠光
            ctx.strokeStyle = isPhaseTwo ? 'rgba(160,80,255,0.7)' : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},0.65)`;
            ctx.lineWidth = 1.5;
            ctx.stroke();

            // パネルライン（横）
            ctx.strokeStyle = isPhaseTwo ? 'rgba(140,70,220,0.3)' : `rgba(255,255,255,${0.1 + pulse * 0.08})`;
            ctx.lineWidth = 1;
            for (let r = 1; r <= 4; r++) {
                const ly = tTopY + r * (tH / 5);
                ctx.beginPath(); ctx.moveTo(tcx - tW/2 + 3, ly); ctx.lineTo(tcx + tW/2 - 3, ly); ctx.stroke();
            }

            // 中央スクリーン（光るディスプレイ）
            const scA = 0.4 + Math.sin(frame * 0.05 + tcx * 0.01) * 0.2;
            ctx.fillStyle = isPhaseTwo ? `rgba(160,80,255,${scA})` : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},${scA * 0.7})`;
            ctx.fillRect(tcx - tW/2 + 5, tTopY + tH * 0.28, tW - 10, tH * 0.22);

            // ディスプレイ内スキャンライン
            ctx.strokeStyle = `rgba(255,255,255,0.25)`;
            ctx.lineWidth = 0.8;
            const scanLine = tTopY + tH * 0.28 + ((frame * 0.8) % (tH * 0.22));
            ctx.beginPath(); ctx.moveTo(tcx - tW/2 + 6, scanLine); ctx.lineTo(tcx + tW/2 - 6, scanLine); ctx.stroke();

            // 銃眼3個（三角型）
            for (let i = 0; i < 3; i++) {
                const mx = tcx - tW/2 + 4 + i * 10;
                ctx.fillStyle = isPhaseTwo ? '#1A0030' : _lightenCached(variant.shadow, 4);
                ctx.strokeStyle = isPhaseTwo ? 'rgba(140,60,220,0.6)' : accent;
                ctx.lineWidth = 0.8;
                ctx.beginPath();
                ctx.moveTo(mx, tTopY - 2);
                ctx.lineTo(mx + 4, tTopY + 8);
                ctx.lineTo(mx + 8, tTopY - 2);
                ctx.closePath(); ctx.fill(); ctx.stroke();
            }

            // アンテナ（上部）
            ctx.shadowColor = isPhaseTwo ? '#C080FF' : accent;
            ctx.shadowBlur = 8 + pulse * 5;
            ctx.strokeStyle = isPhaseTwo ? `rgba(180,100,255,0.8)` : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},0.85)`;
            ctx.lineWidth = 2;
            ctx.beginPath(); ctx.moveTo(tcx, tTopY - 2); ctx.lineTo(tcx, tTopY - 24); ctx.stroke();
            // アンテナ先端LED（ブリンク）
            const antBlink = (Math.sin(frame * 0.15 + tcx * 0.05) + 1) / 2;
            ctx.fillStyle = isPhaseTwo ? `rgba(200,120,255,${0.6 + antBlink * 0.4})` : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},${0.7 + antBlink * 0.3})`;
            ctx.beginPath(); ctx.arc(tcx, tTopY - 26, 4.5, 0, Math.PI * 2); ctx.fill();
            ctx.shadowBlur = 0;
        };
        _drawMechaTowerNew(domeCX - towerOffsetX);
        _drawMechaTowerNew(domeCX + towerOffsetX);

        // ──────────────────────────────────────────────────
        // 6. メインドーム（コンセプトアート風六角装甲キャノピー）
        // ──────────────────────────────────────────────────
        // ドーム後光（外グロー）
        const outerGlowA = 0.08 + pulse * 0.06;
        ctx.fillStyle = isPhaseTwo ? `rgba(140,60,255,${outerGlowA * 1.5})` : glowColor.replace(')', `, ${outerGlowA})`).replace('rgba', 'rgba');
        ctx.beginPath(); ctx.ellipse(domeCX, domeCY, domeRX + 18, domeRY + 18, 0, Math.PI, 0); ctx.fill();

        // ドーム本体グラデ
        const dG = ctx.createRadialGradient(domeCX - domeRX * 0.3, domeCY - domeRY * 0.38, 0, domeCX, domeCY, domeRX);
        dG.addColorStop(0, isPhaseTwo ? '#5020A0' : variant.high);
        dG.addColorStop(0.45, isPhaseTwo ? '#301070' : variant.base);
        dG.addColorStop(1, isPhaseTwo ? '#180A30' : variant.shadow);
        ctx.fillStyle = dG;
        ctx.beginPath();
        ctx.ellipse(domeCX, domeCY, domeRX, domeRY, 0, Math.PI, 0);
        ctx.lineTo(domeCX + domeRX, domeCY);
        ctx.lineTo(domeCX - domeRX, domeCY);
        ctx.closePath();
        ctx.fill();

        // ドーム外枠グロー
        ctx.shadowColor = isPhaseTwo ? '#A050FF' : accent;
        ctx.shadowBlur = 14 + pulse * 8;
        ctx.strokeStyle = isPhaseTwo ? `rgba(160,80,255,${0.7 + pulse * 0.3})` : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},${0.55 + pulse * 0.35})`;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.ellipse(domeCX, domeCY, domeRX, domeRY, 0, Math.PI, 0);
        ctx.stroke();
        ctx.shadowBlur = 0;

        // ドーム装甲ライン（縦横パネル分割）
        ctx.save();
        ctx.beginPath();
        ctx.ellipse(domeCX, domeCY, domeRX - 2, domeRY - 2, 0, Math.PI, 0);
        ctx.clip();
        ctx.strokeStyle = isPhaseTwo ? 'rgba(140,70,220,0.2)' : `rgba(255,255,255,${0.12 + pulse * 0.06})`;
        ctx.lineWidth = 1;
        // 縦分割線
        [-0.45, 0, 0.45].forEach(fx => {
            ctx.beginPath(); ctx.moveTo(domeCX + fx * domeRX, domeCY - domeRY); ctx.lineTo(domeCX + fx * domeRX, domeCY); ctx.stroke();
        });
        // 横分割線
        [-0.5, -0.15].forEach(fy => {
            ctx.beginPath(); ctx.moveTo(domeCX - domeRX * 0.9, domeCY + fy * domeRY); ctx.lineTo(domeCX + domeRX * 0.9, domeCY + fy * domeRY); ctx.stroke();
        });
        // スキャンライン（動的）
        ctx.strokeStyle = isPhaseTwo ? `rgba(160,80,255,${0.22 * pulse})` : `rgba(255,255,255,${0.16 + pulse * 0.14})`;
        ctx.lineWidth = 2;
        const scanPos = domeCY - domeRY + ((frame * 1.2) % (domeRY));
        ctx.beginPath(); ctx.moveTo(domeCX - domeRX, scanPos); ctx.lineTo(domeCX + domeRX, scanPos); ctx.stroke();
        ctx.restore();

        // ハイライト（上部光沢）
        ctx.fillStyle = 'rgba(255,255,255,0.12)';
        ctx.beginPath(); ctx.ellipse(domeCX - domeRX * 0.2, domeCY - domeRY * 0.35, domeRX * 0.28, domeRY * 0.14, -0.3, 0, Math.PI * 2); ctx.fill();

        // ──────────────────────────────────────────────────
        // 7. メカアイ（コンセプト風ワイドビジョン）
        // ──────────────────────────────────────────────────
        const eyeY = domeCY - domeRY * 0.48;
        const eyeW = domeRX * 1.05;
        const eyeH = 11;
        // ビジョン背景
        ctx.fillStyle = '#030810';
        ctx.beginPath();
        ctx.moveTo(domeCX - eyeW / 2 + 5, eyeY - eyeH / 2);
        ctx.lineTo(domeCX + eyeW / 2 - 5, eyeY - eyeH / 2);
        ctx.lineTo(domeCX + eyeW / 2, eyeY);
        ctx.lineTo(domeCX + eyeW / 2 - 5, eyeY + eyeH / 2);
        ctx.lineTo(domeCX - eyeW / 2 + 5, eyeY + eyeH / 2);
        ctx.lineTo(domeCX - eyeW / 2, eyeY);
        ctx.closePath();
        ctx.fill();

        // LED群
        const ledCount = isPhaseTwo ? 11 : 8;
        for (let i = 0; i < ledCount; i++) {
            const lx = domeCX - eyeW / 2 + 10 + (eyeW - 20) / (ledCount - 1) * i;
            const ledPulse = (Math.sin(frame * 0.12 + i * 0.7) + 1) / 2;
            ctx.fillStyle = isPhaseTwo
                ? `rgba(200,100,255,${0.45 + ledPulse * 0.55})`
                : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},${0.45 + ledPulse * 0.55})`;
            ctx.beginPath(); ctx.arc(lx, eyeY, 4, 0, Math.PI * 2); ctx.fill();
        }

        // ビジョンフレームグロー
        ctx.shadowColor = isPhaseTwo ? '#B060FF' : accent;
        ctx.shadowBlur = 10;
        ctx.strokeStyle = isPhaseTwo ? `rgba(180,80,255,${0.8 + pulse * 0.2})` : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},${0.7 + pulse * 0.3})`;
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.moveTo(domeCX - eyeW / 2 + 5, eyeY - eyeH / 2);
        ctx.lineTo(domeCX + eyeW / 2 - 5, eyeY - eyeH / 2);
        ctx.lineTo(domeCX + eyeW / 2, eyeY);
        ctx.lineTo(domeCX + eyeW / 2 - 5, eyeY + eyeH / 2);
        ctx.lineTo(domeCX - eyeW / 2 + 5, eyeY + eyeH / 2);
        ctx.lineTo(domeCX - eyeW / 2, eyeY);
        ctx.closePath();
        ctx.stroke();
        ctx.shadowBlur = 0;

        // ──────────────────────────────────────────────────
        // 8. ステージ固有デコレーション
        // ──────────────────────────────────────────────────
        const _drawStageDecor = () => {
            const embX = domeCX;
            const embY = domeCY + domeRY * 0.28;

            if (stageId === 'c2_stage1') {
                // 廃村の番人 ─ 錆びと腐食、古い紋章
                ctx.strokeStyle = 'rgba(139,105,20,0.5)'; ctx.lineWidth = 2;
                [[domeCX - 30, domeCY - 15], [domeCX + 18, domeCY + 5], [domeCX - 10, domeCY - 30]].forEach(([rx, ry]) => {
                    ctx.beginPath();
                    ctx.moveTo(rx, ry); ctx.lineTo(rx + 8 + Math.random()*4, ry + 14); ctx.lineTo(rx + 2, ry + 22); ctx.stroke();
                });
                // 古い歯車紋章
                ctx.fillStyle = 'rgba(101,72,16,0.75)'; ctx.strokeStyle = 'rgba(180,130,40,0.55)'; ctx.lineWidth = 2;
                ctx.beginPath(); ctx.arc(embX, embY, 14, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
                ctx.strokeStyle = 'rgba(160,110,20,0.5)'; ctx.lineWidth = 1.5;
                for (let i = 0; i < 8; i++) {
                    const a = i * Math.PI / 4;
                    ctx.beginPath(); ctx.moveTo(embX + Math.cos(a) * 9, embY + Math.sin(a) * 9); ctx.lineTo(embX + Math.cos(a) * 15, embY + Math.sin(a) * 15); ctx.stroke();
                }
                ctx.fillStyle = 'rgba(180,130,30,0.65)'; ctx.beginPath(); ctx.arc(embX, embY, 5, 0, Math.PI * 2); ctx.fill();

            } else if (stageId === 'c2_stage2') {
                // 草原の見張り ─ 自然の模様、ターゲットレティクル
                ctx.strokeStyle = `rgba(${parseInt(variant.trim.slice(1,3)||'8B',16)},${parseInt(variant.trim.slice(3,5)||'E9',16)},${parseInt(variant.trim.slice(5,7)||'FF',16)},0.5)`;
                ctx.lineWidth = 1;
                ctx.setLineDash([3, 4]);
                ctx.beginPath(); ctx.arc(embX, embY, 18, 0, Math.PI * 2); ctx.stroke();
                ctx.beginPath(); ctx.arc(embX, embY, 10, 0, Math.PI * 2); ctx.stroke();
                ctx.setLineDash([]);
                // 十字線
                ctx.beginPath(); ctx.moveTo(embX - 20, embY); ctx.lineTo(embX + 20, embY); ctx.stroke();
                ctx.beginPath(); ctx.moveTo(embX, embY - 20); ctx.lineTo(embX, embY + 20); ctx.stroke();
                ctx.fillStyle = `rgba(${parseInt(variant.trim.slice(1,3)||'8B',16)},${parseInt(variant.trim.slice(3,5)||'E9',16)},${parseInt(variant.trim.slice(5,7)||'FF',16)},0.7)`;
                ctx.beginPath(); ctx.arc(embX, embY, 3.5, 0, Math.PI * 2); ctx.fill();

            } else if (stageId === 'c2_stage3') {
                // 海賊テンペスト ─ アンカー紋章、波形ライン
                // 波形ライン
                ctx.strokeStyle = `rgba(${parseInt(variant.trim.slice(1,3)||'8B',16)},${parseInt(variant.trim.slice(3,5)||'E9',16)},${parseInt(variant.trim.slice(5,7)||'FF',16)},0.5)`;
                ctx.lineWidth = 1.5;
                ctx.beginPath();
                for (let wx = domeCX - 36; wx < domeCX + 36; wx += 1) {
                    const wy = (domeCY - domeRY * 0.12) + Math.sin((wx - domeCX) * 0.25 + frame * 0.04) * 4;
                    if (wx === Math.floor(domeCX - 36)) ctx.moveTo(wx, wy);
                    else ctx.lineTo(wx, wy);
                }
                ctx.stroke();
                // アンカー
                ctx.fillStyle = `rgba(${parseInt(variant.trim.slice(1,3)||'8B',16)},${parseInt(variant.trim.slice(3,5)||'E9',16)},${parseInt(variant.trim.slice(5,7)||'FF',16)},0.6)`;
                ctx.beginPath(); ctx.arc(embX, embY, 13, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = variant.shadow;
                ctx.font = 'bold 14px serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
                ctx.fillText('⚓', embX, embY + 1);

            } else if (stageId === 'c2_stage4') {
                // 温泉魔導士 ─ 魔法陣・蒸気
                ctx.strokeStyle = `rgba(${parseInt(variant.trim.slice(1,3)||'8B',16)},${parseInt(variant.trim.slice(3,5)||'E9',16)},${parseInt(variant.trim.slice(5,7)||'FF',16)},0.45)`;
                ctx.lineWidth = 1.2;
                // 回転魔法陣
                ctx.save(); ctx.translate(embX, embY); ctx.rotate(frame * 0.015);
                ctx.beginPath(); ctx.arc(0, 0, 16, 0, Math.PI * 2); ctx.stroke();
                ctx.beginPath();
                for (let i = 0; i < 6; i++) {
                    const a = i * Math.PI / 3;
                    if (i === 0) ctx.moveTo(Math.cos(a) * 16, Math.sin(a) * 16);
                    else ctx.lineTo(Math.cos(a) * 16, Math.sin(a) * 16);
                }
                ctx.closePath(); ctx.stroke();
                ctx.restore();
                // 蒸気パーティクル
                for (let i = 0; i < 3; i++) {
                    const sA = 0.3 + Math.sin(frame * 0.08 + i * 1.1) * 0.2;
                    const sx = domeCX - 20 + i * 18;
                    const sy = domeCY - domeRY * 0.6 + Math.sin(frame * 0.06 + i) * 6;
                    ctx.fillStyle = `rgba(${parseInt(variant.trim.slice(1,3)||'8B',16)},${parseInt(variant.trim.slice(3,5)||'E9',16)},${parseInt(variant.trim.slice(5,7)||'FF',16)},${sA})`;
                    ctx.beginPath(); ctx.arc(sx, sy, 5, 0, Math.PI * 2); ctx.fill();
                }

            } else if (stageId === 'c2_stage5') {
                // 鉄仮面前衛 ─ 歯車紋章、スパイク
                const gearAngle = frame * 0.02;
                ctx.save(); ctx.translate(embX, embY);
                // 外歯車
                ctx.strokeStyle = `rgba(${parseInt(variant.trim.slice(1,3)||'8B',16)},${parseInt(variant.trim.slice(3,5)||'E9',16)},${parseInt(variant.trim.slice(5,7)||'FF',16)},0.55)`;
                ctx.lineWidth = 2.5;
                ctx.rotate(gearAngle);
                for (let i = 0; i < 8; i++) {
                    const a = i * Math.PI / 4;
                    ctx.beginPath(); ctx.moveTo(Math.cos(a) * 10, Math.sin(a) * 10); ctx.lineTo(Math.cos(a) * 18, Math.sin(a) * 18); ctx.stroke();
                }
                ctx.beginPath(); ctx.arc(0, 0, 10, 0, Math.PI * 2); ctx.stroke();
                ctx.restore();
                // 内コア
                const coreA = 0.5 + pulse * 0.4;
                ctx.fillStyle = `rgba(${parseInt(variant.trim.slice(1,3)||'8B',16)},${parseInt(variant.trim.slice(3,5)||'E9',16)},${parseInt(variant.trim.slice(5,7)||'FF',16)},${coreA})`;
                ctx.beginPath(); ctx.arc(embX, embY, 5, 0, Math.PI * 2); ctx.fill();

            } else if (stageId === 'c2_boss') {
                // ギア将軍 ─ 帝王の歯車王冠・三重リング
                // 外オーラ（脈動）
                const bossAura = 0.1 + pulse * 0.12;
                ctx.fillStyle = isPhaseTwo ? `rgba(140,50,255,${bossAura * 2})` : `rgba(${parseInt(variant.trim.slice(1,3)||'8B',16)},${parseInt(variant.trim.slice(3,5)||'E9',16)},${parseInt(variant.trim.slice(5,7)||'FF',16)},${bossAura * 1.5})`;
                ctx.beginPath(); ctx.arc(embX, embY, 26, 0, Math.PI * 2); ctx.fill();
                // 三重リング
                [20, 15, 9].forEach((r, ri) => {
                    const rA = 0.35 + pulse * 0.25;
                    ctx.strokeStyle = isPhaseTwo ? `rgba(180,90,255,${rA})` : `rgba(${parseInt(variant.trim.slice(1,3)||'8B',16)},${parseInt(variant.trim.slice(3,5)||'E9',16)},${parseInt(variant.trim.slice(5,7)||'FF',16)},${rA})`;
                    ctx.lineWidth = 2;
                    ctx.save(); ctx.translate(embX, embY); ctx.rotate(frame * (0.012 + ri * 0.008) * (ri % 2 === 0 ? 1 : -1));
                    ctx.beginPath();
                    for (let i = 0; i < 6; i++) {
                        const a = i * Math.PI / 3;
                        ctx.beginPath(); ctx.moveTo(Math.cos(a) * (r - 3), Math.sin(a) * (r - 3)); ctx.lineTo(Math.cos(a) * (r + 3), Math.sin(a) * (r + 3)); ctx.stroke();
                    }
                    ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.stroke();
                    ctx.restore();
                });
                ctx.fillStyle = isPhaseTwo ? `rgba(200,120,255,${0.7 + pulse * 0.3})` : `rgba(${parseInt(variant.trim.slice(1,3)||'8B',16)},${parseInt(variant.trim.slice(3,5)||'E9',16)},${parseInt(variant.trim.slice(5,7)||'FF',16)},${0.7 + pulse * 0.3})`;
                ctx.beginPath(); ctx.arc(embX, embY, 4, 0, Math.PI * 2); ctx.fill();
            }
        };
        _drawStageDecor();

        // ──────────────────────────────────────────────────
        // 9. 砲塔（鋭角な機械キャノン）
        // ──────────────────────────────────────────────────
        const cannonDir = -1;
        const cannonW = tw * 0.16;
        const cannonL = tw * 0.44;
        const cannonX = domeCX + cannonDir * (domeRX * 0.28);
        const cannonY = domeCY - domeRY * 0.08;

        // 砲台マウント
        ctx.fillStyle = _lightenCached(variant.shadow, 6);
        ctx.strokeStyle = isPhaseTwo ? 'rgba(160,80,255,0.6)' : accent;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(cannonX, cannonY, cannonW * 0.8, cannonW * 0.55, 0, 0, Math.PI * 2);
        ctx.fill(); ctx.stroke();

        // 砲身（テーパー）
        ctx.fillStyle = _lightenCached(variant.shadow, 10);
        ctx.beginPath();
        ctx.moveTo(cannonX, cannonY - cannonW * 0.5);
        ctx.lineTo(cannonX + cannonDir * (domeRX * 0.4 + cannonL), cannonY - cannonW * 0.28);
        ctx.lineTo(cannonX + cannonDir * (domeRX * 0.4 + cannonL), cannonY + cannonW * 0.28);
        ctx.lineTo(cannonX, cannonY + cannonW * 0.5);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = isPhaseTwo ? 'rgba(160,80,255,0.5)' : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},0.5)`;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // 砲身リングマーカー
        ctx.strokeStyle = isPhaseTwo ? 'rgba(140,60,220,0.5)' : `rgba(255,255,255,0.3)`;
        ctx.lineWidth = 2;
        const muzzleX = cannonX + cannonDir * (domeRX * 0.4 + cannonL);
        ctx.beginPath(); ctx.moveTo(muzzleX + 6 * cannonDir, cannonY - cannonW * 0.33); ctx.lineTo(muzzleX + 6 * cannonDir, cannonY + cannonW * 0.33); ctx.stroke();

        // 砲口リング（グロー）
        ctx.shadowColor = isPhaseTwo ? '#A050FF' : accent;
        ctx.shadowBlur = 10;
        ctx.strokeStyle = isPhaseTwo ? '#C080FF' : accent;
        ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.arc(muzzleX, cannonY, cannonW * 0.4, 0, Math.PI * 2); ctx.stroke();
        ctx.shadowBlur = 0;
        // 砲口内部
        ctx.fillStyle = '#020508';
        ctx.beginPath(); ctx.arc(muzzleX, cannonY, cannonW * 0.28, 0, Math.PI * 2); ctx.fill();
        // チャージ光
        ctx.fillStyle = isPhaseTwo ? `rgba(180,90,255,${0.3 + pulse * 0.35})` : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},${0.25 + pulse * 0.3})`;
        ctx.beginPath(); ctx.arc(muzzleX, cannonY, cannonW * 0.2, 0, Math.PI * 2); ctx.fill();

        // ──────────────────────────────────────────────────
        // 10. ダメージフラッシュ
        // ──────────────────────────────────────────────────
        if (dmgFlash > 0) {
            ctx.fillStyle = isPhaseTwo ? `rgba(180,80,255,${dmgFlash * 0.5})` : `rgba(${parseInt(accent.slice(1,3)||'8B',16)},${parseInt(accent.slice(3,5)||'E9',16)},${parseInt(accent.slice(5,7)||'FF',16)},${dmgFlash * 0.4})`;
            ctx.beginPath();
            ctx.ellipse(domeCX, domeCY, domeRX + 6, domeRY + 6, 0, Math.PI, 0);
            ctx.fill();
        }

        // ──────────────────────────────────────────────────
        // 11. フェーズ2：電気嵐エフェクト
        // ──────────────────────────────────────────────────
        if (isPhaseTwo && frame % 3 < 2) {
            ctx.strokeStyle = 'rgba(180,80,255,0.75)';
            ctx.lineWidth = 2;
            for (let e = 0; e < 4; e++) {
                const exStart = bodyX + (((Math.sin(frame * 0.07 + e * 2.9) + 1) * 0.5) * bodyW);
                ctx.beginPath(); ctx.moveTo(exStart, bodyY);
                for (let s = 0; s < 5; s++) {
                    const jitter = Math.sin(frame * 0.21 + e * 5.1 + s * 1.9) * 18;
                    ctx.lineTo(exStart + jitter, bodyY - s * 13);
                }
                ctx.stroke();
            }
        }

        this._drawStageEnemyOverlay(ctx, tx, ty, tw, th, battle, 0.88);
        ctx.restore();
    },


        // ============================================================
    // Chapter3: 天国戦車テーマ（丸みのある白神殿・光輪・翼・金縁）
    // ============================================================
    _drawHeavenThemeTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, tankType, battle) {
        const isPhaseTwo = battle && battle.bossPhase === 2;
        const frame = _getFrameNow();
        const cx = tx + tw / 2;
        const variant = this._getStageEnemyVariant(battle);
        const trim = variant.trim;

        ctx.save();
        if (dmgFlash > 0.5) {
            const st = frame * 0.05;
            ctx.translate(Math.sin(st * 7.3) * 3, Math.sin(st * 11.7) * 2);
        }

        // スケール
        let scaleX = 1.0;
        if (tankType === 'TRUE_BOSS') scaleX = isPhaseTwo ? 1.4 : 1.25;
        else if (tankType === 'BOSS' || tankType === 'HEAVY' || tankType === 'DEFENSE') scaleX = 1.15;
        else if (tankType === 'SCOUT') scaleX = 0.9;
        ctx.translate(cx, ty + th);
        ctx.scale(scaleX, 1.0);
        ctx.translate(-cx, -(ty + th));

        const pulse = (Math.sin(frame * 0.05) + 1) / 2; // 0〜1ゆっくり

        // ── 1. 台座（雲のようなふわっとした白い台座）──
        const treadH = 38;
        const treadW = tw * 0.88;
        const treadX = cx - treadW / 2;
        const treadY = ty + th - treadH;

        // 雲台座グラデーション
        const cloudG = ctx.createLinearGradient(treadX, treadY, treadX, treadY + treadH);
        cloudG.addColorStop(0, isPhaseTwo ? '#FFF8E0' : variant.high);
        cloudG.addColorStop(0.4, isPhaseTwo ? '#F0D890' : _lightenCached(variant.base, 10));
        cloudG.addColorStop(1, isPhaseTwo ? '#C8A830' : variant.base);
        ctx.fillStyle = cloudG;

        // 雲っぽい丸みのある形
        ctx.beginPath();
        ctx.moveTo(treadX + 20, treadY);
        // 上部に雲のでっぱり
        for (let i = 0; i < 5; i++) {
            const bx = treadX + 20 + (treadW - 40) * (i / 4);
            const br = 14 - (i % 2) * 4;
            ctx.arc(bx, treadY, br, Math.PI, 0, false);
        }
        ctx.lineTo(treadX + treadW, treadY + treadH);
        ctx.quadraticCurveTo(cx, treadY + treadH + 6, treadX, treadY + treadH);
        ctx.closePath();
        ctx.fill();

        // 金縁
        ctx.strokeStyle = isPhaseTwo ? '#FFD700' : trim;
        ctx.lineWidth = 2;
        ctx.stroke();

        // 雲の光彩（下部）
        ctx.shadowColor = isPhaseTwo ? '#FFD700' : trim;
        ctx.shadowBlur = 12 + pulse * 8;
        ctx.strokeStyle = isPhaseTwo ? `rgba(255,215,0,${0.4 + pulse * 0.3})` : `rgba(255,255,255,${0.5 + pulse * 0.3})`;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(treadX + 10, treadY + treadH - 4);
        ctx.lineTo(treadX + treadW - 10, treadY + treadH - 4);
        ctx.stroke();
        ctx.shadowBlur = 0;

        // 粒子（舞う光の粒）
        for (let i = 0; i < 5; i++) {
            const px2 = treadX + ((frame * (1 + i * 0.3) + i * 60) % treadW);
            const py2 = treadY + 5 + (Math.sin(frame * 0.05 + i) + 1) * 10;
            const pa = 0.3 + Math.sin(frame * 0.08 + i * 1.3) * 0.3;
            ctx.fillStyle = `rgba(255,245,200,${pa})`;
            ctx.beginPath(); ctx.arc(px2, py2, 3, 0, Math.PI * 2); ctx.fill();
        }

        // ── 2. 車体（神殿の柱のような白い車体）──
        const bodyH = th - treadH - 8;
        const bodyW = tw * 0.74;
        const bodyX = cx - bodyW / 2;
        const bodyY = treadY - bodyH;

        // 車体グラデーション
        const bodyG = ctx.createLinearGradient(bodyX, bodyY, bodyX + bodyW, bodyY + bodyH);
        bodyG.addColorStop(0, isPhaseTwo ? '#FFFDE8' : variant.high);
        bodyG.addColorStop(0.5, isPhaseTwo ? '#F5E8A0' : _lightenCached(variant.base, 16));
        bodyG.addColorStop(1, isPhaseTwo ? '#D4B840' : variant.base);
        ctx.fillStyle = bodyG;

        // 神殿アーチ型の形
        ctx.beginPath();
        ctx.moveTo(bodyX + 8, bodyY + 16);
        ctx.quadraticCurveTo(cx, bodyY - 10, bodyX + bodyW - 8, bodyY + 16);
        ctx.lineTo(bodyX + bodyW + 4, bodyY + bodyH);
        ctx.lineTo(bodyX - 4, bodyY + bodyH);
        ctx.closePath();
        ctx.fill();

        // 金縁
        ctx.strokeStyle = isPhaseTwo ? '#FFD700' : trim;
        ctx.lineWidth = 2;
        ctx.stroke();

        // 柱模様（縦ライン）
        const colCount = 4;
        for (let i = 1; i < colCount; i++) {
            const colX = bodyX + (bodyW / colCount) * i;
            ctx.strokeStyle = `rgba(180,160,100,0.3)`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(colX, bodyY + 20);
            ctx.lineTo(colX, bodyY + bodyH - 4);
            ctx.stroke();
        }

        // ── 3. ドーム（丸みのある神殿ドーム）──
        const domeCX = cx;
        const domeCY = bodyY - 2;
        const domeRX = bodyW * 0.48;
        const domeRY = bodyH * 0.65;

        // 後光（ドーム背面の光輪）
        const haloR = domeRX * 1.45;
        const haloAlpha = 0.12 + pulse * 0.1;
        const haloG = ctx.createRadialGradient(domeCX, domeCY, domeRX * 0.8, domeCX, domeCY, haloR);
        haloG.addColorStop(0, isPhaseTwo ? `rgba(255,215,0,${haloAlpha * 2})` : `rgba(241,201,107,${haloAlpha * 2})`);
        haloG.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = haloG;
        ctx.beginPath(); ctx.arc(domeCX, domeCY - domeRY * 0.3, haloR, 0, Math.PI * 2); ctx.fill();

        // ドーム本体
        const domeG = ctx.createRadialGradient(domeCX - domeRX * 0.3, domeCY - domeRY * 0.4, 0, domeCX, domeCY, domeRX);
        domeG.addColorStop(0, isPhaseTwo ? '#FFFBF0' : variant.high);
        domeG.addColorStop(0.5, isPhaseTwo ? '#F5E890' : _lightenCached(variant.base, 14));
        domeG.addColorStop(1, isPhaseTwo ? '#D0B040' : variant.base);
        ctx.fillStyle = domeG;
        ctx.beginPath();
        ctx.ellipse(domeCX, domeCY, domeRX, domeRY, 0, Math.PI, 0);
        ctx.lineTo(domeCX + domeRX, domeCY);
        ctx.lineTo(domeCX - domeRX, domeCY);
        ctx.closePath();
        ctx.fill();

        // 金縁グロー
        ctx.shadowColor = isPhaseTwo ? '#FFD700' : trim;
        ctx.shadowBlur = 14 + pulse * 8;
        ctx.strokeStyle = isPhaseTwo ? `rgba(255,215,0,${0.8 + pulse * 0.2})` : `rgba(255,255,255,${0.6 + pulse * 0.25})`;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.ellipse(domeCX, domeCY, domeRX, domeRY, 0, Math.PI, 0);
        ctx.stroke();
        ctx.shadowBlur = 0;

        // ドーム内：光の柱（ステンドグラス風）
        if (showInterior) {
            ctx.save();
            ctx.beginPath();
            ctx.ellipse(domeCX, domeCY, domeRX - 3, domeRY - 3, 0, Math.PI, 0);
            ctx.clip();
            const colors = ['rgba(255,220,100,0.15)', 'rgba(200,230,255,0.15)', 'rgba(255,255,200,0.15)'];
            for (let i = 0; i < 5; i++) {
                const ang = Math.PI + (Math.PI / 5) * i;
                ctx.fillStyle = colors[i % colors.length];
                ctx.beginPath();
                ctx.moveTo(domeCX, domeCY);
                ctx.arc(domeCX, domeCY, domeRX, ang, ang + Math.PI / 5);
                ctx.closePath();
                ctx.fill();
            }
            ctx.restore();
        }

        // 目（穏やかな大きな瞳）
        const eyeY = domeCY - domeRY * 0.5;
        [-1, 1].forEach(side => {
            const ex = domeCX + side * domeRX * 0.38;
            // 白目
            ctx.fillStyle = 'rgba(255,255,255,0.95)';
            ctx.beginPath(); ctx.ellipse(ex, eyeY, 12, 14, 0, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = isPhaseTwo ? '#FFD700' : trim; ctx.lineWidth = 1.5; ctx.stroke();
            // 瞳
            ctx.fillStyle = isPhaseTwo ? '#7A5000' : '#5A4300';
            ctx.beginPath(); ctx.ellipse(ex, eyeY, 7, 9, 0, 0, Math.PI * 2); ctx.fill();
            // ハイライト
            ctx.fillStyle = 'rgba(255,255,255,0.8)';
            ctx.beginPath(); ctx.ellipse(ex - 3, eyeY - 4, 3, 4, -0.3, 0, Math.PI * 2); ctx.fill();
            // 瞳のグロー
            ctx.shadowColor = isPhaseTwo ? '#FFD700' : trim;
            ctx.shadowBlur = 6;
            ctx.fillStyle = isPhaseTwo ? 'rgba(255,215,0,0.4)' : 'rgba(255,255,255,0.4)';
            ctx.beginPath(); ctx.ellipse(ex, eyeY, 8, 10, 0, 0, Math.PI * 2); ctx.fill();
            ctx.shadowBlur = 0;
        });

        // ── 4. 光輪（頭上に浮く回転する光輪）──
        const haloHaloY = domeCY - domeRY - 18;
        const haloHaloRX = domeRX * 0.6;
        const haloHaloRY = haloHaloRX * 0.25;
        const haloRot = frame * 0.018;
        ctx.shadowColor = isPhaseTwo ? '#FFD700' : trim;
        ctx.shadowBlur = 16 + pulse * 8;
        ctx.strokeStyle = isPhaseTwo ? `rgba(255,215,0,${0.8 + pulse * 0.2})` : `rgba(255,255,255,${0.7 + pulse * 0.2})`;
        ctx.lineWidth = isPhaseTwo ? 5 : 4;
        ctx.beginPath();
        ctx.ellipse(domeCX, haloHaloY, haloHaloRX, haloHaloRY, haloRot, 0, Math.PI * 2);
        ctx.stroke();
        ctx.shadowBlur = 0;
        // 光輪の光粒
        for (let i = 0; i < 6; i++) {
            const a = haloRot + (Math.PI * 2 / 6) * i;
            const gx = domeCX + Math.cos(a) * haloHaloRX;
            const gy = haloHaloY + Math.sin(a) * haloHaloRY;
            ctx.fillStyle = isPhaseTwo ? `rgba(255,220,80,${0.6 + pulse * 0.4})` : `rgba(255,248,180,${0.6 + pulse * 0.4})`;
            ctx.beginPath(); ctx.arc(gx, gy, 3 + pulse * 2, 0, Math.PI * 2); ctx.fill();
        }

        // ── 5. 翼（ドーム両サイドに広がる羽根）──
        [-1, 1].forEach(side => {
            const wingBaseX = domeCX + side * domeRX * 0.85;
            const wingBaseY = domeCY - domeRY * 0.3;
            const flapAngle = Math.sin(frame * 0.04) * 0.12 * side;
            ctx.save();
            ctx.translate(wingBaseX, wingBaseY);
            ctx.rotate(flapAngle);

            // 羽根（3枚重ねで奥行き感）
            const featherColors = [
                isPhaseTwo ? 'rgba(255,240,150,0.5)' : 'rgba(200,230,255,0.5)',
                isPhaseTwo ? 'rgba(255,230,100,0.7)' : 'rgba(230,245,255,0.7)',
                isPhaseTwo ? 'rgba(255,248,200,0.9)' : 'rgba(255,255,255,0.9)',
            ];
            featherColors.forEach((col, fi) => {
                const wLen = (50 + fi * 20) * (isPhaseTwo ? 1.2 : 1.0);
                const wAng = (0.25 + fi * 0.18) * side;
                ctx.fillStyle = col;
                ctx.strokeStyle = isPhaseTwo ? 'rgba(255,215,0,0.6)' : 'rgba(255,255,255,0.6)';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.quadraticCurveTo(
                    Math.cos(wAng) * wLen * 0.6 + Math.sin(wAng) * 10 * side,
                    Math.sin(wAng) * wLen * 0.6 - 8,
                    Math.cos(wAng) * wLen,
                    Math.sin(wAng) * wLen
                );
                ctx.quadraticCurveTo(
                    Math.cos(wAng) * wLen * 0.5,
                    Math.sin(wAng) * wLen * 0.5 + 12,
                    0, 8
                );
                ctx.closePath();
                ctx.fill(); ctx.stroke();
            });
            ctx.restore();
        });

        // ── 6. 砲塔（エレガントな曲線キャノン）──
        const cannonDir = -1;
        const cannonBaseX = domeCX + cannonDir * domeRX * 0.3;
        const cannonBaseY = domeCY - domeRY * 0.1;
        const cannonLen = tw * 0.4;
        const cannonW2 = 10;

        // 砲身（テーパー）
        ctx.fillStyle = isPhaseTwo ? '#F5E080' : '#E8F2FF';
        ctx.beginPath();
        ctx.moveTo(cannonBaseX, cannonBaseY - cannonW2);
        ctx.lineTo(cannonBaseX + cannonDir * (domeRX * 0.6 + cannonLen), cannonBaseY - cannonW2 * 0.5);
        ctx.lineTo(cannonBaseX + cannonDir * (domeRX * 0.6 + cannonLen), cannonBaseY + cannonW2 * 0.5);
        ctx.lineTo(cannonBaseX, cannonBaseY + cannonW2);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = isPhaseTwo ? '#FFD700' : trim;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // 砲口の光輪
        const muzzleX = cannonBaseX + cannonDir * (domeRX * 0.6 + cannonLen);
        ctx.shadowColor = isPhaseTwo ? '#FFD700' : trim;
        ctx.shadowBlur = 12;
        ctx.strokeStyle = isPhaseTwo ? '#FFD700' : '#FFFFFF';
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(muzzleX, cannonBaseY, cannonW2, 0, Math.PI * 2); ctx.stroke();
        ctx.shadowBlur = 0;

        // ── 7. ダメージフラッシュ ──
        if (dmgFlash > 0) {
            ctx.fillStyle = isPhaseTwo ? `rgba(255,245,150,${dmgFlash * 0.5})` : variant.glow;
            ctx.beginPath();
            ctx.ellipse(domeCX, domeCY, domeRX + 6, domeRY + 6, 0, Math.PI, 0);
            ctx.fill();
        }

        // ── 8. フェーズ2：後光が強まり光柱が出る ──
        if (isPhaseTwo) {
            ctx.shadowColor = '#FFD700';
            ctx.shadowBlur = 20 + pulse * 15;
            ctx.strokeStyle = `rgba(255,215,0,${0.3 + pulse * 0.2})`;
            ctx.lineWidth = 2;
            for (let r = 0; r < 8; r++) {
                const ra = (Math.PI * 2 / 8) * r + frame * 0.01;
                ctx.beginPath();
                ctx.moveTo(domeCX, domeCY - domeRY * 0.5);
                ctx.lineTo(domeCX + Math.cos(ra) * domeRX * 2.5, domeCY - domeRY * 0.5 + Math.sin(ra) * domeRY * 2);
                ctx.stroke();
            }
            ctx.shadowBlur = 0;
        }

        this._drawStageEnemyOverlay(ctx, tx, ty, tw, th, battle, 0.92);
        ctx.restore();
    },

    // 🌑 Ch.4 混沌テーマ描画（深淵スタイル）
    _drawChaosThemeTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, tankType, battle) {
        ctx.save();
        const t = Date.now();
        const isPhaseTwo = battle && battle.bossPhase === 2;
        const flash = dmgFlash > 0 ? Math.min(1, dmgFlash / 10) : 0;

        // スケール調整（tankTypeごと）
        let scaleX = 1.0;
        if (tankType === 'TRUE_BOSS') scaleX = isPhaseTwo ? 1.4 : 1.25;
        else if (tankType === 'BOSS' || tankType === 'HEAVY' || tankType === 'DEFENSE') scaleX = 1.15;
        else if (tankType === 'SCOUT') scaleX = 0.9;
        const scaledTW = tw * scaleX;
        const scaledTX = tx - (scaledTW - tw) / 2;

        // 本体グラデ（漆黒×深紫）
        const bodyGrad = ctx.createLinearGradient(scaledTX, ty, scaledTX, ty + th);
        if (flash > 0) {
            bodyGrad.addColorStop(0, '#AA66FF'); bodyGrad.addColorStop(1, '#660099');
        } else if (isPhaseTwo) {
            bodyGrad.addColorStop(0, '#1A0040'); bodyGrad.addColorStop(0.4, '#2D0060'); bodyGrad.addColorStop(1, '#060010');
        } else {
            bodyGrad.addColorStop(0, '#0D0020'); bodyGrad.addColorStop(0.4, '#1A0035'); bodyGrad.addColorStop(1, '#060015');
        }
        ctx.fillStyle = bodyGrad;
        Renderer._roundRect(ctx, scaledTX, ty, scaledTW, th, 10);
        ctx.fill();

        // 発光クラック（混沌の亀裂）
        const crackAlpha = (isPhaseTwo ? 0.7 : 0.45) + Math.sin(t * 0.004) * 0.15;
        ctx.strokeStyle = `rgba(${isPhaseTwo ? '220,80,255' : '160,40,220'},${crackAlpha})`;
        ctx.lineWidth = isPhaseTwo ? 2 : 1.5;
        const cx = scaledTX + scaledTW * 0.5, cy = ty + th * 0.5;
        ctx.beginPath(); ctx.moveTo(cx - 8, ty + 8); ctx.lineTo(cx + 3, cy); ctx.lineTo(cx - 5, ty + th - 8); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx + 10, ty + 12); ctx.lineTo(cx - 2, cy - 5); ctx.lineTo(cx + 8, ty + th - 10); ctx.stroke();

        // 中央虚無オーブ
        const orbR = (isPhaseTwo ? 9 : 6) + Math.sin(t * 0.005) * 2;
        const orbGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, orbR * 2.5);
        orbGrad.addColorStop(0, isPhaseTwo ? 'rgba(255,150,255,0.95)' : 'rgba(200,80,255,0.9)');
        orbGrad.addColorStop(0.5, 'rgba(100,0,180,0.6)');
        orbGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = orbGrad;
        ctx.beginPath(); ctx.arc(cx, cy, orbR * 2.5, 0, Math.PI * 2); ctx.fill();

        // 砲台（深淵砲）
        const barrelCY = ty + th * 0.38;
        const barrelW = scaledTW * (tankType === 'TRUE_BOSS' ? 0.62 : 0.52);
        ctx.fillStyle = '#0A0018';
        Renderer._roundRect(ctx, scaledTX - barrelW, barrelCY - 7, barrelW, 14, 4);
        ctx.fill();
        ctx.strokeStyle = `rgba(180,60,255,${0.65 + Math.sin(t * 0.005) * 0.2})`;
        ctx.lineWidth = 1.5;
        Renderer._roundRect(ctx, scaledTX - barrelW, barrelCY - 7, barrelW, 14, 4);
        ctx.stroke();
        // 砲口エネルギー
        const bTipX = scaledTX - barrelW - 8;
        ctx.shadowBlur = 8; ctx.shadowColor = 'rgba(180,0,255,0.7)';
        ctx.fillStyle = `rgba(200,80,255,${0.75 + Math.sin(t * 0.007) * 0.2})`;
        ctx.beginPath(); ctx.arc(bTipX, barrelCY, 9, 0, Math.PI * 2); ctx.fill();
        ctx.shadowBlur = 0;

        // 触手（TRUE_BOSSのみ）
        if (tankType === 'TRUE_BOSS') {
            ctx.strokeStyle = `rgba(140,0,220,${0.5 + Math.sin(t * 0.003) * 0.2})`; ctx.lineWidth = 2.5;
            for (let i = 0; i < 4; i++) {
                const bx2 = scaledTX + scaledTW * (0.2 + i * 0.2);
                const wave = Math.sin(t * 0.004 + i * 1.8) * 7;
                ctx.beginPath();
                ctx.moveTo(bx2, ty);
                ctx.quadraticCurveTo(bx2 + wave, ty - 14, bx2 + wave * 0.5, ty - 24);
                ctx.stroke();
            }
        }

        // 縁取り
        ctx.shadowBlur = isPhaseTwo ? 12 : 6;
        ctx.shadowColor = isPhaseTwo ? 'rgba(220,80,255,0.8)' : 'rgba(140,0,220,0.5)';
        ctx.strokeStyle = flash > 0 ? '#FF88FF' : `rgba(${isPhaseTwo ? '220,80,255' : '160,40,220'},${0.7 + Math.sin(t * 0.004) * 0.2})`;
        ctx.lineWidth = isPhaseTwo ? 2.5 : 2;
        Renderer._roundRect(ctx, scaledTX, ty, scaledTW, th, 10);
        ctx.stroke();
        ctx.shadowBlur = 0;

        this._drawStageEnemyOverlay(ctx, tx, ty, tw, th, battle, 0.88);
        ctx.restore();
    },

    // 🌟 原初テーマ（genesis）描画 — c5_boss ルーメン専用
    // enemySkinType 未設定かつ第二形態スキン未発動時のフォールバック
    // 特徴: 白金＋虹色光輪・十字コア・原初の翼・全方位オーラ
    _drawGenesisThemeTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, tankType, battle) {
        const cx  = tx + tw / 2;
        const t   = Date.now() * 0.001;
        const fl  = dmgFlash > 0 ? Math.min(1, dmgFlash / 10) : 0;
        const tH  = Math.round(th * 0.27);
        const bH  = th - tH;
        const hpRatio = battle ? (battle.enemyTankHP / battle.enemyTankMaxHP) : 1;
        ctx.save();

        // ── 原初のオーラ（虹色放射）──
        const aR = tw * 1.1 + Math.sin(t*2)*8;
        const aG = ctx.createRadialGradient(cx, ty+th*0.45, 0, cx, ty+th*0.45, aR);
        aG.addColorStop(0, `hsla(${(t*40)%360},100%,90%,0.22)`);
        aG.addColorStop(0.5, `hsla(${(t*40+120)%360},100%,70%,0.10)`);
        aG.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = aG;
        ctx.beginPath(); ctx.ellipse(cx, ty+th*0.45, aR, aR*0.65, 0, 0, Math.PI*2); ctx.fill();

        // ── キャタピラ（白金）──
        const tg = ctx.createLinearGradient(tx, ty+bH, tx, ty+th);
        tg.addColorStop(0, fl ? '#FFFFFF' : (hpRatio < 0.5 ? '#FFD0D0' : '#D8E8FF'));
        tg.addColorStop(1, fl ? '#C8D8FF' : (hpRatio < 0.5 ? '#C08080' : '#8098C8'));
        ctx.fillStyle = tg;
        ctx.beginPath();
        ctx.moveTo(tx-16, ty+bH+2); ctx.lineTo(tx+tw+16, ty+bH+2);
        ctx.lineTo(tx+tw+20, ty+th); ctx.lineTo(tx-20, ty+th);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = hpRatio < 0.5 ? '#FF6060' : '#90A8D8'; ctx.lineWidth = 2.5; ctx.stroke();

        for (let i = 0; i < 4; i++) {
            const wx = tx+16+(tw-32)/3*i, wy = ty+bH+tH*0.52;
            const wg = ctx.createRadialGradient(wx, wy, 0, wx, wy, 14);
            const hue = (t*60 + i*90) % 360;
            wg.addColorStop(0, `hsl(${hue},100%,90%)`);
            wg.addColorStop(1, `hsl(${hue},60%,50%)`);
            ctx.fillStyle = wg; ctx.beginPath(); ctx.arc(wx, wy, 13, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = `hsl(${hue},80%,70%)`; ctx.lineWidth = 2; ctx.stroke();
            // 十字スポーク
            ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1.5;
            for (let s = 0; s < 4; s++) {
                const a = s * Math.PI/2 + t;
                ctx.beginPath(); ctx.moveTo(wx, wy); ctx.lineTo(wx+Math.cos(a)*10, wy+Math.sin(a)*10); ctx.stroke();
            }
        }

        // ── 本体（白金装甲・虹縁）──
        const bg = ctx.createLinearGradient(tx, ty, tx, ty+bH);
        bg.addColorStop(0, fl ? '#FFFFFF' : (hpRatio < 0.5 ? '#FFF0F0' : '#F0F6FF'));
        bg.addColorStop(0.4, fl ? '#F8F8FF' : (hpRatio < 0.5 ? '#F0D0D0' : '#D8E4F8'));
        bg.addColorStop(1, fl ? '#E0E8FF' : (hpRatio < 0.5 ? '#D08080' : '#A8B8D8'));
        ctx.fillStyle = bg; Renderer._roundRect(ctx, tx, ty, tw, bH, 12); ctx.fill();
        // 虹色縁取り
        const borderHue = (t*50) % 360;
        ctx.shadowBlur = 14; ctx.shadowColor = `hsl(${borderHue},100%,70%)`;
        ctx.strokeStyle = `hsl(${borderHue},100%,65%)`; ctx.lineWidth = 3;
        Renderer._roundRect(ctx, tx, ty, tw, bH, 12); ctx.stroke();
        ctx.shadowBlur = 0;

        // ── 中央の十字コア（原初の力）──
        const coreCX = cx - (tw*0.08), coreCY = ty + bH*0.46;
        const coreR = 18 + Math.sin(t*3)*3;
        const coreHue = (t*80) % 360;
        const coreG = ctx.createRadialGradient(coreCX, coreCY, 0, coreCX, coreCY, coreR*1.4);
        coreG.addColorStop(0, '#FFFFFF');
        coreG.addColorStop(0.3, `hsl(${coreHue},100%,80%)`);
        coreG.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = coreG; ctx.beginPath(); ctx.arc(coreCX, coreCY, coreR*1.4, 0, Math.PI*2); ctx.fill();
        // 十字光線
        for (let arm = 0; arm < 4; arm++) {
            const a = arm * Math.PI/2 + t*0.5;
            const armLen = coreR * (2.0 + Math.sin(t*4 + arm)*0.3);
            const grad = ctx.createLinearGradient(coreCX, coreCY, coreCX+Math.cos(a)*armLen, coreCY+Math.sin(a)*armLen);
            grad.addColorStop(0, `hsla(${(coreHue+arm*30)%360},100%,90%,0.9)`);
            grad.addColorStop(1, 'rgba(255,255,255,0)');
            ctx.strokeStyle = grad; ctx.lineWidth = 4 - arm*0.3;
            ctx.beginPath(); ctx.moveTo(coreCX, coreCY);
            ctx.lineTo(coreCX+Math.cos(a)*armLen, coreCY+Math.sin(a)*armLen);
            ctx.stroke();
        }

        if (!showInterior) {
            // ── 原初の翼（展開した光翼）──
            const wingPhase = hpRatio < 0.5 ? 1.4 : 1.0; // 瀕死で翼が広がる
            [-1, 1].forEach(s => {
                const wBaseX = cx + s*(tw*0.46);
                const wBaseY = ty + bH*0.40;
                const wTipX  = wBaseX + s * (50 * wingPhase);
                const wTipY  = wBaseY - 45 * wingPhase;
                const wingHue = (t*60 + (s > 0 ? 0 : 180)) % 360;
                // 翼本体
                ctx.fillStyle = `hsla(${wingHue},80%,85%,${0.5 + Math.sin(t*2+s)*0.1})`;
                ctx.beginPath();
                ctx.moveTo(wBaseX, wBaseY + 10);
                ctx.lineTo(wTipX, wTipY + 5);
                ctx.lineTo(wTipX + s*14, wTipY - 20);
                ctx.lineTo(wTipX + s*28, wTipY + 0);
                ctx.lineTo(wTipX + s*10, wTipY + 20);
                ctx.lineTo(wBaseX, wBaseY - 15);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = `hsl(${wingHue},100%,70%)`; ctx.lineWidth = 1.5; ctx.stroke();
                // 翼脈（光の筋）
                ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 1;
                for (let f = 1; f <= 3; f++) {
                    const frac = f/4;
                    ctx.beginPath();
                    ctx.moveTo(wBaseX, wBaseY);
                    ctx.lineTo(wBaseX + (wTipX - wBaseX)*frac, wBaseY + (wTipY - wBaseY)*frac);
                    ctx.stroke();
                }
            });

            // ── 砲塔（左側・虹色発光）──
            const turretW = tw*0.42, turretH = bH*0.38;
            const turretX = cx - turretW*0.5;
            const turretY = ty + bH*0.15;
            const turrHue = (t*40+60) % 360;
            const turrG = ctx.createLinearGradient(turretX, turretY, turretX, turretY+turretH);
            turrG.addColorStop(0, fl ? '#FFFFFF' : `hsl(${turrHue},40%,90%)`);
            turrG.addColorStop(1, fl ? '#D0E0FF' : `hsl(${turrHue},50%,70%)`);
            ctx.fillStyle = turrG;
            Renderer._roundRect(ctx, turretX, turretY, turretW, turretH, 8); ctx.fill();
            ctx.shadowBlur = 8; ctx.shadowColor = `hsl(${turrHue},100%,70%)`;
            ctx.strokeStyle = `hsl(${turrHue},80%,60%)`; ctx.lineWidth = 2;
            Renderer._roundRect(ctx, turretX, turretY, turretW, turretH, 8); ctx.stroke();
            ctx.shadowBlur = 0;

            // 砲口（虹色リング多重）
            const barrelX = turretX;
            const barrelY = turretY + turretH*0.5;
            for (let r = 0; r < 3; r++) {
                const ringR = 10 - r*2.5;
                const rHue = (turrHue + r*40) % 360;
                ctx.strokeStyle = `hsla(${rHue},100%,70%,${0.9 - r*0.2})`; ctx.lineWidth = 2;
                ctx.beginPath(); ctx.arc(barrelX, barrelY, ringR, 0, Math.PI*2); ctx.stroke();
            }
        }

        // ── 目（星型・虹色）──
        const eyeY = ty + bH*0.36;
        [cx - tw*0.15, cx + tw*0.07].forEach((ex, ei) => {
            const eyeHue = (t*100 + ei*90) % 360;
            ctx.fillStyle = `hsl(${eyeHue},100%,75%)`;
            ctx.shadowBlur = 8; ctx.shadowColor = `hsl(${eyeHue},100%,80%)`;
            ctx.beginPath(); ctx.arc(ex, eyeY, 5.5, 0, Math.PI*2); ctx.fill();
            ctx.shadowBlur = 0;
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath(); ctx.arc(ex-1.5, eyeY-1.5, 2, 0, Math.PI*2); ctx.fill();
        });

        ctx.restore();
    },

    _drawSlimeTank(ctx, tx, ty, tw, th, isEnemy, dmgFlash, showInterior, tankType = 'NORMAL', battle = null) {
        const wt = CONFIG.TANK.WALL_THICKNESS;
        const dir = isEnemy ? -1 : 1;
        const enemyTheme = isEnemy && battle && battle.stageData ? battle.stageData.enemyTankTheme : null;
        const variant = isEnemy ? this._getStageEnemyVariant(battle) : null;

        // === スキン判定（プレイヤーのみ）===
        if (!isEnemy) {
            const _skinCustom = window.game && window.game.saveData && window.game.saveData.tankCustom;
            const _skinId = (_skinCustom && _skinCustom.skin) || 'skin_default';
            if (_skinId !== 'skin_default') {
                const result = this._drawSkinTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, _skinId, battle, false);
                // 👑 潜り込みオーバーレイ：プレイヤー戦車の上に金色スライム侵食エフェクト
                if (battle && battle.skInfiltrating) {
                    this._drawInfiltrationOverlay(ctx, tx, ty, tw, th, battle);
                }
                return result;
            }
            // 潜り込みオーバーレイ（デフォルトスキン時も適用）
            if (battle && battle.skInfiltrating) {
                this._drawInfiltrationOverlay(ctx, tx, ty, tw, th, battle);
            }
        }

        // 👑 スライム王潜り込み中：敵戦車を非表示（代わりに消滅エフェクト）
        if (isEnemy && battle && battle.skInfiltrating) {
            // 空っぽの場所に王冠残像だけ描く
            const t = Date.now() * 0.003;
            const cx2 = tx + tw / 2;
            const cy2 = ty + th * 0.3;
            ctx.save();
            ctx.globalAlpha = 0.3 + Math.sin(t * 4) * 0.2;
            ctx.font = `bold ${Math.round(tw * 0.4)}px serif`;
            ctx.textAlign = 'center';
            ctx.fillStyle = '#FFD700';
            ctx.fillText('👑', cx2, cy2);
            ctx.globalAlpha = 1.0;
            ctx.restore();
            return;
        }

        // === 借金王（敵スキン）===
        if (isEnemy && tankType === 'SHAKKIN') {
            return this._drawShakkinTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle, true);
        }

        // === 敵スキン描画（enemySkinType が設定されている場合はテーマより優先）===
        // ★バグ修正: 以前はテーマチェックが先にreturnしていたため、enemySkinTypeが無視されていた
        //   （例: c4_boss は chaos テーマ + skin_abyss の両方を持つが、skin_abyss が描画されなかった）
        const _isPhaseTwo = battle && battle.bossPhase === 2;
        const _hasPhase2Skin = _isPhaseTwo && battle.stageData && battle.stageData.enemySkinPhase2;
        if (isEnemy && battle && battle.enemySkinType) {
            return this._drawSkinTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle.enemySkinType, battle, true);
        }

        // === Chapter2/3 テーマ専用描画 ===
        // enemySkinType が未設定の場合のみテーマ描画にフォールバック
        if (isEnemy && enemyTheme === 'mecha' && !_hasPhase2Skin) {
            return this._drawMechaThemeTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, tankType, battle);
        }
        if (isEnemy && enemyTheme === 'heaven' && !_hasPhase2Skin) {
            return this._drawHeavenThemeTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, tankType, battle);
        }
        if (isEnemy && enemyTheme === 'chaos' && !_hasPhase2Skin) {
            return this._drawChaosThemeTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, tankType, battle);
        }
        if (isEnemy && enemyTheme === 'genesis' && !_hasPhase2Skin) {
            return this._drawGenesisThemeTank(ctx, tx, ty, tw, th, dmgFlash, showInterior, tankType, battle);
        }

        // === 敵タイプ別専用デザイン ===
        if (isEnemy) {
            if (tankType === 'SCOUT') {
                return this._drawEnemyScout(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle);
            } else if (tankType === 'HEAVY' || tankType === 'DEFENSE') {
                return this._drawEnemyHeavy(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle, tankType);
            } else if (tankType === 'MAGICAL') {
                return this._drawEnemyMagical(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle);
            } else if (tankType === 'BOSS') {
                return this._drawEnemyBoss(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle);
            } else if (tankType === 'TRUE_BOSS') {
                return this._drawEnemyTrueBoss(ctx, tx, ty, tw, th, dmgFlash, showInterior, battle);
            }
        }

        // Colors Setup
        let bodyBase, bodyHigh, bodyShadow, panelColor;

        // 第二形態かどうかをチェック
        const isPhaseTwo = battle && battle.bossPhase === 2;

        if (isEnemy) {
            if (enemyTheme === 'mecha') {
                bodyBase = '#50606E'; bodyHigh = '#A9BBC7'; bodyShadow = '#1B242B'; panelColor = '#5ED3FF';
            } else if (enemyTheme === 'heaven') {
                bodyBase = '#DCE9F6'; bodyHigh = '#FFFFFF'; bodyShadow = '#97ABC2'; panelColor = '#F1C96B';
            } else if (tankType === 'HEAVY' || tankType === 'DEFENSE') {
                bodyBase = '#444'; bodyHigh = '#666'; bodyShadow = '#222'; panelColor = '#555';
            } else if (tankType === 'SCOUT') {
                bodyBase = '#388E3C'; bodyHigh = '#4CAF50'; bodyShadow = '#1B5E20'; panelColor = '#2E7D32';
            } else if (tankType === 'MAGICAL') {
                bodyBase = '#7B1FA2'; bodyHigh = '#9C27B0'; bodyShadow = '#4A148C'; panelColor = '#6A1B9A';
            } else if (tankType === 'BOSS') {
                bodyBase = '#1A1A1A'; bodyHigh = '#333'; bodyShadow = '#000'; panelColor = '#222';
            } else if (tankType === 'TRUE_BOSS') {
                // 第二形態はより派手でいかつい色に
                if (isPhaseTwo) {
                    bodyBase = '#8B0000'; bodyHigh = '#FF0000'; bodyShadow = '#4A0000'; panelColor = '#A00000';
                } else {
                    bodyBase = '#2A0A4A'; bodyHigh = '#4A148C'; bodyShadow = '#1A0030'; panelColor = '#3A0A5A';
                }
            } else { // Normal
                bodyBase = variant.base; bodyHigh = variant.high; bodyShadow = variant.shadow; panelColor = variant.trim;
            }
        } else {
            // プレイヤータンク：カスタムカラー対応
            const custom = window.game && window.game.saveData && window.game.saveData.tankCustom;
            const colorId = (custom && custom.color) || 'color_blue';
            const parts = window.TANK_PARTS;
            const colorDef = parts && parts.colors.find(c => c.id === colorId);
            if (colorDef && colorDef.isRainbow) {
                // レインボー：フレームで色相回転
                const hue = (_getFrameNow() * 0.5) % 360;
                bodyBase   = `hsl(${hue},70%,35%)`;
                bodyHigh   = `hsl(${(hue+40)%360},80%,60%)`;
                bodyShadow = `hsl(${(hue+20)%360},70%,20%)`;
                panelColor = `hsl(${(hue+20)%360},70%,40%)`;
            } else if (colorDef && colorDef.base) {
                bodyBase = colorDef.base; bodyHigh = colorDef.high;
                bodyShadow = colorDef.shadow; panelColor = colorDef.panel;
            } else {
                bodyBase = '#0277BD'; bodyHigh = '#29B6F6'; bodyShadow = '#01579B'; panelColor = '#0288D1';
            }
        }

        const cx = tx + tw / 2;
        const cy = ty + th / 2;

        ctx.save();
        ctx.translate(cx, ty + th);
        if (dmgFlash > 0.5) {
            // Math.random()の代わりにフレーム時刻ベースのシェイク（再現性あり、GC不要）
            const st = _getFrameNow() * 0.05;
            ctx.translate(Math.sin(st * 7.3) * 2, Math.sin(st * 11.7) * 1);
        }

        // Scale & Transform (DEFENSE/TRUE_BOSSはより大きく重々しく)
        let scaleX = 1.0;
        if (tankType === 'HEAVY' || tankType === 'DEFENSE' || tankType === 'BOSS') scaleX = 1.15;
        if (tankType === 'TRUE_BOSS') scaleX = isPhaseTwo ? 1.4 : 1.25; // 第二形態はさらに大きく
        if (tankType === 'SCOUT') scaleX = 0.95; // SCOUTは少し小さく
        ctx.scale(scaleX, 1.0);
        ctx.translate(-cx, -(ty + th));

        // 1. TREADS - 画像3スタイル: タイヤをはっきり見せる
        const treadH = 44;               // 高さアップ
        const treadW = tw * 0.80;
        const treadX = cx - treadW / 2;
        const treadY = ty + th - treadH;

        // キャタピラ本体
        const treadGrad = ctx.createLinearGradient(0, treadY, 0, treadY + treadH);
        treadGrad.addColorStop(0, '#4A5060');
        treadGrad.addColorStop(0.4, '#6A7080');
        treadGrad.addColorStop(1, '#252830');
        ctx.fillStyle = treadGrad;
        this._roundRect(ctx, treadX, treadY, treadW, treadH, 10);
        ctx.fill();
        ctx.strokeStyle = '#1A1C20';
        ctx.lineWidth = 2;
        ctx.stroke();

        // キャタピラの溝（点線）
        ctx.strokeStyle = '#1A1C20';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 5]);
        ctx.beginPath();
        ctx.moveTo(treadX + 10, treadY + treadH * 0.5);
        ctx.lineTo(treadX + treadW - 10, treadY + treadH * 0.5);
        ctx.stroke();
        ctx.setLineDash([]);

        // ホイール（4個しっかり見える）
        const wheelCount = 4;
        const wRad = 14;
        const wY = treadY + treadH * 0.55;
        const wSpan = treadW - 50;
        for (let i = 0; i < wheelCount; i++) {
            const wx = treadX + 25 + i * (wSpan / (wheelCount - 1));
            // ホイール外周
            ctx.fillStyle = '#37474F';
            ctx.beginPath(); ctx.arc(wx, wY, wRad, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#1A252A'; ctx.lineWidth = 1.5; ctx.stroke();
            // ホイール内周
            ctx.fillStyle = '#546E7A';
            ctx.beginPath(); ctx.arc(wx, wY, wRad * 0.55, 0, Math.PI * 2); ctx.fill();
            // ハブ
            ctx.fillStyle = '#78909C';
            ctx.beginPath(); ctx.arc(wx, wY, wRad * 0.22, 0, Math.PI * 2); ctx.fill();
        }

        // 2. MAIN BODY (Dome) - ★原作準拠: 横広まん丸ドーム
        const bw = tw;
        const bh = th * 0.85;
        const by = treadY - bh + 25;

        // 原作に合わせて横幅広め・縦はやや抑えてまん丸感を出す
        const dRX = bw * 0.50;   // 横: 広め
        const dRY = bh * 0.48;   // 縦: やや抑えてまん丸に
        const dCX = cx;
        const dCY = treadY - dRY * 0.90; // ドーム中心をタイヤ直上に

        // ── ドーム影（奥行き感）──
        ctx.beginPath();
        ctx.ellipse(dCX + 6, dCY + 6, dRX, dRY, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0,0,0,0.18)';
        ctx.fill();

        // ── ドーム本体 ──
        ctx.beginPath();
        ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI * 2);
        ctx.closePath();
        const domeKey = `dome2_${bodyBase}_${bodyHigh}_${bodyShadow}_${cx | 0}_${dCY | 0}`;
        const domeGrad = _getCachedGradient(ctx, domeKey, () => {
            const g = ctx.createRadialGradient(dCX - dRX * 0.35, dCY - dRY * 0.35, dRX * 0.08, dCX, dCY, dRX * 1.1);
            g.addColorStop(0,   bodyHigh);
            g.addColorStop(0.4, bodyBase);
            g.addColorStop(1,   bodyShadow);
            return g;
        });
        ctx.fillStyle = domeGrad;
        ctx.fill();

        // ── レンガ模様（横線＋縦目地）──
        ctx.save();
        ctx.beginPath();
        ctx.ellipse(dCX, dCY, dRX - 1, dRY - 1, 0, 0, Math.PI * 2);
        ctx.clip();
        ctx.strokeStyle = 'rgba(0,0,0,0.18)';
        ctx.lineWidth = 1.5;
        const brickRows = 7;
        const brickH = (dRY * 1.8) / brickRows;
        for (let row = 0; row <= brickRows; row++) {
            const lineY = (dCY - dRY * 0.9) + row * brickH;
            ctx.beginPath();
            ctx.moveTo(dCX - dRX, lineY);
            ctx.lineTo(dCX + dRX, lineY);
            ctx.stroke();
            // 縦目地（段ごとにオフセット）
            ctx.lineWidth = 1;
            ctx.strokeStyle = 'rgba(0,0,0,0.10)';
            const brickW = 32;
            const offset = (row % 2 === 0) ? 0 : brickW / 2;
            for (let bx2 = dCX - dRX + offset; bx2 < dCX + dRX; bx2 += brickW) {
                ctx.beginPath();
                ctx.moveTo(bx2, lineY);
                ctx.lineTo(bx2, lineY + brickH);
                ctx.stroke();
            }
            ctx.lineWidth = 1.5;
            ctx.strokeStyle = 'rgba(0,0,0,0.18)';
        }
        ctx.restore();

        // ── ドーム輪郭線 ──
        ctx.beginPath();
        ctx.ellipse(dCX, dCY, dRX, dRY, 0, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(0,0,0,0.30)';
        ctx.lineWidth = 2.5;
        ctx.stroke();

        // ── ハイライト（上部の光沢）──
        ctx.beginPath();
        ctx.ellipse(dCX - dRX * 0.18, dCY - dRY * 0.3, dRX * 0.32, dRY * 0.18, -0.3, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255,255,255,0.18)';
        ctx.fill();

        // 3. ── 塔2本・翼アーマー・中央大砲口・顔（強化版）──
        if (!showInterior) {

        // ── 翼アーマー（左右）: Image1インスパイアの金属翼板 ──
        const drawWings = (wingColor, wingHighlight, spiked) => {
            const wBaseY = dCY - dRY * 0.15;
            const wTipY  = dCY - dRY * 0.65;
            // 左翼
            ctx.fillStyle = wingColor;
            ctx.beginPath();
            ctx.moveTo(dCX - dRX + 4,  wBaseY + 10);
            ctx.lineTo(dCX - dRX - 22, wTipY + 10);
            ctx.lineTo(dCX - dRX - 35, wTipY - 8);
            ctx.lineTo(dCX - dRX - 18, wBaseY - 20);
            ctx.lineTo(dCX - dRX + 4,  wBaseY - 15);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 1.5; ctx.stroke();
            ctx.fillStyle = wingHighlight;
            ctx.beginPath();
            ctx.moveTo(dCX - dRX + 2,  wBaseY + 5);
            ctx.lineTo(dCX - dRX - 18, wTipY + 8);
            ctx.lineTo(dCX - dRX - 28, wTipY - 4);
            ctx.lineTo(dCX - dRX - 14, wBaseY - 16);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = 'rgba(255,255,255,0.18)'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.moveTo(dCX - dRX - 8, wBaseY - 5); ctx.lineTo(dCX - dRX - 26, wTipY); ctx.stroke();
            if (spiked) {
                ctx.fillStyle = wingColor;
                ctx.beginPath(); ctx.moveTo(dCX - dRX - 30, wTipY - 2); ctx.lineTo(dCX - dRX - 44, wTipY - 14); ctx.lineTo(dCX - dRX - 28, wTipY - 16); ctx.closePath(); ctx.fill();
            }
            // 右翼
            ctx.fillStyle = wingColor;
            ctx.beginPath();
            ctx.moveTo(dCX + dRX - 4,  wBaseY + 10);
            ctx.lineTo(dCX + dRX + 22, wTipY + 10);
            ctx.lineTo(dCX + dRX + 35, wTipY - 8);
            ctx.lineTo(dCX + dRX + 18, wBaseY - 20);
            ctx.lineTo(dCX + dRX - 4,  wBaseY - 15);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 1.5; ctx.stroke();
            ctx.fillStyle = wingHighlight;
            ctx.beginPath();
            ctx.moveTo(dCX + dRX - 2,  wBaseY + 5);
            ctx.lineTo(dCX + dRX + 18, wTipY + 8);
            ctx.lineTo(dCX + dRX + 28, wTipY - 4);
            ctx.lineTo(dCX + dRX + 14, wBaseY - 16);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = 'rgba(255,255,255,0.18)'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.moveTo(dCX + dRX + 8, wBaseY - 5); ctx.lineTo(dCX + dRX + 26, wTipY); ctx.stroke();
            if (spiked) {
                ctx.fillStyle = wingColor;
                ctx.beginPath(); ctx.moveTo(dCX + dRX + 30, wTipY - 2); ctx.lineTo(dCX + dRX + 44, wTipY - 14); ctx.lineTo(dCX + dRX + 28, wTipY - 16); ctx.closePath(); ctx.fill();
            }
        };

        // ── 城塔を左右に描く（強化版: 銃眼3個・アーチ窓・詳細石目）──
        const drawTower = (tcx, roofColor) => {
            const tRad = 22;
            const tH   = bh * 0.54;
            const tTopY = treadY - tH;

            // 塔本体グラデ
            const tG = ctx.createLinearGradient(tcx - tRad, 0, tcx + tRad, 0);
            tG.addColorStop(0,   '#8A6A38');
            tG.addColorStop(0.28,'#C8A060');
            tG.addColorStop(0.65,'#D4AA70');
            tG.addColorStop(1,   '#9A7A48');
            ctx.fillStyle = tG;
            ctx.beginPath(); ctx.rect(tcx - tRad, tTopY, tRad * 2, tH); ctx.fill();

            // 横の石目線
            ctx.strokeStyle = 'rgba(0,0,0,0.17)'; ctx.lineWidth = 1;
            for (let r = 1; r <= 6; r++) {
                const ly = tTopY + r * (tH / 7);
                ctx.beginPath(); ctx.moveTo(tcx - tRad + 2, ly); ctx.lineTo(tcx + tRad - 2, ly); ctx.stroke();
            }
            // 縦目地（互い違い）
            ctx.strokeStyle = 'rgba(0,0,0,0.09)'; ctx.lineWidth = 1;
            for (let r = 0; r <= 6; r++) {
                const ly = tTopY + r * (tH / 7);
                const offset = (r % 2 === 0) ? 0 : tRad;
                for (let vx = tcx - tRad + offset; vx < tcx + tRad; vx += tRad) {
                    ctx.beginPath(); ctx.moveTo(vx, ly); ctx.lineTo(vx, ly + tH / 7); ctx.stroke();
                }
            }
            // 輪郭
            ctx.strokeStyle = 'rgba(0,0,0,0.38)'; ctx.lineWidth = 1.8;
            ctx.strokeRect(tcx - tRad, tTopY, tRad * 2, tH);

            // アーチ窓（尖頭アーチ）
            const winY = tTopY + tH * 0.42;
            ctx.fillStyle = 'rgba(8,8,25,0.85)';
            ctx.beginPath();
            ctx.moveTo(tcx - 7, winY + 10);
            ctx.lineTo(tcx - 7, winY);
            ctx.quadraticCurveTo(tcx - 7, winY - 12, tcx, winY - 16);
            ctx.quadraticCurveTo(tcx + 7, winY - 12, tcx + 7, winY);
            ctx.lineTo(tcx + 7, winY + 10);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#9A7A50'; ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(tcx - 6, winY);
            ctx.quadraticCurveTo(tcx - 6, winY - 10, tcx, winY - 14);
            ctx.quadraticCurveTo(tcx + 6, winY - 10, tcx + 6, winY);
            ctx.stroke();
            // 窓の光
            ctx.fillStyle = 'rgba(255,220,80,0.18)';
            ctx.beginPath(); ctx.arc(tcx, winY - 4, 5, 0, Math.PI*2); ctx.fill();

            // 銃眼 x3（バトルメント）
            const mW = 7, mH = 11, mGap = 5;
            const mTotalW = 3 * mW + 2 * mGap;
            ctx.fillStyle = '#C8A060'; ctx.strokeStyle = 'rgba(0,0,0,0.28)'; ctx.lineWidth = 1;
            for (let i = 0; i < 3; i++) {
                const mx = tcx - mTotalW / 2 + i * (mW + mGap);
                ctx.beginPath(); ctx.rect(mx, tTopY - mH, mW, mH + 2); ctx.fill(); ctx.stroke();
            }
            // 天板ライン
            ctx.strokeStyle = 'rgba(0,0,0,0.28)'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.moveTo(tcx - tRad, tTopY); ctx.lineTo(tcx + tRad, tTopY); ctx.stroke();

            // 円錐屋根
            ctx.fillStyle = roofColor || (isEnemy ? '#BF360C' : '#C62828');
            ctx.beginPath();
            ctx.moveTo(tcx - tRad - 3, tTopY - mH);
            ctx.lineTo(tcx, tTopY - mH - 32);
            ctx.lineTo(tcx + tRad + 3, tTopY - mH);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = 'rgba(0,0,0,0.32)'; ctx.lineWidth = 1.5; ctx.stroke();
            ctx.strokeStyle = 'rgba(255,255,255,0.22)'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.moveTo(tcx, tTopY - mH - 30); ctx.lineTo(tcx - tRad * 0.4, tTopY - mH - 3); ctx.stroke();

            // 旗ポール
            ctx.strokeStyle = '#4E342E'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.moveTo(tcx, tTopY - mH - 32); ctx.lineTo(tcx, tTopY - mH - 50); ctx.stroke();
            ctx.fillStyle = roofColor || (isEnemy ? '#E53935' : '#43A047');
            ctx.beginPath();
            ctx.moveTo(tcx, tTopY - mH - 50); ctx.lineTo(tcx + 12, tTopY - mH - 43);
            ctx.lineTo(tcx, tTopY - mH - 36); ctx.closePath(); ctx.fill();
        };

        // ── エンブレム（胸元の歯車メダル）共通ヘルパー ──
        const drawEmblem = (ex, ey, innerColor, gemColor) => {
            ctx.fillStyle = '#1A2838'; ctx.strokeStyle = '#4A7090'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(ex, ey, 17, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            ctx.fillStyle = innerColor; ctx.strokeStyle = 'rgba(70,120,160,0.7)'; ctx.lineWidth = 1;
            ctx.beginPath(); ctx.arc(ex, ey, 11, 0, Math.PI*2); ctx.fill(); ctx.stroke();
            // 歯車の歯 x8
            for (let t = 0; t < 8; t++) {
                const ang = t * Math.PI / 4;
                const tx1 = ex + Math.cos(ang) * 14, ty1 = ey + Math.sin(ang) * 14;
                const tx2 = ex + Math.cos(ang) * 19, ty2 = ey + Math.sin(ang) * 19;
                ctx.strokeStyle = '#4A7090'; ctx.lineWidth = 3.5; ctx.lineCap = 'round';
                ctx.beginPath(); ctx.moveTo(tx1, ty1); ctx.lineTo(tx2, ty2); ctx.stroke();
            }
            ctx.fillStyle = gemColor;
            ctx.beginPath(); ctx.arc(ex, ey, 5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = 'rgba(255,255,255,0.5)';
            ctx.beginPath(); ctx.arc(ex - 2, ey - 2, 2, 0, Math.PI*2); ctx.fill();
        };

        // タイプ別に翼・塔・砲口・顔・エンブレムを描く
        if (!isEnemy) {
            // ── プレイヤー: ロイヤルブルー翼 ──
            drawWings('#5070A0', '#7090C0', false);
            const towerOffsetX = dRX * 0.86;
            drawTower(dCX - towerOffsetX, '#C62828');
            drawTower(dCX + towerOffsetX, '#C62828');
        } else if (enemyTheme === 'mecha') {
            drawWings('#324654', '#5ED3FF', true);
            const towerOffsetX = dRX * 0.84;
            const drawMechaThemeTower = (tcx) => {
                const towerW = 32;
                const towerH = 88;
                const towerX = tcx - towerW / 2;
                const towerY = dCY - dRY - 18;
                const g = ctx.createLinearGradient(towerX, towerY, towerX + towerW, towerY);
                g.addColorStop(0, '#1A232B');
                g.addColorStop(0.5, '#50606E');
                g.addColorStop(1, '#24313A');
                ctx.fillStyle = g;
                ctx.fillRect(towerX, towerY, towerW, towerH);
                ctx.strokeStyle = 'rgba(94,211,255,0.75)';
                ctx.lineWidth = 1.5;
                ctx.strokeRect(towerX, towerY, towerW, towerH);
                for (let i = 0; i < 3; i++) {
                    const ly = towerY + 20 + i * 18;
                    ctx.strokeStyle = 'rgba(160,220,255,0.55)';
                    ctx.beginPath();
                    ctx.moveTo(towerX + 5, ly);
                    ctx.lineTo(towerX + towerW - 5, ly);
                    ctx.stroke();
                }
                ctx.fillStyle = '#8BE9FF';
                ctx.fillRect(towerX + towerW / 2 - 3, towerY - 14, 6, 14);
                ctx.beginPath(); ctx.arc(towerX + towerW / 2, towerY - 18, 5, 0, Math.PI * 2); ctx.fill();
            };
            drawMechaThemeTower(dCX - towerOffsetX);
            drawMechaThemeTower(dCX + towerOffsetX);
        } else if (enemyTheme === 'heaven') {
            drawWings('#F6FBFF', '#F1C96B', false);
            const towerOffsetX = dRX * 0.84;
            const drawHeavenThemeTower = (tcx) => {
                const towerW = 30;
                const towerH = 84;
                const towerX = tcx - towerW / 2;
                const towerY = dCY - dRY - 16;
                const g = ctx.createLinearGradient(towerX, towerY, towerX, towerY + towerH);
                g.addColorStop(0, '#FFFFFF');
                g.addColorStop(0.5, '#E8F1FB');
                g.addColorStop(1, '#C4D4E6');
                ctx.fillStyle = g;
                ctx.beginPath();
                ctx.roundRect(towerX, towerY, towerW, towerH, 10);
                ctx.fill();
                ctx.strokeStyle = 'rgba(241,201,107,0.9)';
                ctx.lineWidth = 1.5;
                ctx.stroke();
                ctx.fillStyle = '#F1C96B';
                ctx.beginPath();
                ctx.moveTo(towerX - 4, towerY + 8);
                ctx.lineTo(towerX + towerW / 2, towerY - 18);
                ctx.lineTo(towerX + towerW + 4, towerY + 8);
                ctx.closePath();
                ctx.fill();
                ctx.strokeStyle = 'rgba(255,255,255,0.75)';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(towerX + towerW / 2, towerY + 12);
                ctx.lineTo(towerX + towerW / 2, towerY + towerH - 14);
                ctx.stroke();
            };
            drawHeavenThemeTower(dCX - towerOffsetX);
            drawHeavenThemeTower(dCX + towerOffsetX);
        } else if (tankType === 'SCOUT') {
            // ── SCOUT: 軽量グリーン翼（細くてスリム）──
            drawWings('#2E6030', '#4CAF50', false);
            const towerOffsetX = dRX * 0.84;
            drawTower(dCX - towerOffsetX, '#2E7D32');
            drawTower(dCX + towerOffsetX, '#2E7D32');
        } else if (tankType === 'HEAVY' || tankType === 'DEFENSE') {
            // ── HEAVY: 重装甲グレー翼（スパイク付き）──
            drawWings('#333', '#555', true);
            const towerOffsetX = dRX * 0.86;
            drawTower(dCX - towerOffsetX, '#8B0000');
            drawTower(dCX + towerOffsetX, '#8B0000');
        } else if (tankType === 'MAGICAL') {
            // ── MAGICAL: 魔法クリスタル翼 ──
            drawWings('#5A0090', '#9C27B0', false);
            const towerOffsetX = dRX * 0.84;
            drawTower(dCX - towerOffsetX, '#6A1B9A');
            drawTower(dCX + towerOffsetX, '#6A1B9A');
        } else if (tankType === 'BOSS') {
            // ── BOSS: ゴールド装甲翼（スパイク付き）──
            drawWings('#664400', '#AA7700', true);
            const towerOffsetX = dRX * 0.86;
            drawTower(dCX - towerOffsetX, '#B8860B');
            drawTower(dCX + towerOffsetX, '#B8860B');
        } else if (tankType === 'TRUE_BOSS') {
            // ── TRUE_BOSS: 禍々しい紫黒翼（スパイク付き）──
            drawWings('#2A0050', '#6A00C0', true);
            const towerOffsetX = dRX * (isPhaseTwo ? 0.90 : 0.86);
            drawTower(dCX - towerOffsetX, isPhaseTwo ? '#C00000' : '#4A0080');
            drawTower(dCX + towerOffsetX, isPhaseTwo ? '#C00000' : '#4A0080');
        } else {
            // ── NORMAL: 標準レッド翼 ──
            drawWings('#882020', '#BB4040', false);
            const towerOffsetX = dRX * 0.84;
            drawTower(dCX - towerOffsetX, '#BF360C');
            drawTower(dCX + towerOffsetX, '#BF360C');
        }

        // ── ドーム頂上の旗 ──
        const domeTopX = dCX;
        const domeTopY = dCY - dRY;
        ctx.fillStyle = '#C8A060';
        ctx.beginPath(); ctx.ellipse(domeTopX, domeTopY, 9, 3.5, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#D4AA70';
        ctx.beginPath(); ctx.rect(domeTopX - 5, domeTopY - 12, 10, 12); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 1; ctx.stroke();
        ctx.fillStyle = isEnemy ? '#BF360C' : '#C62828';
        ctx.beginPath();
        ctx.moveTo(domeTopX - 8, domeTopY - 12); ctx.lineTo(domeTopX, domeTopY - 24);
        ctx.lineTo(domeTopX + 8, domeTopY - 12); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 1; ctx.stroke();
        ctx.strokeStyle = '#4E342E'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(domeTopX, domeTopY - 24); ctx.lineTo(domeTopX, domeTopY - 38); ctx.stroke();
        ctx.fillStyle = isEnemy ? '#E53935' : '#43A047';
        ctx.beginPath();
        ctx.moveTo(domeTopX, domeTopY - 38); ctx.lineTo(domeTopX + 12, domeTopY - 32);
        ctx.lineTo(domeTopX, domeTopY - 26); ctx.closePath(); ctx.fill();

        // ── 中央の大砲口（強化版：二重リング＋砲身リング装飾）──
        const cannonSide = isEnemy ? -1 : 1;
        const bigCannonX = dCX + cannonSide * dRX * 0.30;
        const bigCannonY = dCY + dRY * 0.10;
        const bigCannonR = dRX * 0.20;

        // 外枠リング（二重）
        ctx.fillStyle = '#2A3540';
        ctx.beginPath(); ctx.arc(bigCannonX, bigCannonY, bigCannonR + 9, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = 2; ctx.stroke();
        ctx.fillStyle = '#37474F';
        ctx.beginPath(); ctx.arc(bigCannonX, bigCannonY, bigCannonR + 5, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = 'rgba(100,140,160,0.3)'; ctx.lineWidth = 1; ctx.stroke();
        // 砲口の穴
        ctx.fillStyle = '#050810';
        ctx.beginPath(); ctx.arc(bigCannonX, bigCannonY, bigCannonR, 0, Math.PI * 2); ctx.fill();
        // 穴の内部ハイライト
        ctx.fillStyle = 'rgba(255,255,255,0.08)';
        ctx.beginPath(); ctx.ellipse(bigCannonX - bigCannonR*0.3, bigCannonY - bigCannonR*0.3, bigCannonR*0.4, bigCannonR*0.25, -0.5, 0, Math.PI*2); ctx.fill();
        // 砲身（穴から突き出る）
        const barrelLen = 44;
        const barrelR   = bigCannonR * 0.62;
        const barrelGrad = ctx.createLinearGradient(
            bigCannonX, bigCannonY - barrelR,
            bigCannonX, bigCannonY + barrelR
        );
        barrelGrad.addColorStop(0, '#90A4AE');
        barrelGrad.addColorStop(0.4, '#B0BEC5');
        barrelGrad.addColorStop(1, '#455A64');
        ctx.fillStyle = barrelGrad;
        ctx.beginPath();
        ctx.ellipse(bigCannonX + cannonSide * barrelLen * 0.5, bigCannonY,
                    Math.abs(cannonSide * barrelLen) * 0.55, barrelR, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1.5; ctx.stroke();
        // 砲身リング装飾
        const ringX = bigCannonX + cannonSide * barrelLen * 0.65;
        ctx.fillStyle = '#3A4858'; ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.ellipse(ringX, bigCannonY, 5, barrelR + 3, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
        // 砲口先端リング（二重）
        const tipX = bigCannonX + cannonSide * barrelLen;
        ctx.fillStyle = '#2A3540';
        ctx.beginPath(); ctx.arc(tipX, bigCannonY, barrelR + 5, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.fillStyle = '#37474F';
        ctx.beginPath(); ctx.arc(tipX, bigCannonY, barrelR + 2, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#050810';
        ctx.beginPath(); ctx.arc(tipX, bigCannonY, barrelR, 0, Math.PI * 2); ctx.fill();

        // ── タイプ別：目の形・固有装飾 ──
        const eyeCY    = dCY - dRY * 0.28;
        const eyeR     = dRX * 0.09;
        const eyeGap   = eyeR * 3.0;
        const eyeBaseX = dCX + cannonSide * dRX * 0.18;

        // 目を2個描くヘルパー
        const drawEyes = (style, color = '#0A0A14', scaleY = 1) => {
            for (let e = 0; e < 2; e++) {
                const ex = eyeBaseX + cannonSide * (e - 0.5) * eyeGap;
                ctx.fillStyle = 'rgba(0,0,0,0.18)';
                ctx.beginPath(); ctx.ellipse(ex+1, eyeCY+1, eyeR+2, (eyeR+2)*scaleY, 0, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = '#C8C8D8';
                ctx.beginPath(); ctx.ellipse(ex, eyeCY, eyeR+1.5, (eyeR+1.5)*scaleY, 0, 0, Math.PI*2); ctx.fill();
                if (style === 'slit') {
                    ctx.fillStyle = color;
                    ctx.beginPath(); ctx.ellipse(ex, eyeCY, eyeR, eyeR*scaleY, 0, 0, Math.PI*2); ctx.fill();
                    ctx.fillStyle = '#FF0000';
                    ctx.beginPath(); ctx.ellipse(ex, eyeCY, eyeR*0.28, eyeR*scaleY*0.9, 0, 0, Math.PI*2); ctx.fill();
                } else if (style === 'star') {
                    ctx.fillStyle = color;
                    ctx.beginPath(); ctx.ellipse(ex, eyeCY, eyeR, eyeR*scaleY, 0, 0, Math.PI*2); ctx.fill();
                    ctx.fillStyle = '#FFD700';
                    ctx.save(); ctx.translate(ex, eyeCY);
                    ctx.beginPath();
                    for (let s = 0; s < 5; s++) {
                        const a = (s*4*Math.PI/5) - Math.PI/2;
                        const b = (s*4*Math.PI/5 + 2*Math.PI/5) - Math.PI/2;
                        if (s===0) ctx.moveTo(Math.cos(a)*eyeR*0.7, Math.sin(a)*eyeR*0.7*scaleY);
                        else       ctx.lineTo(Math.cos(a)*eyeR*0.7, Math.sin(a)*eyeR*0.7*scaleY);
                        ctx.lineTo(Math.cos(b)*eyeR*0.3, Math.sin(b)*eyeR*0.3*scaleY);
                    }
                    ctx.closePath(); ctx.fill(); ctx.restore();
                } else if (style === 'angry') {
                    ctx.fillStyle = color;
                    ctx.beginPath(); ctx.ellipse(ex, eyeCY, eyeR, eyeR*scaleY, 0, 0, Math.PI*2); ctx.fill();
                    ctx.fillStyle = 'rgba(255,255,255,0.55)';
                    ctx.beginPath(); ctx.arc(ex - eyeR*0.28, eyeCY - eyeR*0.3*scaleY, eyeR*0.28, 0, Math.PI*2); ctx.fill();
                    const eySign = (e === 0) ? 1 : -1;
                    ctx.strokeStyle = '#1A0000'; ctx.lineWidth = 3; ctx.lineCap = 'round';
                    ctx.beginPath();
                    ctx.moveTo(ex - eyeR*0.8, eyeCY - eyeR*1.1*scaleY);
                    ctx.lineTo(ex + eyeR*0.8*eySign*cannonSide, eyeCY - eyeR*1.5*scaleY);
                    ctx.stroke();
                } else if (style === 'narrow') {
                    ctx.fillStyle = color;
                    ctx.beginPath(); ctx.ellipse(ex, eyeCY, eyeR, eyeR*scaleY, 0, 0, Math.PI*2); ctx.fill();
                    ctx.fillStyle = 'rgba(255,255,255,0.5)';
                    ctx.beginPath(); ctx.arc(ex - eyeR*0.28, eyeCY - eyeR*0.3*scaleY, eyeR*0.28, 0, Math.PI*2); ctx.fill();
                } else {
                    ctx.fillStyle = color;
                    ctx.beginPath(); ctx.ellipse(ex, eyeCY, eyeR, eyeR*scaleY, 0, 0, Math.PI*2); ctx.fill();
                    ctx.fillStyle = 'rgba(255,255,255,0.6)';
                    ctx.beginPath(); ctx.arc(ex - eyeR*0.28, eyeCY - eyeR*0.32, eyeR*0.3, 0, Math.PI*2); ctx.fill();
                }
            }
        };

        // ── タイプ別：目・固有装飾 ──
        if (!isEnemy) {
            // プレイヤー: 黒目＋歯車エンブレム（ブルー）
            drawEyes('normal', '#0A0A14', 1.0);
            drawEmblem(dCX - cannonSide * dRX * 0.28, dCY + dRY * 0.38, '#0A1520', '#5A90B0');
        } else if (tankType === 'SCOUT') {
            // SCOUT: 細い目＋アンテナ＋緑エンブレム
            drawEyes('narrow', '#0A2A0A', 0.55);
            ctx.strokeStyle = '#2E7D32'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.moveTo(dCX - 16, dCY - dRY * 0.72); ctx.lineTo(dCX - 26, dCY - dRY - 22); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(dCX + 16, dCY - dRY * 0.72); ctx.lineTo(dCX + 26, dCY - dRY - 22); ctx.stroke();
            ctx.fillStyle = '#4CAF50';
            ctx.beginPath(); ctx.arc(dCX - 26, dCY - dRY - 22, 5, 0, Math.PI*2); ctx.fill();
            ctx.beginPath(); ctx.arc(dCX + 26, dCY - dRY - 22, 5, 0, Math.PI*2); ctx.fill();
            drawEmblem(dCX - cannonSide * dRX * 0.28, dCY + dRY * 0.38, '#0A200A', '#4CAF50');
        } else if (tankType === 'HEAVY' || tankType === 'DEFENSE') {
            // HEAVY: 怒り眉大きな目＋スパイク装甲＋グレーエンブレム
            drawEyes('angry', '#1A0000', 1.15);
            ctx.fillStyle = '#444';
            for (let s = 0; s < 4; s++) {
                const sy = dCY - dRY * 0.35 + s * dRY * 0.24;
                ctx.beginPath();
                ctx.moveTo(dCX - dRX + 3, sy); ctx.lineTo(dCX - dRX - 15, sy + 7); ctx.lineTo(dCX - dRX + 3, sy + 14); ctx.closePath(); ctx.fill();
                ctx.beginPath();
                ctx.moveTo(dCX + dRX - 3, sy); ctx.lineTo(dCX + dRX + 15, sy + 7); ctx.lineTo(dCX + dRX - 3, sy + 14); ctx.closePath(); ctx.fill();
            }
            drawEmblem(dCX - cannonSide * dRX * 0.28, dCY + dRY * 0.38, '#1A0A0A', '#888');
        } else if (tankType === 'MAGICAL') {
            // MAGICAL: 星形の目＋クリスタル＋紫エンブレム
            drawEyes('star', '#1A0030', 1.0);
            [[dCX - 38, dCY - dRY + 8], [dCX, dCY - dRY - 8], [dCX + 38, dCY - dRY + 8]].forEach(([cx2, cy2]) => {
                ctx.fillStyle = '#CE93D8';
                ctx.beginPath(); ctx.moveTo(cx2, cy2 - 12); ctx.lineTo(cx2+6, cy2); ctx.lineTo(cx2, cy2+12); ctx.lineTo(cx2-6, cy2); ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#9C27B0'; ctx.lineWidth = 1; ctx.stroke();
                ctx.fillStyle = 'rgba(255,255,255,0.55)';
                ctx.beginPath(); ctx.moveTo(cx2-2, cy2-9); ctx.lineTo(cx2+1, cy2); ctx.lineTo(cx2-2, cy2+9); ctx.closePath(); ctx.fill();
            });
            const auraA = 0.12 + Math.sin((_getFrameNow() || 0) * 0.04) * 0.06;
            ctx.strokeStyle = `rgba(180,0,255,${auraA})`; ctx.lineWidth = 5;
            ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX + 6, dRY + 6, 0, 0, Math.PI*2); ctx.stroke();
            drawEmblem(dCX - cannonSide * dRX * 0.28, dCY + dRY * 0.38, '#150025', '#AB47BC');
        } else if (tankType === 'BOSS') {
            // BOSS: 赤目＋豪華王冠＋ゴールドエンブレム
            drawEyes('normal', '#8B0000', 1.1);
            ctx.fillStyle = '#FFD700';
            const crownY = dCY - dRY - 6;
            ctx.beginPath();
            ctx.moveTo(dCX - 32, crownY);
            ctx.lineTo(dCX - 22, crownY - 18); ctx.lineTo(dCX - 11, crownY - 8);
            ctx.lineTo(dCX,      crownY - 23); ctx.lineTo(dCX + 11, crownY - 8);
            ctx.lineTo(dCX + 22, crownY - 18); ctx.lineTo(dCX + 32, crownY);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#B8860B'; ctx.lineWidth = 1.5; ctx.stroke();
            // 宝石 x3
            ctx.fillStyle = '#FF1744'; ctx.beginPath(); ctx.arc(dCX, crownY - 20, 5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#00BCD4'; ctx.beginPath(); ctx.arc(dCX - 21, crownY - 15, 3.5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#00BCD4'; ctx.beginPath(); ctx.arc(dCX + 21, crownY - 15, 3.5, 0, Math.PI*2); ctx.fill();
            drawEmblem(dCX - cannonSide * dRX * 0.28, dCY + dRY * 0.38, '#1A1000', '#FFD700');
        } else if (tankType === 'TRUE_BOSS') {
            // TRUE_BOSS: 縦スリット目＋大きな角2本＋脈動オーラ＋暗黒エンブレム
            drawEyes('slit', '#200020', 0.9);
            const hornColor = isPhaseTwo ? '#8B0000' : '#4A0080';
            const hornAccent = isPhaseTwo ? '#FF0000' : '#6A00B0';
            ctx.fillStyle = hornColor;
            ctx.beginPath(); ctx.moveTo(dCX - 38, dCY - dRY + 6); ctx.lineTo(dCX - 26, dCY - dRY - 38); ctx.lineTo(dCX - 17, dCY - dRY + 6); ctx.closePath(); ctx.fill();
            ctx.strokeStyle = hornAccent; ctx.lineWidth = 1.5; ctx.stroke();
            ctx.beginPath(); ctx.moveTo(dCX + 38, dCY - dRY + 6); ctx.lineTo(dCX + 26, dCY - dRY - 38); ctx.lineTo(dCX + 17, dCY - dRY + 6); ctx.closePath(); ctx.fill();
            ctx.stroke();
            // 角の小トゲ
            ctx.fillStyle = hornAccent;
            ctx.beginPath(); ctx.moveTo(dCX - 38, dCY - dRY + 4); ctx.lineTo(dCX - 44, dCY - dRY - 10); ctx.lineTo(dCX - 36, dCY - dRY - 6); ctx.closePath(); ctx.fill();
            ctx.beginPath(); ctx.moveTo(dCX + 38, dCY - dRY + 4); ctx.lineTo(dCX + 44, dCY - dRY - 10); ctx.lineTo(dCX + 36, dCY - dRY - 6); ctx.closePath(); ctx.fill();
            const auraAlpha = 0.15 + Math.sin((_getFrameNow() || 0) * 0.04) * 0.08;
            const auraColor = isPhaseTwo ? `rgba(255,0,0,${auraAlpha})` : `rgba(150,0,255,${auraAlpha})`;
            ctx.strokeStyle = auraColor; ctx.lineWidth = 9;
            ctx.beginPath(); ctx.ellipse(dCX, dCY, dRX + 10, dRY + 10, 0, 0, Math.PI*2); ctx.stroke();
            const emblemGem = isPhaseTwo ? '#FF1744' : '#9C27B0';
            drawEmblem(dCX - cannonSide * dRX * 0.28, dCY + dRY * 0.38, '#0A0010', emblemGem);
        } else {
            // NORMAL: 標準目＋シンプルエンブレム
            drawEyes('normal', '#0A0A14', 1.0);
            drawEmblem(dCX - cannonSide * dRX * 0.28, dCY + dRY * 0.38, '#150808', '#E64A19');
        }

        } // end if (!showInterior) - tower, flag, face, battlements

        // 4. INTERIOR FRAME (外観時はエンブレム非表示・顔で代用済み)
        if (!showInterior) {
            // 外観時: 顔で表現済みのためエンブレムは描かない
        } else {
            // INTERIOR VIEW CUTOUT
            // Darken inside background
            const ix = CONFIG.TANK.OFFSET_X + wt;
            const iy = CONFIG.TANK.OFFSET_Y + wt + 20; // Align with logic
            const iw = CONFIG.TANK.INTERIOR_W - wt * 2;
            const ih = CONFIG.TANK.INTERIOR_H - wt * 2; // Approximate

            // We need to draw the "Frame" around the interior since the interior is drawn separately
            // Actually, game.js draws tank.draw() which uses this function.
            // But tank.draw() ALSO draws the internal platforms/machines ON TOP of this.
            // So we just need to draw the "Container" here.

            const frameColor = '#5D4037'; // Wood/Metal mixed interior
            ctx.fillStyle = frameColor;
            // Left Wall
            ctx.fillRect(tx + 5, ty + 20, wt + 10, th - 30);
            // Right Wall
            ctx.fillRect(tx + tw - wt - 15, ty + 20, wt + 10, th - 30);
            // Bottom Floor
            ctx.fillRect(tx + 5, ty + th - 25, tw - 10, 25);

            // Rivets on frame
            ctx.fillStyle = '#8D6E63';
            for (let y = ty + 40; y < ty + th - 40; y += 30) {
                ctx.beginPath(); ctx.arc(tx + 15, y, 4, 0, Math.PI * 2); ctx.fill();
                ctx.beginPath(); ctx.arc(tx + tw - 15, y, 4, 0, Math.PI * 2); ctx.fill();
            }
        }

        // === プレイヤータンク：エフェクトオーラ（周回オブジェクト） ===
        if (!isEnemy) {
            const _efxCustom2 = window.game && window.game.saveData && window.game.saveData.tankCustom;
            const _efxId2 = (_efxCustom2 && _efxCustom2.effect) || 'effect_normal';
            if (_efxId2 !== 'effect_normal') {
                // ★修正: カスタマイズ画面ではプレビュー用スケール(0.55)がかかるためエフェクト非表示
                const _isCustomizePreview = window.game && window.game.state === 'customize';
                if (_isCustomizePreview) { /* skip orbit in customize preview */ } else {
                // タンク中心・周回半径
                const orbitCx = cx;
                const orbitCy = ty + th * 0.45;
                const orbitRx = tw * 0.58;  // 横半径
                const orbitRy = th * 0.30;  // 縦半径（楕円で奥行き感）

                ctx.save();
                // ★修正: 上画面（y < OFFSET_Y）にのみ描画するようクリッピング
                const _upperH = (window.CONFIG && window.CONFIG.TANK && window.CONFIG.TANK.OFFSET_Y) || 420;
                ctx.beginPath();
                ctx.rect(0, 0, ctx.canvas.width, _upperH);
                ctx.clip();

                // --- 共通描画ヘルパー ---
                // 火の玉を描く
                const drawFireball = (ox, oy, r) => {
                    ctx.fillStyle = 'rgba(255,60,0,0.9)';
                    ctx.beginPath(); ctx.arc(ox, oy, r, 0, Math.PI * 2); ctx.fill();
                    ctx.fillStyle = 'rgba(255,200,0,0.85)';
                    ctx.beginPath(); ctx.arc(ox - r * 0.25, oy - r * 0.25, r * 0.55, 0, Math.PI * 2); ctx.fill();
                    ctx.fillStyle = 'rgba(255,255,180,0.7)';
                    ctx.beginPath(); ctx.arc(ox - r * 0.35, oy - r * 0.35, r * 0.25, 0, Math.PI * 2); ctx.fill();
                };
                // 雪の結晶を描く
                const drawSnowflake = (ox, oy, r) => {
                    ctx.strokeStyle = 'rgba(180,240,255,0.95)'; ctx.lineWidth = 1.8;
                    for (let li = 0; li < 3; li++) {
                        const a = (li * Math.PI / 3);
                        ctx.beginPath();
                        ctx.moveTo(ox + Math.cos(a) * r, oy + Math.sin(a) * r);
                        ctx.lineTo(ox - Math.cos(a) * r, oy - Math.sin(a) * r);
                        ctx.stroke();
                        // 枝
                        const bx1 = ox + Math.cos(a) * r * 0.5, by1 = oy + Math.sin(a) * r * 0.5;
                        const bx2 = ox - Math.cos(a) * r * 0.5, by2 = oy - Math.sin(a) * r * 0.5;
                        for (const [bx, by] of [[bx1,by1],[bx2,by2]]) {
                            ctx.beginPath();
                            ctx.moveTo(bx + Math.cos(a + Math.PI/2)*r*0.3, by + Math.sin(a + Math.PI/2)*r*0.3);
                            ctx.lineTo(bx - Math.cos(a + Math.PI/2)*r*0.3, by - Math.sin(a + Math.PI/2)*r*0.3);
                            ctx.stroke();
                        }
                    }
                    ctx.fillStyle = 'rgba(220,248,255,0.95)';
                    ctx.beginPath(); ctx.arc(ox, oy, r * 0.22, 0, Math.PI * 2); ctx.fill();
                };
                // 稲妻マークを描く
                const drawBolt = (ox, oy, r) => {
                    ctx.fillStyle = 'rgba(255,230,0,0.95)';
                    ctx.strokeStyle = 'rgba(255,255,150,0.8)'; ctx.lineWidth = 1;
                    ctx.beginPath();
                    ctx.moveTo(ox + r*0.2, oy - r);
                    ctx.lineTo(ox - r*0.2, oy - r*0.05);
                    ctx.lineTo(ox + r*0.15, oy - r*0.05);
                    ctx.lineTo(ox - r*0.2, oy + r);
                    ctx.lineTo(ox + r*0.2, oy + r*0.05);
                    ctx.lineTo(ox - r*0.15, oy + r*0.05);
                    ctx.closePath(); ctx.fill(); ctx.stroke();
                };
                // ハートを描く
                const drawHeart = (ox, oy, r) => {
                    ctx.fillStyle = 'rgba(255,100,160,0.95)';
                    ctx.strokeStyle = 'rgba(255,180,210,0.8)'; ctx.lineWidth = 1;
                    ctx.beginPath();
                    ctx.moveTo(ox, oy + r * 0.8);
                    ctx.bezierCurveTo(ox - r * 1.1, oy + r * 0.2, ox - r * 1.1, oy - r * 0.7, ox, oy - r * 0.25);
                    ctx.bezierCurveTo(ox + r * 1.1, oy - r * 0.7, ox + r * 1.1, oy + r * 0.2, ox, oy + r * 0.8);
                    ctx.closePath(); ctx.fill(); ctx.stroke();
                    // ハイライト
                    ctx.fillStyle = 'rgba(255,220,235,0.7)';
                    ctx.beginPath(); ctx.ellipse(ox - r*0.3, oy - r*0.1, r*0.25, r*0.15, -0.5, 0, Math.PI*2); ctx.fill();
                };
                // 月を描く
                const drawMoon = (ox, oy, r) => {
                    ctx.fillStyle = 'rgba(200,160,255,0.95)';
                    ctx.beginPath(); ctx.arc(ox, oy, r, 0, Math.PI * 2); ctx.fill();
                    // 欠け部分（三日月）
                    ctx.fillStyle = 'rgba(30,0,50,0.92)';
                    ctx.beginPath(); ctx.arc(ox + r * 0.35, oy - r * 0.1, r * 0.78, 0, Math.PI * 2); ctx.fill();
                    // 星のきらめき
                    ctx.fillStyle = 'rgba(230,200,255,0.9)';
                    ctx.beginPath(); ctx.arc(ox - r * 0.5, oy - r * 0.6, r * 0.12, 0, Math.PI * 2); ctx.fill();
                };

                // エフェクト別設定（個数・サイズ・描画関数）
                const efxConfig = {
                    effect_fire:    { count: 3, r: 9,  draw: drawFireball },
                    effect_ice:     { count: 4, r: 10, draw: drawSnowflake },
                    effect_thunder: { count: 3, r: 9,  draw: drawBolt },
                    effect_holy:    { count: 4, r: 8,  draw: drawHeart },
                    effect_dark:    { count: 3, r: 10, draw: drawMoon },
                };
                const cfg = efxConfig[_efxId2];
                if (cfg) {
                    for (let oi = 0; oi < cfg.count; oi++) {
                        // ★修正: 時間を使わず固定角度で配置（動き回らない）
                        const angle = (oi / cfg.count) * Math.PI * 2;
                        const ox = orbitCx + Math.cos(angle) * orbitRx;
                        const oy = orbitCy + Math.sin(angle) * orbitRy;
                        cfg.draw(ox, oy, cfg.r);
                    }
                }

                ctx.restore();
                } // end if (!_isCustomizePreview)
            }
        }

        // === プレイヤータンク：装甲オーバーレイ ===
        if (!isEnemy) {
            const custom = window.game && window.game.saveData && window.game.saveData.tankCustom;
            const armorId = (custom && custom.armor) || 'armor_normal';
            const bx = tx + 15, bw2 = tw - 30;
            const by2 = ty + 20;

            if (armorId === 'armor_spike') {
                // スパイク装甲：左右＋上部にトゲ（より大きく・目立つ色）
                const spikeColor = '#E0E0E0';
                const spikeStroke = '#999';
                ctx.fillStyle = spikeColor;
                ctx.strokeStyle = spikeStroke; ctx.lineWidth = 1.2;
                // 左右のトゲ（大きめ）
                for (let i = 0; i < 5; i++) {
                    const sy = by2 + 15 + i * 26;
                    // 左
                    ctx.beginPath();
                    ctx.moveTo(tx + 20, sy); ctx.lineTo(tx - 18, sy + 6); ctx.lineTo(tx + 20, sy + 12);
                    ctx.closePath(); ctx.fill(); ctx.stroke();
                    // 右
                    ctx.beginPath();
                    ctx.moveTo(tx + tw - 20, sy); ctx.lineTo(tx + tw + 18, sy + 6); ctx.lineTo(tx + tw - 20, sy + 12);
                    ctx.closePath(); ctx.fill(); ctx.stroke();
                }
                // 上部プレート＋上向きトゲ3本
                ctx.fillStyle = bodyBase;
                ctx.fillRect(cx - 75, by2, 150, 14);
                ctx.strokeStyle = spikeColor; ctx.lineWidth = 1.5;
                ctx.strokeRect(cx - 75, by2, 150, 14);
                ctx.fillStyle = spikeColor;
                ctx.strokeStyle = spikeStroke; ctx.lineWidth = 1;
                for (let i = 0; i < 3; i++) {
                    const spx = cx - 40 + i * 40;
                    ctx.beginPath();
                    ctx.moveTo(spx - 8, by2); ctx.lineTo(spx, by2 - 18); ctx.lineTo(spx + 8, by2);
                    ctx.closePath(); ctx.fill(); ctx.stroke();
                }

            } else if (armorId === 'armor_shield') {
                // シールド型：大型の盾＋紋章（より存在感を出す）
                const shieldX = (dir === 1 ? tx + tw - 8 : tx - 36);
                const shieldW = 36, shieldH = 100;
                const shieldTop = ty + 55;
                // 盾の外枠グロー
                ctx.save();
                ctx.globalAlpha = 0.35;
                ctx.fillStyle = bodyHigh;
                ctx.beginPath();
                ctx.moveTo(shieldX - 4, shieldTop - 4);
                ctx.lineTo(shieldX + shieldW + 4, shieldTop - 4);
                ctx.lineTo(shieldX + shieldW + 4, shieldTop + shieldH * 0.65);
                ctx.lineTo(shieldX + shieldW / 2, shieldTop + shieldH + 4);
                ctx.lineTo(shieldX - 4, shieldTop + shieldH * 0.65);
                ctx.closePath(); ctx.fill();
                ctx.restore();
                // 盾本体
                ctx.fillStyle = bodyHigh;
                ctx.beginPath();
                ctx.moveTo(shieldX, shieldTop);
                ctx.lineTo(shieldX + shieldW, shieldTop);
                ctx.lineTo(shieldX + shieldW, shieldTop + shieldH * 0.65);
                ctx.lineTo(shieldX + shieldW / 2, shieldTop + shieldH);
                ctx.lineTo(shieldX, shieldTop + shieldH * 0.65);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 2; ctx.stroke();
                // 盾の縦ライン
                ctx.strokeStyle = bodyBase; ctx.lineWidth = 1.5;
                ctx.beginPath();
                ctx.moveTo(shieldX + shieldW / 2, shieldTop + 6);
                ctx.lineTo(shieldX + shieldW / 2, shieldTop + shieldH - 10);
                ctx.stroke();
                // 盾の中央紋章（星形）
                const embX = shieldX + shieldW / 2, embY = shieldTop + 38, embR = 11;
                ctx.fillStyle = bodyBase;
                ctx.beginPath();
                for (let i = 0; i < 5; i++) {
                    const a = (i * 4 * Math.PI / 5) - Math.PI / 2;
                    const b = (i * 4 * Math.PI / 5 + 2 * Math.PI / 5) - Math.PI / 2;
                    if (i === 0) ctx.moveTo(embX + Math.cos(a) * embR, embY + Math.sin(a) * embR);
                    else ctx.lineTo(embX + Math.cos(a) * embR, embY + Math.sin(a) * embR);
                    ctx.lineTo(embX + Math.cos(b) * embR * 0.42, embY + Math.sin(b) * embR * 0.42);
                }
                ctx.closePath(); ctx.fill();

            } else if (armorId === 'armor_wings') {
                // 天使の翼：大型化＋羽毛ライン追加
                const t = _getFrameNow() * 0.012;
                const flapY = Math.sin(t) * 8;
                const flapX = Math.sin(t * 0.7) * 3;
                // 翼の影（奥行き感）
                ctx.save();
                ctx.globalAlpha = 0.25;
                ctx.fillStyle = '#FFD700';
                // 左翼影
                ctx.beginPath();
                ctx.moveTo(tx + 14, ty + 70 + flapY + 5);
                ctx.bezierCurveTo(tx - 52, ty + 30 + flapY, tx - 65, ty + 130 + flapY, tx + 10, ty + 175 + flapY);
                ctx.bezierCurveTo(tx - 18, ty + 140 + flapY, tx - 10, ty + 95 + flapY, tx + 14, ty + 70 + flapY + 5);
                ctx.fill();
                // 右翼影
                ctx.beginPath();
                ctx.moveTo(tx + tw - 14, ty + 70 + flapY + 5);
                ctx.bezierCurveTo(tx + tw + 52, ty + 30 + flapY, tx + tw + 65, ty + 130 + flapY, tx + tw - 10, ty + 175 + flapY);
                ctx.bezierCurveTo(tx + tw + 18, ty + 140 + flapY, tx + tw + 10, ty + 95 + flapY, tx + tw - 14, ty + 70 + flapY + 5);
                ctx.fill();
                ctx.restore();
                // 翼本体
                ctx.fillStyle = 'rgba(255,255,210,0.88)';
                ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 2;
                // 左翼
                ctx.beginPath();
                ctx.moveTo(tx + 14 + flapX, ty + 70 + flapY);
                ctx.bezierCurveTo(tx - 50 + flapX, ty + 25 + flapY, tx - 62 + flapX, ty + 125 + flapY, tx + 10 + flapX, ty + 172 + flapY);
                ctx.bezierCurveTo(tx - 16 + flapX, ty + 135 + flapY, tx - 8 + flapX, ty + 90 + flapY, tx + 14 + flapX, ty + 70 + flapY);
                ctx.fill(); ctx.stroke();
                // 左翼の羽毛ライン3本
                ctx.strokeStyle = 'rgba(255,220,100,0.7)'; ctx.lineWidth = 1;
                for (let fi = 0; fi < 3; fi++) {
                    const fp = 0.3 + fi * 0.25;
                    const fx1 = tx + 14 + flapX + (tx - 50 + flapX - tx - 14 - flapX) * fp;
                    const fy1 = ty + 70 + flapY + (ty + 25 + flapY - ty - 70 - flapY) * fp;
                    ctx.beginPath();
                    ctx.moveTo(fx1, fy1);
                    ctx.lineTo(tx + 10 + flapX, ty + 172 + flapY - fi * 28);
                    ctx.stroke();
                }
                // 右翼
                ctx.fillStyle = 'rgba(255,255,210,0.88)';
                ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(tx + tw - 14 - flapX, ty + 70 + flapY);
                ctx.bezierCurveTo(tx + tw + 50 - flapX, ty + 25 + flapY, tx + tw + 62 - flapX, ty + 125 + flapY, tx + tw - 10 - flapX, ty + 172 + flapY);
                ctx.bezierCurveTo(tx + tw + 16 - flapX, ty + 135 + flapY, tx + tw + 8 - flapX, ty + 90 + flapY, tx + tw - 14 - flapX, ty + 70 + flapY);
                ctx.fill(); ctx.stroke();
                // 右翼の羽毛ライン3本
                ctx.strokeStyle = 'rgba(255,220,100,0.7)'; ctx.lineWidth = 1;
                for (let fi = 0; fi < 3; fi++) {
                    const fp = 0.3 + fi * 0.25;
                    const fx1 = tx + tw - 14 - flapX + (tx + tw + 50 - flapX - (tx + tw - 14 - flapX)) * fp;
                    const fy1 = ty + 70 + flapY + (ty + 25 + flapY - ty - 70 - flapY) * fp;
                    ctx.beginPath();
                    ctx.moveTo(fx1, fy1);
                    ctx.lineTo(tx + tw - 10 - flapX, ty + 172 + flapY - fi * 28);
                    ctx.stroke();
                }
            } else if (armorId === 'armor_crab') {
                // 🦀 カニ装甲：両サイドに大きなハサミ＋目玉
                const ft2 = _getFrameNow();
                const clawSnap = Math.sin(ft2 * 0.04) * 0.18; // ハサミのパチパチ
                const clawColor = '#E53935';
                const clawDark  = '#B71C1C';
                const clawHigh  = '#FF7043';

                // ── 左ハサミ ──
                ctx.save();
                ctx.translate(tx - 10, ty + th * 0.38);
                // 腕の根元
                ctx.fillStyle = clawDark;
                ctx.beginPath(); ctx.ellipse(14, 0, 14, 9, -0.2, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = clawColor;
                ctx.beginPath(); ctx.ellipse(12, -1, 12, 7, -0.2, 0, Math.PI*2); ctx.fill();
                // 上ハサミ（パチパチ）
                ctx.fillStyle = clawColor;
                ctx.save(); ctx.rotate(-clawSnap);
                ctx.beginPath();
                ctx.moveTo(22, -2);
                ctx.bezierCurveTo(30, -14, 48, -16, 52, -8);
                ctx.bezierCurveTo(48, -4, 32, -2, 22, -2);
                ctx.closePath(); ctx.fill();
                ctx.fillStyle = clawHigh;
                ctx.beginPath(); ctx.ellipse(44, -10, 6, 3, -0.4, 0, Math.PI*2); ctx.fill();
                ctx.restore();
                // 下ハサミ（固定）
                ctx.fillStyle = clawDark;
                ctx.beginPath();
                ctx.moveTo(22, 2);
                ctx.bezierCurveTo(30, 10, 46, 12, 50, 6);
                ctx.bezierCurveTo(46, 2, 32, 2, 22, 2);
                ctx.closePath(); ctx.fill();
                ctx.restore();

                // ── 右ハサミ ──
                ctx.save();
                ctx.translate(tx + tw + 10, ty + th * 0.38);
                ctx.scale(-1, 1); // 左右反転
                // 腕の根元
                ctx.fillStyle = clawDark;
                ctx.beginPath(); ctx.ellipse(14, 0, 14, 9, -0.2, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = clawColor;
                ctx.beginPath(); ctx.ellipse(12, -1, 12, 7, -0.2, 0, Math.PI*2); ctx.fill();
                // 上ハサミ（パチパチ）
                ctx.fillStyle = clawColor;
                ctx.save(); ctx.rotate(-clawSnap);
                ctx.beginPath();
                ctx.moveTo(22, -2);
                ctx.bezierCurveTo(30, -14, 48, -16, 52, -8);
                ctx.bezierCurveTo(48, -4, 32, -2, 22, -2);
                ctx.closePath(); ctx.fill();
                ctx.fillStyle = clawHigh;
                ctx.beginPath(); ctx.ellipse(44, -10, 6, 3, -0.4, 0, Math.PI*2); ctx.fill();
                ctx.restore();
                // 下ハサミ（固定）
                ctx.fillStyle = clawDark;
                ctx.beginPath();
                ctx.moveTo(22, 2);
                ctx.bezierCurveTo(30, 10, 46, 12, 50, 6);
                ctx.bezierCurveTo(46, 2, 32, 2, 22, 2);
                ctx.closePath(); ctx.fill();
                ctx.restore();

                // ── タンク上部の目玉2つ ──
                const eyeY = ty + 28;
                for (const ex of [cx - 22, cx + 22]) {
                    // 目の柄（細い棒）
                    ctx.fillStyle = clawDark;
                    ctx.fillRect(ex - 3, eyeY - 12, 6, 14);
                    // 白目
                    ctx.fillStyle = '#FFFFFF';
                    ctx.beginPath(); ctx.arc(ex, eyeY - 12, 9, 0, Math.PI*2); ctx.fill();
                    // 黒目
                    ctx.fillStyle = '#111';
                    ctx.beginPath(); ctx.arc(ex + 2, eyeY - 13, 5, 0, Math.PI*2); ctx.fill();
                    // ハイライト
                    ctx.fillStyle = '#FFF';
                    ctx.beginPath(); ctx.arc(ex + 4, eyeY - 15, 2, 0, Math.PI*2); ctx.fill();
                    // 目の縁
                    ctx.strokeStyle = clawDark; ctx.lineWidth = 1.5;
                    ctx.beginPath(); ctx.arc(ex, eyeY - 12, 9, 0, Math.PI*2); ctx.stroke();
                }
            }
            // armor_normal は装飾なし
        }

        // Damage Overlay (composite=overplayは重いのでsource-overで代替)
        if (dmgFlash > 0) {
            ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(0.5, dmgFlash * 0.04)})`;
            ctx.fillRect(tx - 20, ty - 20, tw + 40, th + 40);
        }

        // === TANK TYPE SPECIFIC DECORATIONS (敵のみ) ===
        if (isEnemy && tankType !== 'NORMAL') {
            const decorY = by + 30; // 装飾の基準Y座標

            if (enemyTheme === 'mecha') {
                ctx.fillStyle = 'rgba(94,211,255,0.22)';
                ctx.fillRect(cx - 64, decorY - 10, 128, 12);
                ctx.strokeStyle = 'rgba(94,211,255,0.75)';
                ctx.lineWidth = 2;
                ctx.strokeRect(cx - 64, decorY - 10, 128, 12);
                [-54, -18, 18, 54].forEach(offset => {
                    ctx.fillStyle = '#324654';
                    ctx.fillRect(cx + offset - 8, decorY + 10, 16, 18);
                    ctx.strokeStyle = '#8EB7CC';
                    ctx.lineWidth = 1;
                    ctx.strokeRect(cx + offset - 8, decorY + 10, 16, 18);
                });
            } else if (enemyTheme === 'heaven') {
                ctx.strokeStyle = 'rgba(241,201,107,0.95)';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(cx - 52, decorY + 8);
                ctx.quadraticCurveTo(cx - 24, decorY - 12, cx, decorY + 2);
                ctx.quadraticCurveTo(cx + 24, decorY - 12, cx + 52, decorY + 8);
                ctx.stroke();
                ctx.fillStyle = 'rgba(255,248,220,0.85)';
                ctx.beginPath(); ctx.arc(cx, decorY + 22, 10, 0, Math.PI * 2); ctx.fill();
                ctx.strokeStyle = 'rgba(255,255,255,0.8)';
                ctx.stroke();
            } else if (tankType === 'SCOUT') {
                // アンテナ（速度センサー的な）
                ctx.strokeStyle = bodyBase;
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.moveTo(cx - 40, decorY);
                ctx.lineTo(cx - 50, decorY - 40);
                ctx.moveTo(cx + 40, decorY);
                ctx.lineTo(cx + 50, decorY - 40);
                ctx.stroke();

                // アンテナ先端
                ctx.fillStyle = '#4CAF50';
                ctx.beginPath();
                ctx.arc(cx - 50, decorY - 40, 5, 0, Math.PI * 2);
                ctx.arc(cx + 50, decorY - 40, 5, 0, Math.PI * 2);
                ctx.fill();

                // スピードライン（稲妻マーク）
                ctx.strokeStyle = '#FFD700';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(cx - 20, decorY + 20);
                ctx.lineTo(cx - 10, decorY + 30);
                ctx.lineTo(cx - 15, decorY + 30);
                ctx.lineTo(cx - 5, decorY + 40);
                ctx.stroke();
            }

            if (tankType === 'DEFENSE' || tankType === 'BOSS') {
                // 装甲トゲ（左右）
                const spikeCount = 4;
                ctx.fillStyle = bodyShadow;
                for (let i = 0; i < spikeCount; i++) {
                    const sy = (dCY - dRY * 0.3) + i * 30;
                    // 左側のトゲ
                    ctx.beginPath();
                    ctx.moveTo(cx - bw / 2 + 25, sy);
                    ctx.lineTo(cx - bw / 2 - 5, sy + 5);
                    ctx.lineTo(cx - bw / 2 + 25, sy + 10);
                    ctx.closePath();
                    ctx.fill();
                    // 右側のトゲ
                    ctx.beginPath();
                    ctx.moveTo(cx + bw / 2 - 25, sy);
                    ctx.lineTo(cx + bw / 2 + 5, sy + 5);
                    ctx.lineTo(cx + bw / 2 - 25, sy + 10);
                    ctx.closePath();
                    ctx.fill();
                }

                // 上部に重装甲プレート
                ctx.fillStyle = bodyBase;
                ctx.fillRect(cx - 80, dCY - dRY + 5, 160, 15);
                ctx.strokeStyle = bodyShadow;
                ctx.lineWidth = 2;
                ctx.strokeRect(cx - 80, dCY - dRY + 5, 160, 15);
            }

            if (tankType === 'MAGICAL') {
                // 魔法のクリスタル（上部）
                const crystals = [
                    { x: cx - 50, y: dCY - dRY + 20 },
                    { x: cx, y: dCY - dRY - 5 },
                    { x: cx + 50, y: dCY - dRY + 20 }
                ];

                crystals.forEach((crystal, i) => {
                    // クリスタルの輝き

                    // クリスタル本体（ひし形）
                    ctx.fillStyle = bodyHigh;
                    ctx.beginPath();
                    ctx.moveTo(crystal.x, crystal.y - 12);
                    ctx.lineTo(crystal.x + 6, crystal.y);
                    ctx.lineTo(crystal.x, crystal.y + 12);
                    ctx.lineTo(crystal.x - 6, crystal.y);
                    ctx.closePath();
                    ctx.fill();

                    // クリスタルのハイライト
                    ctx.fillStyle = 'rgba(255,255,255,0.6)';
                    ctx.beginPath();
                    ctx.moveTo(crystal.x - 2, crystal.y - 6);
                    ctx.lineTo(crystal.x + 2, crystal.y);
                    ctx.lineTo(crystal.x - 2, crystal.y + 6);
                    ctx.closePath();
                    ctx.fill();

                });

                // 魔法陣（装飾）
                ctx.strokeStyle = bodyHigh;
                ctx.lineWidth = 2;
                ctx.setLineDash([5, 5]);
                ctx.beginPath();
                ctx.arc(cx, dCY, 40, 0, Math.PI * 2);
                ctx.stroke();
                ctx.setLineDash([]);
            }

            if (tankType === 'BOSS') {
                // 王冠（ボスの証）
                ctx.fillStyle = '#FFD700';
                ctx.beginPath();
                const crownY = dCY - dRY + 5;
                ctx.moveTo(cx - 30, crownY - 5);
                ctx.lineTo(cx - 20, crownY - 20);
                ctx.lineTo(cx - 10, crownY - 5);
                ctx.lineTo(cx, crownY - 25);
                ctx.lineTo(cx + 10, crownY - 5);
                ctx.lineTo(cx + 20, crownY - 20);
                ctx.lineTo(cx + 30, crownY - 5);
                ctx.lineTo(cx + 25, crownY + 5);
                ctx.lineTo(cx - 25, crownY + 5);
                ctx.closePath();
                ctx.fill();
                ctx.strokeStyle = '#FFA500';
                ctx.lineWidth = 2;
                ctx.stroke();

                // 王冠の宝石
                ctx.fillStyle = '#FF0000';
                ctx.beginPath();
                ctx.arc(cx, dCY - dRY - 10, 4, 0, Math.PI * 2);
                ctx.fill();
            }

            if (tankType === 'TRUE_BOSS' && !showInterior) {
                // 全ての装飾を統合した究極形態（外観のみ・下画面には表示しない）

                // 第二形態の追加装飾
                if (isPhaseTwo) {
                    // 赤いオーラ（簡略化：1つの大きなグラデーションか少ない円で表現）
                    const time = _getFrameNow() * 0.001;
                    ctx.save();
                    ctx.globalAlpha = 0.3 + Math.sin(time * 5) * 0.1;
                    ctx.strokeStyle = '#F00';
                    ctx.lineWidth = 10;
                    ctx.beginPath();
                    ctx.arc(cx, cy, 90 + Math.sin(time * 10) * 10, 0, Math.PI * 2);
                    ctx.stroke();
                    ctx.restore();

                    // 巨大な角（両側）
                    ctx.strokeStyle = '#8B0000';
                    ctx.lineWidth = 8;
                    ctx.lineCap = 'round';
                    ctx.beginPath();
                    ctx.moveTo(cx - 60, dCY - dRY + 50);
                    ctx.quadraticCurveTo(cx - 80, dCY - dRY - 20, cx - 70, dCY - dRY - 60);
                    ctx.stroke();
                    ctx.beginPath();
                    ctx.moveTo(cx + 60, dCY - dRY + 50);
                    ctx.quadraticCurveTo(cx + 80, dCY - dRY - 20, cx + 70, dCY - dRY - 60);
                    ctx.stroke();

                    // 角の先端
                    ctx.fillStyle = '#FF0000';
                    ctx.beginPath();
                    ctx.arc(cx - 70, dCY - dRY - 60, 8, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.beginPath();
                    ctx.arc(cx + 70, dCY - dRY - 60, 8, 0, Math.PI * 2);
                    ctx.fill();

                    // トゲ（全身）
                    ctx.fillStyle = '#8B0000';
                    for (let i = 0; i < 8; i++) {
                        const angle = (Math.PI * 2 * i) / 8;
                        const spikeX = cx + Math.cos(angle) * (bw / 2 - 10);
                        const spikeY = cy + Math.sin(angle) * (bh / 2);
                        ctx.beginPath();
                        ctx.moveTo(spikeX, spikeY);
                        ctx.lineTo(spikeX + Math.cos(angle) * 25, spikeY + Math.sin(angle) * 25);
                        ctx.lineTo(spikeX + Math.cos(angle + 0.3) * 15, spikeY + Math.sin(angle + 0.3) * 15);
                        ctx.closePath();
                        ctx.fill();
                    }
                }

                // オーラリング（簡略化：3重を1重に）
                const time = _getFrameNow() * 0.001;
                const alpha = 0.2 + Math.sin(time * 3) * 0.1;
                ctx.strokeStyle = isPhaseTwo ? `rgba(255, 0, 0, ${alpha})` : `rgba(138, 43, 226, ${alpha})`;
                ctx.lineWidth = 4;
                ctx.setLineDash([15, 10]);
                ctx.beginPath();
                ctx.arc(cx, cy - 20, 80 + Math.sin(time * 2) * 10, 0, Math.PI * 2);
                ctx.stroke();
                ctx.setLineDash([]);

                // 巨大クリスタル（頂上）
                ctx.save();
                ctx.translate(cx, dCY - dRY - 30);

                ctx.fillStyle = isPhaseTwo ? '#8B0000' : '#4A148C';
                ctx.beginPath();
                ctx.moveTo(0, -25);
                ctx.lineTo(12, 0);
                ctx.lineTo(8, 15);
                ctx.lineTo(-8, 15);
                ctx.lineTo(-12, 0);
                ctx.closePath();
                ctx.fill();

                ctx.fillStyle = 'rgba(255,255,255,0.4)';
                ctx.beginPath();
                ctx.moveTo(-3, -15);
                ctx.lineTo(3, -5);
                ctx.lineTo(-3, 5);
                ctx.closePath();
                ctx.fill();

                ctx.restore();

                // 邪悪な目（両側）
                [-45, 45].forEach(offsetX => {
                    const eyeX = cx + offsetX;
                    const eyeY = dCY - dRY * 0.2;

                    // 白目
                    ctx.fillStyle = '#8B0000';
                    ctx.beginPath();
                    ctx.ellipse(eyeX, eyeY, 12, 8, 0, 0, Math.PI * 2);
                    ctx.fill();

                    // 瞳
                    ctx.fillStyle = isPhaseTwo ? '#FFFF00' : '#FF0000'; // 第二形態は黄色い瞳
                    ctx.beginPath();
                    ctx.arc(eyeX + Math.sin(time * 2) * 2, eyeY, 5, 0, Math.PI * 2);
                    ctx.fill();

                    // ハイライト
                    ctx.fillStyle = 'rgba(255,255,255,0.6)';
                    ctx.beginPath();
                    ctx.arc(eyeX - 2, eyeY - 2, 2, 0, Math.PI * 2);
                    ctx.fill();
                });

                // 翼のような装飾
                ctx.strokeStyle = isPhaseTwo ? '#8B0000' : '#4A148C';
                ctx.lineWidth = 4;
                ctx.beginPath();
                ctx.moveTo(cx - bw / 2 + 20, dCY - dRY * 0.1);
                ctx.quadraticCurveTo(cx - bw / 2 - 30, dCY - dRY * 0.3, cx - bw / 2 - 20, dCY - dRY * 0.5);
                ctx.moveTo(cx + bw / 2 - 20, dCY - dRY * 0.1);
                ctx.quadraticCurveTo(cx + bw / 2 + 30, dCY - dRY * 0.3, cx + bw / 2 + 20, dCY - dRY * 0.5);
                ctx.stroke();
            }
        }

        if (isEnemy) this._drawStageEnemyOverlay(ctx, tx, ty, tw, th, battle, 0.9);
        ctx.restore();
    },

    _drawTower(ctx, x, y, w, h, color, roofColor) {
        ctx.fillStyle = color; ctx.strokeStyle = this._darkenHex(color, 20); ctx.lineWidth = 2;
        ctx.fillRect(x, y + 20, w, h - 20); ctx.strokeRect(x, y + 20, w, h - 20);

        // Roof
        ctx.fillStyle = roofColor; ctx.beginPath();
        ctx.moveTo(x - 5, y + 20); ctx.lineTo(x + w / 2, y); ctx.lineTo(x + w + 5, y + 20); ctx.closePath();
        ctx.fill(); ctx.stroke();

        // Windows
        ctx.fillStyle = '#333';
        ctx.fillRect(x + w / 2 - 5, y + 30, 10, 10);
    },

    // === TOP-DOWN WALL (Platform) ===
    drawPlatform(ctx, x, y, w, h) {
        // Wall with Shadow
        ctx.save();

        ctx.shadowOffsetY = 5;

        // Wall Body (Top surface)
        ctx.fillStyle = '#D2B48C';
        ctx.fillRect(x, y, w, h);
        ctx.restore(); // Restore shadow settings before drawing details

        // Wall Detail (Face/Depth)
        const depth = 8;
        ctx.fillStyle = '#A0522D';
        ctx.fillRect(x, y + h - depth, w, depth);

        // Highlights
        ctx.strokeStyle = 'rgba(255,255,255,0.2)';
        ctx.lineWidth = 2;
        ctx.strokeRect(x, y, w, h);
    },

    // === CANNON (Top-Down Style) ===
    drawCannon(ctx, x, y, w, h, dir, loaded, loadProgress) {
        const custom = window.game && window.game.saveData && window.game.saveData.tankCustom;
        const cannonId = (custom && custom.cannon) || 'cannon_normal';

        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        const angle = (dir === 1) ? 0 : Math.PI;

        // ── 丸い砲台マウント（ロケットスライム風）──
        // 台座（楕円ベース）
        ctx.fillStyle = '#4A5060';
        ctx.beginPath(); ctx.ellipse(0, 4, w * 0.42, h * 0.22, 0, 0, Math.PI * 2); ctx.fill();
        // マウント本体（丸）
        const mountGrad = ctx.createRadialGradient(-w*0.1, -h*0.1, 2, 0, 0, w * 0.38);
        mountGrad.addColorStop(0, '#8A9BB0');
        mountGrad.addColorStop(0.5, '#5A6A80');
        mountGrad.addColorStop(1, '#2A3A50');
        ctx.fillStyle = mountGrad;
        ctx.beginPath(); ctx.arc(0, 0, w * 0.38, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#2A3040'; ctx.lineWidth = 2; ctx.stroke();
        // マウントのリベット
        ctx.fillStyle = '#8A9BB0';
        for (let i = 0; i < 6; i++) {
            const a = (i / 6) * Math.PI * 2;
            ctx.beginPath(); ctx.arc(Math.cos(a)*w*0.28, Math.sin(a)*w*0.28, 2.5, 0, Math.PI*2); ctx.fill();
        }

        ctx.rotate(angle);
        const tubeL = w * 0.7;
        const tubeW = h * 0.6;

        if (cannonId === 'cannon_double') {
            // 二連装砲：上下2本
            for (const oy of [-tubeW * 0.55, tubeW * 0.15]) {
                ctx.fillStyle = '#666';
                ctx.fillRect(0, oy, tubeL * 0.9, tubeW * 0.45);
                ctx.strokeStyle = '#333'; ctx.lineWidth = 1;
                ctx.strokeRect(0, oy, tubeL * 0.9, tubeW * 0.45);
                ctx.fillStyle = '#222';
                ctx.fillRect(tubeL * 0.9 - 4, oy - 1, 6, tubeW * 0.45 + 2);
            }
        } else if (cannonId === 'cannon_magic') {
            // 魔法杖砲：細長い杖 + 先端に★
            ctx.fillStyle = '#9C27B0';
            ctx.fillRect(0, -tubeW * 0.2, tubeL * 0.85, tubeW * 0.4);
            ctx.strokeStyle = '#CE93D8'; ctx.lineWidth = 1; ctx.strokeRect(0, -tubeW * 0.2, tubeL * 0.85, tubeW * 0.4);
            // 先端の星
            ctx.fillStyle = loaded ? '#FFD700' : '#CE93D8';
            const sx = tubeL * 0.85, sy = 0, sr = tubeW * 0.45;
            ctx.beginPath();
            for (let i = 0; i < 5; i++) {
                const a = (i * 4 * Math.PI / 5) - Math.PI / 2;
                const b = (i * 4 * Math.PI / 5 + 2 * Math.PI / 5) - Math.PI / 2;
                if (i === 0) ctx.moveTo(sx + Math.cos(a) * sr, sy + Math.sin(a) * sr);
                else ctx.lineTo(sx + Math.cos(a) * sr, sy + Math.sin(a) * sr);
                ctx.lineTo(sx + Math.cos(b) * sr * 0.4, sy + Math.sin(b) * sr * 0.4);
            }
            ctx.closePath(); ctx.fill();
        } else if (cannonId === 'cannon_laser') {
            // レーザー砲：細長くスリムな砲身
            ctx.fillStyle = '#37474F';
            ctx.fillRect(0, -tubeW * 0.18, tubeL * 1.1, tubeW * 0.36);
            ctx.strokeStyle = '#00E5FF'; ctx.lineWidth = 1.5;
            ctx.strokeRect(0, -tubeW * 0.18, tubeL * 1.1, tubeW * 0.36);
            // グロー
            if (loaded) {
                ctx.fillStyle = 'rgba(0,229,255,0.3)';
                ctx.fillRect(0, -tubeW * 0.25, tubeL * 1.1, tubeW * 0.5);
            }
            // 先端の点
            ctx.fillStyle = loaded ? '#00E5FF' : '#78909C';
            ctx.beginPath(); ctx.arc(tubeL * 1.1, 0, tubeW * 0.2, 0, Math.PI * 2); ctx.fill();
        } else if (cannonId === 'cannon_rainbow') {
            // 🌈 レインボー砲：固定7色ストライプ（色相固定でちかちかなし）
            const rainbowColors = ['#FF4444', '#FF9900', '#FFEE00', '#44CC44', '#2299FF', '#7744EE', '#FF44CC'];
            const stripeCount = rainbowColors.length;
            const stripeW = tubeL / stripeCount;
            for (let si = 0; si < stripeCount; si++) {
                ctx.fillStyle = rainbowColors[si];
                ctx.fillRect(si * stripeW, -tubeW * 0.45, stripeW + 1, tubeW * 0.9);
            }
            // 砲身の輪郭（白）
            ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1.5;
            ctx.strokeRect(0, -tubeW * 0.45, tubeL, tubeW * 0.9);
            // 砲口のリング（固定色：白）
            ctx.fillStyle = loaded ? '#FFFFFF' : '#888';
            ctx.beginPath(); ctx.arc(tubeL, 0, tubeW * 0.52, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = 'rgba(200,200,255,0.8)'; ctx.lineWidth = 1.5; ctx.stroke();
            // 砲口の穴（固定色）
            ctx.fillStyle = loaded ? '#FFD700' : '#222';
            ctx.beginPath(); ctx.arc(tubeL, 0, tubeW * 0.28, 0, Math.PI * 2); ctx.fill();
            if (loaded) {
                ctx.globalAlpha = 0.3;
                ctx.fillStyle = '#FFFFFF';
                ctx.beginPath(); ctx.arc(tubeL, 0, tubeW * 0.9, 0, Math.PI * 2); ctx.fill();
                ctx.globalAlpha = 1;
            }
        } else {
            // スタンダード砲（丸い砲身・ロケットスライム風）
            const tubeGrad = ctx.createLinearGradient(0, -tubeW/2, 0, tubeW/2);
            tubeGrad.addColorStop(0, '#8A9BB0');
            tubeGrad.addColorStop(0.35, '#6A7A90');
            tubeGrad.addColorStop(1, '#2A3A50');
            ctx.fillStyle = tubeGrad;
            // 砲身を角丸に
            ctx.beginPath();
            Renderer._roundRect(ctx, 0, -tubeW/2, tubeL, tubeW, tubeW/2);
            ctx.fill();
            ctx.strokeStyle = '#1A2A3A'; ctx.lineWidth = 1.5;
            Renderer._roundRect(ctx, 0, -tubeW/2, tubeL, tubeW, tubeW/2);
            ctx.stroke();
            // 砲口のリング
            ctx.fillStyle = '#2A3A50';
            ctx.beginPath(); ctx.arc(tubeL, 0, tubeW/2 + 2, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#1A2A3A'; ctx.lineWidth = 1.5; ctx.stroke();
            // 砲口の穴
            ctx.fillStyle = loaded ? '#FFD700' : '#0A0A1A';
            ctx.beginPath(); ctx.arc(tubeL, 0, tubeW/2 - 3, 0, Math.PI*2); ctx.fill();
            if (loaded) {
                ctx.fillStyle = 'rgba(255,200,0,0.3)';
                ctx.beginPath(); ctx.arc(tubeL, 0, tubeW/2 + 6, 0, Math.PI*2); ctx.fill();
            }
        }

        ctx.restore();
    },

    // === ENGINE CORE (3D glowing sphere) ===
    drawEngineCore(ctx, x, y, w, h, hp, maxHp) {
        ctx.save();
        const cx = x + w / 2, cy = y + h / 2;
        const t = _getFrameNow();

        // === 外側グロー（拡張オーラ）===
        const pulse = 0.3 + Math.sin(t * 0.003) * 0.2;
        ctx.save();
        ctx.translate(cx, cy);
        ctx.globalAlpha = pulse * 0.6;
        const outerGlow = _getCachedGradient(ctx, `ec_outer2_${w|0}`, () => {
            const g = ctx.createRadialGradient(0, 0, 0, 0, 0, w * 1.5);
            g.addColorStop(0, 'rgba(255,160,0,1)');
            g.addColorStop(0.5, 'rgba(255,80,0,0.5)');
            g.addColorStop(1, 'rgba(255,30,0,0)');
            return g;
        });
        ctx.fillStyle = outerGlow;
        ctx.beginPath(); ctx.arc(0, 0, w * 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.restore();

        // === ハウジング（3Dメタリックボックス）===
        const hGrad = _getCachedGradient(ctx, `ec_housing2_${w|0}_${h|0}`, () => {
            const g = ctx.createLinearGradient(x, y, x, y + h);
            g.addColorStop(0, '#888');
            g.addColorStop(0.4, '#555');
            g.addColorStop(1, '#222');
            return g;
        });
        ctx.fillStyle = hGrad;
        this._roundRect(ctx, x, y, w, h, 8);
        ctx.fill();
        // 発光アウトライン
        ctx.strokeStyle = `rgba(255,${100 + (pulse * 155)|0},0,${0.8 + pulse * 0.2})`;
        ctx.lineWidth = 2.5;
        this._roundRect(ctx, x, y, w, h, 8);
        ctx.stroke();
        // メタルのエッジハイライト
        ctx.strokeStyle = 'rgba(255,255,255,0.25)';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(x + 4, y + 4); ctx.lineTo(x + w - 4, y + 4); ctx.stroke();

        // === コアオーブ（クリスタル風）===
        ctx.save();
        ctx.translate(cx, cy);
        const coreGrad = _getCachedGradient(ctx, `ec_core2_${w|0}`, () => {
            const g = ctx.createRadialGradient(-w*0.1, -w*0.1, 0, 0, 0, w * 0.38);
            g.addColorStop(0, '#FFFDE0');
            g.addColorStop(0.25, '#FFD040');
            g.addColorStop(0.6, '#FF6600');
            g.addColorStop(0.85, '#CC2200');
            g.addColorStop(1, '#550000');
            return g;
        });
        ctx.fillStyle = coreGrad;
        ctx.beginPath(); ctx.arc(0, 0, w * 0.38, 0, Math.PI * 2); ctx.fill();
        // 十字ハイライト光線
        ctx.save();
        ctx.globalAlpha = pulse * 0.7;
        ctx.strokeStyle = 'rgba(255,220,80,0.9)';
        ctx.lineWidth = 1.5;
        ctx.lineCap = 'round';
        for (let a = 0; a < 4; a++) {
            ctx.save();
            ctx.rotate(a * Math.PI / 2 + t * 0.001);
            ctx.beginPath(); ctx.moveTo(0, -w * 0.38); ctx.lineTo(0, -w * 0.65); ctx.stroke();
            ctx.restore();
        }
        ctx.restore();
        // 鏡面ハイライト
        ctx.fillStyle = 'rgba(255,255,255,0.55)';
        ctx.beginPath(); ctx.ellipse(-w*0.1, -w*0.12, w*0.12, w*0.07, -0.5, 0, Math.PI * 2); ctx.fill();
        ctx.restore();

        // === HP バー（強化版）===
        const barW = w + 14, barH = 8;
        const barX = x - 7, barY = y - 16;
        // 背景
        ctx.fillStyle = '#1A1A1A';
        this._roundRect(ctx, barX, barY, barW, barH, 4);
        ctx.fill();
        ctx.strokeStyle = '#444'; ctx.lineWidth = 1;
        this._roundRect(ctx, barX, barY, barW, barH, 4);
        ctx.stroke();
        // HP値
        const ratio = Math.max(0, hp / maxHp);
        const barColor = ratio > 0.5 ? CONFIG.COLORS.HP_GREEN : (ratio > 0.25 ? CONFIG.COLORS.HP_YELLOW : CONFIG.COLORS.HP_RED);
        const barGrad = ctx.createLinearGradient(barX, barY, barX, barY + barH);
        barGrad.addColorStop(0, barColor);
        barGrad.addColorStop(1, barColor.replace('#', '#66').slice(0, 7));
        ctx.fillStyle = barColor;
        this._roundRect(ctx, barX + 1, barY + 1, (barW - 2) * ratio, barH - 2, 3);
        ctx.fill();
        // ラベル
        ctx.font = 'bold 8px monospace';
        ctx.fillStyle = 'rgba(255,255,255,0.8)';
        ctx.textAlign = 'center';
        ctx.fillText('CORE', cx, barY - 2);

        ctx.restore();
    },

    // === PROJECTILE (3D with trail) ===
    drawProjectile(ctx, xOrProj, y, type, dir, angle = 0, scale = 1.0) {
        let x = xOrProj;
        let pY = y;
        let pType = type;
        let pDir = dir;
        let pAngle = angle;
        let pScale = scale;
        let pColor = '#FFF';
        let pVx = 0;

        // Polymorphic check: Is the second argument a projectile object or a coordinate?
        if (typeof xOrProj === 'object' && xOrProj !== null) {
            const p = xOrProj;
            x = p.x;
            pY = p.y;
            pType = p.type;
            pDir = p.dir || 1;
            pAngle = p.angle || 0;
            pScale = p.scale || 1.0;
            pColor = p.color || '#FFF';
            pVx = p.vx || 0;
        }

        const info = CONFIG.AMMO_TYPES[pType] || CONFIG.AMMO_TYPES.rock || { icon: '?' };

        // Validate pDir to prevent NaN errors
        if (!isFinite(pDir) || pDir === 0) {
            pDir = 1; // Default direction
        }

        ctx.save();
        ctx.translate(x, pY);
        ctx.rotate(pAngle);
        ctx.scale(pScale, pScale); // Apply level scaling

        // Logic merging from both versions
        if (pType === 'shuriken') {
            const rot = (_getFrameNow() * 0.03) * 0.5;
            ctx.rotate(rot);
            ctx.fillStyle = '#888';
            ctx.beginPath();
            for (let i = 0; i < 4; i++) {
                ctx.rotate(Math.PI / 2);
                ctx.moveTo(0, -8);
                ctx.lineTo(3, -2);
                ctx.lineTo(3, 2);
                ctx.lineTo(0, 8);
                ctx.lineTo(-3, 2);
                ctx.lineTo(-3, -2);
            }
            ctx.fill();
            // Hole
            ctx.fillStyle = '#333';
            ctx.beginPath(); ctx.arc(0, 0, 2, 0, Math.PI * 2); ctx.fill();

        } else if (pType === 'magic') {
            ctx.fillStyle = pColor || '#F0F';
            ctx.beginPath(); ctx.arc(0, 0, 6, 0, Math.PI * 2); ctx.fill();
            // Tail
            ctx.globalAlpha = 0.5;
            ctx.beginPath();
            ctx.moveTo(0, 6);
            ctx.lineTo(-pVx * 3, 0); // Note: may be 0 if using argument-based call
            ctx.lineTo(0, -6);
            ctx.fill();

        } else if (pType === 'player') {
            // Draw Player Slime flying!
            ctx.rotate(-pAngle); // Counter-rotate to keep slime upright? 
            // Actually, first version's restore() approach was cleaner.
            // ★バグ修正: slimeType='player' を渡してスキン体色を反映
            Renderer.drawSlime(ctx, -15, -15, 30, 30, CONFIG.COLORS.PLAYER, CONFIG.COLORS.PLAYER_DARK, pDir, _getFrameNow() * 0.01, 0, 'player');

        } else if (pType === 'fire') {
            // Fire Effect（軽量版：グラデーションなし）
            const size = 10;
            ctx.fillStyle = 'rgba(255,100,0,0.8)';
            ctx.beginPath(); ctx.arc(0, 0, size, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = 'rgba(255,210,50,0.9)';
            ctx.beginPath(); ctx.arc(0, 0, size * 0.55, 0, Math.PI * 2); ctx.fill();

        } else if (pType === 'ice') {
            // Ice Crystal（軽量版）
            ctx.fillStyle = '#E0F7FA';
            ctx.strokeStyle = '#4FC3F7';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(10, 0); ctx.lineTo(0, 8); ctx.lineTo(-10, 0); ctx.lineTo(0, -8);
            ctx.closePath();
            ctx.fill(); ctx.stroke();

        } else if (pType === 'thunder') {
            // Thunder（軽量版：ラインのみ）
            ctx.strokeStyle = '#FFEB3B';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-10, 0);
            ctx.lineTo(-5, -8); ctx.lineTo(0, 8); ctx.lineTo(5, -5); ctx.lineTo(10, 0);
            ctx.stroke();

        } else {
            // Standard Projectiles（軽量版：グラデーション廃止→ソリッドカラー）
            // トレイル
            ctx.fillStyle = 'rgba(255,140,0,0.28)';
            ctx.beginPath();
            ctx.ellipse(-pDir * 14, 0, 18, 5, 0, 0, Math.PI * 2);
            ctx.fill();
            // グロー（単色）
            ctx.fillStyle = 'rgba(255,190,80,0.22)';
            ctx.beginPath(); ctx.arc(0, 0, 11, 0, Math.PI * 2); ctx.fill();

            // Icon
            ctx.font = '14px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.fillText(info.icon, 0, 0);
        }

        ctx.restore();
    },

    // === SPLIT SCREEN BACKGROUND ===
    drawSplitBackground(ctx, w, h, stageData) {
        const splitY = h * 0.5; // Split at center (400px)

        // === UPPER SCREEN (Battle View) ===
        // === UPPER SCREEN (Battle View) ===
        // Sky
        let skyColors = ['#2A60A0', '#4A90D0', '#78B8E8', '#A8D8F8'];
        if (stageData && stageData.skyColors) skyColors = stageData.skyColors;

        // Theme Overrides for Sky if not set
        if (stageData && !stageData.skyColors) {
            if (stageData.theme === 'forest') skyColors = ['#1B5E20', '#2E7D32', '#43A047', '#66BB6A'];
            else if (stageData.theme === 'desert') skyColors = ['#E65100', '#F57C00', '#FF9800', '#FFB74D'];
            else if (stageData.theme === 'volcano') skyColors = ['#3E2723', '#5D4037', '#8D6E63', '#BCAAA4'];
        }

        // ★新ギミック②: スライム王Phase別背景色変化
        // ★バグ修正S: drawSplitBackground の引数に battle がないため ReferenceError になっていた
        // window.game?.battle 経由で安全に参照する
        const _bgBattle = window.game?.battle;
        if (_bgBattle && _bgBattle.isSlimeKingBoss) {
            if (_bgBattle.skInfiltrating) {
                // 潜り込み中：暗黒・金のノイズ感
                skyColors = ['#0a0000', '#1a0800', '#0a0000', '#200500'];
            } else if (_bgBattle.skPhase >= 3) {
                // Phase3：深紅×金（最終決戦）
                skyColors = ['#1a0000', '#3a0800', '#6a1000', '#1a0000'];
            } else if (_bgBattle.skPhase === 2) {
                // Phase2：濃い紫×炎（激怒形態）
                skyColors = ['#0f0020', '#2a0050', '#1a0040', '#3a0010'];
            }
            // Phase1はstages.jsのskyColorsそのまま（夜の黄金天空）
        }

        const skyGradKey = `sky_${skyColors.join(',')}_${splitY | 0}`;
        const skyGrad = _getCachedGradient(ctx, skyGradKey, () => {
            const g = ctx.createLinearGradient(0, 0, 0, splitY);
            g.addColorStop(0, skyColors[0]);
            g.addColorStop(0.5, skyColors[1]);
            g.addColorStop(1, skyColors[3]);
            return g;
        });
        ctx.fillStyle = skyGrad;
        ctx.fillRect(0, 0, w, splitY);

        // Clouds (Upper) - 3フレームおきに更新（さらなる軽量化）
        const t = _getFrameNow() * 0.005;
        if (_frameNow % 3 !== 0 && this._cloudCache && this._cloudCache.width === w) {
            ctx.drawImage(this._cloudCache, 0, 0);
        } else {
            if (!this._cloudCache || this._cloudCache.width !== w) {
                try {
                    this._cloudCache = document.createElement('canvas');
                    this._cloudCache.width = w; this._cloudCache.height = 120;
                } catch(e) { this._cloudCache = null; }
            }
            if (this._cloudCache && typeof this._cloudCache.getContext === 'function') {
                const cc = this._cloudCache.getContext('2d');
                if (cc) {
                    cc.clearRect(0, 0, w, 120);
                    for (let i = 0; i < 2; i++) {
                        const cx = ((t * 20 + i * 280) % (w + 200)) - 100;
                        const cy = 40 + i * 50 + Math.sin(i * 1.5) * 10;
                        this._draw3DCloud(cc, cx, cy, 28 + i * 6);
                    }
                    ctx.drawImage(this._cloudCache, 0, 0);
                }
            }
        }

        // Background Landscape (Themed) - 静的部分はオフスクリーンキャッシュで高速化
        const theme = stageData ? stageData.theme : 'default';
        const bgKey = `landscape_${theme}_${w}_${splitY | 0}`;
        const bgCanvas = _getCachedBg(bgKey, w, splitY, (bctx) => {
            this._drawLandscape(bctx, w, splitY, theme);
        });
        if (bgCanvas) ctx.drawImage(bgCanvas, 0, 0);

        // Ground (Upper)
        const gndY = splitY - 40;

        let groundColor = '#5A8A2A'; // Grass
        if (stageData) {
            if (stageData.theme === 'desert') groundColor = '#FDD835'; // Sand
            else if (stageData.theme === 'volcano') groundColor = '#3E2723'; // Dark Rock
            else if (stageData.theme === 'forest') groundColor = '#1B5E20'; // Dark Grass
        }

        ctx.fillStyle = groundColor;
        ctx.beginPath();
        ctx.moveTo(0, gndY);
        ctx.bezierCurveTo(w * 0.3, gndY - 10, w * 0.7, gndY + 10, w, gndY);
        ctx.lineTo(w, splitY); ctx.lineTo(0, splitY);
        ctx.fill();

        // === LOWER SCREEN (Interior View) ===
        // 🚀 改善: 下画面の背景を塗りつぶし（上画面の風景が透けるバグを完全に修正）
        ctx.fillStyle = '#222'; // ベースとなる暗い色
        ctx.fillRect(0, splitY, w, h - splitY);

        // Depth/Perimeter Walls
        const wt = CONFIG.TANK.WALL_THICKNESS;
        const ox = CONFIG.TANK.OFFSET_X;
        const oy = CONFIG.TANK.OFFSET_Y + wt + 20;
        const iw = CONFIG.TANK.INTERIOR_W;
        const ih = CONFIG.TANK.INTERIOR_H - 40;

        // Draw side wall thickness for perspective
        ctx.fillStyle = '#A17A4B';
        ctx.fillRect(ox, oy, wt, ih); // Left wall depth
        ctx.fillRect(ox + iw - wt, oy, wt, ih); // Right wall depth

        // Inner wall shading
        const wallGrad = _getCachedGradient(ctx, `wall_${ox}_${oy}`, () => {
            const g = ctx.createLinearGradient(ox, oy, ox, oy + 25);
            g.addColorStop(0, 'rgba(0,0,0,0.3)');
            g.addColorStop(1, 'rgba(0,0,0,0)');
            return g;
        });
        ctx.fillStyle = wallGrad;
        ctx.fillRect(ox + wt, oy, iw - wt * 2, 25);

        // Screen Divider / HUD Border
        ctx.fillStyle = '#111';
        ctx.fillRect(0, splitY - 6, w, 12);
        ctx.fillStyle = '#FFF';
        ctx.fillRect(0, splitY - 1, w, 2);
    },

    // Landscape decoration for upper screen
    _drawLandscape(ctx, w, h, theme) {
        const groundY = h - 40;

        if (theme === 'desert') {
            // DESERT THEME
            // Pyramids
            ctx.fillStyle = '#D4AF37'; // Dull Gold
            ctx.beginPath(); ctx.moveTo(w * 0.2, groundY); ctx.lineTo(w * 0.3, groundY - 100); ctx.lineTo(w * 0.4, groundY); ctx.fill();
            ctx.fillStyle = '#C49F27'; // Shadow side
            ctx.beginPath(); ctx.moveTo(w * 0.3, groundY - 100); ctx.lineTo(w * 0.3, groundY); ctx.lineTo(w * 0.4, groundY); ctx.fill();

            ctx.fillStyle = '#D4AF37';
            ctx.beginPath(); ctx.moveTo(w * 0.7, groundY); ctx.lineTo(w * 0.8, groundY - 150); ctx.lineTo(w * 0.9, groundY); ctx.fill();
            ctx.fillStyle = '#C49F27';
            ctx.beginPath(); ctx.moveTo(w * 0.8, groundY - 150); ctx.lineTo(w * 0.8, groundY); ctx.lineTo(w * 0.9, groundY); ctx.fill();

            // Sun (Big Hot Sun)
            const sunG = ctx.createRadialGradient(w * 0.5, 80, 0, w * 0.5, 80, 60);
            sunG.addColorStop(0, 'rgba(255, 255, 200, 0.9)');
            sunG.addColorStop(1, 'rgba(255, 100, 0, 0)');
            ctx.fillStyle = sunG;
            ctx.beginPath(); ctx.arc(w * 0.5, 80, 60, 0, Math.PI * 2); ctx.fill();

            // Cacti
            ctx.fillStyle = '#2E7D32';
            for (let i = 0; i < 5; i++) {
                const cx = (i * 150 + 50) % w;
                ctx.fillRect(cx, groundY - 40, 10, 40); // Trunk
                ctx.fillRect(cx - 10, groundY - 30, 10, 5); // Arm L
                ctx.fillRect(cx - 10, groundY - 40, 5, 15); // Arm L Up
                ctx.fillRect(cx + 10, groundY - 25, 10, 5); // Arm R
                ctx.fillRect(cx + 15, groundY - 35, 5, 15); // Arm R Up
            }

        } else if (theme === 'volcano') {
            // VOLCANO THEME
            // Dark Mountains
            ctx.fillStyle = '#212121';
            this._drawMountains(ctx, w, h);

            // Lava flow
            ctx.fillStyle = '#D50000';
            ctx.beginPath();
            ctx.moveTo(w * 0.5, groundY - 100); // peak
            ctx.quadraticCurveTo(w * 0.6, groundY - 50, w * 0.55, groundY);
            ctx.lineTo(w * 0.45, groundY);
            ctx.quadraticCurveTo(w * 0.4, groundY - 50, w * 0.5, groundY - 100);
            ctx.fill();

            // Ash particles usually handled by particle system, but draw some static smoke
            ctx.fillStyle = 'rgba(100, 100, 100, 0.5)';
            for (let i = 0; i < 5; i++) {
                this._draw3DCloud(ctx, w * 0.5 + (i - 2) * 30, groundY - 150 - i * 20, 20 + i * 5);
            }

        } else if (theme === 'forest') {
            // FOREST THEME
            // Deep forest background
            ctx.fillStyle = '#004D40'; // Deep Green
            this._drawMountains(ctx, w, h); // Use as hills

            // Lots of Trees (step 60 for performance)
            for (let i = 0; i < w; i += 60) {
                const th = 80 + Math.sin(i * 0.23) * 30 + Math.sin(i * 0.07 + 1.1) * 30;
                // Trunk
                ctx.fillStyle = '#3E2723';
                ctx.fillRect(i + 10, groundY - 20, 10, 20);
                // Leaves
                ctx.fillStyle = (i % 60 === 0) ? '#1B5E20' : '#2E7D32';
                ctx.beginPath();
                ctx.moveTo(i, groundY - 20);
                ctx.lineTo(i + 15, groundY - th);
                ctx.lineTo(i + 30, groundY - 20);
                ctx.fill();
            }

        } else {
            // DEFAULT (Castle/Grassy)
            // Distant Mountains
            ctx.fillStyle = '#1A3A5A';
            this._drawMountains(ctx, w, h);
            ctx.fillStyle = '#2A5A8A';
            this._drawMountains(ctx, w, h - 20);

            // Sun
            const sunG = ctx.createRadialGradient(w * 0.8, 60, 0, w * 0.8, 60, 50);
            sunG.addColorStop(0, 'rgba(255, 255, 200, 0.8)');
            sunG.addColorStop(0.5, 'rgba(255, 255, 100, 0.2)');
            sunG.addColorStop(1, 'rgba(255, 255, 100, 0)');
            ctx.fillStyle = sunG;
            ctx.beginPath(); ctx.arc(w * 0.8, 60, 50, 0, Math.PI * 2); ctx.fill();

            // ★バグ修正: 左下の青い城オブジェクト（プレイヤー戦車と重なり「青い置物」に見えていた）を削除
        }
    },

    // Upper screen battle visualization
    drawUpperBattle(ctx, w, h, battle, state) {
        const splitY = h * 0.5;
        const groundY = splitY - 20;

        // Player Tank (Left, huge)
        // Adjusted for battle movement
        const playerX = 10 + (battle.playerTankX || 0);
        const playerY = groundY - 260 + (battle.playerTankY || 0);
        const playerFlash = battle.dodgeTimer > 0 ? 30 : 0; // Visual flash for dodge
        this.drawTankExterior(ctx, playerX, playerY, 240, 280, false, playerFlash, false);

        // Enemy Tank (Right, huge)
        // Adjusted for battle movement
        // ★バグ修正: sizeMod が設定されているのに一切適用されていなかった
        //   BOSS=1.5倍 / TRUE_BOSS=1.6倍 のサイズ差が視覚的に反映されるよう修正
        const _enemyTypeInfo = (window.CONFIG && window.CONFIG.ENEMY.TYPES[battle.enemyTankType]) || {};
        const _sizeMod = _enemyTypeInfo.sizeMod || 1.0;
        const _baseEnemyW = 240, _baseEnemyH = 280;
        const _enemyW = Math.round(_baseEnemyW * _sizeMod);
        const _enemyH = Math.round(_baseEnemyH * _sizeMod);
        const enemyX = w - 250 - Math.round((_enemyW - _baseEnemyW) / 2) + (battle.enemyTankX || 0);
        const enemyY = groundY - _baseEnemyH - Math.round(_enemyH - _baseEnemyH) + (battle.enemyTankY || 0);
        const enemyFlash = (battle.enemyDamageFlash || 0) + (battle.enemyDodgeTimer > 0 ? 20 : 0);
        this.drawTankExterior(ctx, enemyX, enemyY, _enemyW, _enemyH, true, enemyFlash, false, battle.enemyTankType, battle);

        // === PROJECTILE VISUALIZATION (Corrected for Upper Screen) ===
        if (battle.projectiles) {
            for (const p of battle.projectiles) {
                if (!p.active) continue;

                // Case 1: Standard Arcing Projectile
                if (p.phase === 'flying' && p.totalTime) {
                    // Use progress (t) to interpolate between VISUAL tank positions
                    // This ensures shots look like they originate/land correctly regardless of logical coords
                    const t = Math.min(1, Math.max(0, p.timer / p.totalTime));

                    // Visual Start/End Points
                    let vsx, vsy, vtx, vty;

                    if (p.dir === 1) {
                        // Player -> Enemy
                        vsx = playerX + 180; // Cannon mouth approx
                        vsy = playerY + 120;
                        vtx = enemyX + 60;   // Enemy body hit
                        vty = enemyY + 140;
                    } else {
                        // Enemy -> Player
                        vsx = enemyX + 60;
                        vsy = enemyY + 140; // Enemy cannon approx
                        vtx = playerX + 100;
                        vty = playerY + 100;
                    }

                    // Linear X
                    const dx = vtx - vsx;
                    const vx = vsx + dx * t;

                    // Parabolic Y
                    const dy = vty - vsy;
                    const arcH = (p.arcHeight || 150) * 0.8; // Scale arc for visual
                    const linearY = vsy + dy * t;
                    const arcY = 4 * arcH * t * (1 - t);
                    const vy = linearY - arcY;

                    // Rotation (Angle)
                    const nextT = t + 0.05;
                    const nvx = vsx + dx * nextT;
                    const nlinearY = vsy + dy * nextT;
                    const narcY = 4 * arcH * nextT * (1 - nextT);
                    const nvy = nlinearY - narcY;
                    const vAngle = Math.atan2(nvy - vy, nvx - vx);

                    this.drawProjectile(ctx, vx, vy, p.type, p.dir, vAngle);
                }
                // Case 2: Simple/Ally Projectile (Linear)
                else if (p.vx !== undefined && p.vy !== undefined) {
                    // These exist in logical battle coordinates (e.g. Ally inside tank firing at Invader)
                    // BUT if they are "Ally Turret" projectiles (fired into battle.projectiles), 
                    // they are meant for the upper screen battle?
                    // Ally.js (Stacked) pushes to window.game.battle.projectiles.
                    // Let's assume their x/y are logical tank coords.
                    // Wait, Ally Turret logic: x,y are relative to Ally position in TANK INTERIOR.
                    // But they are battling an INVADER in the interior logic?
                    // OR are they firing at the enemy tank outside?

                    // Re-reading Ally.js:
                    // If stacked on gunner, it fires 'bullet' with simple velocity.
                    // If target is invader, it shoots at invader (Interior).

                    // IF the user says "Ally projectile disappear on collision with enemy projectile",
                    // they mean the upper screen battle interception mechanics.
                    // The standard game doesn't seem to have "Ally firing at Enemy Tank" logic 
                    // other than loading the cannon (which creates a standard Projectile).

                    // Maybe the user is referring to the "Ally Missile" special move?
                    // Or maybe the user THINKS the allies shooting at invaders should appear on top?
                    // No, "enemy ball" implies enemy tank shells.

                    // User said: "Ally ball disappears when hitting enemy ball? And ally ball not visible on upper screen?"
                    // This implies the player is firing CANNONS loaded by allies, or Allies are firing SOMETHING into the upper screen.

                    // If allies load cannons, they trigger `playerFire(type)` in `battle.js`.
                    // This creates a standard `Projectile` with `isPlayer=true` (implicitly, dir=1).
                    // This uses Case 1 logic above. Standard projectiles ARE visible.

                    // So why "not visible"? 
                    // Maybe the projectile type is not handled in `drawProjectile`?
                    // Or maybe `playerFire` isn't setting `active` or `phase` correctly?
                    // `Projectile` constructor sets `active=true`, `phase='flying'`.

                    // Let's look at `SimpleProjectile` usage again.
                    // Search results might show where it's used.
                    // If `SimpleProjectile` is used for "Ally Turret" (gunner/defender) shooting at INVADERS,
                    // those are INTERIOR projectiles. They should NOT be on the upper screen.

                    // However, if the user sees "Ally ball" blocking "Enemy ball", they might mean
                    // PLAYER PROJECTILES (rocks) blocking ENEMY PROJECTILES (rocks).
                    // And they say "Ally ball" -> maybe they mean projectiles loaded by allies?

                    // Let's assume standard interaction:
                    // Player/Ally loads cannon -> Projectile fired -> Visible on upper screen -> Can collide with enemy projectile.

                    // Logic for collision is in proper `battle.js`.

                    // If "Ally projectile not visible", maybe they mean the SPECIAL ALLY MISSILE?
                    // `launchAllyMissile` in `battle.js`?
                    // Let's check `battle.js` for `launchAllyMissile`.

                }
            }
        }

        // === STATUS EFFECTS（軽量版：ループ数・fillRect化で負荷削減）===
        // Fire Effect (Burn) - 5ループ→3に削減
        if (battle.fireEffect > 0) {
            const t = _getFrameNow() * 0.01;
            ctx.save();
            for (let i = 0; i < 3; i++) {
                const fx = enemyX + 90 + Math.cos(t * 1.3 + i * 2.1) * 55;
                const fy = enemyY + 175 + Math.sin(t * 1.7 + i * 1.5) * 45;
                const size = 28 + Math.sin(t + i) * 8;
                ctx.fillStyle = i % 2 === 0 ? 'rgba(255,120,0,0.42)' : 'rgba(255,60,0,0.38)';
                ctx.beginPath(); ctx.arc(fx, fy, size, 0, Math.PI * 2); ctx.fill();
            }
            ctx.restore();
        }
        // Ice Effect (Freeze) - 単純fillRect
        if (battle.iceEffect > 0) {
            ctx.save();
            ctx.fillStyle = 'rgba(100,220,255,0.28)';
            ctx.fillRect(enemyX + 20, enemyY + 20, 200, 240);
            ctx.strokeStyle = 'rgba(200,240,255,0.5)';
            ctx.lineWidth = 2;
            ctx.strokeRect(enemyX + 20, enemyY + 20, 200, 240);
            ctx.restore();
        }
        // Thunder Flash
        if (battle.thunderFlash > 0) {
            ctx.save();
            ctx.fillStyle = `rgba(255,255,200,${battle.thunderFlash * 0.08})`;
            ctx.fillRect(enemyX - 50, enemyY - 50, 340, 380);
            ctx.restore();
        }
        // Wind Effect - 4ループ→2に削減
        if (battle.windEffect > 0) {
            const t = _getFrameNow() * 0.015;
            ctx.save();
            for (let i = 0; i < 2; i++) {
                const wx = enemyX + 50 + Math.cos(t * 2.1 + i * 3.14) * 65;
                const wy = enemyY + 110 + Math.sin(t * 1.8 + i * 3.14) * 50;
                ctx.strokeStyle = `rgba(130,200,130,${0.32 + Math.sin(t + i) * 0.12})`;
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.moveTo(wx - 18, wy);
                ctx.bezierCurveTo(wx, wy - 12, wx + 10, wy - 7, wx + 18, wy);
                ctx.stroke();
            }
            ctx.restore();
        }
        // Burn DoT Effect - 4ループ→2に削減
        if (battle.burnEffect > 0) {
            const t = _getFrameNow() * 0.012;
            ctx.save();
            for (let i = 0; i < 2; i++) {
                const bx = enemyX + 70 + Math.cos(t * 1.6 + i * 3.14) * 50;
                const by = enemyY + 165 + Math.sin(t * 2.0 + i * 2.0) * 35;
                const sz = 16 + Math.sin(t * 2 + i) * 5;
                ctx.fillStyle = `rgba(255,150,0,0.38)`;
                ctx.beginPath(); ctx.arc(bx, by, sz, 0, Math.PI * 2); ctx.fill();
            }
            ctx.restore();
        }

        // ===== プレイヤー砲口フラッシュ（発砲時）軽量版 =====
        if (battle.playerMuzzleFlash > 0) {
            const pmAlpha = battle.playerMuzzleFlash / 8;
            const pmfX = playerX + 185;
            const pmfY = playerY + 130;
            // カスタムエフェクト色
            const _efxCustom = window.game && window.game.saveData && window.game.saveData.tankCustom;
            const _efxId = (_efxCustom && _efxCustom.effect) || 'effect_normal';
            const _efxParts = window.TANK_PARTS && window.TANK_PARTS.effects;
            const _efxDef = _efxParts && _efxParts.find(e => e.id === _efxId);
            const efxColor = (_efxDef && _efxDef.color) || '#AADDFF';
            ctx.save();
            // エフェクト種別ごとの特殊フラッシュ
            if (_efxId === 'effect_fire') {
                // 炎：大きめのオレンジ放射＋リング
                ctx.globalAlpha = pmAlpha * 0.9;
                const fgrad = ctx.createRadialGradient(pmfX, pmfY, 0, pmfX, pmfY, 60);
                fgrad.addColorStop(0, 'rgba(255,220,50,1)');
                fgrad.addColorStop(0.4, 'rgba(255,80,0,0.7)');
                fgrad.addColorStop(1, 'rgba(255,40,0,0)');
                ctx.fillStyle = fgrad;
                ctx.beginPath(); ctx.arc(pmfX, pmfY, 60, 0, Math.PI * 2); ctx.fill();
            } else if (_efxId === 'effect_ice') {
                // 氷：シャープな放射線＋青白いフラッシュ
                ctx.globalAlpha = pmAlpha * 0.85;
                ctx.fillStyle = 'rgba(150,230,255,0.7)';
                ctx.beginPath(); ctx.arc(pmfX, pmfY, 50, 0, Math.PI * 2); ctx.fill();
                ctx.strokeStyle = 'rgba(200,245,255,0.9)'; ctx.lineWidth = 2;
                for (let si = 0; si < 6; si++) {
                    const sa = (si / 6) * Math.PI * 2;
                    ctx.beginPath();
                    ctx.moveTo(pmfX + Math.cos(sa) * 10, pmfY + Math.sin(sa) * 10);
                    ctx.lineTo(pmfX + Math.cos(sa) * 55, pmfY + Math.sin(sa) * 55);
                    ctx.stroke();
                }
            } else if (_efxId === 'effect_thunder') {
                // 雷：ビリビリした放電フラッシュ
                ctx.globalAlpha = pmAlpha * 0.95;
                ctx.fillStyle = 'rgba(255,240,0,0.8)';
                ctx.beginPath(); ctx.arc(pmfX, pmfY, 48, 0, Math.PI * 2); ctx.fill();
                ctx.strokeStyle = 'rgba(255,255,150,1)'; ctx.lineWidth = 2.5;
                for (let li2 = 0; li2 < 5; li2++) {
                    const la = (li2 / 5) * Math.PI * 2;
                    const lx1 = pmfX + Math.cos(la) * 15, ly1 = pmfY + Math.sin(la) * 15;
                    const lx2 = pmfX + Math.cos(la + 0.3) * 35, ly2 = pmfY + Math.sin(la + 0.3) * 35;
                    const lx3 = pmfX + Math.cos(la) * 58, ly3 = pmfY + Math.sin(la) * 58;
                    ctx.beginPath(); ctx.moveTo(lx1, ly1); ctx.lineTo(lx2, ly2); ctx.lineTo(lx3, ly3); ctx.stroke();
                }
            } else if (_efxId === 'effect_holy') {
                // 聖光：十字の光芒＋白いリング
                ctx.globalAlpha = pmAlpha * 0.85;
                const hgrad = ctx.createRadialGradient(pmfX, pmfY, 0, pmfX, pmfY, 55);
                hgrad.addColorStop(0, 'rgba(255,255,230,1)');
                hgrad.addColorStop(1, 'rgba(255,255,200,0)');
                ctx.fillStyle = hgrad;
                ctx.beginPath(); ctx.arc(pmfX, pmfY, 55, 0, Math.PI * 2); ctx.fill();
                // 十字
                ctx.fillStyle = 'rgba(255,255,240,0.9)';
                ctx.fillRect(pmfX - 4, pmfY - 60, 8, 120);
                ctx.fillRect(pmfX - 60, pmfY - 4, 120, 8);
            } else if (_efxId === 'effect_dark') {
                // 暗黒：紫の波紋
                ctx.globalAlpha = pmAlpha * 0.9;
                const dgrad = ctx.createRadialGradient(pmfX, pmfY, 0, pmfX, pmfY, 58);
                dgrad.addColorStop(0, 'rgba(220,50,255,0.9)');
                dgrad.addColorStop(0.5, 'rgba(100,0,180,0.6)');
                dgrad.addColorStop(1, 'rgba(40,0,80,0)');
                ctx.fillStyle = dgrad;
                ctx.beginPath(); ctx.arc(pmfX, pmfY, 58, 0, Math.PI * 2); ctx.fill();
                // 波紋リング
                ctx.strokeStyle = 'rgba(200,100,255,0.7)'; ctx.lineWidth = 2;
                ctx.beginPath(); ctx.arc(pmfX, pmfY, 58 * pmAlpha, 0, Math.PI * 2); ctx.stroke();
            } else {
                // ノーマル（デフォルト）
                ctx.globalAlpha = pmAlpha * 0.85;
                ctx.fillStyle = efxColor;
                ctx.beginPath(); ctx.arc(pmfX, pmfY, 40, 0, Math.PI * 2); ctx.fill();
            }
            ctx.globalAlpha = pmAlpha;
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath(); ctx.arc(pmfX, pmfY, 12, 0, Math.PI * 2); ctx.fill();
            ctx.restore();
        }

        // ===== 敵砲口フラッシュ（発砲時）軽量版 =====
        if (battle.enemyMuzzleFlash > 0) {
            const mAlpha = battle.enemyMuzzleFlash / 8;
            const mfX = enemyX + 55;
            const mfY = enemyY + 130;
            ctx.save();
            ctx.globalAlpha = mAlpha * 0.85;
            ctx.fillStyle = '#FFAA44';
            ctx.beginPath(); ctx.arc(mfX, mfY, 44, 0, Math.PI * 2); ctx.fill();
            ctx.globalAlpha = mAlpha;
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath(); ctx.arc(mfX, mfY, 14, 0, Math.PI * 2); ctx.fill();
            ctx.restore();
        }

        // ===== 低HP時の危機演出: 画面四隅に赤いオーバーレイ（グラデなし・軽量）=====
        const playerHPRatio = battle.playerTankMaxHP > 0 ? battle.playerTankHP / battle.playerTankMaxHP : 1;
        if (playerHPRatio < 0.3) {
            const fn = _getFrameNow ? _getFrameNow() : 0;
            const dangerAlpha = (0.3 - playerHPRatio) / 0.3;
            // 10フレームに1回だけ点滅（Math.sin廃止）
            const blink = Math.floor(fn / 10) % 2 === 0;
            const pulseAlpha = dangerAlpha * (blink ? 0.18 : 0.08);
            ctx.save();
            ctx.globalAlpha = pulseAlpha;
            ctx.fillStyle = '#CC0000';
            // 四隅だけ塗る（fillRect全体より負荷が低い）
            const edgeW = w * 0.18, edgeH = h * 0.18;
            ctx.fillRect(0, 0, w, edgeH);           // 上
            ctx.fillRect(0, h - edgeH, w, edgeH);   // 下
            ctx.fillRect(0, edgeH, edgeW, h - edgeH * 2);  // 左
            ctx.fillRect(w - edgeW, edgeH, edgeW, h - edgeH * 2); // 右
            ctx.restore();
        }

        // ★バグ修正: スライム王「気配」ギミックの描画が完全に欠落していた
        // battle.js で座標・タイマー・当たり判定まで実装済みだが renderer に描画コードがなく
        // プレイヤーが視認不能 → 撃ち抜き不可能・HPが一方的に吸収されるだけになっていた
        if (battle.skKehaiActive && battle.skKehaiX && battle.skKehaiY) {
            const kx = battle.skKehaiX;
            const ky = battle.skKehaiY;
            const kt = battle.skKehaiTimer || 0;
            const pulse = 0.5 + 0.5 * Math.sin(fn * 0.25);
            const alpha = Math.min(1, kt / 30) * (0.7 + 0.3 * pulse);
            ctx.save();
            ctx.globalAlpha = alpha;
            // 外側の光輪
            const grad = ctx.createRadialGradient(kx, ky, 0, kx, ky, 28);
            grad.addColorStop(0,   'rgba(255,230,0,0.9)');
            grad.addColorStop(0.5, 'rgba(255,180,0,0.5)');
            grad.addColorStop(1,   'rgba(255,100,0,0)');
            ctx.fillStyle = grad;
            ctx.beginPath(); ctx.arc(kx, ky, 28, 0, Math.PI * 2); ctx.fill();
            // 中心の👑マーク
            ctx.globalAlpha = alpha * 0.95;
            ctx.font = 'bold 20px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillStyle = '#FFD700';
            ctx.fillText('👑', kx, ky);
            // 点滅リング（撃て！の合図）
            if (Math.floor(fn / 6) % 2 === 0) {
                ctx.globalAlpha = alpha * 0.6;
                ctx.strokeStyle = '#FFFF00';
                ctx.lineWidth = 2.5;
                ctx.beginPath(); ctx.arc(kx, ky, 32 + pulse * 6, 0, Math.PI * 2); ctx.stroke();
            }
            ctx.restore();
        }
    },

    drawBoss(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // Cape (Behind)
        ctx.fillStyle = '#C00';
        ctx.beginPath();
        ctx.moveTo(-10, 5);
        ctx.quadraticCurveTo(-20, 20, -15, 25);
        ctx.lineTo(15, 25);
        ctx.quadraticCurveTo(20, 20, 10, 5);
        ctx.fill();

        // Body (Big Slime)
        ctx.fillStyle = color; // Usually King Slime Blue or Metal
        ctx.beginPath();
        ctx.moveTo(-20, 20);
        ctx.quadraticCurveTo(-25, -20, 0, -20);
        ctx.quadraticCurveTo(25, -20, 20, 20);
        ctx.fill();

        // Crown (Ornate)
        ctx.fillStyle = '#FFD700';
        ctx.beginPath();
        ctx.moveTo(-12, -18);
        ctx.lineTo(-8, -30);
        ctx.lineTo(0, -22); // Middle Dip
        ctx.lineTo(8, -30);
        ctx.lineTo(12, -18);
        ctx.fill();
        // Jewels on Crown
        ctx.fillStyle = '#F00'; ctx.beginPath(); ctx.arc(0, -25, 2, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#0F0'; ctx.beginPath(); ctx.arc(-8, -24, 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#00F'; ctx.beginPath(); ctx.arc(8, -24, 1.5, 0, Math.PI * 2); ctx.fill();

        // Face (Slightly menacing / proud)
        ctx.fillStyle = '#FFF';
        ctx.beginPath(); ctx.arc(6, -6, 5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(-6, -6, 5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#000';
        ctx.beginPath(); ctx.arc(7, -6, 2, 0, Math.PI * 2); ctx.fill(); // Looking side
        ctx.beginPath(); ctx.arc(-5, -6, 2, 0, Math.PI * 2); ctx.fill();

        // Moustache / Cheek (King feel)
        ctx.strokeStyle = 'rgba(0,0,0,0.2)';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(10, 2, 3, 0, Math.PI); ctx.stroke();
        ctx.beginPath(); ctx.arc(-10, 2, 3, 0, Math.PI); ctx.stroke();

        ctx.restore();
    },

    drawNinja(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // Body (Dark Suit)
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.ellipse(0, 0, w * 0.4, h * 0.4, 0, 0, Math.PI * 2);
        ctx.fill();

        // Scarf (Fluttering)
        ctx.fillStyle = '#D32F2F'; // Red Scarf
        ctx.beginPath();
        const flutter = Math.sin(frame * 0.2) * 5;
        ctx.moveTo(-10, 5);
        ctx.quadraticCurveTo(-20, 10 + flutter, -30, 5 + flutter);
        ctx.lineTo(-25, 0 + flutter);
        ctx.fill();

        // Eyes (Sharp)
        ctx.fillStyle = '#FFEB3B';
        ctx.beginPath();
        ctx.moveTo(5, -5); ctx.lineTo(15, -8); ctx.lineTo(15, -2); ctx.fill();

        // Headband
        ctx.fillStyle = '#EEE';
        ctx.fillRect(-12, -15, 24, 4);

        ctx.restore();
    },

    // ハンゾー: 忍者ベース + 白い仮面マーク + 青い鉢巻
    drawNinjaHanzo(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        // Body（濃い紺色）
        ctx.fillStyle = '#1A237E';
        ctx.beginPath();
        ctx.ellipse(0, 0, w * 0.4, h * 0.4, 0, 0, Math.PI * 2);
        ctx.fill();
        // 青い鉢巻
        ctx.fillStyle = '#1565C0';
        ctx.fillRect(-12, -15, 24, 5);
        // 白い仮面（目の部分）
        ctx.fillStyle = 'rgba(255,255,255,0.85)';
        ctx.beginPath();
        ctx.ellipse(0, -2, w * 0.25, h * 0.12, 0, 0, Math.PI * 2);
        ctx.fill();
        // 目（赤）
        ctx.fillStyle = '#EF5350';
        ctx.beginPath();
        ctx.ellipse(-5, -2, 3, 3, 0, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath();
        ctx.ellipse(5, -2, 3, 3, 0, 0, Math.PI * 2); ctx.fill();
        // 青スカーフ
        ctx.fillStyle = '#1565C0';
        ctx.beginPath();
        const fl = Math.sin(frame * 0.2) * 5;
        ctx.moveTo(-10, 5);
        ctx.quadraticCurveTo(-20, 10 + fl, -30, 5 + fl);
        ctx.lineTo(-25, 0 + fl); ctx.fill();
        ctx.restore();
    },

    // マーマン: 忍者ベース + 水色 + ヒレ
    drawNinjaMerman(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        // Body（水色）
        ctx.fillStyle = '#00838F';
        ctx.beginPath();
        ctx.ellipse(0, 0, w * 0.4, h * 0.4, 0, 0, Math.PI * 2);
        ctx.fill();
        // 背びれ
        ctx.fillStyle = '#006064';
        ctx.beginPath();
        ctx.moveTo(0, -h * 0.4);
        ctx.lineTo(-6, -h * 0.65 - Math.sin(frame * 0.15) * 4);
        ctx.lineTo(6, -h * 0.65 - Math.sin(frame * 0.15) * 4);
        ctx.closePath(); ctx.fill();
        // 目（黄緑）
        ctx.fillStyle = '#AEEA00';
        ctx.beginPath();
        ctx.ellipse(-6, -4, 4, 4, 0, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath();
        ctx.ellipse(6, -4, 4, 4, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#000';
        ctx.beginPath();
        ctx.ellipse(-6, -4, 2, 2, 0, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath();
        ctx.ellipse(6, -4, 2, 2, 0, 0, Math.PI * 2); ctx.fill();
        // 水飛沫スカーフ
        ctx.fillStyle = 'rgba(0,188,212,0.7)';
        ctx.beginPath();
        const fl2 = Math.sin(frame * 0.25) * 6;
        ctx.moveTo(-8, 5);
        ctx.quadraticCurveTo(-20, 8 + fl2, -28, 3 + fl2);
        ctx.lineTo(-22, -1 + fl2); ctx.fill();
        ctx.restore();
    },

    drawDragon(ctx, x, y, w, h, color, dir, frame) {
        // drawSlime の dragon ブランチと完全統一（戦闘画面と同じ見た目）
        this.drawSlime(ctx, x, y, w, h, color, '#8B0000', dir, frame, 0, 'dragon');
    },

    drawGhost(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.globalAlpha = 0.6;
        this.drawSlime(ctx, x, y, w, h, '#F5F5F5', '#999', dir, frame + Math.sin(frame * 0.1) * 5, 0);
        ctx.translate(x + w / 2, y + h);
        ctx.scale(dir, 1);
        // Tail
        ctx.fillStyle = '#F5F5F5';
        ctx.beginPath();
        ctx.moveTo(-15, -10);
        ctx.quadraticCurveTo(0, 20 + Math.sin(frame * 0.1) * 10, 20, 10);
        ctx.lineTo(10, -5);
        ctx.fill();
        ctx.restore();
    },

    // どろろん改: ゴーストベース + 紫がかった色 + 黒いオーラ
    drawGhostKai(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.globalAlpha = 0.75;
        // 本体は紫がかった暗い色
        this.drawSlime(ctx, x, y, w, h, '#7B1FA2', '#4A148C', dir, frame + Math.sin(frame * 0.1) * 5, 0);
        ctx.translate(x + w / 2, y + h);
        ctx.scale(dir, 1);
        // 尻尾（紫）
        ctx.fillStyle = '#9C27B0';
        ctx.beginPath();
        ctx.moveTo(-15, -10);
        ctx.quadraticCurveTo(0, 22 + Math.sin(frame * 0.12) * 12, 20, 10);
        ctx.lineTo(10, -5); ctx.fill();
        // オーラ（黒い粒子的な演出）
        ctx.globalAlpha = 0.4;
        ctx.fillStyle = '#212121';
        for (let i = 0; i < 4; i++) {
            const angle = frame * 0.07 + i * Math.PI / 2;
            ctx.beginPath();
            ctx.arc(Math.cos(angle) * 18, -8 + Math.sin(angle) * 10, 4, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();
    },

    drawMetalking(ctx, x, y, w, h, color, dir, frame) {
        this.drawSlime(ctx, x, y, w * 1.2, h * 1.2, '#B0BEC5', '#546E7A', dir, frame, 0);
        ctx.save();
        ctx.translate(x + (w * 1.2) / 2, y + (h * 1.2) / 2);
        ctx.scale(dir, 1);
        // Large Crown
        ctx.fillStyle = '#FFD700';
        ctx.beginPath();
        ctx.moveTo(-20, -35);
        ctx.lineTo(-25, -55); ctx.lineTo(-10, -45); ctx.lineTo(0, -65);
        ctx.lineTo(10, -45); ctx.lineTo(25, -55); ctx.lineTo(20, -35);
        ctx.closePath(); ctx.fill();
        ctx.restore();
    },

    // メタキン (metalking_ex): クロームキングより輝かしい金+銀の王
    drawMetalkingEx(ctx, x, y, w, h, color, dir, frame) {
        // 本体：金色ベース
        this.drawSlime(ctx, x, y, w * 1.25, h * 1.25, '#FFD700', '#E65100', dir, frame, 0);
        ctx.save();
        ctx.translate(x + (w * 1.25) / 2, y + (h * 1.25) / 2);
        ctx.scale(dir, 1);
        // 豪華な二重王冠
        ctx.fillStyle = '#FFD700';
        ctx.beginPath();
        ctx.moveTo(-22, -37);
        ctx.lineTo(-28, -60); ctx.lineTo(-12, -47); ctx.lineTo(0, -70);
        ctx.lineTo(12, -47); ctx.lineTo(28, -60); ctx.lineTo(22, -37);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#E65100'; ctx.lineWidth = 2; ctx.stroke();
        // 宝石（赤）
        ctx.fillStyle = '#E53935';
        ctx.beginPath(); ctx.arc(0, -50, 5, 0, Math.PI * 2); ctx.fill();
        // キラキラ（回転）
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        const a = frame * 0.1;
        ctx.beginPath(); ctx.arc(Math.cos(a) * 20, Math.sin(a) * 10 - 10, 3, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
    },

    drawHealer(ctx, x, y, w, h, color, dir, frame) {
        const floatY = Math.sin(frame * 0.15) * 8;
        this.drawSlime(ctx, x, y + floatY, w * 0.8, h * 0.8, '#42A5F5', '#0D47A1', dir, frame, 0);
        ctx.save();
        ctx.translate(x + w / 2, y + h + floatY);
        ctx.scale(dir, 1);
        // Tentacles
        ctx.fillStyle = '#FFCCBC';
        for (let i = -2; i <= 2; i++) {
            const tx = i * 8;
            const ty = 5 + Math.sin(frame * 0.2 + i) * 5;
            ctx.beginPath();
            ctx.ellipse(tx, ty, 4, 15, Math.sin(frame * 0.1 + i) * 0.2, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();
    },

    // リカバリス (healer_recov): ヒーラーベース + ピンク + 十字マーク
    drawHealerRecov(ctx, x, y, w, h, color, dir, frame) {
        const floatY = Math.sin(frame * 0.15) * 8;
        // ピンク系の本体
        this.drawSlime(ctx, x, y + floatY, w * 0.8, h * 0.8, '#EC407A', '#880E4F', dir, frame, 0);
        ctx.save();
        ctx.translate(x + w / 2, y + h + floatY);
        ctx.scale(dir, 1);
        // 触手（ピンク）
        ctx.fillStyle = '#F48FB1';
        for (let i = -2; i <= 2; i++) {
            const tx = i * 8;
            const ty = 5 + Math.sin(frame * 0.2 + i) * 5;
            ctx.beginPath();
            ctx.ellipse(tx, ty, 4, 15, Math.sin(frame * 0.1 + i) * 0.2, 0, Math.PI * 2);
            ctx.fill();
        }
        // 十字マーク（ヒール能力の強調）
        ctx.fillStyle = '#FFF';
        ctx.fillRect(-3, -h * 0.8 - 12, 6, 16);
        ctx.fillRect(-8, -h * 0.8 - 7, 16, 6);
        ctx.restore();
    },

    drawWizard(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // Body (Robe)
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.moveTo(0, -h * 0.4);
        ctx.lineTo(w * 0.4, h * 0.5);
        ctx.lineTo(-w * 0.4, h * 0.5);
        ctx.fill();

        // Hat (Pointy)
        ctx.fillStyle = '#4A148C'; // Dark Purple
        ctx.beginPath();
        ctx.moveTo(-15, -10);
        ctx.lineTo(15, -10);
        const tipSway = Math.sin(frame * 0.1) * 5;
        ctx.lineTo(tipSway, -45);
        ctx.fill();
        // Hat Brim
        ctx.beginPath(); ctx.ellipse(0, -10, 20, 5, 0, 0, Math.PI * 2); ctx.fill();

        // Eyes
        ctx.fillStyle = '#FFF';
        ctx.beginPath(); ctx.arc(5, 0, 3, 0, Math.PI * 2); ctx.fill();

        ctx.restore();
    },

    drawAngel(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // Wings (Fluttering)
        const wingY = Math.sin(frame * 0.2) * 5;
        ctx.fillStyle = '#FFF';
        ctx.beginPath();
        ctx.ellipse(-20, -10 + wingY, 15, 8, -0.2, 0, Math.PI * 2); // Back wing
        ctx.fill();
        ctx.beginPath();
        ctx.ellipse(20, -10 + wingY, 15, 8, 0.2, 0, Math.PI * 2); // Front wing
        ctx.fill();

        // Body (Glowing)

        ctx.fillStyle = color;
        ctx.beginPath(); ctx.arc(0, 0, w * 0.35, 0, Math.PI * 2); ctx.fill();

        // Halo
        ctx.strokeStyle = '#FFD700';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(0, -25 + wingY * 0.5, 12, 4, 0, 0, Math.PI * 2);
        ctx.stroke();

        // Face (Peaceful)
        ctx.fillStyle = '#333';
        ctx.font = '10px Arial';
        ctx.fillText('^ ^', -6, 2);

        ctx.restore();
    },

    // レジェンドスライム専用（angel_legendタイプ）: 金色・大きな翼・星の輝き
    drawAngelLegend(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        const sz = Math.min(w, h) * 0.42;
        const wingY = Math.sin(frame * 0.15) * 6;
        const hue = (frame * 3) % 360;

        // 外側オーラリング
        ctx.strokeStyle = `hsla(${hue}, 100%, 70%, 0.4)`;
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(0, 0, sz * 1.5, 0, Math.PI * 2); ctx.stroke();

        // 大きな金の翼（4枚）
        ctx.fillStyle = 'rgba(255,215,0,0.85)';
        for (let i = -1; i <= 1; i += 2) {
            ctx.beginPath();
            ctx.ellipse(i * sz * 1.1, -sz * 0.2 + wingY, sz * 0.55, sz * 0.22, i * 0.35, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
            ctx.ellipse(i * sz * 0.8, -sz * 0.6 + wingY * 0.7, sz * 0.4, sz * 0.16, i * 0.5, 0, Math.PI * 2);
            ctx.fill();
        }

        // ボディ（輝く金色）
        const bodyGrad = ctx.createRadialGradient(-sz * 0.2, -sz * 0.3, 0, 0, 0, sz);
        bodyGrad.addColorStop(0, '#FFF9C4');
        bodyGrad.addColorStop(0.5, '#FFD700');
        bodyGrad.addColorStop(1, '#FF8F00');
        ctx.fillStyle = bodyGrad;
        ctx.beginPath(); ctx.arc(0, 0, sz, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#FFA000';
        ctx.lineWidth = 2;
        ctx.stroke();

        // 虹色ハロー（二重リング）
        ctx.strokeStyle = `hsl(${hue}, 100%, 65%)`;
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.ellipse(0, -sz * 1.4 + wingY * 0.4, sz * 0.4, sz * 0.12, 0, 0, Math.PI * 2); ctx.stroke();
        ctx.strokeStyle = `hsl(${(hue + 120) % 360}, 100%, 75%)`;
        ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.ellipse(0, -sz * 1.4 + wingY * 0.4, sz * 0.3, sz * 0.08, 0, 0, Math.PI * 2); ctx.stroke();

        // 星のきらめき
        if (frame % 20 < 10) {
            ctx.fillStyle = '#FFF';
            for (const [sx, sy] of [[sz * 1.3, -sz * 0.8], [-sz * 1.2, -sz * 0.5], [sz * 0.9, sz * 0.7]]) {
                ctx.beginPath(); ctx.arc(sx, sy, 3, 0, Math.PI * 2); ctx.fill();
            }
        }

        // 顔（大きな丸い目）
        const eyeR = sz * 0.22;
        const eyeX = sz * 0.35;
        const eyeY = sz * 0.05;
        ctx.fillStyle = '#FFF';
        ctx.beginPath(); ctx.arc(-eyeX, eyeY, eyeR, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(eyeX, eyeY, eyeR, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#1A1A2E';
        ctx.beginPath(); ctx.arc(-eyeX, eyeY, eyeR * 0.6, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(eyeX, eyeY, eyeR * 0.6, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#FFF';
        ctx.beginPath(); ctx.arc(-eyeX - eyeR * 0.18, eyeY - eyeR * 0.2, eyeR * 0.25, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(eyeX - eyeR * 0.18, eyeY - eyeR * 0.2, eyeR * 0.25, 0, Math.PI * 2); ctx.fill();
        // 笑顔
        ctx.strokeStyle = '#7B3F00';
        ctx.lineWidth = 1.8;
        ctx.beginPath(); ctx.arc(0, eyeY + sz * 0.2, sz * 0.2, 0.2, Math.PI - 0.2); ctx.stroke();

        ctx.restore();
    },

    drawDefender(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // Body (Spiky but heavier)
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(0, 0, w / 2 - 2, 0, Math.PI * 2);
        ctx.fill();

        // Armor Plate
        ctx.fillStyle = '#555';
        ctx.beginPath();
        ctx.arc(0, 0, w / 2 - 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#333';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Helmet
        ctx.fillStyle = '#222';
        ctx.beginPath();
        ctx.arc(0, -5, w / 2, Math.PI, 0);
        ctx.fill();
        ctx.fillStyle = '#EEE'; // Spike center
        ctx.beginPath(); ctx.moveTo(0, -w / 2); ctx.lineTo(-4, -w / 2 - 10); ctx.lineTo(4, -w / 2 - 10); ctx.fill();

        // Eyes (Visor look)
        ctx.fillStyle = '#000';
        ctx.fillRect(-10, -5, 20, 6);
        ctx.fillStyle = '#FFEB3B'; // Glowing eye slit
        ctx.fillRect(-8, -3, 16, 2);

        // Shield (Held in front)
        ctx.fillStyle = '#CCC';
        ctx.strokeStyle = '#888';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.rect(5, 0, 15, 20);
        ctx.restore();
    },

    // ゴーレムA (defender_golem): ディフェンダーベース + 石造り感 + 緑の目
    drawDefenderGolem(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        // 本体（石色）
        ctx.fillStyle = '#78909C';
        ctx.beginPath();
        ctx.arc(0, 0, w / 2 - 2, 0, Math.PI * 2); ctx.fill();
        // 石の質感（ひび割れ）
        ctx.strokeStyle = '#546E7A'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(-8, -10); ctx.lineTo(-3, 0); ctx.lineTo(-8, 8); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(5, -8); ctx.lineTo(2, 2); ctx.stroke();
        // 兜（角付き）
        ctx.fillStyle = '#455A64';
        ctx.beginPath();
        ctx.arc(0, -5, w / 2, Math.PI, 0); ctx.fill();
        // 角
        ctx.fillStyle = '#37474F';
        ctx.beginPath(); ctx.moveTo(-12, -w/2+2); ctx.lineTo(-18, -w/2-14); ctx.lineTo(-6, -w/2-2); ctx.fill();
        ctx.beginPath(); ctx.moveTo(12, -w/2+2); ctx.lineTo(18, -w/2-14); ctx.lineTo(6, -w/2-2); ctx.fill();
        // 目（緑）
        ctx.fillStyle = '#76FF03';
        ctx.fillRect(-10, -5, 8, 5);
        ctx.fillRect(2, -5, 8, 5);
        ctx.restore();
    },

    // エリート兵 (defender_elite): ディフェンダーベース + 金の装甲 + 赤マント
    drawDefenderElite(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        // 本体（金色）
        ctx.fillStyle = '#F9A825';
        ctx.beginPath();
        ctx.arc(0, 0, w / 2 - 2, 0, Math.PI * 2); ctx.fill();
        // 金の鎧
        ctx.fillStyle = '#FF8F00';
        ctx.beginPath();
        ctx.arc(0, 0, w / 2 - 6, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#E65100'; ctx.lineWidth = 2; ctx.stroke();
        // 兜
        ctx.fillStyle = '#E65100';
        ctx.beginPath();
        ctx.arc(0, -5, w / 2, Math.PI, 0); ctx.fill();
        // 兜の飾り羽（赤）
        ctx.fillStyle = '#D32F2F';
        ctx.beginPath(); ctx.moveTo(0, -w/2-2); ctx.lineTo(-5, -w/2-16); ctx.lineTo(5, -w/2-16); ctx.fill();
        // 目（赤く光る）
        ctx.fillStyle = '#B71C1C';
        ctx.fillRect(-10, -5, 20, 6);
        ctx.fillStyle = '#FF5252';
        ctx.fillRect(-8, -3, 16, 2);
        ctx.restore();
    },

    // --- REVOLUTION: UNIQUE SLIME VARIANTS ---
    drawSlimeBlue(ctx, x, y, w, h, color, dir, frame) {
        // Base Slime
        this.drawSlime(ctx, x, y, w, h, color, '#0D47A1', dir, frame, 0);

        // Goggles
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        ctx.fillStyle = '#4FC3F7'; // Glass
        ctx.strokeStyle = '#333';
        ctx.lineWidth = 2;
        // Left lens
        ctx.beginPath(); ctx.arc(-6, -2, 5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        // Right lens
        ctx.beginPath(); ctx.arc(6, -2, 5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        // Strap
        ctx.fillStyle = '#333';
        ctx.fillRect(-12, -3, 3, 2);
        ctx.fillRect(9, -3, 3, 2);
        ctx.restore();
    },

    // アクアスライム (slime_aqua): 水色透明ボディ + 水泡 + きらきら
    drawSlimeAqua(ctx, x, y, w, h, color, dir, frame) {
        // 水色ベース
        this.drawSlime(ctx, x, y, w, h, '#26C6DA', '#00838F', dir, frame, 0);

        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // 透明感（白いハイライト）
        ctx.fillStyle = 'rgba(255,255,255,0.35)';
        ctx.beginPath();
        ctx.ellipse(-w * 0.12, -h * 0.18, w * 0.14, h * 0.1, -0.4, 0, Math.PI * 2);
        ctx.fill();

        // 浮かぶ水泡（小さな円）
        ctx.strokeStyle = 'rgba(255,255,255,0.7)';
        ctx.lineWidth = 1.5;
        const bubbles = [{ox: -12, oy: 8, r: 3, sp: 0.08}, {ox: 6, oy: 12, r: 4, sp: 0.06}, {ox: 10, oy: 4, r: 2, sp: 0.12}];
        bubbles.forEach(b => {
            const by = b.oy - ((frame * b.sp * 20) % (h * 0.8));
            ctx.globalAlpha = Math.max(0, 0.8 - Math.abs(by) / (h * 0.6));
            ctx.beginPath();
            ctx.arc(b.ox, by, b.r, 0, Math.PI * 2);
            ctx.stroke();
        });
        ctx.globalAlpha = 1;

        ctx.restore();
    },

    drawSlimeRed(ctx, x, y, w, h, color, dir, frame) {
        // Base Slime
        this.drawSlime(ctx, x, y, w, h, color, '#B71C1C', dir, frame, 0);

        // Horn
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        ctx.fillStyle = '#EEE';
        ctx.beginPath();
        ctx.moveTo(0, -10);
        ctx.lineTo(3, -2);
        ctx.lineTo(-3, -2);
        ctx.fill();
        ctx.restore();
    },

    drawSlimePurple(ctx, x, y, w, h, color, dir, frame) {
        // パープルスライム: ブルー×レッドの配合産。魔力の紫オーラと双角を持つ
        this.drawSlime(ctx, x, y, w, h, color, '#6A1B9A', dir, frame, 0);

        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // 双角（左右に小さい角）
        ctx.fillStyle = '#CE93D8';
        for (let i = -1; i <= 1; i += 2) {
            ctx.beginPath();
            ctx.moveTo(i * 4, -10);
            ctx.lineTo(i * 7, -17);
            ctx.lineTo(i * 2, -10);
            ctx.fill();
        }

        // 魔力オーラリング（脈動）
        const auraAlpha = 0.18 + Math.sin(frame * 0.1) * 0.08;
        ctx.globalAlpha = auraAlpha;
        ctx.strokeStyle = '#CE93D8';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 0, w * 0.52, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;

        ctx.restore();
    },

    drawSlimeMetal(ctx, x, y, w, h, color, dir, frame) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2 + 5); // Low profile
        ctx.scale(dir, 1);

        // Liquid Body
        ctx.fillStyle = color;
        ctx.beginPath();
        // Wider, flatter
        ctx.ellipse(0, 0, w * 0.5, h * 0.25, 0, Math.PI, 0);
        ctx.lineTo(w * 0.5, h * 0.25);
        ctx.quadraticCurveTo(0, h * 0.4, -w * 0.5, h * 0.25);
        ctx.fill();

        // Face
        ctx.fillStyle = '#FFF';
        ctx.beginPath(); ctx.arc(-6, -2, 2, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(6, -2, 2, 0, Math.PI * 2); ctx.fill();

        ctx.restore();
    },

    drawKingSlime(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        // Base Slime (Huge)
        this.drawSlime(ctx, x, y, w, h, color, '#2A9FD6', dir, frame, 0);

        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // CROWN
        const crownY = -h * 0.45 + Math.sin(frame * 0.1) * 2;
        ctx.fillStyle = '#FFD700'; // Gold
        ctx.strokeStyle = '#DAA520';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-15, crownY);
        ctx.lineTo(-20, crownY - 15); // Left point
        ctx.lineTo(-10, crownY - 8);
        ctx.lineTo(0, crownY - 20);   // Center point
        ctx.lineTo(10, crownY - 8);
        ctx.lineTo(20, crownY - 15);  // Right point
        ctx.lineTo(15, crownY);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Facs (Mustacho?)
        ctx.fillStyle = '#FFF';
        ctx.beginPath();
        ctx.ellipse(0, 5, 10, 5, 0, 0, Math.PI * 2); // Mouth area?
        ctx.fill();

        ctx.restore();
    },

    // ★ typeが 'kingslime' のとき _uiDrawAllyIcon が drawKingslime を探すためエイリアスを追加
    drawKingslime(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        this.drawKingSlime(ctx, x, y, w, h, color, dir, frame);
    },

    drawSlimeGold(ctx, x, y, w, h, color, dir, frame) {
        // slimeTypeを渡してdrawSlime内のslime_goldブランチ（王冠付き）を使う
        // 以前は slimeType未指定→王冠なし+別途ズレた座標でクラウン描画という二重バグがあった
        this.drawSlime(ctx, x, y, w, h, color, '#FFA000', dir, frame, 0, 'slime_gold');
    },

    drawGolem(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // Body (Blocky Stone)
        ctx.fillStyle = color; // Stone Brown
        const sway = Math.sin(frame * 0.05) * 2;
        ctx.fillRect(-w * 0.4, -h * 0.4, w * 0.8, h * 0.7);

        // Head
        ctx.fillRect(-w * 0.25, -h * 0.6 + sway, w * 0.5, h * 0.3);

        // Arms (Long)
        const armAng = Math.sin(frame * 0.1) * 0.2;
        ctx.save();
        ctx.translate(-w * 0.4, -h * 0.3);
        ctx.rotate(armAng);
        ctx.fillRect(-10, 0, 20, h * 0.6); // Left Arm
        ctx.restore();

        ctx.save();
        ctx.translate(w * 0.4, -h * 0.3);
        ctx.rotate(-armAng);
        ctx.fillRect(-10, 0, 20, h * 0.6); // Right Arm
        ctx.restore();

        // Eyes (Glowing)
        ctx.fillStyle = '#0FF'; // Blue magic eyes

        ctx.fillRect(-10, -h * 0.5 + sway, 6, 4);
        ctx.fillRect(4, -h * 0.5 + sway, 6, 4);

        // Cracks/Texture
        ctx.strokeStyle = 'rgba(0,0,0,0.3)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-10, 0); ctx.lineTo(-5, 10); ctx.lineTo(-15, 15);
        ctx.stroke();

        ctx.restore();
    },

    // サンドゴーレム (golem_sand): 砂漠の色 + 砂嵐エフェクト + 眼が赤い
    drawGolemSand(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // 砂色の体
        const sway = Math.sin(frame * 0.05) * 2;
        ctx.fillStyle = '#D4A017';
        ctx.fillRect(-w * 0.4, -h * 0.4, w * 0.8, h * 0.7);

        // 頭（ざらざら感）
        ctx.fillStyle = '#C8960C';
        ctx.fillRect(-w * 0.25, -h * 0.6 + sway, w * 0.5, h * 0.3);

        // 腕
        const armAng = Math.sin(frame * 0.1) * 0.2;
        ctx.fillStyle = '#B8860B';
        ctx.save();
        ctx.translate(-w * 0.4, -h * 0.3);
        ctx.rotate(armAng);
        ctx.fillRect(-10, 0, 20, h * 0.6);
        ctx.restore();
        ctx.save();
        ctx.translate(w * 0.4, -h * 0.3);
        ctx.rotate(-armAng);
        ctx.fillRect(-10, 0, 20, h * 0.6);
        ctx.restore();

        // 目（赤熱）
        ctx.fillStyle = '#FF1744';
        ctx.fillRect(-10, -h * 0.5 + sway, 6, 4);
        ctx.fillRect(4,  -h * 0.5 + sway, 6, 4);

        // 砂粒パーティクル（ふわふわ舞う）
        ctx.globalAlpha = 0.45;
        ctx.fillStyle = '#FFD54F';
        for (let i = 0; i < 5; i++) {
            const a = frame * 0.09 + i * 1.26;
            ctx.beginPath();
            ctx.arc(Math.cos(a) * (w * 0.55), Math.sin(a * 0.7) * (h * 0.45) - 5, 2.5, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.globalAlpha = 1;

        // ひび割れ
        ctx.strokeStyle = 'rgba(0,0,0,0.25)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-8, 2); ctx.lineTo(-3, 12); ctx.lineTo(-12, 18);
        ctx.stroke();

        ctx.restore();
    },

    drawMaster(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        const bob = Math.sin(frame * 0.06) * 2;

        // Aura glow (wise elder energy)
        ctx.save();
        ctx.globalAlpha = 0.18 + Math.sin(frame * 0.04) * 0.08;
        const auraGrad = ctx.createRadialGradient(0, bob, 2, 0, bob, w * 0.72);
        auraGrad.addColorStop(0, '#FFD700');
        auraGrad.addColorStop(1, 'rgba(255,215,0,0)');
        ctx.fillStyle = auraGrad;
        ctx.beginPath();
        ctx.arc(0, bob, w * 0.72, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // Body (Elder Slime - deep magenta)
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(0, bob, w * 0.42, Math.PI, 0);
        ctx.lineTo(w * 0.42, h * 0.42 + bob);
        ctx.quadraticCurveTo(0, h * 0.55 + bob, -w * 0.42, h * 0.42 + bob);
        ctx.fill();

        // Dark robe overlay
        ctx.fillStyle = 'rgba(80,0,40,0.45)';
        ctx.beginPath();
        ctx.arc(0, bob, w * 0.38, Math.PI * 0.15, Math.PI * 0.85);
        ctx.lineTo(w * 0.38, h * 0.42 + bob);
        ctx.quadraticCurveTo(0, h * 0.52 + bob, -w * 0.38, h * 0.42 + bob);
        ctx.fill();

        // Long white beard
        ctx.fillStyle = '#F0EDE8';
        ctx.beginPath();
        ctx.moveTo(-14, 4 + bob);
        ctx.quadraticCurveTo(-8, 26 + bob, 0, 28 + bob);
        ctx.quadraticCurveTo(8, 26 + bob, 14, 4 + bob);
        ctx.quadraticCurveTo(0, -2 + bob, -14, 4 + bob);
        ctx.fill();

        // Wise white eyebrows
        ctx.lineWidth = 3.5;
        ctx.lineCap = 'round';
        ctx.strokeStyle = '#F0EDE8';
        ctx.beginPath();
        ctx.moveTo(-13, -14 + bob); ctx.lineTo(-5, -11 + bob);
        ctx.moveTo(13, -14 + bob); ctx.lineTo(5, -11 + bob);
        ctx.stroke();

        // Eyes (small, wise)
        ctx.fillStyle = '#4A0020';
        ctx.beginPath();
        ctx.arc(-6, -6 + bob, 2.5, 0, Math.PI * 2);
        ctx.arc(6, -6 + bob, 2.5, 0, Math.PI * 2);
        ctx.fill();

        // Golden hat / halo hint
        ctx.strokeStyle = '#FFD700';
        ctx.lineWidth = 2.5;
        ctx.globalAlpha = 0.6 + Math.sin(frame * 0.05) * 0.2;
        ctx.beginPath();
        ctx.ellipse(0, -18 + bob, 13, 4, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;

        // Staff (right side, animated sway)
        ctx.save();
        ctx.translate(w * 0.44, -4 + bob);
        const sway = Math.sin(frame * 0.08) * 0.12;
        ctx.rotate(sway);
        // Staff pole
        ctx.fillStyle = '#6D4C41';
        ctx.fillRect(-2.5, -32, 5, 62);
        // Gold tip
        ctx.fillStyle = '#FFD700';
        ctx.beginPath();
        ctx.arc(0, -34, 7, 0, Math.PI * 2);
        ctx.fill();
        // Gem shine
        const gemGlow = 0.5 + Math.sin(frame * 0.07) * 0.3;
        ctx.fillStyle = `rgba(255,255,255,${gemGlow})`;
        ctx.beginPath();
        ctx.arc(-2, -36, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        ctx.restore();
    },

    // 老師（旧報酬）(master_old): 老師ベース + 白髪 + 黒い禅ローブ + 青い杖宝石
    drawMasterOld(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // 体（黒のローブ）
        ctx.fillStyle = '#212121';
        ctx.beginPath();
        ctx.arc(0, 0, w * 0.4, Math.PI, 0);
        ctx.lineTo(w * 0.4, h * 0.4);
        ctx.quadraticCurveTo(0, h * 0.5, -w * 0.4, h * 0.4);
        ctx.fill();

        // 白い長い髭
        ctx.fillStyle = '#FAFAFA';
        ctx.beginPath();
        ctx.moveTo(-16, 0);
        ctx.quadraticCurveTo(0, 28, 16, 0);
        ctx.quadraticCurveTo(0, -5, -16, 0);
        ctx.fill();

        // 白い太い眉
        ctx.lineWidth = 4;
        ctx.lineCap = 'round';
        ctx.strokeStyle = '#FAFAFA';
        ctx.beginPath();
        ctx.moveTo(-13, -16); ctx.lineTo(-5, -13);
        ctx.moveTo(13, -16); ctx.lineTo(5, -13);
        ctx.stroke();

        // 杖（黒い木）
        ctx.save();
        ctx.translate(w * 0.4, 0);
        ctx.rotate(Math.sin(frame * 0.1) * 0.1);
        ctx.fillStyle = '#37474F';
        ctx.fillRect(-2, -30, 4, 60);
        // 青い宝石
        ctx.fillStyle = '#29B6F6';
        ctx.beginPath(); ctx.arc(0, -32, 6, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.beginPath(); ctx.arc(-2, -34, 2, 0, Math.PI * 2); ctx.fill();
        ctx.restore();

        ctx.restore();
    },

    // 次元スライム (master_dim): 老師ベース + 虹色オーラ + 次元の歪みエフェクト
    drawMasterDim(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // 体（深紫）
        ctx.fillStyle = '#4A148C';
        ctx.beginPath();
        ctx.arc(0, 0, w * 0.4, Math.PI, 0);
        ctx.lineTo(w * 0.4, h * 0.4);
        ctx.quadraticCurveTo(0, h * 0.5, -w * 0.4, h * 0.4);
        ctx.fill();

        // 次元の歪みオーラ（回転する虹リング）
        const hues = [0, 60, 120, 180, 240, 300];
        hues.forEach((hue, i) => {
            const a = frame * 0.06 + i * (Math.PI / 3);
            ctx.globalAlpha = 0.3;
            ctx.strokeStyle = `hsl(${hue}, 100%, 60%)`;
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.ellipse(Math.cos(a) * 4, Math.sin(a) * 3, w * 0.48, h * 0.48, a, 0, Math.PI * 2);
            ctx.stroke();
        });
        ctx.globalAlpha = 1;

        // 白髭
        ctx.fillStyle = '#CE93D8';
        ctx.beginPath();
        ctx.moveTo(-14, 0);
        ctx.quadraticCurveTo(0, 22, 14, 0);
        ctx.quadraticCurveTo(0, -4, -14, 0);
        ctx.fill();

        // 眉
        ctx.lineWidth = 3;
        ctx.strokeStyle = '#CE93D8';
        ctx.beginPath();
        ctx.moveTo(-12, -15); ctx.lineTo(-5, -12);
        ctx.moveTo(12, -15); ctx.lineTo(5, -12);
        ctx.stroke();

        // 次元の杖（虹色宝石）
        ctx.save();
        ctx.translate(w * 0.4, 0);
        ctx.rotate(Math.sin(frame * 0.1) * 0.15);
        ctx.fillStyle = '#6A1B9A';
        ctx.fillRect(-2, -30, 4, 60);
        const gemHue = (frame * 3) % 360;
        ctx.fillStyle = `hsl(${gemHue}, 100%, 60%)`;
        ctx.beginPath(); ctx.arc(0, -32, 7, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.6)';
        ctx.beginPath(); ctx.arc(-2, -34, 2.5, 0, Math.PI * 2); ctx.fill();
        ctx.restore();

        ctx.restore();
    },

    drawDrone(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        const yOffset = Math.sin(frame * 0.1) * 3;
        ctx.translate(0, yOffset);
        ctx.scale(dir, 1);

        // Propeller (Blurry when moving)
        ctx.fillStyle = '#AAA';
        ctx.fillRect(-16, -20, 32, 4);
        const propSpeed = frame * 1.5;
        ctx.fillStyle = `rgba(255,255,255,${0.5 + Math.sin(propSpeed) * 0.3})`;
        ctx.beginPath(); ctx.ellipse(0, -22, 25, 3, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#555'; // Shaft
        ctx.fillRect(-2, -20, 4, 8);

        // Body (Metallic sphere)
        const grad = ctx.createRadialGradient(-5, -5, 2, 0, 0, 15);
        grad.addColorStop(0, '#EEE');
        grad.addColorStop(1, '#777');
        ctx.fillStyle = grad;
        ctx.beginPath(); ctx.arc(0, 0, 14, 0, Math.PI * 2); ctx.fill();

        // Eye (Camera Lens)
        ctx.fillStyle = '#111';
        ctx.beginPath(); ctx.arc(6, 0, 6, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = frame % 60 < 30 ? '#F00' : '#800'; // Blinking recording light
        ctx.beginPath(); ctx.arc(6, 0, 3, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.6)'; // Lens reflection
        ctx.beginPath(); ctx.arc(7, -2, 1.5, 0, Math.PI * 2); ctx.fill();

        // Arms / Claw
        ctx.strokeStyle = '#555';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, 12); ctx.lineTo(-5, 20); ctx.lineTo(5, 20); // Claw
        ctx.stroke();

        ctx.restore();
    },

    _draw3DCloud(ctx, x, y, size) {
        // パフォーマンス改善: save/restore廃止、3楕円を1パスに統合
        ctx.fillStyle = 'rgba(240,248,255,0.55)';
        ctx.beginPath();
        ctx.ellipse(x, y, size, size * 0.28, 0, 0, Math.PI * 2);
        ctx.ellipse(x - size * 0.3, y + 3, size * 0.55, size * 0.22, 0, 0, Math.PI * 2);
        ctx.ellipse(x + size * 0.35, y + 2, size * 0.45, size * 0.18, 0, 0, Math.PI * 2);
        ctx.fill();
    },

    _drawMountains(ctx, w, h) {
        const mtnY = h * 0.7;
        // Far mountains (blueish, lighter) - step 15 for perf (mountains don't need pixel precision)
        ctx.fillStyle = 'rgba(80,110,150,0.35)';
        ctx.beginPath(); ctx.moveTo(0, mtnY);
        for (let x = 0; x <= w; x += 15) {
            const my = mtnY - 40 - Math.sin(x * 0.005) * 30 - Math.sin(x * 0.013) * 15;
            ctx.lineTo(x, my);
        }
        ctx.lineTo(w, mtnY); ctx.closePath(); ctx.fill();

        // Near mountains (darker)
        ctx.fillStyle = 'rgba(60,90,50,0.4)';
        ctx.beginPath(); ctx.moveTo(0, mtnY);
        for (let x = 0; x <= w; x += 15) {
            const my = mtnY - 20 - Math.sin(x * 0.008 + 1) * 25 - Math.sin(x * 0.02 + 2) * 10;
            ctx.lineTo(x, my);
        }
        ctx.lineTo(w, mtnY); ctx.closePath(); ctx.fill();
    },

    // === UTILITY ===
    // Map logical battle/interior coordinates to upper screen visualization coordinates
    _toUpperCoord(lx, ly, w, h) {
        // ★バグ修正: 引数が null / undefined / NaN の場合はデフォルト値にフォールバック
        // NaN のまま演算すると描画座標が全て NaN になりキャンバス描画が無効化される
        if (!isFinite(lx)) lx = 40;
        if (!isFinite(ly)) ly = 420;
        if (!isFinite(w)  || w  <= 0) w  = 800;
        if (!isFinite(h)  || h  <= 0) h  = 400;

        // Logical X: typically 40 (player) to 800 (enemy)
        // Upper Screen X mapping:
        // Player tank visual center: ~80
        // Enemy tank visual center: ~w - 80
        const margin = 120;
        const ux = margin + ((lx - 40) / (800 - 40)) * (w - margin * 2);

        // Logical Y: typically OFFSET_Y + ...
        // Upper Screen Y mapping (around ground line):
        const groundY = h - 60;
        const uy = groundY - 150 + ((ly - 420) / 360) * 100;

        return {
            x: isFinite(ux) ? ux : w / 2,
            y: isFinite(uy) ? uy : h / 2,
        };
    },

    _roundRect(ctx, x, y, w, h, r) {
        ctx.beginPath();
        ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r);
        ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
        ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
        ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y);
        ctx.closePath();
    },

    _parseColor(c) {
        if (!c || typeof c !== 'string') return [0, 0, 0];
        if (c.startsWith('#')) {
            let hex = c.replace('#', '');
            if (hex.length === 3) hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
            return [parseInt(hex.substr(0, 2), 16) || 0, parseInt(hex.substr(2, 2), 16) || 0, parseInt(hex.substr(4, 2), 16) || 0];
        }
        if (c.startsWith('rgb')) {
            const m = c.match(/\d+/g);
            if (m && m.length >= 3) return [parseInt(m[0]) || 0, parseInt(m[1]) || 0, parseInt(m[2]) || 0];
        }
        return [0, 0, 0];
    },

    _lighten(color, amt) {
        const [r, g, b] = this._parseColor(color);
        return `rgb(${Math.min(255, r + amt)},${Math.min(255, g + amt)},${Math.min(255, b + amt)})`;
    },

    _darkenHex(color, amt) {
        const [r, g, b] = this._parseColor(color);
        return `rgb(${Math.max(0, r - amt)},${Math.max(0, g - amt)},${Math.max(0, b - amt)})`;
    },

    // === SPECIAL MOVE VISUALS ===
    drawSpecialCutin(ctx, W, H, frame) {
        // frame: 55→0 カウントダウン
        // Phase1 (55-40): フラッシュ＋テキスト登場
        // Phase2 (40-20): スライム突撃アニメ
        // Phase3 (20-0):  爆発・衝撃波フェードアウト
        const alpha = frame > 48 ? (55 - frame) / 7 : frame < 8 ? frame / 8 : 1.0;
        ctx.save();
        ctx.globalAlpha = Math.min(1, alpha);

        // ── 背景：黒に赤グラデ ──
        const bg = ctx.createRadialGradient(W * 0.72, H * 0.28, 0, W * 0.72, H * 0.28, W * 0.9);
        bg.addColorStop(0, 'rgba(180,0,0,0.85)');
        bg.addColorStop(0.5, 'rgba(60,0,0,0.75)');
        bg.addColorStop(1, 'rgba(0,0,0,0.92)');
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, W, H);

        // ── 斜線エフェクト（スピード感） ──
        ctx.strokeStyle = 'rgba(255,80,0,0.25)';
        ctx.lineWidth = 3;
        for (let i = 0; i < 14; i++) {
            const lx = (W * i / 14 + frame * 18) % (W + 80) - 40;
            ctx.beginPath();
            ctx.moveTo(lx, 0);
            ctx.lineTo(lx - 80, H);
            ctx.stroke();
        }

        // ── Phase2: 複数スライムが右上の敵に向かって突撃 ──
        if (frame <= 42 && frame > 8) {
            const rushProgress = 1 - (frame - 8) / 34; // 0→1
            const slimeCount = 5;
            const colors = ['#4CAF50', '#2196F3', '#FF9800', '#E91E63', '#FFD700'];
            for (let i = 0; i < slimeCount; i++) {
                const delay = i * 0.15;
                const prog = Math.max(0, Math.min(1, rushProgress - delay));
                if (prog <= 0) continue;

                // 左下から右上の敵位置へ
                const startX = W * 0.1 + i * 18;
                const startY = H * 0.75;
                const endX = W * 0.72;
                const endY = H * 0.28;

                const sx = startX + (endX - startX) * prog;
                const sy = startY + (endY - startY) * prog;
                const sz = 28 + i * 4;

                if (prog >= 0.92) continue; // 衝突したら消える

                // 残像トレイル
                for (let t = 1; t <= 3; t++) {
                    const tp = Math.max(0, prog - t * 0.06);
                    const tx2 = startX + (endX - startX) * tp;
                    const ty2 = startY + (endY - startY) * tp;
                    ctx.globalAlpha = alpha * (0.25 - t * 0.07);
                    ctx.fillStyle = colors[i];
                    ctx.beginPath();
                    ctx.arc(tx2, ty2, sz * 0.5, 0, Math.PI * 2);
                    ctx.fill();
                }
                ctx.globalAlpha = Math.min(1, alpha);

                // スライム本体
                ctx.save();
                ctx.translate(sx, sy);
                // 進行方向に傾ける
                const angle = Math.atan2(endY - startY, endX - startX);
                ctx.rotate(angle + Math.PI / 2);
                if (window.Renderer) {
                    window.Renderer.drawSlime(ctx, -sz / 2, -sz / 2, sz, sz, colors[i], '#1B5E20', 1, frame + i * 7, 0, 'slime');
                }
                ctx.restore();
            }
        }

        // ── Phase3: 爆発エフェクト ──
        if (frame <= 22) {
            const phase = 1 - frame / 22;
            // 爆発リング（複数）
            const rings = [
                { r: phase * W * 0.55, c: '#FF6600', lw: 8 * (1 - phase) },
                { r: phase * W * 0.38, c: '#FFD700', lw: 5 * (1 - phase) },
                { r: phase * W * 0.22, c: '#FFF',    lw: 3 * (1 - phase) },
            ];
            for (const ring of rings) {
                ctx.globalAlpha = alpha * (1 - phase) * 0.9;
                ctx.strokeStyle = ring.c;
                ctx.lineWidth = Math.max(0.5, ring.lw);
                ctx.beginPath();
                ctx.arc(W * 0.72, H * 0.28, ring.r, 0, Math.PI * 2);
                ctx.stroke();
            }
            // 爆発フラッシュ
            ctx.globalAlpha = alpha * (1 - phase) * 0.6;
            ctx.fillStyle = '#FFF';
            ctx.beginPath();
            ctx.arc(W * 0.72, H * 0.28, phase * W * 0.18, 0, Math.PI * 2);
            ctx.fill();

            // 破片パーティクル
            const shards = 10;
            ctx.globalAlpha = alpha * (1 - phase);
            for (let i = 0; i < shards; i++) {
                const angle = (i / shards) * Math.PI * 2;
                const dist = phase * 120;
                const px2 = W * 0.72 + Math.cos(angle) * dist;
                const py2 = H * 0.28 + Math.sin(angle) * dist;
                ctx.fillStyle = i % 2 === 0 ? '#FFD700' : '#FF4400';
                ctx.beginPath();
                ctx.arc(px2, py2, 5 * (1 - phase * 0.5), 0, Math.PI * 2);
                ctx.fill();
            }
        }

        ctx.globalAlpha = Math.min(1, alpha);

        // ── テキスト（上部） ──
        const textScale = frame > 45 ? (55 - frame) / 10 : 1 + (frame < 12 ? (12 - frame) * 0.03 : 0);
        ctx.save();
        ctx.translate(W / 2, H * 0.12);
        ctx.scale(textScale, textScale);
        ctx.font = 'bold italic 52px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        // アウトライン
        ctx.strokeStyle = '#FF4400';
        ctx.lineWidth = 8;
        // ★バグ修正: skin_lumen 装備時は専用の技名を表示
        const _cutinSkinId = window.game?.saveData?.tankCustom?.skin || 'skin_default';
        const _cutinLabel = _cutinSkinId === 'skin_lumen'   ? '✨ 原初の光砲 !!!' :
                            _cutinSkinId === 'skin_dragon'  ? '👑 究極の龍炎砲 !!!' :
                            _cutinSkinId === 'skin_abyss'   ? '🌑 深淵の虚無砲 !!!' :
                            _cutinSkinId === 'skin_seraph'  ? '✨ 天門砲 !!!' :
                            'SLIME RUSH!!!';
        ctx.strokeText(_cutinLabel, 0, 0);
        // メインテキスト（グラデ）
        const tg = ctx.createLinearGradient(-120, -30, 120, 30);
        if (_cutinSkinId === 'skin_lumen') {
            tg.addColorStop(0, '#AAFFCC'); tg.addColorStop(0.5, '#FFFFFF'); tg.addColorStop(1, '#CCFFEE');
        } else if (_cutinSkinId === 'skin_dragon') {
            tg.addColorStop(0, '#FF6600'); tg.addColorStop(0.5, '#FFF'); tg.addColorStop(1, '#FF4400');
        } else {
            tg.addColorStop(0, '#FFD700'); tg.addColorStop(0.5, '#FFF'); tg.addColorStop(1, '#FF9800');
        }
        ctx.fillStyle = tg;
        ctx.fillText(_cutinLabel, 0, 0);
        ctx.restore();

        // ── サブテキスト ──
        if (frame < 44) {
            ctx.font = 'bold 22px Arial';
            ctx.textAlign = 'center';
            ctx.strokeStyle = 'rgba(0,0,0,0.8)';
            ctx.lineWidth = 4;
            ctx.strokeText('全員突撃ーーっ！！', W / 2, H * 0.88);
            ctx.fillStyle = '#FFF';
            ctx.fillText('全員突撃ーーっ！！', W / 2, H * 0.88);
        }

        ctx.restore();
    },

    // ===================================================================
    // ★ タイタンゴーレム 連携技カットイン【天崩地裂】 (妖怪ウォッチ風・強化版)
    // frame: 100→0
    // Phase1 (100-80): 暗転 & 地響きラインが走る
    // Phase2 (80-55): タイタンが下から飛び込んでくる（スライドイン）
    // Phase3 (55-25): キャラ顔アップ & 名前パネル登場 & 技名ズームイン
    // Phase4 (25-10): 技名フラッシュ・震え
    // Phase5 (10-0):  ズームアウト＆フェードアウト
    // ===================================================================
    drawTitanSpecialCutin(ctx, W, H, frame) {
        const MAX = 100;
        const t = MAX - frame; // t: 0→100 (経過フレーム)
        const alpha = frame > (MAX - 8) ? (MAX - frame) / 8 : frame < 12 ? frame / 12 : 1.0;
        ctx.save();

        // ── Phase1: 暗転フラッシュ（t=0-20）──
        const bgAlpha = Math.min(1, t / 15) * alpha;
        const bg = ctx.createLinearGradient(0, 0, 0, H);
        bg.addColorStop(0, '#0d0d1a');
        bg.addColorStop(0.5, '#1a1a2e');
        bg.addColorStop(1, '#3d1a00');
        ctx.globalAlpha = bgAlpha * 0.98;
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, W, H);
        ctx.globalAlpha = 1;

        // ── 地響きラインエフェクト（t=5-40）──
        if (t > 5 && t < 55) {
            const lineP = Math.min(1, (t - 5) / 20);
            ctx.save();
            ctx.globalAlpha = alpha * lineP * 0.6;
            for (let i = 0; i < 8; i++) {
                const ly = H * (0.1 + i * 0.11);
                const lw = W * lineP * (0.3 + Math.sin(i * 1.7) * 0.2);
                const lx = (i % 2 === 0) ? -lw + W * lineP * 0.8 : W - W * lineP * 0.8;
                ctx.fillStyle = i % 3 === 0 ? '#FF8C00' : (i % 3 === 1 ? '#FFD700' : '#FF4500');
                ctx.fillRect(lx, ly - 2, lw, 4 + (i % 3) * 2);
            }
            ctx.restore();
        }

        // ── Phase2: タイタンが下から飛び込む（t=20-50）──
        const slideT = Math.max(0, Math.min(1, (t - 20) / 30));
        const easeSlide = slideT < 0.5 ? 4 * slideT * slideT * slideT : 1 - Math.pow(-2 * slideT + 2, 3) / 2; // ease in-out cubic
        const splitX = W * 0.54 * easeSlide;

        // 左パネル（キャラ側）
        if (easeSlide > 0) {
            ctx.save();
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(splitX, 0);
            ctx.lineTo(splitX - H * 0.22, H);
            ctx.lineTo(0, H);
            ctx.closePath();
            const panelBg = ctx.createLinearGradient(0, 0, splitX, H);
            panelBg.addColorStop(0, '#2a3a4a');
            panelBg.addColorStop(1, '#1a2030');
            ctx.fillStyle = panelBg;
            ctx.globalAlpha = alpha;
            ctx.fill();
            ctx.restore();
        }

        // ── キャラクター描画（大きく、左パネル中央）──
        if (slideT > 0.3) {
            const charAlpha = Math.min(1, (slideT - 0.3) / 0.5);
            ctx.save();
            ctx.globalAlpha = alpha * charAlpha;

            // Phase4の技名フラッシュ時にキャラも揺れる
            const shakeX = (t > 25 && t < 55) ? Math.sin(t * 1.8) * 3 * (1 - (t - 25) / 30) : 0;
            const shakeY = (t > 25 && t < 55) ? Math.cos(t * 2.3) * 2 * (1 - (t - 25) / 30) : 0;

            // フェードアウト時ズームアウト
            const charScale = frame < 14 ? 1 + (14 - frame) * 0.012 : 1.0;
            // ズームイン演出（Phase3入場時）
            const zoomIn = t > 20 && t < 50 ? 1 + (1 - easeSlide) * 0.3 : 1.0;
            const finalScale = charScale * zoomIn;

            const cw = W * 0.44 * finalScale;
            const ch = H * 0.80 * finalScale;
            const cx = W * 0.22 - cw / 2 + shakeX;
            const cy = H * 0.5 - ch / 2 - H * 0.03 + shakeY;

            // クリップして左パネル内に収める
            ctx.beginPath();
            ctx.moveTo(0, 0); ctx.lineTo(splitX + 10, 0);
            ctx.lineTo(splitX - H * 0.22 + 10, H); ctx.lineTo(0, H);
            ctx.closePath(); ctx.clip();

            // タイタンゴーレム本体を大きく描画（アニメーションフレームを使う）
            const animFrame = t * 3;
            this.drawTitanGolem(ctx, cx, cy, cw, ch, '#546E7A', 1, animFrame);

            // 足元のオーラ（パルスアニメ）
            const auraSize = 1 + Math.sin(t * 0.35) * 0.25;
            ctx.globalAlpha = (0.4 + Math.sin(t * 0.3) * 0.2) * charAlpha * alpha;
            const auraGrd = ctx.createRadialGradient(W*0.22, H*0.9, 0, W*0.22, H*0.9, cw*0.5*auraSize);
            auraGrd.addColorStop(0, 'rgba(255,140,0,0.8)');
            auraGrd.addColorStop(0.5, 'rgba(255,80,0,0.4)');
            auraGrd.addColorStop(1, 'rgba(255,40,0,0)');
            ctx.fillStyle = auraGrd;
            ctx.beginPath();
            ctx.ellipse(W * 0.22, H * 0.9, cw * 0.5 * auraSize, H * 0.07, 0, 0, Math.PI * 2);
            ctx.fill();

            // 衝撃波リング（入場時: t=20-40）
            if (t > 22 && t < 42) {
                const ringP = (t - 22) / 20;
                ctx.globalAlpha = (1 - ringP) * charAlpha * alpha * 0.7;
                ctx.strokeStyle = '#FF8C00';
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.ellipse(W*0.22, H*0.7, cw*0.3*ringP*2, H*0.04*ringP*2, 0, 0, Math.PI*2);
                ctx.stroke();
            }

            ctx.restore();
        }

        // ── 右パネル（名前＆技名）t=30から登場 ──
        if (t > 30) {
            const txtT = Math.min(1, (t - 30) / 20);
            const easeT = txtT * txtT * (3 - 2 * txtT); // smooth step
            ctx.save();
            ctx.globalAlpha = alpha * easeT;

            // キャラ名プレート（右からスライドイン）
            const nameX = W * 0.56;
            const nameY = H * 0.26;
            const plateOffX = (1 - easeT) * W * 0.5; // 右からスライドイン

            ctx.save();
            ctx.translate(plateOffX, 0);

            // プレート背景
            ctx.fillStyle = '#FF8C00';
            ctx.beginPath();
            this._roundRect(ctx, nameX, nameY - 18, W * 0.38, 38, 4);
            ctx.fill();
            // プレート左の三角装飾
            ctx.beginPath();
            ctx.moveTo(nameX, nameY - 18);
            ctx.lineTo(nameX - 12, nameY + 1);
            ctx.lineTo(nameX, nameY + 20);
            ctx.closePath(); ctx.fill();

            // プレート右の光沢
            ctx.fillStyle = 'rgba(255,255,255,0.2)';
            ctx.beginPath();
            this._roundRect(ctx, nameX + 2, nameY - 16, W * 0.36, 16, 2);
            ctx.fill();

            ctx.font = 'bold 22px Arial';
            ctx.fillStyle = '#FFF';
            ctx.textAlign = 'left';
            ctx.shadowColor = 'rgba(0,0,0,0.5)';
            _setShadowBlur(ctx, 4);
            ctx.fillText('タイタンゴーレム', nameX + 10, nameY + 8);
            ctx.shadowBlur = 0;
            ctx.restore();

            // ── 技名テキスト（t=40からズームイン）──
            if (t > 40) {
                const skillT = Math.min(1, (t - 40) / 15);
                const skillEase = skillT < 0.5 ? 2 * skillT * skillT : 1 - Math.pow(-2 * skillT + 2, 2) / 2;
                const skillScale = 1 + (1 - skillEase) * 0.8; // 大→通常サイズにズームイン
                const skillY = H * 0.50;
                const skillCX = nameX + W * 0.19;

                // フラッシュ（Phase4: t=45-60）
                const flashAlpha = (t > 45 && t < 60) ? Math.sin((t - 45) / 15 * Math.PI) * 0.5 : 0;

                ctx.save();
                ctx.globalAlpha = alpha * skillEase;
                ctx.translate(skillCX, skillY);
                ctx.scale(skillScale, skillScale);
                ctx.translate(-skillCX, -skillY);

                // フラッシュ効果
                if (flashAlpha > 0) {
                    ctx.save();
                    ctx.globalAlpha = flashAlpha;
                    ctx.fillStyle = '#FFFFFF';
                    ctx.fillRect(nameX - 10, skillY - 45, W * 0.42, 65);
                    ctx.restore();
                }

                // 技名アウトライン
                ctx.font = 'bold italic 42px Arial';
                ctx.strokeStyle = '#4a1500';
                ctx.lineWidth = 8;
                ctx.textAlign = 'center';
                ctx.strokeText('天崩地裂', skillCX, skillY);

                // 技名グラデ（フラッシュ時は白くなる）
                const tg = ctx.createLinearGradient(skillCX - 85, skillY - 35, skillCX + 85, skillY + 10);
                tg.addColorStop(0, flashAlpha > 0.2 ? '#FFFFFF' : '#FFD700');
                tg.addColorStop(0.5, flashAlpha > 0.2 ? '#FFFFFF' : '#FFF');
                tg.addColorStop(1, flashAlpha > 0.2 ? '#FFFFFF' : '#FF8C00');
                ctx.fillStyle = tg;
                ctx.fillText('天崩地裂', skillCX, skillY);

                // サブテキスト（英字）
                ctx.font = 'bold 19px Arial';
                ctx.fillStyle = 'rgba(255,220,150,0.9)';
                ctx.fillText('GRAND  QUAKE', skillCX, skillY + 30);

                ctx.restore();

                // 区切り線（t=50から）
                if (t > 50) {
                    const lineT = Math.min(1, (t - 50) / 15);
                    ctx.save();
                    ctx.globalAlpha = alpha * lineT;
                    ctx.strokeStyle = 'rgba(255,140,0,0.6)';
                    ctx.lineWidth = 1.5;
                    ctx.beginPath();
                    const lineLeft = nameX;
                    const lineRight = nameX + W * 0.38 * lineT;
                    ctx.moveTo(lineLeft, H * 0.63); ctx.lineTo(lineRight, H * 0.63);
                    ctx.stroke();
                    ctx.restore();
                }

                // 効果説明（t=55から）
                if (t > 55) {
                    const descT = Math.min(1, (t - 55) / 12);
                    ctx.save();
                    ctx.globalAlpha = alpha * descT;
                    ctx.font = '14px Arial';
                    ctx.fillStyle = 'rgba(255,255,255,0.75)';
                    ctx.textAlign = 'left';
                    ctx.fillText('敵に超大ダメージ', nameX + 6, H * 0.72);
                    ctx.fillText('プレイヤーを回復・無敵化', nameX + 6, H * 0.77);
                    ctx.restore();
                }
            }

            ctx.restore();
        }

        // ── 小石・地割れパーティクル（t=35-65）──
        if (t > 35 && t < 70) {
            ctx.save();
            ctx.globalAlpha = alpha * 0.7;
            for (let i = 0; i < 6; i++) {
                const seed = i * 173.1;
                const px = (seed * 0.3 % (W * 0.5));
                const py = H * 0.85 + Math.sin(t * 0.2 + seed) * H * 0.08;
                const pr = 3 + (seed % 5);
                ctx.fillStyle = i % 2 === 0 ? '#8B6914' : '#A0522D';
                ctx.beginPath();
                ctx.arc(px, py + (t - 35) * 0.5, pr, 0, Math.PI * 2);
                ctx.fill();
            }
            ctx.restore();
        }

        // ── 斜めラインのキラリ光（パネル境界）──
        if (easeSlide > 0.8) {
            const glowAlpha = alpha * 0.8 * Math.min(1, (easeSlide - 0.8) / 0.2);
            ctx.save();
            ctx.globalAlpha = glowAlpha;
            const grd = ctx.createLinearGradient(splitX - 20, 0, splitX + 5, 0);
            grd.addColorStop(0, 'rgba(255,200,80,0)');
            grd.addColorStop(0.5, 'rgba(255,200,80,0.95)');
            grd.addColorStop(1, 'rgba(255,200,80,0)');
            ctx.fillStyle = grd;
            ctx.beginPath();
            ctx.moveTo(splitX - 18, 0); ctx.lineTo(splitX + 4, 0);
            ctx.lineTo(splitX - H * 0.22 + 4, H); ctx.lineTo(splitX - H * 0.22 - 18, H);
            ctx.closePath(); ctx.fill();
            ctx.restore();
        }

        // ── コーナー装飾（四隅の三角）──
        if (t > 45) {
            const cornT = Math.min(1, (t - 45) / 15);
            ctx.save();
            ctx.globalAlpha = alpha * cornT * 0.6;
            ctx.fillStyle = '#FF8C00';
            const cs = 18; // corner size
            // 右上
            ctx.beginPath(); ctx.moveTo(W, 0); ctx.lineTo(W - cs, 0); ctx.lineTo(W, cs); ctx.fill();
            // 右下
            ctx.beginPath(); ctx.moveTo(W, H); ctx.lineTo(W - cs, H); ctx.lineTo(W, H - cs); ctx.fill();
            ctx.restore();
        }

        ctx.restore();
    },

    // ===================================================================
    // ★ ドラゴンロード 連携技カットイン【覇竜炎】 (妖怪ウォッチ風・強化版)
    // frame: 105→0
    // Phase1 (105-85): 燃え上がる暗転 & 炎が下から這い上がる
    // Phase2 (85-60): ドラゴンが右から降臨（羽ばたきアニメ付き）
    // Phase3 (60-25): 名前パネル & 技名ズームイン & 炎エフェクト
    // Phase4 (25-12): 技名フラッシュ＋画面震え
    // Phase5 (12-0):  ドラゴン突進→フェードアウト
    // ===================================================================
    drawDragonSpecialCutin(ctx, W, H, frame) {
        const MAX = 105;
        const t = MAX - frame; // t: 0→105 (経過フレーム)
        const alpha = frame > (MAX - 8) ? (MAX - frame) / 8 : frame < 12 ? frame / 12 : 1.0;
        ctx.save();

        // ── Phase1: 背景（深紅＋黒、徐々に明るく）──
        const bgAlpha = Math.min(1, t / 18) * alpha;
        const bg = ctx.createLinearGradient(0, 0, 0, H);
        bg.addColorStop(0, '#1a0000');
        bg.addColorStop(0.4, '#2d0000');
        bg.addColorStop(1, '#600000');
        ctx.globalAlpha = bgAlpha * 0.98;
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, W, H);
        ctx.globalAlpha = 1;

        // ── 炎が下から這い上がる（t=0-50）──
        if (t > 3) {
            const fireP = Math.min(1, (t - 3) / 40);
            ctx.save();
            ctx.globalAlpha = alpha * Math.min(0.6, fireP * 0.6);
            const maxFlameH = H * 0.5 * fireP;
            for (let i = 0; i < 7; i++) {
                const fx = W * (i / 7) + W * 0.07;
                const fBase = H * (0.15 + Math.sin(t * 0.18 + i * 0.9) * 0.08);
                const fh = maxFlameH * fBase / H;
                // 炎グラデ
                const flameGrd = ctx.createLinearGradient(fx, H, fx, H - fh * H);
                flameGrd.addColorStop(0, 'rgba(255,60,0,0.9)');
                flameGrd.addColorStop(0.4, 'rgba(255,120,0,0.6)');
                flameGrd.addColorStop(1, 'rgba(255,200,0,0)');
                ctx.fillStyle = flameGrd;
                const fw = W * 0.13;
                ctx.beginPath();
                ctx.moveTo(fx - fw/2, H);
                ctx.quadraticCurveTo(fx - fw*0.3, H - fh*H*0.5, fx + Math.sin(t*0.2+i)*fw*0.3, H - fh*H);
                ctx.quadraticCurveTo(fx + fw*0.5, H - fh*H*0.5, fx + fw/2, H);
                ctx.closePath();
                ctx.fill();
            }
            ctx.restore();
        }

        // ── Phase2: 斜め分割スライドイン（t=20-55）──
        const slideT = Math.max(0, Math.min(1, (t - 20) / 35));
        const easeSlide = slideT < 0.5 ? 4 * slideT * slideT * slideT : 1 - Math.pow(-2 * slideT + 2, 3) / 2;
        const splitX = W - W * 0.52 * easeSlide;

        if (easeSlide > 0) {
            // 右パネル（キャラ側）
            ctx.save();
            ctx.beginPath();
            ctx.moveTo(splitX + H * 0.22, 0);
            ctx.lineTo(W, 0); ctx.lineTo(W, H);
            ctx.lineTo(splitX, H);
            ctx.closePath();
            const panelBg = ctx.createLinearGradient(splitX, 0, W, H);
            panelBg.addColorStop(0, '#3d0808');
            panelBg.addColorStop(1, '#600000');
            ctx.fillStyle = panelBg;
            ctx.globalAlpha = alpha;
            ctx.fill();
            ctx.restore();
        }

        // ── ドラゴンロード描画（右パネル）──
        if (slideT > 0.25) {
            const charAlpha = Math.min(1, (slideT - 0.25) / 0.55);

            // Phase5: 突進エフェクト（frame < 12）
            const rushOffX = frame < 12 ? -(12 - frame) * 15 : 0;
            const rushOffY = frame < 12 ? (12 - frame) * 5 : 0;

            // Phase4の震え（t=25-45）
            const shakeX = (t > 25 && t < 50) ? Math.sin(t * 2.1) * 4 * Math.min(1, (50 - t) / 25) : 0;
            const shakeY = (t > 25 && t < 50) ? Math.cos(t * 1.7) * 3 * Math.min(1, (50 - t) / 25) : 0;

            ctx.save();
            ctx.globalAlpha = alpha * charAlpha;

            const zoomIn = (slideT < 0.8) ? 1 + (1 - slideT) * 0.35 : 1.0;
            const charScale = frame < 14 ? 1 + (14 - frame) * 0.012 : 1.0;
            const finalScale = charScale * zoomIn;

            const cw = W * 0.43 * finalScale;
            const ch = H * 0.80 * finalScale;
            const cx = W * 0.79 - cw / 2 + shakeX + rushOffX;
            const cy = H * 0.5 - ch / 2 - H * 0.03 + shakeY + rushOffY;

            // 右パネルでクリップ
            ctx.beginPath();
            ctx.moveTo(splitX + H * 0.22 - 12, 0);
            ctx.lineTo(W, 0); ctx.lineTo(W, H);
            ctx.lineTo(splitX - 12, H);
            ctx.closePath(); ctx.clip();

            // ドラゴンロード（左向きで描画）
            const animFrame = t * 3;
            this.drawDragonLord(ctx, cx, cy, cw, ch, '#C62828', -1, animFrame);

            // 足元の炎オーラ（大きく脈動）
            const auraSize = 1 + Math.sin(t * 0.3) * 0.3;
            ctx.globalAlpha = (0.5 + Math.sin(t * 0.2) * 0.2) * charAlpha * alpha;
            const flameAura = ctx.createRadialGradient(W*0.79, H*0.9, 0, W*0.79, H*0.9, cw*0.55*auraSize);
            flameAura.addColorStop(0, 'rgba(255,100,0,0.85)');
            flameAura.addColorStop(0.4, 'rgba(200,30,0,0.5)');
            flameAura.addColorStop(1, 'rgba(150,0,0,0)');
            ctx.fillStyle = flameAura;
            ctx.beginPath();
            ctx.ellipse(W*0.79, H*0.9, cw*0.52*auraSize, H*0.07, 0, 0, Math.PI*2);
            ctx.fill();

            // 衝撃波リング（入場時: t=22-45）
            if (t > 22 && t < 48) {
                const ringP = (t - 22) / 26;
                ctx.globalAlpha = (1 - ringP) * charAlpha * alpha * 0.7;
                ctx.strokeStyle = '#FF4500';
                ctx.lineWidth = 4;
                ctx.beginPath();
                ctx.ellipse(W*0.79, H*0.72, cw*0.3*ringP*2.2, H*0.04*ringP*2, 0, 0, Math.PI*2);
                ctx.stroke();
                // 2つ目のリング（少し遅れて）
                if (t > 30 && t < 50) {
                    const r2p = (t - 30) / 20;
                    ctx.globalAlpha = (1 - r2p) * charAlpha * alpha * 0.4;
                    ctx.strokeStyle = '#FFD700';
                    ctx.lineWidth = 2;
                    ctx.beginPath();
                    ctx.ellipse(W*0.79, H*0.72, cw*0.4*r2p*2, H*0.05*r2p*1.8, 0, 0, Math.PI*2);
                    ctx.stroke();
                }
            }

            // 突進トレイル（frame < 12）
            if (frame < 12) {
                ctx.globalAlpha = (frame / 12) * 0.5;
                for (let i = 1; i <= 3; i++) {
                    ctx.globalAlpha = (frame / 12) * 0.3 / i;
                    this.drawDragonLord(ctx, cx + i * 20, cy + i * 5, cw, ch, '#FF4500', -1, animFrame);
                }
            }

            ctx.restore();
        }

        // ── 左パネル（名前＆技名）t=35から登場 ──
        if (t > 35) {
            const txtT = Math.min(1, (t - 35) / 22);
            const easeT = txtT * txtT * (3 - 2 * txtT);
            ctx.save();
            ctx.globalAlpha = alpha * easeT;

            const nameX = W * 0.05;
            const nameY = H * 0.26;
            const plateOffX = -(1 - easeT) * W * 0.5; // 左からスライドイン

            ctx.save();
            ctx.translate(plateOffX, 0);

            // キャラ名プレート（深紅）
            const plateBg = ctx.createLinearGradient(nameX, nameY - 18, nameX + W * 0.40, nameY + 20);
            plateBg.addColorStop(0, '#B71C1C');
            plateBg.addColorStop(1, '#7f0000');
            ctx.fillStyle = plateBg;
            ctx.beginPath();
            this._roundRect(ctx, nameX, nameY - 18, W * 0.40, 38, 4);
            ctx.fill();
            // プレート右の三角装飾
            ctx.beginPath();
            const rx = nameX + W * 0.40;
            ctx.moveTo(rx, nameY - 18);
            ctx.lineTo(rx + 12, nameY + 1);
            ctx.lineTo(rx, nameY + 20);
            ctx.closePath(); ctx.fill();

            // 光沢
            ctx.fillStyle = 'rgba(255,255,255,0.15)';
            ctx.beginPath();
            this._roundRect(ctx, nameX + 2, nameY - 16, W * 0.38, 16, 2);
            ctx.fill();

            ctx.font = 'bold 22px Arial';
            ctx.fillStyle = '#FFD700';
            ctx.textAlign = 'left';
            ctx.shadowColor = 'rgba(0,0,0,0.6)';
            _setShadowBlur(ctx, 5);
            ctx.fillText('ドラゴンロード', nameX + 10, nameY + 8);
            ctx.shadowBlur = 0;
            ctx.restore();

            // ── 技名テキスト（t=48からズームイン）──
            if (t > 48) {
                const skillT = Math.min(1, (t - 48) / 18);
                const skillEase = skillT < 0.5 ? 2 * skillT * skillT : 1 - Math.pow(-2 * skillT + 2, 2) / 2;
                const skillScale = 1 + (1 - skillEase) * 1.0; // 大→通常サイズ
                const skillY = H * 0.50;
                const skillCX = nameX + W * 0.20;

                // フラッシュ（t=55-72）
                const flashAlpha = (t > 55 && t < 72) ? Math.sin((t - 55) / 17 * Math.PI) * 0.5 : 0;

                ctx.save();
                ctx.globalAlpha = alpha * skillEase;
                ctx.translate(skillCX, skillY);
                ctx.scale(skillScale, skillScale);
                ctx.translate(-skillCX, -skillY);

                if (flashAlpha > 0) {
                    ctx.save();
                    ctx.globalAlpha = flashAlpha;
                    ctx.fillStyle = '#FF4500';
                    ctx.fillRect(nameX - 5, skillY - 50, W * 0.42, 75);
                    ctx.restore();
                }

                // 技名アウトライン
                ctx.font = 'bold italic 44px Arial';
                ctx.strokeStyle = '#200000';
                ctx.lineWidth = 9;
                ctx.textAlign = 'center';
                ctx.strokeText('覇竜炎', skillCX, skillY);

                // 技名グラデ
                const tg2 = ctx.createLinearGradient(skillCX - 80, skillY - 35, skillCX + 80, skillY + 10);
                tg2.addColorStop(0, flashAlpha > 0.3 ? '#FFFFFF' : '#FF4500');
                tg2.addColorStop(0.4, flashAlpha > 0.3 ? '#FFFF88' : '#FFD700');
                tg2.addColorStop(1, flashAlpha > 0.3 ? '#FFFFFF' : '#FF1500');
                ctx.fillStyle = tg2;
                ctx.fillText('覇竜炎', skillCX, skillY);

                // サブテキスト
                ctx.font = 'bold 19px Arial';
                ctx.fillStyle = 'rgba(255,180,80,0.95)';
                ctx.fillText('INFERNO  BURST', skillCX, skillY + 32);

                ctx.restore();

                // 区切り線（t=60から左から伸びる）
                if (t > 60) {
                    const lineT = Math.min(1, (t - 60) / 15);
                    ctx.save();
                    ctx.globalAlpha = alpha * lineT;
                    ctx.strokeStyle = 'rgba(200,50,0,0.7)';
                    ctx.lineWidth = 1.5;
                    ctx.beginPath();
                    ctx.moveTo(nameX, H * 0.63); ctx.lineTo(nameX + W * 0.40 * lineT, H * 0.63);
                    ctx.stroke();
                    ctx.restore();
                }

                // 効果説明（t=68から）
                if (t > 68) {
                    const descT = Math.min(1, (t - 68) / 12);
                    ctx.save();
                    ctx.globalAlpha = alpha * descT;
                    ctx.font = '14px Arial';
                    ctx.fillStyle = 'rgba(255,200,150,0.82)';
                    ctx.textAlign = 'left';
                    ctx.fillText('5方向炎弾＋敵タンクに炎', nameX + 6, H * 0.72);
                    ctx.fillText('全味方の攻撃力を強化！', nameX + 6, H * 0.77);
                    ctx.restore();
                }
            }

            ctx.restore();
        }

        // ── 炎の火花パーティクル（t=30-80）──
        if (t > 30 && t < 85) {
            ctx.save();
            for (let i = 0; i < 8; i++) {
                const seed = i * 211.3 + t * 0.7;
                const px = (seed * 0.45 % (W * 0.48)) + W * 0.03;
                const py = H * 0.75 - ((t - 30) * (0.5 + (seed % 1.5))) % (H * 0.6);
                const pr = 2 + (seed % 4);
                ctx.globalAlpha = alpha * (0.4 + Math.sin(seed) * 0.3);
                ctx.fillStyle = i % 3 === 0 ? '#FF6000' : (i % 3 === 1 ? '#FFD700' : '#FF2000');
                ctx.beginPath();
                ctx.arc(px, py, pr, 0, Math.PI * 2);
                ctx.fill();
            }
            ctx.restore();
        }

        // ── 斜めラインのキラリ光（境界）──
        if (easeSlide > 0.8) {
            const glowAlpha = alpha * 0.75 * Math.min(1, (easeSlide - 0.8) / 0.2);
            ctx.save();
            ctx.globalAlpha = glowAlpha;
            const grd = ctx.createLinearGradient(splitX - 5, 0, splitX + 22, 0);
            grd.addColorStop(0, 'rgba(255,100,0,0)');
            grd.addColorStop(0.5, 'rgba(255,150,50,0.95)');
            grd.addColorStop(1, 'rgba(255,100,0,0)');
            ctx.fillStyle = grd;
            ctx.beginPath();
            ctx.moveTo(splitX + H * 0.22 - 3, 0); ctx.lineTo(splitX + H * 0.22 + 20, 0);
            ctx.lineTo(splitX + 20, H); ctx.lineTo(splitX - 3, H);
            ctx.closePath(); ctx.fill();
            ctx.restore();
        }

        // ── コーナー装飾（t=55から）──
        if (t > 55) {
            const cornT = Math.min(1, (t - 55) / 12);
            ctx.save();
            ctx.globalAlpha = alpha * cornT * 0.7;
            ctx.fillStyle = '#FF4500';
            const cs = 20;
            // 左上
            ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(cs, 0); ctx.lineTo(0, cs); ctx.fill();
            // 左下
            ctx.beginPath(); ctx.moveTo(0, H); ctx.lineTo(cs, H); ctx.lineTo(0, H - cs); ctx.fill();
            ctx.restore();
        }

        ctx.restore();
    },


    // ============================================================
    // プラチナゴーレム 必殺技カットイン 【聖光天罰・DIVINE JUDGEMENT】
    // 妖怪ウォッチ風：左キャラ＋右ネームプレート、神聖な白金オーラ演出
    // ============================================================
    drawPlatinumSpecialCutin(ctx, W, H, frame) {
        const MAX = 110;
        const t = MAX - frame; // 0→110 経過フレーム
        const alpha = frame > (MAX - 8) ? (MAX - frame) / 8 : frame < 12 ? frame / 12 : 1.0;
        ctx.save();

        // ── Phase1: 背景（白銀→深紺グラデ）──
        const bgAlpha = Math.min(1, t / 16) * alpha;
        const bg = ctx.createLinearGradient(0, 0, 0, H);
        bg.addColorStop(0, '#0a0a1f');
        bg.addColorStop(0.4, '#141428');
        bg.addColorStop(1, '#1a1a3d');
        ctx.globalAlpha = bgAlpha * 0.97;
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, W, H);
        ctx.globalAlpha = 1;

        // ── 天から降り注ぐ光の柱（t=0-60）──
        if (t > 2) {
            const lightP = Math.min(1, (t - 2) / 40);
            ctx.save();
            ctx.globalAlpha = alpha * lightP * 0.45;
            for (let i = 0; i < 6; i++) {
                const lx = W * (0.08 + i * 0.17) + Math.sin(t * 0.07 + i) * 15;
                const lh = H * lightP * (0.5 + Math.sin(i * 1.3) * 0.3);
                const pillarGrd = ctx.createLinearGradient(lx, 0, lx, lh);
                pillarGrd.addColorStop(0, 'rgba(255,255,220,0.9)');
                pillarGrd.addColorStop(0.5, 'rgba(200,230,255,0.5)');
                pillarGrd.addColorStop(1, 'rgba(180,200,255,0)');
                ctx.fillStyle = pillarGrd;
                const lw = 18 + (i % 3) * 10;
                ctx.fillRect(lx - lw / 2, 0, lw, lh);
            }
            ctx.restore();
        }

        // ── Phase2: 斜めパネルスライドイン（t=18-52）──
        const slideT = Math.max(0, Math.min(1, (t - 18) / 34));
        const easeSlide = slideT < 0.5 ? 4 * slideT * slideT * slideT : 1 - Math.pow(-2 * slideT + 2, 3) / 2;
        const splitX = W * 0.56 * easeSlide;

        if (easeSlide > 0) {
            ctx.save();
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(splitX, 0);
            ctx.lineTo(splitX - H * 0.20, H);
            ctx.lineTo(0, H);
            ctx.closePath();
            const panelBg = ctx.createLinearGradient(0, 0, splitX, H);
            panelBg.addColorStop(0, '#1e2a3a');
            panelBg.addColorStop(1, '#0d1520');
            ctx.fillStyle = panelBg;
            ctx.globalAlpha = alpha;
            ctx.fill();
            ctx.restore();
        }

        // ── プラチナゴーレム描画（左パネル）──
        if (slideT > 0.25) {
            const charAlpha = Math.min(1, (slideT - 0.25) / 0.5);
            const shakeX = (t > 28 && t < 55) ? Math.sin(t * 1.9) * 3 * (1 - (t - 28) / 27) : 0;
            const shakeY = (t > 28 && t < 55) ? Math.cos(t * 2.5) * 2 * (1 - (t - 28) / 27) : 0;
            const zoomIn = slideT < 0.8 ? 1 + (1 - slideT) * 0.3 : 1.0;
            const charScale = frame < 14 ? 1 + (14 - frame) * 0.012 : 1.0;
            const finalScale = charScale * zoomIn;

            const cw = W * 0.44 * finalScale;
            const ch = H * 0.80 * finalScale;
            const cx = W * 0.22 - cw / 2 + shakeX;
            const cy = H * 0.5 - ch / 2 - H * 0.03 + shakeY;

            ctx.save();
            ctx.globalAlpha = alpha * charAlpha;

            // クリップ（左パネル内）
            ctx.beginPath();
            ctx.moveTo(0, 0); ctx.lineTo(splitX + 10, 0);
            ctx.lineTo(splitX - H * 0.20 + 10, H); ctx.lineTo(0, H);
            ctx.closePath(); ctx.clip();

            // プラチナゴーレム本体
            const animFrame = t * 3;
            this.drawPlatinumGolem(ctx, cx, cy, cw, ch, '#CFD8DC', 1, animFrame);

            // 足元の聖なるオーラ（白金、脈動）
            const auraSize = 1 + Math.sin(t * 0.28) * 0.22;
            ctx.globalAlpha = (0.45 + Math.sin(t * 0.25) * 0.2) * charAlpha * alpha;
            const auraGrd = ctx.createRadialGradient(W*0.22, H*0.9, 0, W*0.22, H*0.9, cw*0.5*auraSize);
            auraGrd.addColorStop(0, 'rgba(220,240,255,0.9)');
            auraGrd.addColorStop(0.4, 'rgba(150,200,255,0.45)');
            auraGrd.addColorStop(1, 'rgba(100,150,255,0)');
            ctx.fillStyle = auraGrd;
            ctx.beginPath();
            ctx.ellipse(W*0.22, H*0.9, cw*0.5*auraSize, H*0.07, 0, 0, Math.PI*2);
            ctx.fill();

            // 神聖リング（入場 t=20-45）
            if (t > 20 && t < 46) {
                const ringP = (t - 20) / 26;
                ctx.globalAlpha = (1 - ringP) * charAlpha * alpha * 0.75;
                ctx.strokeStyle = '#E3F2FD';
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.ellipse(W*0.22, H*0.7, cw*0.3*ringP*2, H*0.04*ringP*2, 0, 0, Math.PI*2);
                ctx.stroke();
                // 内側光輪
                if (t > 28 && t < 46) {
                    const r2 = (t - 28) / 18;
                    ctx.globalAlpha = (1 - r2) * charAlpha * alpha * 0.4;
                    ctx.strokeStyle = '#BBDEFB';
                    ctx.lineWidth = 1.5;
                    ctx.beginPath();
                    ctx.ellipse(W*0.22, H*0.7, cw*0.2*r2*2.5, H*0.035*r2*2, 0, 0, Math.PI*2);
                    ctx.stroke();
                }
            }
            ctx.restore();
        }

        // ── 右パネル（名前＆技名）t=32から ──
        if (t > 32) {
            const txtT = Math.min(1, (t - 32) / 22);
            const easeT = txtT * txtT * (3 - 2 * txtT);
            ctx.save();
            ctx.globalAlpha = alpha * easeT;

            const nameX = W * 0.56;
            const nameY = H * 0.26;
            const plateOffX = (1 - easeT) * W * 0.5; // 右からスライドイン

            ctx.save();
            ctx.translate(plateOffX, 0);

            // プレート（銀白グラデ）
            const plateBg = ctx.createLinearGradient(nameX, nameY-18, nameX + W*0.38, nameY+20);
            plateBg.addColorStop(0, '#455A64');
            plateBg.addColorStop(0.5, '#607D8B');
            plateBg.addColorStop(1, '#78909C');
            ctx.fillStyle = plateBg;
            ctx.beginPath();
            this._roundRect(ctx, nameX, nameY - 18, W * 0.38, 38, 4);
            ctx.fill();
            // 三角装飾
            ctx.beginPath();
            ctx.moveTo(nameX, nameY - 18);
            ctx.lineTo(nameX - 12, nameY + 1);
            ctx.lineTo(nameX, nameY + 20);
            ctx.closePath(); ctx.fill();
            // 光沢
            ctx.fillStyle = 'rgba(255,255,255,0.25)';
            ctx.beginPath();
            this._roundRect(ctx, nameX + 2, nameY - 16, W*0.36, 16, 2);
            ctx.fill();

            ctx.font = 'bold 22px Arial';
            ctx.fillStyle = '#E3F2FD';
            ctx.textAlign = 'left';
            ctx.shadowColor = 'rgba(100,180,255,0.8)';
            _setShadowBlur(ctx, 8);
            ctx.fillText('プラチナゴーレム', nameX + 10, nameY + 8);
            ctx.shadowBlur = 0;
            ctx.restore();

            // ── 技名テキスト（t=50からズームイン）──
            if (t > 50) {
                const skillT = Math.min(1, (t - 50) / 18);
                const skillEase = skillT < 0.5 ? 2 * skillT * skillT : 1 - Math.pow(-2 * skillT + 2, 2) / 2;
                const skillScale = 1 + (1 - skillEase) * 1.0;
                const skillY = H * 0.50;
                const skillCX = nameX + W * 0.19;

                // フラッシュ（t=58-75）白銀フラッシュ
                const flashAlpha = (t > 58 && t < 75) ? Math.sin((t - 58) / 17 * Math.PI) * 0.55 : 0;

                ctx.save();
                ctx.globalAlpha = alpha * skillEase;
                ctx.translate(skillCX, skillY);
                ctx.scale(skillScale, skillScale);
                ctx.translate(-skillCX, -skillY);

                if (flashAlpha > 0) {
                    ctx.save();
                    ctx.globalAlpha = flashAlpha;
                    ctx.fillStyle = '#B0BEC5';
                    ctx.fillRect(nameX - 5, skillY - 50, W*0.40, 75);
                    ctx.restore();
                }

                // 技名アウトライン
                ctx.font = 'bold italic 40px Arial';
                ctx.strokeStyle = '#001030';
                ctx.lineWidth = 9;
                ctx.textAlign = 'center';
                ctx.strokeText('聖光天罰', skillCX, skillY);

                // 技名グラデ（白→水色→白金）
                const tg = ctx.createLinearGradient(skillCX - 80, skillY - 35, skillCX + 80, skillY + 10);
                tg.addColorStop(0,   flashAlpha > 0.3 ? '#FFFFFF' : '#E3F2FD');
                tg.addColorStop(0.4, flashAlpha > 0.3 ? '#FFFDE7' : '#B3E5FC');
                tg.addColorStop(1,   flashAlpha > 0.3 ? '#FFFFFF' : '#CFD8DC');
                ctx.fillStyle = tg;
                ctx.fillText('聖光天罰', skillCX, skillY);

                // サブテキスト
                ctx.font = 'bold 17px Arial';
                ctx.fillStyle = 'rgba(200,230,255,0.92)';
                ctx.fillText('DIVINE  JUDGEMENT', skillCX, skillY + 32);

                ctx.restore();

                // 区切り線
                if (t > 63) {
                    const lineT = Math.min(1, (t - 63) / 14);
                    ctx.save();
                    ctx.globalAlpha = alpha * lineT;
                    ctx.strokeStyle = 'rgba(150,200,255,0.6)';
                    ctx.lineWidth = 1.5;
                    ctx.beginPath();
                    ctx.moveTo(nameX, H*0.63); ctx.lineTo(nameX + W*0.40*lineT, H*0.63);
                    ctx.stroke();
                    ctx.restore();
                }

                // 効果説明（t=70から）
                if (t > 70) {
                    const descT = Math.min(1, (t - 70) / 12);
                    ctx.save();
                    ctx.globalAlpha = alpha * descT;
                    ctx.font = '14px Arial';
                    ctx.fillStyle = 'rgba(200,230,255,0.82)';
                    ctx.textAlign = 'left';
                    ctx.fillText('聖なる光弾×7＋全体回復', nameX + 6, H*0.72);
                    ctx.fillText('味方全員のHPを回復！', nameX + 6, H*0.77);
                    ctx.restore();
                }
            }

            ctx.restore();
        }

        // ── 光の粒子が舞い上がる（t=28-90）──
        if (t > 28 && t < 92) {
            ctx.save();
            for (let i = 0; i < 9; i++) {
                const seed = i * 173.7 + t * 0.65;
                const px = (seed * 0.37 % (W * 0.50)) + W * 0.02;
                const py = H * 0.85 - ((t - 28) * (0.4 + (seed % 1.2))) % (H * 0.65);
                const pr = 1.5 + (seed % 3.5);
                ctx.globalAlpha = alpha * (0.35 + Math.sin(seed) * 0.3);
                ctx.fillStyle = i % 3 === 0 ? '#E3F2FD' : (i % 3 === 1 ? '#BBDEFB' : '#CFD8DC');
                ctx.beginPath();
                ctx.arc(px, py, pr, 0, Math.PI * 2);
                ctx.fill();
            }
            ctx.restore();
        }

        // ── 境界の輝き ──
        if (easeSlide > 0.8) {
            const glowAlpha = alpha * 0.8 * Math.min(1, (easeSlide - 0.8) / 0.2);
            ctx.save();
            ctx.globalAlpha = glowAlpha;
            const grd = ctx.createLinearGradient(splitX - 5, 0, splitX + 20, 0);
            grd.addColorStop(0, 'rgba(200,230,255,0)');
            grd.addColorStop(0.5, 'rgba(220,240,255,0.95)');
            grd.addColorStop(1, 'rgba(200,230,255,0)');
            ctx.fillStyle = grd;
            ctx.beginPath();
            ctx.moveTo(splitX + H*0.20 - 3, 0); ctx.lineTo(splitX + H*0.20 + 18, 0);
            ctx.lineTo(splitX + 18, H); ctx.lineTo(splitX - 3, H);
            ctx.closePath(); ctx.fill();
            ctx.restore();
        }

        // ── コーナー装飾（t=58から）──
        if (t > 58) {
            const cornT = Math.min(1, (t - 58) / 12);
            ctx.save();
            ctx.globalAlpha = alpha * cornT * 0.65;
            ctx.fillStyle = '#90CAF9';
            const cs = 18;
            // 四隅の三角
            [[0,0,cs,0,0,cs], [W,0,W-cs,0,W,cs], [0,H,cs,H,0,H-cs], [W,H,W-cs,H,W,H-cs]].forEach(([x1,y1,x2,y2,x3,y3]) => {
                ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.lineTo(x3,y3); ctx.closePath(); ctx.fill();
            });
            ctx.restore();
        }

        ctx.restore();
    },

    // ===================================================================
    // 👑 ゴッドキングスライム 連携技カットイン【神王裁断・DIVINE VERDICT】
    // frame: 120→0
    // Phase1 (120-95): 金色フラッシュ＆オールバック登場
    // Phase2 (95-55):  顔アップ＆技名パネル
    // Phase3 (55-20):  王冠から九連光弾が放たれる
    // Phase4 (20-0):   神聖爆発＆フェードアウト
    // ===================================================================
    drawGodKingSpecialCutin(ctx, W, H, frame) {
        const MAX = 120;
        const t = MAX - frame; // 0→120経過
        const alpha = frame > (MAX-10) ? (MAX-frame)/10 : frame < 12 ? frame/12 : 1.0;
        ctx.save();

        // ── 背景：神聖な白→金→黒のグラデ ──
        const bgA = Math.min(1, t/10) * alpha;
        const bg = ctx.createRadialGradient(W*0.5, H*0.3, 0, W*0.5, H*0.3, W);
        bg.addColorStop(0, '#FFFDE0');
        bg.addColorStop(0.25, '#3D2E00');
        bg.addColorStop(0.6, '#1A0D00');
        bg.addColorStop(1, '#000000');
        ctx.globalAlpha = bgA * 0.98;
        ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
        ctx.globalAlpha = 1;

        // ── 後光放射（神の光・16本）──
        if (t > 5 && t < 100) {
            const rayAlpha = Math.min(1,(t-5)/12) * alpha * 0.5;
            ctx.globalAlpha = rayAlpha;
            for (let r = 0; r < 16; r++) {
                const angle = (r/16)*Math.PI*2 + t*0.006;
                const len = W * 0.95;
                ctx.strokeStyle = r % 2 === 0
                    ? `hsl(${(r*22+t*2)%360},100%,75%)`
                    : 'rgba(255,248,220,0.6)';
                ctx.lineWidth = r % 2 === 0 ? 5 : 2.5;
                ctx.beginPath();
                ctx.moveTo(W*0.5, H*0.3);
                ctx.lineTo(W*0.5 + Math.cos(angle)*len, H*0.3 + Math.sin(angle)*len);
                ctx.stroke();
            }
            ctx.globalAlpha = 1;
        }

        // ── キャラ（ゴッドキング神様）──
        if (t > 12 && t < 108) {
            const slideIn = Math.min(1,(t-12)/20);
            const ease = 1 - Math.pow(1-slideIn, 3);
            const faceX = W*0.6 - (1-ease)*W*0.35;
            const faceY = H*0.32;
            const faceR = H*0.24 * ease;

            ctx.globalAlpha = ease * alpha;

            // 神聖オーラ（多層グロー）
            [2.2, 1.7, 1.3].forEach((mul, i) => {
                const aG = ctx.createRadialGradient(faceX, faceY, 0, faceX, faceY, faceR*mul);
                const hue = (t*4 + i*60) % 360;
                aG.addColorStop(0, `hsla(${hue},100%,80%,${0.25-i*0.07})`);
                aG.addColorStop(1, 'rgba(255,215,0,0)');
                ctx.fillStyle = aG;
                ctx.beginPath(); ctx.arc(faceX, faceY, faceR*mul, 0, Math.PI*2); ctx.fill();
            });

            // 後光（頭の後ろの円形後光）
            ctx.strokeStyle = `hsl(${(t*3)%360},100%,75%)`;
            ctx.lineWidth = faceR * 0.12;
            ctx.globalAlpha = ease * alpha * 0.7;
            ctx.beginPath(); ctx.arc(faceX, faceY, faceR*1.15, 0, Math.PI*2); ctx.stroke();
            ctx.globalAlpha = ease * alpha;

            // 体（神聖な白玉体）
            const bodyG = ctx.createRadialGradient(faceX-faceR*0.25, faceY-faceR*0.35, faceR*0.05, faceX, faceY, faceR);
            bodyG.addColorStop(0, '#FFFFFF');
            bodyG.addColorStop(0.3, '#FFFCE0');
            bodyG.addColorStop(0.7, '#FFD700');
            bodyG.addColorStop(1, '#6D5200');
            ctx.fillStyle = bodyG;
            ctx.beginPath(); ctx.arc(faceX, faceY, faceR, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = `hsl(${(t*5)%360},100%,70%)`; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.arc(faceX, faceY, faceR, 0, Math.PI*2); ctx.stroke();

            // 5本タワー神冠
            const crY = faceY - faceR*0.85;
            ctx.fillStyle = '#FFD700';
            [[0,1.1,'#FF1744'],[-faceR*0.28,0.75,'#29B6F6'],[faceR*0.28,0.75,'#29B6F6'],
             [-faceR*0.48,0.55,'#AB47BC'],[faceR*0.48,0.55,'#AB47BC']].forEach(([tx,h,gc]) => {
                const tH = faceR * 0.35 * h;
                ctx.fillStyle = '#FFD700';
                ctx.beginPath();
                ctx.moveTo(faceX+tx-faceR*0.08, crY);
                ctx.lineTo(faceX+tx, crY-tH);
                ctx.lineTo(faceX+tx+faceR*0.08, crY);
                ctx.closePath(); ctx.fill();
                ctx.fillStyle = gc;
                const gPulse = 0.7 + 0.3*Math.sin(t*0.15+tx);
                ctx.globalAlpha = ease * alpha * gPulse;
                ctx.beginPath(); ctx.arc(faceX+tx, crY-tH+faceR*0.03, faceR*0.07, 0, Math.PI*2); ctx.fill();
                ctx.globalAlpha = ease * alpha;
            });

            // 第三の目
            const teY = faceY - faceR*0.5;
            const tePulse = 0.5 + 0.5*Math.sin(t*0.25);
            ctx.fillStyle = `hsla(${(t*8)%360},100%,70%,${tePulse})`;
            ctx.beginPath(); ctx.arc(faceX, teY, faceR*0.13, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#FFF'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.arc(faceX, teY, faceR*0.13, 0, Math.PI*2); ctx.stroke();

            // 眉・目（金の瞳）
            ctx.strokeStyle = '#888'; ctx.lineWidth = faceR*0.055; ctx.lineCap='round';
            [-1,1].forEach(s => {
                ctx.beginPath();
                ctx.moveTo(faceX+s*faceR*0.06, faceY-faceR*0.28);
                ctx.lineTo(faceX+s*faceR*0.32, faceY-faceR*0.23+s*faceR*0.02);
                ctx.stroke();
                // 白目
                ctx.fillStyle='#FFF';
                ctx.beginPath();ctx.ellipse(faceX+s*faceR*0.24,faceY-faceR*0.13,faceR*0.11,faceR*0.085,0,0,Math.PI*2);ctx.fill();
                // 金の瞳
                const eG=ctx.createRadialGradient(faceX+s*faceR*0.24,faceY-faceR*0.13,0,faceX+s*faceR*0.24,faceY-faceR*0.13,faceR*0.07);
                eG.addColorStop(0,'#FFD700');eG.addColorStop(1,'#FF8C00');
                ctx.fillStyle=eG;
                ctx.beginPath();ctx.arc(faceX+s*faceR*0.24,faceY-faceR*0.13,faceR*0.07,0,Math.PI*2);ctx.fill();
            });

            // 白ひげ（神様）
            const bG=ctx.createLinearGradient(faceX, faceY+faceR*0.1, faceX, faceY+faceR*0.75);
            bG.addColorStop(0,'#FFFFFF'); bG.addColorStop(1,'rgba(220,220,220,0)');
            ctx.fillStyle=bG;
            ctx.beginPath();
            ctx.moveTo(faceX-faceR*0.18, faceY+faceR*0.08);
            ctx.quadraticCurveTo(faceX-faceR*0.25,faceY+faceR*0.45,faceX-faceR*0.1,faceY+faceR*0.75);
            ctx.quadraticCurveTo(faceX,faceY+faceR*0.8,faceX+faceR*0.1,faceY+faceR*0.75);
            ctx.quadraticCurveTo(faceX+faceR*0.25,faceY+faceR*0.45,faceX+faceR*0.18,faceY+faceR*0.08);
            ctx.quadraticCurveTo(faceX,faceY+faceR*0.16,faceX-faceR*0.18,faceY+faceR*0.08);
            ctx.fill();

            ctx.globalAlpha = 1;
        }

        // ── 技名パネル（左側）──
        if (t > 28 && t < 110) {
            const panelEase = Math.min(1,(t-28)/18);
            const panelX = W*0.03 - (1-panelEase)*W*0.35;
            ctx.globalAlpha = panelEase * alpha;

            // パネル背景（神聖グラデ）
            const panG = ctx.createLinearGradient(panelX, H*0.16, panelX+W*0.5, H*0.42);
            panG.addColorStop(0, 'rgba(80,50,0,0.96)');
            panG.addColorStop(0.5, 'rgba(30,20,0,0.94)');
            panG.addColorStop(1, 'rgba(60,40,0,0.9)');
            ctx.fillStyle = panG;
            Renderer._roundRect(ctx, panelX, H*0.16, W*0.5, H*0.22, 12); ctx.fill();
            // 金枠
            const borderG = ctx.createLinearGradient(panelX, 0, panelX+W*0.5, 0);
            borderG.addColorStop(0,'#B8860B'); borderG.addColorStop(0.5,'#FFD700'); borderG.addColorStop(1,'#B8860B');
            ctx.strokeStyle = borderG; ctx.lineWidth = 3;
            Renderer._roundRect(ctx, panelX, H*0.16, W*0.5, H*0.22, 12); ctx.stroke();

            // 技名（神聖な光文字）
            const techScale = t > 60 ? (1 + (t-60)*0.035) : 1;
            ctx.save();
            ctx.translate(panelX + W*0.25, H*0.245);
            ctx.scale(techScale, techScale);
            ctx.font = 'bold italic 30px Arial';
            ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            // グロー
            ctx.shadowColor = '#FFD700'; ctx.shadowBlur = 18;
            ctx.strokeStyle = '#2A1500'; ctx.lineWidth = 7;
            ctx.strokeText('神王裁断', 0, 0);
            const tg = ctx.createLinearGradient(-90,-18,90,18);
            tg.addColorStop(0,'#FFD700'); tg.addColorStop(0.4,'#FFFFFF'); tg.addColorStop(1,'#FFB300');
            ctx.fillStyle = tg; ctx.fillText('神王裁断', 0, 0);
            ctx.shadowBlur = 0;
            ctx.restore();

            // サブタイトル
            ctx.font = 'bold 14px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.fillStyle = `hsla(${(t*4)%360},100%,80%,0.9)`;
            ctx.fillText('✨ DIVINE VERDICT ✨', panelX + W*0.25, H*0.33);

            // 装飾ライン
            ctx.strokeStyle = 'rgba(255,215,0,0.4)'; ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(panelX+W*0.04, H*0.355); ctx.lineTo(panelX+W*0.46, H*0.355); ctx.stroke();

            ctx.globalAlpha = 1;
        }

        // ── 神聖光弾散布エフェクト ──
        if (t > 52 && t < 102) {
            const prog = (t - 52) / 50;
            for (let r = 0; r < 9; r++) {
                const angle = (r/9)*Math.PI*2;
                const dist = prog * W * 0.65;
                const bx = W*0.6 + Math.cos(angle)*dist;
                const by = H*0.3 + Math.sin(angle)*dist*0.45;
                const hue = (r*40+t*3)%360;
                const sz2 = 12*(1-prog*0.5);
                ctx.globalAlpha = (1-prog)*alpha*0.9;
                // グロー
                ctx.fillStyle = `hsla(${hue},100%,80%,0.4)`;
                ctx.beginPath(); ctx.arc(bx, by, sz2*2.2, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = `hsl(${hue},100%,70%)`;
                ctx.beginPath(); ctx.arc(bx, by, sz2, 0, Math.PI*2); ctx.fill();
            }
            ctx.globalAlpha = 1;
        }

        // ── 神聖爆発リング（フィナーレ）──
        if (t > 90 && frame < 28) {
            const phase = (28 - frame) / 28;
            [W*0.65, W*0.42, W*0.22, W*0.08].forEach((maxR, i) => {
                const hue = (i*45+t*5) % 360;
                ctx.globalAlpha = (1-phase) * alpha * (0.7-i*0.12);
                ctx.strokeStyle = i===0 ? '#FFFFFF' : `hsl(${hue},100%,75%)`;
                ctx.lineWidth = Math.max(0.5, (8-i*2)*(1-phase));
                ctx.beginPath(); ctx.arc(W*0.6, H*0.3, phase*maxR, 0, Math.PI*2); ctx.stroke();
            });
            ctx.globalAlpha = 1;
        }

        ctx.restore();
    },

    // 👑 スライム王 連携技カットイン
    drawSlimeKingGodSpecialCutin(ctx, W, H, frame) {
        const MAX = 120;
        const t = MAX - frame; // 0→120
        const alpha = frame > (MAX-10) ? (MAX-frame)/10 : frame < 12 ? frame/12 : 1.0;
        ctx.save();

        // ── 背景：金×黒グラデ ──
        const bgA = Math.min(1, t/12) * alpha;
        const bg = ctx.createLinearGradient(0, 0, W, H);
        bg.addColorStop(0, '#1A1000');
        bg.addColorStop(0.4, '#3D2E00');
        bg.addColorStop(1, '#0A0800');
        ctx.globalAlpha = bgA * 0.97;
        ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
        ctx.globalAlpha = 1;

        // ── 放射光（神の威光）──
        if (t > 8 && t < 95) {
            const rayCount = 12;
            const rayAlpha = Math.min(1,(t-8)/15) * alpha * 0.35;
            ctx.globalAlpha = rayAlpha;
            for (let r = 0; r < rayCount; r++) {
                const angle = (r/rayCount)*Math.PI*2 + t*0.008;
                const len = W * 0.85;
                ctx.strokeStyle = r%2===0 ? '#FFD700' : '#FFF8DC';
                ctx.lineWidth = 4;
                ctx.beginPath();
                ctx.moveTo(W*0.62, H*0.3);
                ctx.lineTo(W*0.62 + Math.cos(angle)*len, H*0.3 + Math.sin(angle)*len);
                ctx.stroke();
            }
            ctx.globalAlpha = 1;
        }

        // ── Phase2/3: キャラ顔（ゴッドキングスライム）──
        if (t > 15 && t < 105) {
            const slideIn = Math.min(1,(t-15)/22);
            const ease = 1 - Math.pow(1-slideIn, 3);
            const faceX = W*0.62 - (1-ease)*W*0.3;
            const faceY = H*0.3;
            const faceR = Math.min(H*0.26, H*0.26*ease);

            ctx.globalAlpha = ease * alpha;

            // オーラ
            const aG = ctx.createRadialGradient(faceX, faceY, 0, faceX, faceY, faceR*1.7);
            aG.addColorStop(0, 'rgba(255,215,0,0.5)');
            aG.addColorStop(0.5, 'rgba(255,180,0,0.15)');
            aG.addColorStop(1, 'rgba(255,215,0,0)');
            ctx.fillStyle = aG;
            ctx.beginPath(); ctx.arc(faceX, faceY, faceR*1.7, 0, Math.PI*2); ctx.fill();

            // 体
            const bodyG = ctx.createRadialGradient(faceX-faceR*0.2, faceY-faceR*0.3, faceR*0.05, faceX, faceY, faceR);
            bodyG.addColorStop(0, '#FFFDE7');
            bodyG.addColorStop(0.4, '#FFD700');
            bodyG.addColorStop(1, '#6D5200');
            ctx.fillStyle = bodyG;
            ctx.beginPath(); ctx.arc(faceX, faceY, faceR, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = `hsl(${(t*3)%360},100%,65%)`; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.arc(faceX, faceY, faceR, 0, Math.PI*2); ctx.stroke();

            // 王冠
            const cr = faceR;
            const crY = faceY - cr*0.82;
            ctx.fillStyle = '#FFD700';
            ctx.beginPath();
            ctx.moveTo(faceX - cr*0.5, crY);
            ctx.lineTo(faceX - cr*0.5, crY - cr*0.22);
            ctx.lineTo(faceX - cr*0.2, crY - cr*0.42);
            ctx.lineTo(faceX,           crY - cr*0.58);
            ctx.lineTo(faceX + cr*0.2, crY - cr*0.42);
            ctx.lineTo(faceX + cr*0.5, crY - cr*0.22);
            ctx.lineTo(faceX + cr*0.5, crY);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#B8860B'; ctx.lineWidth = 2; ctx.stroke();
            // 王冠宝石
            [[0,'#FF1744'],[- cr*0.3,'#29B6F6'],[cr*0.3,'#76FF03']].forEach(([ox,c]) => {
                ctx.fillStyle = c;
                ctx.beginPath(); ctx.arc(faceX+ox, crY-cr*0.12, cr*0.08, 0, Math.PI*2); ctx.fill();
            });

            // 眉・目・ヒゲ（シンプル版）
            ctx.strokeStyle = '#444'; ctx.lineWidth = faceR*0.06; ctx.lineCap='round';
            [-1,1].forEach(s => {
                ctx.beginPath();
                ctx.moveTo(faceX+s*cr*0.08, faceY-cr*0.28);
                ctx.lineTo(faceX+s*cr*0.32, faceY-cr*0.24+s*cr*0.03);
                ctx.stroke();
            });
            ctx.fillStyle='#FFF';
            [-1,1].forEach(s=>{ctx.beginPath();ctx.ellipse(faceX+s*cr*0.26,faceY-cr*0.14,cr*0.1,cr*0.08,0,0,Math.PI*2);ctx.fill();});
            ctx.fillStyle='#3E2000';
            [-1,1].forEach(s=>{ctx.beginPath();ctx.arc(faceX+s*cr*0.28,faceY-cr*0.14,cr*0.055,0,Math.PI*2);ctx.fill();});
            ctx.fillStyle='#E0E0E0';
            [-1,1].forEach(s=>{
                ctx.beginPath();
                ctx.moveTo(faceX+s*cr*0.03,faceY+cr*0.02);
                ctx.quadraticCurveTo(faceX+s*cr*0.25,faceY+cr*0.03,faceX+s*cr*0.28,faceY+cr*0.1);
                ctx.quadraticCurveTo(faceX+s*cr*0.18,faceY+cr*0.1,faceX+s*cr*0.03,faceY+cr*0.02);
                ctx.fill();
            });

            ctx.globalAlpha = 1;
        }

        // ── 技名パネル（左側）──
        if (t > 30 && t < 108) {
            const panelEase = Math.min(1,(t-30)/20);
            const panelX = W*0.04 - (1-panelEase)*W*0.3;
            ctx.globalAlpha = panelEase * alpha;

            // パネル背景
            const panG = ctx.createLinearGradient(panelX, H*0.18, panelX+W*0.46, H*0.18);
            panG.addColorStop(0, 'rgba(100,70,0,0.95)');
            panG.addColorStop(1, 'rgba(40,28,0,0.85)');
            ctx.fillStyle = panG;
            Renderer._roundRect(ctx, panelX, H*0.18, W*0.46, H*0.18, 10); ctx.fill();
            ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 2.5;
            Renderer._roundRect(ctx, panelX, H*0.18, W*0.46, H*0.18, 10); ctx.stroke();

            // 技名
            const techScale = t > 62 ? (1+(t-62)*0.04) : 1;
            ctx.save();
            ctx.translate(panelX + W*0.23, H*0.27);
            ctx.scale(techScale, techScale);
            ctx.font = 'bold italic 28px Arial';
            ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.strokeStyle = '#3D2000'; ctx.lineWidth = 6;
            ctx.strokeText('神王裁断', 0, 0);
            const tg2 = ctx.createLinearGradient(-80, -15, 80, 15);
            tg2.addColorStop(0,'#FFD700'); tg2.addColorStop(0.5,'#FFFFF0'); tg2.addColorStop(1,'#FFB300');
            ctx.fillStyle = tg2; ctx.fillText('神王裁断', 0, 0);
            ctx.restore();

            // サブタイトル
            ctx.font = 'bold 16px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.fillStyle = 'rgba(255,220,100,0.9)';
            ctx.fillText('DIVINE VERDICT', panelX + W*0.23, H*0.32);

            ctx.globalAlpha = 1;
        }

        // ── Phase3: 光弾放射エフェクト ──
        if (t > 55 && t < 100) {
            const prog = (t - 55) / 45;
            const dist = prog * W * 0.6;
            for (let r = 0; r < 9; r++) {
                const angle = (r/9)*Math.PI*2;
                const bx = W*0.62 + Math.cos(angle)*dist;
                const by = H*0.3 + Math.sin(angle)*dist*0.5;
                const hue = (r*40)%360;
                ctx.globalAlpha = (1-prog)*alpha*0.85;
                ctx.fillStyle = `hsl(${hue},100%,65%)`;
                ctx.beginPath(); ctx.arc(bx, by, 10*(1-prog*0.5), 0, Math.PI*2); ctx.fill();
            }
            ctx.globalAlpha = 1;
        }

        // ── Phase4: 神聖爆発 ──
        if (t > 88 && frame < 30) {
            const phase = (30 - frame) / 30;
            ctx.globalAlpha = (1 - phase) * alpha * 0.7;
            const rings = [
                { r: phase*W*0.6, c:'#FFD700', lw:10*(1-phase) },
                { r: phase*W*0.4, c:'#FFF8DC', lw:6*(1-phase) },
                { r: phase*W*0.2, c:'#FFF',    lw:3*(1-phase) },
            ];
            for (const ring of rings) {
                ctx.strokeStyle = ring.c; ctx.lineWidth = Math.max(0.5, ring.lw);
                ctx.beginPath(); ctx.arc(W*0.62, H*0.3, ring.r, 0, Math.PI*2); ctx.stroke();
            }
            ctx.globalAlpha = 1;
        }

        ctx.restore();
    },


    drawSlimeRush(ctx, W, H, frame) {
        // Draw many small slimes flying from left to right
        const count = 30;
        for (let i = 0; i < count; i++) {
            // Pseudo-random based on index and frame
            const seed = i * 137.5;
            const speed = 15 + (seed % 10);
            const x = ((frame * speed) + seed * 10) % (W + 200) - 100;
            const y = (seed % (H * 0.6)) + H * 0.1; // Upper screen area mostly

            // Only draw if on screen
            if (x > -50 && x < W + 50) {
                const size = 30 + (seed % 30);
                const color = (seed % 2 > 1) ? '#44AAFF' : ((seed % 3 > 2) ? '#FF8844' : '#4CAF50'); // Random colors
                const dark = this._darkenHex(color, 20);

                this.drawSlime(ctx, x, y, size, size, color, dark, 1, frame + i);

                // Trail
                ctx.fillStyle = `rgba(255,255,255,0.3)`;
                ctx.beginPath();
                ctx.ellipse(x - 20, y + size / 2, 30, 10, 0, 0, Math.PI * 2);
                ctx.fill();
            }
        }
    },

    // === INVASION GIMMICKS ===
    drawSecuritySwitch(ctx, x, y, w, h, activated, label) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        const t = _getFrameNow();

        // === 外側グロー（未起動: 赤点滅 / 起動: 緑パルス）===
        const glowAlpha = activated
            ? 0.25 + Math.sin(t * 0.004) * 0.15
            : 0.15 + Math.sin(t * 0.008) * 0.15;
        const glowColor = activated ? 'rgba(76,175,80,' : 'rgba(231,76,60,';
        ctx.fillStyle = glowColor + glowAlpha + ')';
        ctx.beginPath(); ctx.arc(0, 0, w * 0.85, 0, Math.PI * 2); ctx.fill();

        // === ベース（メタリックボックス）===
        const bgGrad = ctx.createLinearGradient(-w/2, -h/2, w/2, h/2);
        bgGrad.addColorStop(0, '#555');
        bgGrad.addColorStop(0.5, '#3A3A3A');
        bgGrad.addColorStop(1, '#222');
        ctx.fillStyle = bgGrad;
        this._roundRect(ctx, -w / 2, -h / 2, w, h, 5);
        ctx.fill();
        ctx.strokeStyle = activated ? '#4CAF50' : '#E74C3C';
        ctx.lineWidth = 2;
        this._roundRect(ctx, -w / 2, -h / 2, w, h, 5);
        ctx.stroke();

        // === スイッチスロット ===
        ctx.fillStyle = '#0A0A0A';
        ctx.fillRect(-w * 0.18, -h * 0.28, w * 0.36, h * 0.56);

        // === レバー ===
        const leverLen = h * 0.45;
        const angle = activated ? -Math.PI * 0.22 : Math.PI * 0.22;
        const lx = Math.sin(angle) * leverLen;
        const ly = Math.cos(angle) * leverLen;
        ctx.strokeStyle = activated ? '#81C784' : '#EF5350';
        ctx.lineWidth = 4;
        ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(lx, ly); ctx.stroke();

        // === ノブ（起動時はチェックアイコン）===
        ctx.fillStyle = activated ? '#4CAF50' : '#C0392B';
        ctx.beginPath(); ctx.arc(lx, ly, 7, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = activated ? '#A5D6A7' : '#EF5350'; ctx.lineWidth = 1.5; ctx.stroke();
        // ハイライト
        ctx.fillStyle = 'rgba(255,255,255,0.45)';
        ctx.beginPath(); ctx.arc(lx - 2, ly - 2, 2.5, 0, Math.PI * 2); ctx.fill();

        // 起動済みなら中央にチェックマーク
        if (activated) {
            ctx.strokeStyle = '#FFF'; ctx.lineWidth = 2.5; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
            ctx.beginPath();
            ctx.moveTo(-4, 0); ctx.lineTo(-1, 4); ctx.lineTo(6, -4);
            ctx.stroke();
        }

        // === ラベル ===
        ctx.font = 'bold 11px Arial';
        ctx.textAlign = 'center';
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.fillText(label, 1, h / 2 + 14);
        ctx.fillStyle = activated ? '#81C784' : '#EF5350';
        ctx.fillText(label, 0, h / 2 + 13);

        ctx.restore();
    },

    drawBarrier(ctx, x, y, w, h) {
        ctx.save();
        // ★バグ修正: _getFrameNow()はDate.now()を返すため * 0.003 でゆっくりした脈動に
        const pulse = 0.35 + Math.sin(_getFrameNow() * 0.003) * 0.2;
        const alpha = pulse * 0.85;

        // クリップ領域を設定してはみ出し防止
        ctx.save();
        this._roundRect(ctx, x - 2, y - 2, w + 4, h + 4, 12);
        ctx.clip();

        // ハニカム（六角形）パターン描画
        const hexR = 12; // 六角形の半径
        const hexW = hexR * Math.sqrt(3);
        const hexH = hexR * 2;
        ctx.strokeStyle = `rgba(0,220,255,${alpha * 0.7})`;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        for (let row = -1; row * hexH * 0.75 < h + hexH; row++) {
            for (let col = -1; col * hexW < w + hexW; col++) {
                const hx = x + col * hexW + (row % 2 === 0 ? 0 : hexW / 2);
                const hy = y + row * hexH * 0.75;
                ctx.moveTo(hx + hexR, hy);
                for (let i = 1; i <= 6; i++) {
                    const a = (Math.PI / 3) * i;
                    ctx.lineTo(hx + hexR * Math.cos(a), hy + hexR * Math.sin(a));
                }
            }
        }
        ctx.stroke();
        ctx.restore();

        // 外側フィル（半透明シアン）
        ctx.fillStyle = `rgba(0, 200, 255, ${pulse * 0.18})`;
        this._roundRect(ctx, x, y, w, h, 10);
        ctx.fill();

        // アウトライン（脈動）
        ctx.strokeStyle = `rgba(0, 200, 255, ${alpha})`;
        ctx.lineWidth = 2.5;
        this._roundRect(ctx, x, y, w, h, 10);
        ctx.stroke();

        ctx.restore();
    },

    drawDragonNinja(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        const floatY = Math.sin(frame * 0.15) * 3;
        ctx.translate(0, floatY);

        // Wings
        ctx.fillStyle = '#C62828';
        ctx.beginPath();
        ctx.moveTo(-w / 2, 0); ctx.lineTo(-w, -h / 2); ctx.lineTo(-w / 2, -h / 4); ctx.fill();
        ctx.beginPath();
        ctx.moveTo(w / 2, 0); ctx.lineTo(w, -h / 2); ctx.lineTo(w / 2, -h / 4); ctx.fill();

        // Body
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(0, 0, w / 2, 0, Math.PI * 2);
        ctx.fill();

        // Horns
        ctx.fillStyle = '#333';
        ctx.beginPath(); ctx.moveTo(-10, -10); ctx.lineTo(-15, -20); ctx.lineTo(-5, -12); ctx.fill();
        ctx.beginPath(); ctx.moveTo(10, -10); ctx.lineTo(15, -20); ctx.lineTo(5, -12); ctx.fill();

        // Ninja Scarf
        ctx.fillStyle = '#D32F2F';
        const scarfX = Math.sin(frame * 0.2) * 20 - 10;
        ctx.beginPath();
        ctx.moveTo(-w / 2, 5); ctx.lineTo(-w / 2 - 25, 5 + scarfX); ctx.lineTo(-w / 2, 12); ctx.fill();

        // Eyes (Sharp)
        ctx.fillStyle = '#FFF';
        ctx.beginPath(); ctx.ellipse(-8, -2, 6, 2, 0.2, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(8, -2, 6, 2, -0.2, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#FF0000';
        ctx.beginPath(); ctx.arc(-8, -2, 2, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(8, -2, 2, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
    },
    drawAngelGolem(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // Body (Stony)
        ctx.fillStyle = '#795548';
        this._roundRect(ctx, -w / 2, -h / 2, w, h, 8);
        ctx.fill();
        ctx.strokeStyle = '#5D4037';
        ctx.lineWidth = 3;
        ctx.stroke();

        // Angel Wings
        ctx.fillStyle = '#FFF';
        const wingW = Math.sin(frame * 0.1) * 10;
        ctx.beginPath(); ctx.ellipse(-w / 2 - 10, -5, 15 + wingW, 8, -0.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(w / 2 + 10, -5, 15 + wingW, 8, 0.5, 0, Math.PI * 2); ctx.fill();

        // Halo
        ctx.strokeStyle = '#FFEB3B';
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.ellipse(0, -h / 2 - 15, 15, 5, 0, 0, Math.PI * 2); ctx.stroke();

        // Eyes (Glowing)
        ctx.fillStyle = '#00BCD4';

        ctx.fillRect(-12, -8, 6, 4);
        ctx.fillRect(6, -8, 6, 4);
        ctx.restore();
    },

    drawLegendMetal(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // Metallic Glow

        ctx.fillStyle = '#B0BEC5';
        ctx.beginPath(); ctx.arc(0, 0, w / 2, 0, Math.PI * 2); ctx.fill();

        // Golden Crown (Majestic)
        ctx.fillStyle = '#FFD700';
        ctx.beginPath();
        ctx.moveTo(-w / 2, -h / 3); ctx.lineTo(-w / 2 - 5, -h); ctx.lineTo(-w / 4, -h / 1.5);
        ctx.lineTo(0, -h - 5); ctx.lineTo(w / 4, -h / 1.5); ctx.lineTo(w / 2 + 5, -h);
        ctx.lineTo(w / 2, -h / 3); ctx.fill();

        // Face (Wise eyes)
        ctx.fillStyle = '#333';
        ctx.beginPath(); ctx.arc(-7, -3, 3, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(7, -3, 3, 0, Math.PI * 2); ctx.fill();
        // Eyebrows (Elder look)
        ctx.strokeStyle = '#555';
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(-11, -9); ctx.lineTo(-4, -7);
        ctx.moveTo(11, -9);  ctx.lineTo(4, -7);
        ctx.stroke();
        ctx.restore();
    },

    // === 秘密コマンド・配合キャラの描画関数 ===

    drawAngelSeraph(ctx, x, y, w, h, color, dir, frame) {
        // セラフィム: 天使の上位種、6枚翼
        this.drawAngel(ctx, x, y, w, h, color, dir, frame);
        // Extra wings
        ctx.save(); ctx.translate(x + w / 2, y + h / 2); ctx.scale(dir, 1);
        ctx.globalAlpha = 0.5;
        for (let i = 0; i < 2; i++) {
            const side = i === 0 ? 1 : -1;
            ctx.fillStyle = '#FFD700';
            ctx.beginPath(); ctx.moveTo(0, 0);
            ctx.lineTo(side * w * 0.9, -h * 0.3); ctx.lineTo(side * w * 0.7, h * 0.2);
            ctx.fill();
        }
        ctx.globalAlpha = 0.4 + Math.sin(frame * 0.08) * 0.2;
        ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(0, -h * 0.6, w * 0.25, 0, Math.PI * 2); ctx.stroke();
        ctx.restore();
    },

    drawUltimate(ctx, x, y, w, h, color, dir, frame) {
        // アルティメットスライム: 全形態の合体・虹色マグナム
        ctx.save(); ctx.translate(x + w / 2, y + h / 2); ctx.scale(dir, 1);
        const hue = (frame * 4) % 360;
        // Outer glow rings
        for (let i = 3; i >= 0; i--) {
            ctx.globalAlpha = 0.15;
            ctx.fillStyle = `hsl(${(hue + i * 30) % 360}, 100%, 60%)`;
            ctx.beginPath(); ctx.arc(0, 0, w / 2 + i * 5, 0, Math.PI * 2); ctx.fill();
        }
        ctx.globalAlpha = 1;
        ctx.fillStyle = color;
        ctx.beginPath(); ctx.arc(0, 0, w / 2, 0, Math.PI * 2); ctx.fill();
        // Star crown
        ctx.fillStyle = '#FFD700'; ctx.font = `${w * 0.45}px Arial`;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('★', 0, 0);
        ctx.restore();
    },

    // === 配合専用キャラクターの描画関数 ===

    // シャドウメイジ (ニンジャ + 魔法使い): 暗黒のローブ、影のオーラ、紫の炎眼
    drawShadowMage(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        const floatY = Math.sin(frame * 0.08) * 4;
        ctx.translate(0, floatY);

        // 影のオーラ（脈動）
        const auraAlpha = 0.2 + Math.sin(frame * 0.12) * 0.1;
        for (let i = 3; i >= 1; i--) {
            ctx.globalAlpha = auraAlpha / i;
            ctx.fillStyle = '#5E35B1';
            ctx.beginPath();
            ctx.arc(0, 0, w / 2 + i * 6, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.globalAlpha = 1;

        // 体（ダークローブ）
        ctx.fillStyle = '#1A0030';
        ctx.beginPath();
        ctx.arc(0, 0, w / 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#5E35B1';
        ctx.lineWidth = 2;
        ctx.stroke();

        // ローブの裾（三角）
        ctx.fillStyle = '#2D1B5A';
        for (let i = -1; i <= 1; i++) {
            ctx.beginPath();
            ctx.moveTo(i * w * 0.3, h * 0.3);
            ctx.lineTo(i * w * 0.5, h * 0.7 + Math.sin(frame * 0.1 + i) * 3);
            ctx.lineTo((i + (i >= 0 ? 0.5 : -0.5)) * w * 0.3, h * 0.35);
            ctx.fill();
        }

        // フード（忍者頭巾風）
        ctx.fillStyle = '#0D001A';
        ctx.beginPath();
        ctx.arc(0, -h * 0.1, w * 0.42, Math.PI, 0);
        ctx.fill();
        // 額の符（魔法紋様）
        ctx.fillStyle = '#CE93D8';
        ctx.font = `bold ${w * 0.25}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('魔', 0, -h * 0.1);

        // 瞳（紫炎）
        const eyeGlow = 0.7 + Math.sin(frame * 0.15) * 0.3;
        ctx.globalAlpha = eyeGlow;
        ctx.fillStyle = '#CE93D8';
        ctx.beginPath(); ctx.ellipse(-8, 2, 5, 3, 0, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(8, 2, 5, 3, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath(); ctx.arc(-8, 2, 2, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(8, 2, 2, 0, Math.PI * 2); ctx.fill();
        ctx.globalAlpha = 1;

        // 手裏剣（周囲に浮遊）
        ctx.fillStyle = '#B0BEC5';
        for (let i = 0; i < 4; i++) {
            const ang = frame * 0.07 + i * Math.PI / 2;
            const sx = Math.cos(ang) * w * 0.75;
            const sy = Math.sin(ang) * w * 0.55;
            ctx.save();
            ctx.translate(sx, sy);
            ctx.rotate(ang * 2);
            ctx.beginPath();
            ctx.moveTo(0, -5); ctx.lineTo(2, -1); ctx.lineTo(5, 0);
            ctx.lineTo(1, 2); ctx.lineTo(0, 5); ctx.lineTo(-2, 1);
            ctx.lineTo(-5, 0); ctx.lineTo(-1, -2);
            ctx.closePath();
            ctx.fill();
            ctx.restore();
        }
        ctx.restore();
    },

    // スティールニンジャ (メタルスライム + ニンジャ): 鋼鉄の鎧忍者、クロームボディ
    drawSteelNinja(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        const bounce = Math.abs(Math.sin(frame * 0.15)) * 2;

        // 金属光沢ボディ
        const grad = ctx.createRadialGradient(-w * 0.2, -h * 0.2, 1, 0, 0, w * 0.55);
        grad.addColorStop(0, '#ECEFF1');
        grad.addColorStop(0.5, '#90A4AE');
        grad.addColorStop(1, '#455A64');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(0, bounce * 0.3, w / 2, 0, Math.PI * 2);
        ctx.fill();

        // 鎧プレート（胸当て）
        ctx.fillStyle = '#546E7A';
        ctx.strokeStyle = '#B0BEC5';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-w * 0.3, -h * 0.05);
        ctx.lineTo(w * 0.3, -h * 0.05);
        ctx.lineTo(w * 0.2, h * 0.25);
        ctx.lineTo(-w * 0.2, h * 0.25);
        ctx.closePath();
        ctx.fill(); ctx.stroke();

        // 頭巾（忍者マスク）
        ctx.fillStyle = '#37474F';
        ctx.beginPath();
        ctx.arc(0, -h * 0.05 + bounce * 0.3, w * 0.42, Math.PI, 0);
        ctx.fill();

        // 目（細いスリット）
        ctx.fillStyle = '#B0BEC5';
        ctx.fillRect(-10, -h * 0.18 + bounce * 0.3, 20, 3);
        // スリットのハイライト
        ctx.fillStyle = '#E0F2F1';
        ctx.fillRect(-8, -h * 0.18 + bounce * 0.3, 6, 1);
        ctx.fillRect(2, -h * 0.18 + bounce * 0.3, 6, 1);

        // 手裏剣（腰に装備）
        ctx.fillStyle = '#CFD8DC';
        ctx.strokeStyle = '#546E7A';
        ctx.lineWidth = 1;
        for (let side = -1; side <= 1; side += 2) {
            ctx.save();
            ctx.translate(side * w * 0.48, h * 0.1);
            ctx.rotate(Math.PI / 4 + frame * 0.03 * side);
            ctx.beginPath();
            ctx.moveTo(0, -6); ctx.lineTo(2, -1); ctx.lineTo(6, 0);
            ctx.lineTo(1, 2); ctx.lineTo(0, 6); ctx.lineTo(-2, 1);
            ctx.lineTo(-6, 0); ctx.lineTo(-1, -2);
            ctx.closePath();
            ctx.fill(); ctx.stroke();
            ctx.restore();
        }

        // クロームの反射ライン
        ctx.globalAlpha = 0.4;
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(-w * 0.1, -h * 0.15, w * 0.25, Math.PI * 1.1, Math.PI * 1.7);
        ctx.stroke();
        ctx.globalAlpha = 1;
        ctx.restore();
    },

    // ウォーマシン (ドローン + ボス): 重装甲メカ、砲台付き
    drawWarMachine(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        const rumble = Math.sin(frame * 0.3) * 1;

        // 脚部（キャタピラ）
        ctx.fillStyle = '#212121';
        ctx.fillRect(-w * 0.55, h * 0.2 + rumble, w * 1.1, h * 0.3);
        // キャタピラのコマ
        ctx.fillStyle = '#424242';
        for (let i = -3; i <= 3; i++) {
            ctx.fillRect(i * w * 0.16 - 4, h * 0.22 + rumble, 8, h * 0.25);
        }

        // メインボディ（装甲）
        ctx.fillStyle = '#37474F';
        ctx.strokeStyle = '#263238';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(-w * 0.45, h * 0.2);
        ctx.lineTo(-w * 0.5, -h * 0.1);
        ctx.lineTo(-w * 0.35, -h * 0.4);
        ctx.lineTo(w * 0.35, -h * 0.4);
        ctx.lineTo(w * 0.5, -h * 0.1);
        ctx.lineTo(w * 0.45, h * 0.2);
        ctx.closePath();
        ctx.fill(); ctx.stroke();

        // 装甲プレートのライン
        ctx.strokeStyle = '#546E7A';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-w * 0.3, -h * 0.1); ctx.lineTo(w * 0.3, -h * 0.1);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(-w * 0.25, h * 0.05); ctx.lineTo(w * 0.25, h * 0.05);
        ctx.stroke();

        // 砲台（左右）
        const gunAngle = Math.sin(frame * 0.04) * 0.2;
        for (let side = -1; side <= 1; side += 2) {
            ctx.save();
            ctx.translate(side * w * 0.5, -h * 0.15);
            ctx.rotate(gunAngle * side);
            ctx.fillStyle = '#212121';
            ctx.fillRect(side > 0 ? 0 : -w * 0.4, -5, w * 0.4, 10);
            // 砲口の光（発射エフェクト）
            if (frame % 60 < 5) {
                ctx.globalAlpha = 0.8;
                ctx.fillStyle = '#FF6F00';
                ctx.beginPath();
                ctx.arc(side > 0 ? w * 0.4 : -w * 0.4, 0, 6, 0, Math.PI * 2);
                ctx.fill();
                ctx.globalAlpha = 1;
            }
            ctx.restore();
        }

        // センサーアイ（スキャン中）
        const scanX = Math.sin(frame * 0.06) * w * 0.15;
        ctx.fillStyle = '#000';
        ctx.fillRect(-w * 0.25, -h * 0.32, w * 0.5, h * 0.18);
        ctx.fillStyle = '#FF1744';
        ctx.beginPath();
        ctx.arc(scanX, -h * 0.23, 5, 0, Math.PI * 2);
        ctx.fill();
        // スキャンライン
        ctx.globalAlpha = 0.3;
        ctx.strokeStyle = '#FF1744';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(-w * 0.25, -h * 0.23);
        ctx.lineTo(w * 0.25, -h * 0.23);
        ctx.stroke();
        ctx.globalAlpha = 1;

        ctx.restore();
    },

    // フォートレスゴーレム (ディフェンダー + ゴーレム): 要塞ゴーレム、城壁の鎧
    drawFortressGolem(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        const sway = Math.sin(frame * 0.04) * 1.5;

        // 腕（城の塔のように四角く）
        ctx.fillStyle = '#455A64';
        ctx.strokeStyle = '#263238';
        ctx.lineWidth = 2;
        for (let side = -1; side <= 1; side += 2) {
            ctx.fillRect(side * w * 0.55, -h * 0.3, w * 0.22, h * 0.65);
            // 城壁の凸凹（胸壁）
            for (let j = 0; j < 3; j++) {
                ctx.fillRect(side * w * 0.55 + j * w * 0.07, -h * 0.3 - h * 0.12, w * 0.05, h * 0.12);
            }
        }

        // メインボディ
        const bodyGrad = ctx.createLinearGradient(-w * 0.4, -h * 0.5, w * 0.4, h * 0.4);
        bodyGrad.addColorStop(0, '#546E7A');
        bodyGrad.addColorStop(1, '#263238');
        ctx.fillStyle = bodyGrad;
        ctx.beginPath();
        ctx.moveTo(-w * 0.4, h * 0.4);
        ctx.lineTo(-w * 0.45, -h * 0.2);
        ctx.lineTo(-w * 0.3, -h * 0.5);
        ctx.lineTo(w * 0.3, -h * 0.5);
        ctx.lineTo(w * 0.45, -h * 0.2);
        ctx.lineTo(w * 0.4, h * 0.4);
        ctx.closePath();
        ctx.fill(); ctx.stroke();

        // 城壁の凸凹（頭頂）
        ctx.fillStyle = '#455A64';
        for (let j = -2; j <= 2; j++) {
            ctx.fillRect(j * w * 0.12 - 5, -h * 0.5, 10, h * 0.15);
        }

        // 盾（正面に装備）
        ctx.fillStyle = '#37474F';
        ctx.strokeStyle = '#B0BEC5';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, -h * 0.25);
        ctx.lineTo(w * 0.22, -h * 0.05);
        ctx.lineTo(w * 0.18, h * 0.25);
        ctx.lineTo(0, h * 0.32);
        ctx.lineTo(-w * 0.18, h * 0.25);
        ctx.lineTo(-w * 0.22, -h * 0.05);
        ctx.closePath();
        ctx.fill(); ctx.stroke();
        // 盾の紋章
        ctx.fillStyle = '#FFD700';
        ctx.font = `bold ${w * 0.22}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('⚔', 0, h * 0.04);

        // 目（要塞の窓のように細長い）
        ctx.fillStyle = '#0D47A1';
        ctx.fillRect(-w * 0.22, -h * 0.3 + sway, w * 0.16, h * 0.08);
        ctx.fillRect(w * 0.06, -h * 0.3 + sway, w * 0.16, h * 0.08);
        // 目の輝き
        const eyeGlow = 0.6 + Math.sin(frame * 0.1) * 0.4;
        ctx.globalAlpha = eyeGlow;
        ctx.fillStyle = '#42A5F5';
        ctx.fillRect(-w * 0.2, -h * 0.28 + sway, w * 0.12, h * 0.04);
        ctx.fillRect(w * 0.08, -h * 0.28 + sway, w * 0.12, h * 0.04);
        ctx.globalAlpha = 1;

        ctx.restore();
    },

    // プラチナスライム (クロームスライム + ゴールデンスライム): 白金の輝き
    drawPlatinumSlime(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2 + 4);
        ctx.scale(dir, 1);

        // 輝きのオーラ
        for (let i = 4; i >= 1; i--) {
            ctx.globalAlpha = 0.06;
            ctx.fillStyle = '#E5E4E2';
            ctx.beginPath();
            ctx.arc(0, 0, w * 0.5 + i * 5, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.globalAlpha = 1;

        // 金属光沢ボディ（白金グラデーション）
        const grad = ctx.createRadialGradient(-w * 0.25, -h * 0.25, 2, 0, 0, w * 0.55);
        grad.addColorStop(0, '#FFFFFF');
        grad.addColorStop(0.3, '#E5E4E2');
        grad.addColorStop(0.7, '#A8A8A8');
        grad.addColorStop(1, '#757575');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.ellipse(0, 0, w * 0.52, h * 0.4, 0, Math.PI, 0);
        ctx.lineTo(w * 0.52, h * 0.25);
        ctx.quadraticCurveTo(0, h * 0.5, -w * 0.52, h * 0.25);
        ctx.fill();

        // 表面の光沢スパーク
        const sparkTime = (frame * 7) % 360;
        for (let i = 0; i < 5; i++) {
            const sx = Math.cos((sparkTime + i * 72) * Math.PI / 180) * w * 0.3;
            const sy = Math.sin((sparkTime + i * 72) * Math.PI / 180) * h * 0.2;
            const ss = Math.max(0, Math.sin((sparkTime + i * 72) * Math.PI / 180)) * 3;
            ctx.globalAlpha = ss / 3;
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath(); ctx.arc(sx, sy, ss, 0, Math.PI * 2); ctx.fill();
        }
        ctx.globalAlpha = 1;

        // 顔（高貴な表情）
        ctx.fillStyle = '#757575';
        ctx.beginPath(); ctx.arc(-7, -4, 2.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(7, -4, 2.5, 0, Math.PI * 2); ctx.fill();
        // 王冠（小さめ）
        ctx.fillStyle = '#E5E4E2';
        ctx.strokeStyle = '#A8A8A8';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(-10, -h * 0.28);
        ctx.lineTo(-13, -h * 0.42); ctx.lineTo(-7, -h * 0.35);
        ctx.lineTo(0, -h * 0.45); ctx.lineTo(7, -h * 0.35);
        ctx.lineTo(13, -h * 0.42); ctx.lineTo(10, -h * 0.28);
        ctx.closePath();
        ctx.fill(); ctx.stroke();
        // 王冠の宝石
        ctx.fillStyle = '#B2EBF2';
        ctx.beginPath(); ctx.arc(0, -h * 0.38, 3, 0, Math.PI * 2); ctx.fill();

        ctx.restore();
    },

    // プラチナゴーレム (プラチナスライム + フォートレスゴーレム): 究極の防御形態
    drawPlatinumGolem(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        const t = frame;
        const pulse = Math.sin(t * 0.07) * 0.5 + 0.5;
        const sway = Math.sin(t * 0.04) * 1.5;

        // ── 白金オーラ（2重リング） ──
        for (let ring = 2; ring >= 1; ring--) {
            ctx.globalAlpha = (0.08 + pulse * 0.06) / ring;
            ctx.fillStyle = ring === 1 ? '#E5E4E2' : '#B2EBF2';
            ctx.beginPath(); ctx.arc(0, 0, w * (0.62 + ring * 0.18), 0, Math.PI * 2); ctx.fill();
        }
        ctx.globalAlpha = 1;

        // ── 脚部（厚めの装甲プレート・歩行アニメ） ──
        for (const side of [-1, 1]) {
            // 左右で逆位相の歩行ボブ（±4px）
            const stepOffset = Math.sin(t * 0.10 + side * Math.PI) * 4;
            // 足の踏み込み角（±5度）
            const stepAngle = Math.sin(t * 0.10 + side * Math.PI) * 0.09;
            ctx.save();
            ctx.translate(side * w * 0.21, h * 0.38); // 脚の付け根を基点に回転
            ctx.rotate(stepAngle);
            // すね当て
            const lg = ctx.createLinearGradient(0, -h * 0.16 + stepOffset, w * 0.22, h * 0.20 + stepOffset);
            lg.addColorStop(0, '#CFD8DC');
            lg.addColorStop(0.5, '#90A4AE');
            lg.addColorStop(1, '#546E7A');
            ctx.fillStyle = lg;
            this._roundRect(ctx, -w * 0.11, -h * 0.16, w * 0.22, h * 0.38, 4);
            ctx.fill();
            ctx.strokeStyle = '#B0BEC5'; ctx.lineWidth = 1.5; ctx.stroke();
            // ひざアーマー
            ctx.fillStyle = '#ECEFF1';
            ctx.beginPath(); ctx.ellipse(0, -h * 0.10, w * 0.1, h * 0.07, 0, 0, Math.PI * 2); ctx.fill();
            // 足先アーマー（ブーツ）
            ctx.fillStyle = '#B0BEC5';
            this._roundRect(ctx, -w * 0.12, h * 0.18, w * 0.24, h * 0.07, 3); ctx.fill();
            ctx.strokeStyle = '#78909C'; ctx.lineWidth = 1; ctx.stroke();
            ctx.restore();
        }

        // ── 肩アーマー（翼状・大型） ──
        for (const side of [-1, 1]) {
            ctx.save();
            const sg = ctx.createLinearGradient(side * w * 0.3, -h * 0.35, side * w * 0.75, -h * 0.05);
            sg.addColorStop(0, '#ECEFF1');
            sg.addColorStop(0.4, '#B0BEC5');
            sg.addColorStop(1, '#546E7A');
            ctx.fillStyle = sg;
            ctx.beginPath();
            ctx.moveTo(side * w * 0.28, -h * 0.3);
            ctx.lineTo(side * w * 0.72, -h * 0.38);
            ctx.lineTo(side * w * 0.78, -h * 0.1);
            ctx.lineTo(side * w * 0.62, h * 0.05);
            ctx.lineTo(side * w * 0.32, h * 0.1);
            ctx.closePath();
            ctx.fill();
            ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 1.5;
            ctx.globalAlpha = 0.7; ctx.stroke(); ctx.globalAlpha = 1;
            // 肩リベット
            ctx.fillStyle = '#CFD8DC';
            ctx.beginPath(); ctx.arc(side * w * 0.6, -h * 0.2, 4, 0, Math.PI * 2); ctx.fill();
            ctx.restore();
        }

        // ── 腕（円柱状・ガントレット付き） ──
        for (const side of [-1, 1]) {
            const ag = ctx.createLinearGradient(side * w * 0.38, 0, side * w * 0.65, 0);
            ag.addColorStop(0, '#B0BEC5');
            ag.addColorStop(1, '#455A64');
            ctx.fillStyle = ag;
            ctx.beginPath();
            ctx.moveTo(side * w * 0.36, -h * 0.18);
            ctx.lineTo(side * w * 0.65, -h * 0.12);
            ctx.lineTo(side * w * 0.65, h * 0.22);
            ctx.lineTo(side * w * 0.36, h * 0.22);
            ctx.closePath();
            ctx.fill(); ctx.strokeStyle = '#78909C'; ctx.lineWidth = 1.5; ctx.stroke();
            // ガントレット（拳部分）
            const gg = ctx.createRadialGradient(side * w * 0.63, h * 0.25, 2, side * w * 0.63, h * 0.25, w * 0.18);
            gg.addColorStop(0, '#ECEFF1'); gg.addColorStop(1, '#546E7A');
            ctx.fillStyle = gg;
            ctx.beginPath(); ctx.ellipse(side * w * 0.63, h * 0.28, w * 0.12, h * 0.1, 0, 0, Math.PI * 2); ctx.fill();
        }

        // ── メインボディ（白金装甲・台形） ──
        const bodyG = ctx.createLinearGradient(-w * 0.36, -h * 0.48, w * 0.36, h * 0.26);
        bodyG.addColorStop(0, '#ECEFF1');
        bodyG.addColorStop(0.3, '#CFD8DC');
        bodyG.addColorStop(0.7, '#90A4AE');
        bodyG.addColorStop(1, '#455A64');
        ctx.fillStyle = bodyG;
        ctx.beginPath();
        ctx.moveTo(-w * 0.34, h * 0.28);
        ctx.lineTo(-w * 0.38, -h * 0.12);
        ctx.lineTo(-w * 0.25, -h * 0.48);
        ctx.lineTo(w * 0.25, -h * 0.48);
        ctx.lineTo(w * 0.38, -h * 0.12);
        ctx.lineTo(w * 0.34, h * 0.28);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#CFD8DC'; ctx.lineWidth = 2; ctx.stroke();

        // ボディ縦ライン（装甲の継ぎ目）
        ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(0, -h * 0.44); ctx.lineTo(0, h * 0.24); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(-w * 0.18, -h * 0.42); ctx.lineTo(-w * 0.16, h * 0.22); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(w * 0.18, -h * 0.42); ctx.lineTo(w * 0.16, h * 0.22); ctx.stroke();

        // ── 目（白金の電磁アイ） ──
        const eyeY = -h * 0.28 + sway;
        for (const ex of [-w * 0.14, w * 0.06]) {
            // 外枠
            ctx.fillStyle = '#102027';
            ctx.fillRect(ex, eyeY, w * 0.14, h * 0.1);
            // 内側グロー（pulse）
            const eyeGlow = `rgba(${176 + Math.floor(pulse * 79)}, 240, 255, ${0.8 + pulse * 0.2})`;
            ctx.fillStyle = eyeGlow;
            ctx.fillRect(ex + w * 0.01, eyeY + h * 0.015, w * 0.12, h * 0.07);
        }

        // ── 胸のクリスタルコア（メインギミック） ──
        const coreGlow = 0.6 + pulse * 0.4;
        // 外リング
        ctx.strokeStyle = `rgba(178, 235, 242, ${coreGlow})`;
        ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.arc(0, h * 0.04, w * 0.17, 0, Math.PI * 2); ctx.stroke();
        // 内リング（回転）
        ctx.save();
        ctx.rotate(t * 0.03);
        ctx.strokeStyle = `rgba(255,255,255,${coreGlow * 0.6})`;
        ctx.lineWidth = 1;
        for (let i = 0; i < 6; i++) {
            const a = (i / 6) * Math.PI * 2;
            ctx.beginPath();
            ctx.moveTo(Math.cos(a) * w * 0.1, h * 0.04 + Math.sin(a) * w * 0.1);
            ctx.lineTo(Math.cos(a) * w * 0.17, h * 0.04 + Math.sin(a) * w * 0.17);
            ctx.stroke();
        }
        ctx.restore();
        // コア本体（六角形ダイヤモンド）
        ctx.fillStyle = `rgba(${100 + Math.floor(pulse * 80)}, 230, 255, ${0.9 + pulse * 0.1})`;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
            const a = (i / 6) * Math.PI * 2 - Math.PI / 6;
            if (i === 0) ctx.moveTo(Math.cos(a) * w * 0.09, h * 0.04 + Math.sin(a) * w * 0.09);
            else ctx.lineTo(Math.cos(a) * w * 0.09, h * 0.04 + Math.sin(a) * w * 0.09);
        }
        ctx.closePath(); ctx.fill();
        // 中心の輝点
        ctx.globalAlpha = coreGlow;
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath(); ctx.arc(0, h * 0.04, w * 0.03, 0, Math.PI * 2); ctx.fill();
        ctx.globalAlpha = 1;

        ctx.restore();
    },

    drawArchAngel(ctx, x, y, w, h, color, dir, frame) {
        // アークエンジェル: 真っ白な8枚翼の大天使。セラフィムより大きく神々しい
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        const beat = Math.sin(frame * 0.12) * 6;

        // 8枚翼（外側から内側へ順に描画）
        const wingDefs = [
            { span: w * 1.2, vy: -h * 0.1, rot: 0.4, alpha: 0.3, col: '#E3F2FD' },
            { span: w * 1.0, vy: -h * 0.2, rot: 0.2, alpha: 0.5, col: '#FFF9C4' },
            { span: w * 0.75, vy: -h * 0.3, rot: 0.1, alpha: 0.8, col: '#FFFFFF' },
            { span: w * 0.55, vy: -h * 0.35, rot: 0.0, alpha: 1.0, col: '#FFD700' },
        ];
        wingDefs.forEach(wd => {
            const wBeat = beat * (wd.alpha);
            for (const side of [-1, 1]) {
                ctx.save();
                ctx.globalAlpha = wd.alpha;
                ctx.fillStyle = wd.col;
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.quadraticCurveTo(side * wd.span * 0.7, wd.vy + wBeat - 10, side * wd.span, wd.vy + wBeat);
                ctx.quadraticCurveTo(side * wd.span * 0.5, wd.vy + wBeat + 20, 0, 10);
                ctx.fill();
                ctx.restore();
            }
        });

        // 体（白い楕円 + 金のライン）
        ctx.globalAlpha = 1;
        ctx.fillStyle = '#FFFDE7';
        // shadowColor removed for perf
        ctx.shadowBlur = 0;
        ctx.beginPath(); ctx.ellipse(0, 0, w * 0.38, h * 0.42, 0, 0, Math.PI * 2); ctx.fill();
        ctx.shadowBlur = 0;

        // 胸の聖印
        ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(0, -10); ctx.lineTo(0, 10);
        ctx.moveTo(-8, 0); ctx.lineTo(8, 0);
        ctx.stroke();

        // 輪光（大きめの二重円）
        ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 2;
        ctx.globalAlpha = 0.7 + Math.sin(frame * 0.06) * 0.2;
        ctx.beginPath(); ctx.ellipse(0, -h * 0.55 + beat * 0.3, w * 0.3, w * 0.1, 0, 0, Math.PI * 2); ctx.stroke();
        ctx.globalAlpha = 0.4;
        ctx.beginPath(); ctx.ellipse(0, -h * 0.55 + beat * 0.3, w * 0.4, w * 0.13, 0, 0, Math.PI * 2); ctx.stroke();
        ctx.globalAlpha = 1;

        // 顔（穏やかな微笑み）
        ctx.fillStyle = '#B8860B';
        ctx.beginPath(); ctx.arc(-7, -4, 2.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(7, -4, 2.5, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#B8860B'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(0, 2, 5, 0.1, Math.PI - 0.1); ctx.stroke();

        ctx.restore();
    },

    drawDragonLord(ctx, x, y, w, h, color, dir, frame) {
        // ドラゴンロード: ドラゴンより大柄で鎧を纏い、金の王冠と溶岩オーラ
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        const roar = Math.sin(frame * 0.08) * 3;

        // 溶岩オーラ（脈動する外縁）
        const auraAlpha = 0.15 + Math.sin(frame * 0.1) * 0.08;
        ctx.globalAlpha = auraAlpha;
        ctx.fillStyle = '#FF5722';
        ctx.beginPath(); ctx.ellipse(0, 0, w * 0.65, h * 0.65, 0, 0, Math.PI * 2); ctx.fill();
        ctx.globalAlpha = 1;

        // 尾（太く長い）
        ctx.fillStyle = this._darkenHex(color, 20);
        ctx.beginPath();
        ctx.moveTo(w * 0.3, h * 0.2);
        ctx.quadraticCurveTo(w * 0.7, h * 0.5 + roar, w * 0.55, h * 0.65);
        ctx.quadraticCurveTo(w * 0.4, h * 0.6, w * 0.1, h * 0.3);
        ctx.fill();

        // 体（ずっしりした楕円、鎧色）
        const armorColor = '#880000';
        ctx.fillStyle = armorColor;
        ctx.beginPath(); ctx.ellipse(0, h * 0.08, w * 0.42, h * 0.38, 0, 0, Math.PI * 2); ctx.fill();

        // 鎧のリベット
        ctx.fillStyle = '#FFD700';
        for (let i = -2; i <= 2; i++) {
            ctx.beginPath(); ctx.arc(i * 8, h * 0.1, 2, 0, Math.PI * 2); ctx.fill();
        }

        // 翼（大型・ギザギザ）
        for (const side of [-1, 1]) {
            ctx.save();
            ctx.scale(side, 1);
            ctx.fillStyle = '#4A0000';
            ctx.globalAlpha = 0.85;
            ctx.beginPath();
            ctx.moveTo(w * 0.3, -h * 0.2);
            ctx.lineTo(w * 0.9, -h * 0.55 + roar * 0.5);
            ctx.lineTo(w * 0.7, -h * 0.3);
            ctx.lineTo(w * 0.85, -h * 0.1 + roar * 0.3);
            ctx.lineTo(w * 0.5, h * 0.1);
            ctx.fill();
            ctx.globalAlpha = 1;
            ctx.restore();
        }

        // 頭
        ctx.fillStyle = color;
        ctx.beginPath(); ctx.ellipse(0, -h * 0.32 + roar, w * 0.28, h * 0.22, 0, 0, Math.PI * 2); ctx.fill();

        // 角（2本）
        ctx.fillStyle = '#FFF176';
        for (const sx of [-8, 8]) {
            ctx.beginPath();
            ctx.moveTo(sx, -h * 0.44 + roar);
            ctx.lineTo(sx - 3, -h * 0.62 + roar);
            ctx.lineTo(sx + 3, -h * 0.62 + roar);
            ctx.fill();
        }

        // 王冠（ドラゴンロードの証）
        ctx.fillStyle = '#FFD700';
        const cx = 0, cy = -h * 0.58 + roar;
        ctx.beginPath();
        ctx.moveTo(-14, cy); ctx.lineTo(-14, cy - 8);
        ctx.lineTo(-8, cy - 4); ctx.lineTo(0, cy - 12);
        ctx.lineTo(8, cy - 4); ctx.lineTo(14, cy - 8);
        ctx.lineTo(14, cy); ctx.closePath(); ctx.fill();
        // 宝石
        ctx.fillStyle = '#F44336';
        ctx.beginPath(); ctx.arc(0, cy - 6, 3, 0, Math.PI * 2); ctx.fill();

        // 眼（赤く光る）
        ctx.fillStyle = '#FF1744';
        // shadowColor removed for perf ctx.shadowBlur = 0;
        ctx.beginPath(); ctx.arc(-7, -h * 0.3 + roar, 3.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(7, -h * 0.3 + roar, 3.5, 0, Math.PI * 2); ctx.fill();
        ctx.shadowBlur = 0;

        // 牙
        ctx.fillStyle = '#FFF';
        ctx.beginPath();
        ctx.moveTo(-5, -h * 0.22 + roar); ctx.lineTo(-3, -h * 0.15 + roar); ctx.lineTo(-7, -h * 0.15 + roar);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(5, -h * 0.22 + roar); ctx.lineTo(3, -h * 0.15 + roar); ctx.lineTo(7, -h * 0.15 + roar);
        ctx.fill();

        ctx.restore();
    },

    drawTitan(ctx, x, y, w, h, color, dir, frame) {
        this.drawSlime(ctx, x, y, w, h, color, this._darkenHex(color, 40), dir, frame, 0, 'titan');
    },

    drawTitanGolem(ctx, x, y, w, h, color, dir, frame) {
        // タイタンゴーレム: 鉄と魔石でできた超巨大機械ゴーレム。タイタンとは別物
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        const rumble = Math.sin(frame * 0.07) * 2;

        // 地面振動エフェクト
        ctx.globalAlpha = 0.1 + Math.sin(frame * 0.15) * 0.05;
        ctx.fillStyle = '#78909C';
        ctx.beginPath(); ctx.ellipse(0, h * 0.45, w * 0.55, h * 0.1, 0, 0, Math.PI * 2); ctx.fill();
        ctx.globalAlpha = 1;

        // 脚（がっしりした柱）
        ctx.fillStyle = this._darkenHex(color, 30);
        ctx.fillRect(-w * 0.3, h * 0.2 + rumble, w * 0.22, h * 0.3);
        ctx.fillRect(w * 0.08, h * 0.2 - rumble, w * 0.22, h * 0.3);

        // 胴体（重厚な四角）
        ctx.fillStyle = color;
        ctx.strokeStyle = '#455A64';
        ctx.lineWidth = 2;
        ctx.beginPath();
        this._roundRect(ctx, -w * 0.38, -h * 0.15, w * 0.76, h * 0.45, 4);
        ctx.fill(); ctx.stroke();

        // 胸の魔力コア（脈動）
        const coreGlow = 0.6 + Math.sin(frame * 0.1) * 0.3;
        ctx.fillStyle = `rgba(0, 200, 255, ${coreGlow})`;
        // shadowColor removed for perf ctx.shadowBlur = 0;
        ctx.beginPath(); ctx.arc(0, h * 0.08, w * 0.13, 0, Math.PI * 2); ctx.fill();
        ctx.shadowBlur = 0;
        // コア内側
        ctx.fillStyle = '#FFF';
        ctx.beginPath(); ctx.arc(0, h * 0.08, w * 0.06, 0, Math.PI * 2); ctx.fill();

        // パネルライン（メカ感）
        ctx.strokeStyle = '#546E7A'; ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(-w * 0.35, h * 0.05); ctx.lineTo(-w * 0.12, h * 0.05);
        ctx.moveTo(w * 0.12, h * 0.05); ctx.lineTo(w * 0.35, h * 0.05);
        ctx.moveTo(-w * 0.35, h * 0.2); ctx.lineTo(w * 0.35, h * 0.2);
        ctx.stroke();

        // 腕（巨大なハンマー状）
        const armSway = Math.sin(frame * 0.08) * 0.15;
        for (const side of [-1, 1]) {
            ctx.save();
            ctx.translate(side * w * 0.42, 0);
            ctx.rotate(side * armSway);
            ctx.fillStyle = this._darkenHex(color, 15);
            ctx.strokeStyle = '#455A64'; ctx.lineWidth = 1;
            // 上腕
            this._roundRect(ctx, -7, -h * 0.12, 14, h * 0.3, 3); ctx.fill(); ctx.stroke();
            // 拳（大きめ）
            ctx.fillStyle = '#37474F';
            this._roundRect(ctx, -10, h * 0.15, 20, 18, 4); ctx.fill(); ctx.stroke();
            // ナックル
            for (let k = 0; k < 3; k++) {
                ctx.fillStyle = '#78909C';
                ctx.beginPath(); ctx.arc(-6 + k * 6, h * 0.15, 2.5, 0, Math.PI * 2); ctx.fill();
            }
            ctx.restore();
        }

        // 肩アーマー（四角い突起）
        ctx.fillStyle = '#546E7A';
        ctx.strokeStyle = '#37474F'; ctx.lineWidth = 1;
        for (const sx of [-1, 1]) {
            ctx.beginPath();
            ctx.moveTo(sx * w * 0.28, -h * 0.12);
            ctx.lineTo(sx * w * 0.45, -h * 0.22);
            ctx.lineTo(sx * w * 0.48, -h * 0.05);
            ctx.lineTo(sx * w * 0.32, h * 0.0);
            ctx.closePath(); ctx.fill(); ctx.stroke();
        }

        // 頭（四角く重い）
        ctx.fillStyle = this._darkenHex(color, 10);
        ctx.strokeStyle = '#455A64'; ctx.lineWidth = 2;
        this._roundRect(ctx, -w * 0.24, -h * 0.5 + rumble, w * 0.48, h * 0.38, 5);
        ctx.fill(); ctx.stroke();

        // バイザー（横長一直線の目）
        const vizGlow = 0.7 + Math.sin(frame * 0.2) * 0.2;
        ctx.fillStyle = `rgba(0, 230, 118, ${vizGlow})`;
        // shadowColor removed for perf ctx.shadowBlur = 0;
        ctx.fillRect(-w * 0.18, -h * 0.35 + rumble, w * 0.36, 6);
        ctx.shadowBlur = 0;

        // アンテナ
        ctx.strokeStyle = '#90A4AE'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(0, -h * 0.5 + rumble); ctx.lineTo(0, -h * 0.65 + rumble); ctx.stroke();
        ctx.fillStyle = '#EF5350';
        ctx.beginPath(); ctx.arc(0, -h * 0.67 + rumble, 3, 0, Math.PI * 2); ctx.fill();

        ctx.restore();
    },

    drawSpecial(ctx, x, y, w, h, color, dir, frame) {
        this.drawSlime(ctx, x, y, w, h, color, this._darkenHex(color, 40), dir, frame, 0, 'special');
    },
    drawRoyalGuard(ctx, x, y, w, h, color, dir, frame) {
        // ロイヤルガード: 金の甲冑に赤いマントの近衛騎士。ディフェンダーとは別格
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        const march = Math.sin(frame * 0.1) * 2;

        // マント（後ろに揺れる）
        const capeWave = Math.sin(frame * 0.08) * 5;
        ctx.fillStyle = '#B71C1C';
        ctx.globalAlpha = 0.85;
        ctx.beginPath();
        ctx.moveTo(-w * 0.2, -h * 0.35 + march);
        ctx.quadraticCurveTo(-w * 0.5, h * 0.1, -w * 0.4 + capeWave, h * 0.45);
        ctx.lineTo(w * 0.05, h * 0.45);
        ctx.quadraticCurveTo(w * 0.1, h * 0.0, w * 0.2, -h * 0.35 + march);
        ctx.fill();
        ctx.globalAlpha = 1;

        // 脚（プレートアーマー）
        ctx.fillStyle = '#FFD700';
        ctx.strokeStyle = '#B8860B'; ctx.lineWidth = 1;
        this._roundRect(ctx, -w * 0.25, h * 0.18 + march, w * 0.2, h * 0.28, 3); ctx.fill(); ctx.stroke();
        this._roundRect(ctx, w * 0.05, h * 0.18 - march, w * 0.2, h * 0.28, 3); ctx.fill(); ctx.stroke();

        // 胴体アーマー
        ctx.fillStyle = '#FFD700';
        ctx.strokeStyle = '#B8860B'; ctx.lineWidth = 2;
        this._roundRect(ctx, -w * 0.32, -h * 0.18, w * 0.64, h * 0.42, 6); ctx.fill(); ctx.stroke();

        // 胸の紋章
        ctx.fillStyle = '#B71C1C';
        ctx.beginPath();
        ctx.moveTo(0, -h * 0.12); ctx.lineTo(-8, -h * 0.0); ctx.lineTo(-6, h * 0.1);
        ctx.lineTo(0, h * 0.14); ctx.lineTo(6, h * 0.1); ctx.lineTo(8, -h * 0.0);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#FFD700';
        ctx.font = `bold ${w * 0.18}px Arial`;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('R', 0, h * 0.02);

        // 肩プレート
        for (const sx of [-1, 1]) {
            ctx.fillStyle = '#FFC107';
            ctx.strokeStyle = '#B8860B'; ctx.lineWidth = 1;
            ctx.beginPath(); ctx.ellipse(sx * w * 0.36, -h * 0.12, w * 0.12, h * 0.1, 0, 0, Math.PI * 2);
            ctx.fill(); ctx.stroke();
        }

        // 盾（大型）
        ctx.fillStyle = '#CFD8DC';
        ctx.strokeStyle = '#90A4AE'; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(w * 0.15, -h * 0.2);
        ctx.lineTo(w * 0.45, -h * 0.2);
        ctx.lineTo(w * 0.45, h * 0.15);
        ctx.lineTo(w * 0.3, h * 0.28);
        ctx.lineTo(w * 0.15, h * 0.15);
        ctx.closePath(); ctx.fill(); ctx.stroke();
        // 盾の紋
        ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(w * 0.3, -h * 0.15); ctx.lineTo(w * 0.3, h * 0.2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(w * 0.18, 0); ctx.lineTo(w * 0.42, 0); ctx.stroke();

        // 頭（フルフェイスヘルム）
        ctx.fillStyle = '#FFD700';
        ctx.strokeStyle = '#B8860B'; ctx.lineWidth = 2;
        this._roundRect(ctx, -w * 0.22, -h * 0.55 + march, w * 0.44, h * 0.4, 8);
        ctx.fill(); ctx.stroke();

        // バイザー（T字スリット）
        ctx.fillStyle = '#1A237E';
        // shadowColor removed for perf ctx.shadowBlur = 0;
        ctx.fillRect(-w * 0.16, -h * 0.42 + march, w * 0.32, 5);
        ctx.fillRect(-3, -h * 0.5 + march, 6, 14);
        ctx.shadowBlur = 0;

        // 兜の飾り羽（赤）
        ctx.fillStyle = '#EF5350';
        for (let i = 0; i < 3; i++) {
            const px = (i - 1) * 7;
            ctx.beginPath(); ctx.ellipse(px, -h * 0.6 + march + Math.sin(frame * 0.12 + i) * 3, 3, 8, 0, 0, Math.PI * 2);
            ctx.fill();
        }

        ctx.restore();
    },

    drawSageSlime(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // Body
        ctx.fillStyle = color;
        ctx.beginPath(); ctx.arc(0, 0, w / 2, 0, Math.PI * 2); ctx.fill();

        // Wizard Hat (Mini)
        ctx.fillStyle = '#4A148C';
        ctx.beginPath(); ctx.moveTo(-10, -h / 2); ctx.lineTo(10, -h / 2); ctx.lineTo(0, -h / 2 - 20); ctx.fill();

        // Tentacles (Healer)
        ctx.strokeStyle = color; ctx.lineWidth = 2;
        for (let i = 0; i < 3; i++) {
            ctx.beginPath(); ctx.moveTo(-6 + i * 6, h / 2 - 2); ctx.lineTo(-6 + i * 6, h / 2 + 8); ctx.stroke();
        }

        // Magic Aura
        ctx.globalAlpha = 0.3;
        ctx.fillStyle = (frame % 60 < 30) ? '#F44336' : '#2196F3';
        ctx.beginPath(); ctx.arc(0, 0, w / 2 + 5, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
    },

    // === ALIASES FOR COMPATIBILITY ===
    drawPhantom(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        const floatY = Math.sin(frame * 0.1) * 5;
        ctx.translate(0, floatY);

        // 影のオーラ
        ctx.globalAlpha = 0.2 + Math.sin(frame * 0.08) * 0.1;
        ctx.fillStyle = '#1A0033';
        ctx.beginPath(); ctx.arc(0, 0, w * 0.65, 0, Math.PI * 2); ctx.fill();

        // 半透明ボディ
        ctx.globalAlpha = 0.6 + Math.sin(frame * 0.12) * 0.15;
        ctx.fillStyle = color;
        ctx.beginPath(); ctx.arc(0, 0, w / 2, 0, Math.PI * 2); ctx.fill();

        // 忍者マスク
        ctx.globalAlpha = 0.8;
        ctx.fillStyle = '#1A0033';
        ctx.beginPath();
        ctx.arc(0, -h * 0.05, w * 0.4, Math.PI, 0); ctx.fill();

        // 光る目（紫）
        ctx.globalAlpha = 0.9;
        ctx.fillStyle = '#CE93D8';
        ctx.beginPath(); ctx.arc(-7, -2, 3, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(7, -2, 3, 0, Math.PI * 2); ctx.fill();

        // スカーフ（幽霊のように揺れる）
        ctx.globalAlpha = 0.5;
        ctx.fillStyle = '#4A148C';
        const scarfW = Math.sin(frame * 0.15) * 15;
        ctx.beginPath();
        ctx.moveTo(-w / 2, 5);
        ctx.lineTo(-w / 2 - 20, scarfW);
        ctx.lineTo(-w / 2, 12);
        ctx.fill();

        ctx.restore();
    },

    // パラディン (ヒーラー+重装兵): 聖騎士、光の盾と回復オーラ
    drawPaladin(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // 聖なるオーラ
        ctx.globalAlpha = 0.15 + Math.sin(frame * 0.06) * 0.08;
        ctx.fillStyle = '#FFEB3B';
        ctx.beginPath(); ctx.arc(0, 0, w * 0.7, 0, Math.PI * 2); ctx.fill();
        ctx.globalAlpha = 1;

        // ボディ（装甲）
        ctx.fillStyle = color;
        ctx.strokeStyle = '#7CB342';
        ctx.lineWidth = 2;
        this._roundRect(ctx, -w / 2, -h / 2, w, h, 8);
        ctx.fill(); ctx.stroke();

        // 十字盾
        ctx.fillStyle = '#FFF';
        ctx.fillRect(-3, -h * 0.25, 6, h * 0.35);
        ctx.fillRect(-w * 0.15, -h * 0.1, w * 0.3, 6);

        // ヘルメット
        ctx.fillStyle = '#9E9D24';
        ctx.beginPath();
        ctx.arc(0, -h * 0.15, w * 0.35, Math.PI, 0); ctx.fill();

        // 目（正義の光）
        ctx.fillStyle = '#FFF';
        ctx.beginPath(); ctx.arc(-7, -5, 4, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(7, -5, 4, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#33691E';
        ctx.beginPath(); ctx.arc(-7, -5, 2, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(7, -5, 2, 0, Math.PI * 2); ctx.fill();

        ctx.restore();
    },

    // 錬金術師 (ゴールド+ウィザード): 黄金のローブ、フラスコを持つ
    drawAlchemist(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);

        // ボディ
        ctx.fillStyle = color;
        ctx.beginPath(); ctx.arc(0, 0, w / 2, 0, Math.PI * 2); ctx.fill();

        // 三角帽子（錬金術師）
        ctx.fillStyle = '#E65100';
        ctx.beginPath();
        ctx.moveTo(-12, -h / 2 + 5);
        ctx.lineTo(12, -h / 2 + 5);
        ctx.lineTo(0, -h / 2 - 18);
        ctx.fill();
        // 帽子の星
        ctx.fillStyle = '#FFD700';
        ctx.font = `${w * 0.2}px Arial`;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('★', 0, -h / 2 - 5);

        // フラスコ（前に浮遊）
        const flaskBob = Math.sin(frame * 0.12) * 3;
        ctx.fillStyle = 'rgba(76,175,80,0.6)';
        ctx.beginPath();
        ctx.moveTo(w * 0.35, h * 0.1 + flaskBob);
        ctx.lineTo(w * 0.45, h * 0.3 + flaskBob);
        ctx.lineTo(w * 0.25, h * 0.3 + flaskBob);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(139,195,74,0.8)';
        ctx.beginPath(); ctx.arc(w * 0.35, h * 0.25 + flaskBob, 5, 0, Math.PI * 2); ctx.fill();

        // 目
        ctx.fillStyle = '#FFF';
        ctx.beginPath(); ctx.arc(-6, -3, 5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(6, -3, 5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#333';
        ctx.beginPath(); ctx.arc(-6, -3, 2, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(6, -3, 2, 0, Math.PI * 2); ctx.fill();

        ctx.restore();
    },

    // ワイバーンロード (ボス+ドラゴン): 翼を持つ王冠付きスライム
    drawWyvernLord(ctx, x, y, w, h, color, dir = 1, frame = 0) {
        ctx.save();
        ctx.translate(x + w / 2, y + h / 2);
        ctx.scale(dir, 1);
        const floatY = Math.sin(frame * 0.12) * 4;
        ctx.translate(0, floatY);

        // 翼（大きめ）
        ctx.fillStyle = '#880E4F';
        const wingFlap = Math.sin(frame * 0.15) * 10;
        ctx.beginPath();
        ctx.moveTo(-w * 0.3, 0);
        ctx.lineTo(-w, -h * 0.6 + wingFlap);
        ctx.lineTo(-w * 0.5, -h * 0.1);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(w * 0.3, 0);
        ctx.lineTo(w, -h * 0.6 + wingFlap);
        ctx.lineTo(w * 0.5, -h * 0.1);
        ctx.fill();

        // ボディ
        ctx.fillStyle = color;
        ctx.beginPath(); ctx.arc(0, 0, w / 2, 0, Math.PI * 2); ctx.fill();

        // 王冠
        ctx.fillStyle = '#FFD700';
        ctx.beginPath();
        ctx.moveTo(-12, -h * 0.35);
        ctx.lineTo(-15, -h * 0.6); ctx.lineTo(-6, -h * 0.45);
        ctx.lineTo(0, -h * 0.65); ctx.lineTo(6, -h * 0.45);
        ctx.lineTo(15, -h * 0.6); ctx.lineTo(12, -h * 0.35);
        ctx.fill();

        // ドラゴンの角
        ctx.fillStyle = '#4E342E';
        ctx.beginPath(); ctx.moveTo(-10, -h * 0.3); ctx.lineTo(-16, -h * 0.5); ctx.lineTo(-6, -h * 0.3); ctx.fill();
        ctx.beginPath(); ctx.moveTo(10, -h * 0.3); ctx.lineTo(16, -h * 0.5); ctx.lineTo(6, -h * 0.3); ctx.fill();

        // 厳つい目
        ctx.fillStyle = '#FFF';
        ctx.beginPath(); ctx.ellipse(-8, -3, 6, 3, 0, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(8, -3, 6, 3, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#FF0000';
        ctx.beginPath(); ctx.arc(-8, -3, 2, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(8, -3, 2, 0, Math.PI * 2); ctx.fill();

        ctx.restore();
    },


    // 👑 スライム王 第2必殺技「王の終焉審判」カットイン
    drawSlimeKingUltraSpecialCutin(ctx, W, H, frame) {
        const MAX = 150;
        const t = MAX - frame; // 0→150
        const alpha = frame > (MAX - 12) ? (MAX - frame) / 12 : frame < 15 ? frame / 15 : 1.0;
        ctx.save();

        // ── 背景：深紅×黒（終焉のイメージ）──
        const bgA = Math.min(1, t / 10) * alpha;
        const bg = ctx.createLinearGradient(0, 0, W, H);
        bg.addColorStop(0, '#1A0000');
        bg.addColorStop(0.35, '#3D0000');
        bg.addColorStop(0.7, '#1A0000');
        bg.addColorStop(1, '#050000');
        ctx.globalAlpha = bgA * 0.98;
        ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
        ctx.globalAlpha = 1;

        // ── 亀裂エフェクト（世界が割れるイメージ）──
        if (t > 5 && t < 130) {
            const crackAlpha = Math.min(1, (t - 5) / 20) * alpha * 0.6;
            ctx.globalAlpha = crackAlpha;
            ctx.strokeStyle = '#FF4500'; ctx.lineWidth = 3;
            [[W * 0.3, 0, W * 0.2, H], [W * 0.7, 0, W * 0.55, H],
             [W * 0.5, 0, W * 0.65, H * 0.6], [0, H * 0.4, W * 0.35, H * 0.3]].forEach(([x1, y1, x2, y2]) => {
                ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
            });
            ctx.globalAlpha = 1;
        }

        // ── 放射光（禍々しい赤×オレンジ）──
        if (t > 10 && t < 120) {
            const rayAlpha = Math.min(1, (t - 10) / 18) * alpha * 0.4;
            ctx.globalAlpha = rayAlpha;
            const rayCount = 16;
            for (let r = 0; r < rayCount; r++) {
                const angle = (r / rayCount) * Math.PI * 2 + t * 0.01;
                const len = W * 0.9;
                ctx.strokeStyle = r % 2 === 0 ? '#FF2200' : '#FF8C00';
                ctx.lineWidth = r % 4 === 0 ? 5 : 2;
                ctx.beginPath();
                ctx.moveTo(W * 0.58, H * 0.28);
                ctx.lineTo(W * 0.58 + Math.cos(angle) * len, H * 0.28 + Math.sin(angle) * len);
                ctx.stroke();
            }
            ctx.globalAlpha = 1;
        }

        // ── スライム王の顔（金×赤の神格化バージョン）──
        if (t > 18 && t < 132) {
            const slideIn = Math.min(1, (t - 18) / 25);
            const ease = 1 - Math.pow(1 - slideIn, 3);
            const faceX = W * 0.6 - (1 - ease) * W * 0.35;
            const faceY = H * 0.28;
            const faceR = Math.min(H * 0.28, H * 0.28 * ease);

            ctx.globalAlpha = ease * alpha;

            // 黒オーラ（終焉の力）
            const darkAura = ctx.createRadialGradient(faceX, faceY, 0, faceX, faceY, faceR * 2.2);
            darkAura.addColorStop(0, 'rgba(180,0,0,0.5)');
            darkAura.addColorStop(0.4, 'rgba(100,0,0,0.25)');
            darkAura.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = darkAura;
            ctx.beginPath(); ctx.arc(faceX, faceY, faceR * 2.2, 0, Math.PI * 2); ctx.fill();

            // 金オーラ（王の威厳）
            const goldAura = ctx.createRadialGradient(faceX, faceY, faceR * 0.5, faceX, faceY, faceR * 1.7);
            goldAura.addColorStop(0, 'rgba(255,200,0,0.4)');
            goldAura.addColorStop(0.6, 'rgba(255,100,0,0.15)');
            goldAura.addColorStop(1, 'rgba(255,50,0,0)');
            ctx.fillStyle = goldAura;
            ctx.beginPath(); ctx.arc(faceX, faceY, faceR * 1.7, 0, Math.PI * 2); ctx.fill();

            // 体（金×赤のオーラ）
            const bodyG = ctx.createRadialGradient(faceX - faceR * 0.25, faceY - faceR * 0.35, faceR * 0.05, faceX, faceY, faceR);
            bodyG.addColorStop(0, '#FFFDE7');
            bodyG.addColorStop(0.3, '#FFD700');
            bodyG.addColorStop(0.7, '#FF4500');
            bodyG.addColorStop(1, '#7A0000');
            ctx.fillStyle = bodyG;
            ctx.beginPath(); ctx.arc(faceX, faceY, faceR, 0, Math.PI * 2); ctx.fill();

            // 体の縁（赤×金の虹色パルス）
            const edgeHue = (t * 4) % 360;
            ctx.strokeStyle = `hsl(${edgeHue < 60 ? edgeHue : edgeHue < 120 ? 60 : edgeHue < 180 ? 60 - (edgeHue - 120) : 0},100%,55%)`;
            ctx.lineWidth = 4;
            ctx.beginPath(); ctx.arc(faceX, faceY, faceR, 0, Math.PI * 2); ctx.stroke();

            // 王冠（巨大化・赤宝石）
            const cr = faceR;
            const crY = faceY - cr * 0.85;
            // 王冠ベース
            const crownG = ctx.createLinearGradient(faceX - cr * 0.6, crY - cr * 0.1, faceX + cr * 0.6, crY + cr * 0.1);
            crownG.addColorStop(0, '#8B6914'); crownG.addColorStop(0.5, '#FFD700'); crownG.addColorStop(1, '#8B6914');
            ctx.fillStyle = crownG;
            ctx.beginPath();
            ctx.moveTo(faceX - cr * 0.58, crY);
            ctx.lineTo(faceX - cr * 0.58, crY - cr * 0.28);
            ctx.lineTo(faceX - cr * 0.22, crY - cr * 0.52);
            ctx.lineTo(faceX, crY - cr * 0.72);
            ctx.lineTo(faceX + cr * 0.22, crY - cr * 0.52);
            ctx.lineTo(faceX + cr * 0.58, crY - cr * 0.28);
            ctx.lineTo(faceX + cr * 0.58, crY);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#FF4500'; ctx.lineWidth = 2.5; ctx.stroke();

            // 王冠の宝石（赤く光る）
            const gemPulse = 0.7 + Math.sin(t * 0.15) * 0.3;
            [[0, '#FF0000'], [-cr * 0.35, '#FF4500'], [cr * 0.35, '#FF4500']].forEach(([ox, gc]) => {
                const gemG = ctx.createRadialGradient(faceX + ox, crY - cr * 0.15, 0, faceX + ox, crY - cr * 0.15, cr * 0.12);
                gemG.addColorStop(0, `rgba(255,200,200,${gemPulse})`);
                gemG.addColorStop(0.5, `rgba(255,50,0,${gemPulse * 0.8})`);
                gemG.addColorStop(1, `rgba(${gc.slice(1,3) === 'FF' ? '180' : '120'},0,0,0.3)`);
                ctx.fillStyle = gemG;
                ctx.beginPath(); ctx.arc(faceX + ox, crY - cr * 0.15, cr * 0.11, 0, Math.PI * 2); ctx.fill();
            });

            // 目（怒りの赤炎）
            [-1, 1].forEach(s => {
                const ex = faceX + s * cr * 0.27;
                const ey = faceY - cr * 0.14;
                // 黒目
                ctx.fillStyle = '#1A0000';
                ctx.beginPath(); ctx.ellipse(ex, ey, cr * 0.12, cr * 0.09, 0, 0, Math.PI * 2); ctx.fill();
                // 赤の炎眼
                const eG = ctx.createRadialGradient(ex, ey, 0, ex, ey, cr * 0.11);
                eG.addColorStop(0, `rgba(255,255,0,${gemPulse})`);
                eG.addColorStop(0.4, `rgba(255,50,0,${gemPulse * 0.9})`);
                eG.addColorStop(1, 'rgba(200,0,0,0)');
                ctx.fillStyle = eG;
                ctx.beginPath(); ctx.ellipse(ex, ey, cr * 0.1, cr * 0.07, 0, 0, Math.PI * 2); ctx.fill();
                // 眼炎グロー
                ctx.strokeStyle = `rgba(255,60,0,${gemPulse * 0.6})`; ctx.lineWidth = 4;
                ctx.beginPath(); ctx.ellipse(ex, ey, cr * 0.13, cr * 0.1, 0, 0, Math.PI * 2); ctx.stroke();
            });

            // ヒゲ（6本・シルバー）
            [-1, 1].forEach(s => {
                [0, 1, 2].forEach(hi => {
                    ctx.strokeStyle = `rgba(220,220,220,${0.7 - hi * 0.15})`; ctx.lineWidth = 1.5; ctx.lineCap = 'round';
                    const hx = faceX + s * cr * 0.05;
                    const hy = faceY + cr * 0.04 + hi * cr * 0.1;
                    ctx.beginPath();
                    ctx.moveTo(hx, hy);
                    ctx.lineTo(hx + s * cr * (0.52 + hi * 0.08), hy + hi * cr * 0.04);
                    ctx.stroke();
                });
            });

            ctx.globalAlpha = 1;
        }

        // ── 技名パネル（衝撃的な演出）──
        if (t > 35 && t < 140) {
            const panelEase = Math.min(1, (t - 35) / 22);
            const panelX = W * 0.03 - (1 - panelEase) * W * 0.4;
            ctx.globalAlpha = panelEase * alpha;

            // パネル背景（赤×黒）
            const panG = ctx.createLinearGradient(panelX, H * 0.16, panelX + W * 0.5, H * 0.16);
            panG.addColorStop(0, 'rgba(120,0,0,0.96)');
            panG.addColorStop(1, 'rgba(40,0,0,0.88)');
            ctx.fillStyle = panG;
            ctx.beginPath();
            ctx.moveTo(panelX, H * 0.16);
            ctx.lineTo(panelX + W * 0.5, H * 0.16);
            ctx.lineTo(panelX + W * 0.44, H * 0.53);
            ctx.lineTo(panelX, H * 0.53);
            ctx.closePath(); ctx.fill();

            // 赤い縁取り
            ctx.strokeStyle = '#FF2200'; ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(panelX, H * 0.16);
            ctx.lineTo(panelX + W * 0.5, H * 0.16);
            ctx.lineTo(panelX + W * 0.44, H * 0.53);
            ctx.lineTo(panelX, H * 0.53);
            ctx.closePath(); ctx.stroke();

            // 技名（日本語）
            ctx.textAlign = 'left';
            ctx.font = `bold ${Math.floor(H * 0.058)}px Arial`;
            ctx.fillStyle = '#FF2200';
            ctx.fillText('王の', panelX + 14, H * 0.27);
            ctx.fillStyle = '#FF6600';
            ctx.fillText('終焉審判', panelX + 14, H * 0.38);

            // サブテキスト
            ctx.font = `bold ${Math.floor(H * 0.032)}px Arial`;
            ctx.fillStyle = '#FFD700';
            ctx.fillText('KING ANNIHILATION', panelX + 14, H * 0.48);

            // 装飾ライン
            ctx.strokeStyle = '#FF4500'; ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(panelX + 10, H * 0.295);
            ctx.lineTo(panelX + W * 0.38, H * 0.295);
            ctx.stroke();

            ctx.globalAlpha = 1;
        }

        // ── 衝撃波エフェクト（発動時）──
        if (t > 22 && t < 55) {
            const shockAlpha = Math.max(0, 1 - (t - 22) / 33) * alpha * 0.5;
            ctx.globalAlpha = shockAlpha;
            const shockR = ((t - 22) / 33) * W * 0.8;
            ctx.strokeStyle = '#FF4500'; ctx.lineWidth = 6;
            ctx.beginPath(); ctx.arc(W * 0.58, H * 0.28, shockR, 0, Math.PI * 2); ctx.stroke();
            ctx.strokeStyle = '#FFD700'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(W * 0.58, H * 0.28, shockR * 0.7, 0, Math.PI * 2); ctx.stroke();
            ctx.globalAlpha = 1;
        }

        ctx.restore();
    },


};

window.Renderer = Renderer;
