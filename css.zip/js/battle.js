// ======================================
// BATTLE - Projectiles, Enemy AI, Allies
// ======================================

// Projectile flying between tanks
// Projectile flying between tanks (Parabolic arc)
class Projectile {
    constructor(x, y, tx, ty, type, dir, damage, owner = null) {
        this.x = x; this.y = y;
        this.tx = tx; this.ty = ty; // Target coordinates
        this.type = type;
        // Validate dir to ensure it's never 0, NaN, or undefined
        this.dir = (!isFinite(dir) || dir === 0) ? 1 : dir; // 1 = going right, -1 = going left
        this.damage = damage;
        this.owner = owner; // Added owner field for EXP gain

        this.effect = null; // burn, freeze, shock

        // Physics for arc
        const dx = tx - x;
        const dy = ty - y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        // Simplified arc: fixed travel time based on distance
        this.totalTime = Math.max(30, dist / CONFIG.PROJECTILE.SPEED);
        this.timer = 0;

        // Parabola params
        this.startX = x; this.startY = y;
        this.targetX = tx; this.targetY = ty;
        this.arcHeight = 150 + Math.random() * 50; // Height of arc

        this.active = true;
        this.phase = 'flying';
        this.angle = 0;
        this.rotSpeed = (Math.random() - 0.5) * 0.5;

        // Special: Player Launch
        this.isPlayer = (type === 'player');
        this.onHit = null; // Callback when hit
        this.scale = 1.0;
    }
    update() {
        if (!this.active) return;

        this.timer++;

        // Missile Homing Logic
        if (this.type === 'missile') {
            const dx = this.targetX - this.x;
            const dy = this.targetY - this.y;
            const dist = Math.sqrt(dx * dx + dy * dy) || 1; // Prevent divide by zero
            const speed = 7;

            if (dist < speed) {
                this.phase = 'hit';
                this.active = false;
                if (this.onHit) this.onHit(); // Callback
            } else {
                this.x += (dx / dist) * speed;
                this.y += (dy / dist) * speed;
                this.angle = Math.atan2(dy, dx);
                // Smoke trail
                if (Math.random() < 0.04 && window.game) { // パフォーマンス改善: 0.08→0.04
                    window.game.particles.smoke(this.x - Math.cos(this.angle) * 10, this.y - Math.sin(this.angle) * 10, 1);
                }
            }
            if (this.timer > 150) {
                this.active = false; // Timeout
                if (this.onHit) this.onHit(); // Return anyway
            }
            // ★バグ修正: ミサイルの画面外判定を追加（画面外に飛んで消えないバグを修正）
            if (this.x < -100 || this.x > CONFIG.CANVAS_WIDTH + 100 || this.y < -100 || this.y > CONFIG.CANVAS_HEIGHT + 100) {
                this.active = false;
                if (this.onHit) this.onHit();
            }
            return;
        }

        const t = this.timer / this.totalTime;

        if (t >= 1) {
            this.phase = 'hit';
            this.active = false;
            if (this.onHit) this.onHit();
            return;
        }

        // Linear interpolation for X
        this.x = this.startX + (this.targetX - this.startX) * t;

        // Parabolic interpolation for Y
        // y = Lerp(start, end, t) - 4 * h * t * (1-t)
        const linearY = this.startY + (this.targetY - this.startY) * t;
        const arcY = 4 * this.arcHeight * t * (1 - t);
        this.y = linearY - arcY;

        this.angle += this.rotSpeed;
    }
    draw(ctx) {
        if (!this.active) return;
        Renderer.drawProjectile(ctx, this.x, this.y, this.type, this.dir, this.angle, this.scale);
    }
}

// Battle manager
class BattleManager {
    constructor(stageData, saveData) {
        // --- UPGRADES ---
        const hpLevel = (saveData && saveData.upgrades && saveData.upgrades.hp) || 0;
        const atkLevel = (saveData && saveData.upgrades && saveData.upgrades.attack) || 0;

        const hpBonus = hpLevel * 500; // ★大幅増加: +100/lv → +500/lv（最大Lv30で+15000HP）
        this.attackMultiplier = 1 + (atkLevel * 0.06); // +6%/level（以前10%でインフレ気味、下方修正）

        // ★バグ修正: 装備スキンの hpMult / attackBonus をバトル開始時に適用する
        // これまで attackSpeedMult のみ Player 側で適用されていたが、
        // hpMult と attackBonus は一切反映されていなかった（表示だけ存在するデッドコードだった）
        const _equippedSkinId = (saveData && saveData.tankCustom && saveData.tankCustom.skin) || 'skin_default';
        const _equippedSkin = (window.TANK_PARTS && window.TANK_PARTS.skins || []).find(s => s.id === _equippedSkinId);
        const _skinHpMult     = (_equippedSkin && _equippedSkin.hpMult)     || 1.0;
        const _skinAtkBonus   = (_equippedSkin && _equippedSkin.attackBonus) || 1.0;

        this.attackMultiplier *= _skinAtkBonus;

        this.playerTankHP = Math.ceil(((stageData.playerHP || CONFIG.TANK.DEFAULT_HP) + hpBonus) * _skinHpMult);
        this.playerTankMaxHP = this.playerTankHP;

        this.enemyTankHP = stageData.enemyHP || CONFIG.TANK.DEFAULT_HP;
        this.enemyTankMaxHP = this.enemyTankHP;
        this.projectiles = [];
        this.battleTimer = 0;
        this.enemyFireTimer = stageData.enemyFireInterval || CONFIG.ENEMY.BASE_FIRE_INTERVAL * 1.2; // 20% slower
        this.enemyFireInterval = this.enemyFireTimer;
        this.enemyDamage = Math.round((stageData.enemyDamage || CONFIG.ENEMY.BASE_DAMAGE) * 0.8); // 20% less damage

        // Tank Type Variations
        this.enemyTankType = (stageData.isBossRush && stageData.bosses && stageData.bosses.length > 0)
            ? stageData.bosses[0]
            : (stageData.tankType || 'NORMAL');
        const typeInfo = CONFIG.ENEMY.TYPES[this.enemyTankType] || CONFIG.ENEMY.TYPES.NORMAL;

        // 敵スキン（enemySkinが設定されていればそのスキンで描画）
        this.enemySkinType = stageData.enemySkin || null;

        // Apply multipliers (Disabled for consistency with stage select HP)
        // this.enemyTankHP *= (typeInfo.hpMod || 1.0);
        this.enemyTankMaxHP = this.enemyTankHP;
        this.enemyFireInterval *= (typeInfo.fireRateMod || 1.0);
        this.enemyDodgeProb = typeInfo.dodgeProb || 0.1;

        // Special / Support
        this.specialGauge = 0;
        this.maxSpecialGauge = CONFIG.SPECIAL.GAUGE_MAX;

        // Interactive Battle State
        this.crosshairX = CONFIG.CANVAS_WIDTH / 2;
        this.crosshairY = CONFIG.TANK.OFFSET_Y + CONFIG.TANK.INTERIOR_H / 2;
        this.playerTankX = 0; // Relative to default
        this.playerTankY = 0;
        this.playerTankTargetX = 0;
        this.playerTankTargetY = 0;
        this.dodgeTimer = 0;

        this.enemyTankX = 0;
        this.enemyTankY = 0;
        this.enemyTankTargetX = 0;
        this.enemyTankTargetY = 0;
        this.enemyDodgeTimer = 0;

        this.incomingShots = []; // For indicators
        this.shieldActive = false; // Moved this line to correct position
        this.woodArmorActive = false; // もくのよろい：ダメージ軽減バリア
        this.woodArmorHP = 0;        // 残りバリアHP
        this.turboBoostTimer = 0;    // ターボパーツ：残り効果時間
        this.damageFlash = 0;
        this.enemyDamageFlash = 0;
        this.phase = 'battle'; // battle, enemy_disabled, invasion, victory, defeat
        this.invasionAvailable = false;

        // Magic Effects
        this.playerFireEffect = 0; // Burn timer (player tank被弾 → playerTankHPにDoT)
        this.playerIceEffect = 0; // Freeze timer (player被弾 → 敵の行動は変わらない)
        this.enemyFireEffect = 0;  // Burn timer (enemy tank被弾 → enemyTankHPにDoT)
        this.enemyMuzzleFlash = 0;  // 敵砲口フラッシュタイマー
        this.playerMuzzleFlash = 0; // 自砲口フラッシュタイマー
        this.enemyIceEffect = 0;   // Freeze timer (enemy被弾 → 敵の行動を遅くする)
        this.enemyWindEffect = 0;  // Wind timer (leaf_storm: 敵射撃間隔を延長 1200fr=20秒)
        this.enemyBurnEffect = 0;  // Burn DoT timer (sun_stone: 毎秒3ダメージ 90fr=3秒)
        // 後方互換のため旧エイリアスも残す
        Object.defineProperty(this, 'fireEffect', {
            get: () => this.enemyFireEffect,
            set: (v) => { this.enemyFireEffect = v; }
        });
        Object.defineProperty(this, 'iceEffect', {
            get: () => this.enemyIceEffect,
            set: (v) => { this.enemyIceEffect = v; }
        });
        Object.defineProperty(this, 'windEffect', {
            get: () => this.enemyWindEffect,
            set: (v) => { this.enemyWindEffect = v; }
        });
        Object.defineProperty(this, 'burnEffect', {
            get: () => this.enemyBurnEffect,
            set: (v) => { this.enemyBurnEffect = v; }
        });
        this.thunderFlash = 0; // Visual flash for thunder
        this.stageData = stageData; // Added to constructor for enemyFire

        // === ラスボス必殺技システム ===
        this.bossSpecialTimer = 0;
        this.bossSpecialInterval = 600; // 10秒ごとに必殺技チャンス
        this.bossSpecialActive = false;
        this.bossSpecialPhase = 0; // 必殺技のフェーズ管理
        this.bossSpecialType = null; // 現在発動中の必殺技タイプ

        // === 形態変化システム ===
        this.bossPhase = 1; // 1 = 第一形態, 2 = 第二形態
        this.hasPhaseTwo = stageData.hasPhaseTwo || false; // 第二形態があるか
        this.phaseTransitionActive = false; // 形態変化中フラグ

        // --- BOSS RUSH ---
        this.currentBossIndex = 0;

        // フレームベースのバーストキュー（setTimeout/setInterval代替）
        this.burstQueue = []; // [{delay, fn}]
        this.laserFrames = 0; // bossLaserAttack フレームカウンタ
        this.laserActive = false;

        // ============================================================
        // 👑 スライム王専用ギミックシステム
        // ============================================================
        this.isSlimeKingBoss = stageData.isSlimeKingBoss || false;
        this.skPhase = 1;               // 1=通常, 2=激怒, 3=復活後最終形態
        this.skHasRevived = false;      // 復活済みフラグ（1回のみ）
        this.skRevivalActive = false;   // 復活演出中フラグ
        this.skPhase2Active = false;    // Phase2移行演出中フラグ
        this.skPhase2Triggered = false; // Phase2移行済み
        // ★新機能: 戦闘中セリフトリガーフラグ（各HP閾値で1回だけ発言）
        this.skSpeech75Done = false; // HP75%セリフ済み
        this.skSpeech25Done = false; // HP25%セリフ済み（Phase3）
        this.skSpeech10Done = false; // HP10%セリフ済み
        // 潜り込みギミック
        this.skInfiltrating = false;    // 潜り込み中フラグ
        this.skInfilTimer = 0;          // 潜り込みインターバルカウンタ
        this.skInfilDuration = 0;       // 潜り込み残り時間
        this.skInfilInterval = 900;     // 潜り込み発動間隔（phase2: 900f, phase3: 600f）
        // ★新ギミック①: 気配システム
        this.skKehaiActive = false;     // 気配出現中
        this.skKehaiX = 0;             // 気配X座標（タンク内部基準）
        this.skKehaiY = 0;             // 気配Y座標
        this.skKehaiTimer = 0;         // 気配残り時間（90fで消える）
        this.skKehaiHit = false;       // 今回の潜り込みで撃ち抜いたか
        this.skKehaiNextSpawn = 0;     // 次の気配出現までのカウンタ
        // ★新ギミック③: 王冠弾（Phase3限定）
        this.skCrownShotTimer = 0;
        // コア奪取・変身
        this.coreStealTriggered = false;
        this.coreStealActive = false;
        // 強プレイヤー対策：phase3突入後この時間が経過したら強制発動
        this.coreStealForceTimer = 0;
        this.coreStealForceLimit = 1500; // 25秒 = 必ず発動する保証タイマー
        this.playerTransformed = false;
        this.originalPlayerSkin = null;
    }

    update() {
        const tick = 1;

        // バーストキュー処理（処理中に新しく追加されたキューを消失させないロジックに修正）
        if (this.burstQueue.length > 0) {
            const currentQueue = this.burstQueue;
            this.burstQueue = []; // 新しいキューを受け入れるために一時的に空転
            const pending = [];
            for (const entry of currentQueue) {
                entry.delay--;
                if (entry.delay <= 0) {
                    try { entry.fn(); } catch (e) { }
                } else {
                    pending.push(entry);
                }
            }
            // 処理中に新しく追加されたものがあれば結合
            this.burstQueue = pending.concat(this.burstQueue);
        }

        // bossLaserAttack フレームベース処理
        if (this.laserActive) {
            this.laserFrames++;
            if (this.laserFrames >= 120) {
                this.laserActive = false;
                this.laserFrames = 0;
            } else if (this.laserFrames % 10 === 0 && window.game && window.game.state === 'battle') {
                const px = CONFIG.CANVAS_WIDTH - 50;
                const py = CONFIG.TANK.OFFSET_Y + 80 + Math.random() * 100;
                const tx = CONFIG.TANK.OFFSET_X + 100;
                const ty = CONFIG.TANK.OFFSET_Y + Math.random() * CONFIG.TANK.INTERIOR_H;
                this.projectiles.push(new Projectile(px, py, tx, ty, 'thunder', -1, this.enemyDamage));
                window.game.particles.lightning(px, py, tx, ty);
                window.game.camera_shake = 5;
            }
        }

        // Apply SLOW_TIME powerup (Slow down game logic)
        let effectiveTick = tick;
        if (window.game && window.game.powerupManager && window.game.powerupManager.hasEffect('slowTime')) {
            effectiveTick *= window.game.powerupManager.getEffectValue('slowTime', 'slowFactor');
        }

        // Update battle timer (Important: used for time attack records and time bonus rewards)
        // ★バグ修正: effectiveTick が SLOW_TIME powerup で小数になるため、
        // 整数に丸めてから加算する。ハイスコア比較やゴールド計算が浮動小数点誤差で
        // ズレるバグを防ぐ。
        this.battleTimer += Math.round(effectiveTick);

        // --- TIME LIMIT CHECK ---
        if (this.phase === 'battle' && this.stageData && this.stageData.timeLimit) {
            const timeLimitFrames = this.stageData.timeLimit * 60;
            if (this.battleTimer > timeLimitFrames) {
                this.phase = 'defeat';
                if (window.game) {
                    window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT / 2, 'TIME UP!', '#F00');
                    window.game.sound.play('damage');
                }
            }
        }

        // Update tank positions (Smooth movement)
        this.playerTankX += (this.playerTankTargetX - this.playerTankX) * 0.1;
        this.playerTankY += (this.playerTankTargetY - this.playerTankY) * 0.1;
        // ★バグ修正: speedMod を移動速度に反映（TRUE_BOSS=1.8倍でより素早く回避）
        const _sMod = (CONFIG.ENEMY.TYPES[this.enemyTankType] || {}).speedMod || 1.0;
        this.enemyTankX += (this.enemyTankTargetX - this.enemyTankX) * Math.min(0.18, 0.05 * _sMod);
        this.enemyTankY += (this.enemyTankTargetY - this.enemyTankY) * Math.min(0.18, 0.05 * _sMod);

        if (this.dodgeTimer > 0) this.dodgeTimer--;
        if (this.enemyDodgeTimer > 0) this.enemyDodgeTimer--;

        if (this.damageFlash > 0) this.damageFlash--;
        if (this.enemyMuzzleFlash > 0) this.enemyMuzzleFlash--;
        if (this.playerMuzzleFlash > 0) this.playerMuzzleFlash--;
        if (this.enemyDamageFlash > 0) this.enemyDamageFlash--;

        // ターボパーツ効果タイマー
        if (this.turboBoostTimer > 0) this.turboBoostTimer--;

        // Thunder Effect: Flash effect and enhanced enemy attack speed
        if (this.thunderFlash > 0) {
            this.thunderFlash--;
            // Thunder provides enemy a burst chance to fire faster
            if (this.thunderFlash === 1 && Math.random() < 0.5) {
                this.enemyFireTimer -= 30; // Shorten fire interval by 0.5 sec
            }
        }

        // Update Projectiles (インプレース処理: splice O(n²) を O(n) に改善)
        const g = window.game; // window.gameのローカルキャッシュ
        let projWriteIdx = 0;
        for (let i = 0; i < this.projectiles.length; i++) {
            const p = this.projectiles[i];
            p.update();

            if (!p.active) {
                if (p.phase === 'hit') {
                    const hitByEnemy = p.dir === -1;

                    if (hitByEnemy) {
                        // 着弾座標: プレイヤータンク上部（上画面の視覚位置に近い位置）
                        const hitX = CONFIG.TANK.OFFSET_X + 100 + this.playerTankX;
                        const hitY = CONFIG.CANVAS_HEIGHT * 0.4 + this.playerTankY;

                        if (this.shieldActive) {
                            this.shieldActive = false;
                            if (g) {
                                g.sound.play('confirm');
                                g.particles.rateEffect(hitX, hitY, 'BLOCK!', '#FFF');
                            }
                        } else if (this.woodArmorActive && this.woodArmorHP > 0) {
                            // もくのよろい：バリアHPでダメージを肩代わり
                            const absorbed = Math.min(this.woodArmorHP, p.damage);
                            this.woodArmorHP -= absorbed;
                            const remaining = p.damage - absorbed;
                            if (this.woodArmorHP <= 0) {
                                this.woodArmorActive = false;
                                this.woodArmorHP = 0;
                            }
                            if (remaining > 0) {
                                this.playerTankHP = Math.max(0, this.playerTankHP - remaining);
                                this.damageFlash = 6;
                            }
                            if (g) {
                                g.particles.rateEffect(hitX, hitY, `守備-${absorbed}`, '#8D6E63');
                                if (remaining > 0) g.sound.play('damage');
                                else g.sound.play('confirm');
                            }
                        } else {
                            this.playerTankHP = Math.max(0, this.playerTankHP - p.damage);
                            this.damageFlash = 12;
                            this.specialGauge = Math.min(CONFIG.SPECIAL.GAUGE_MAX, this.specialGauge + CONFIG.SPECIAL.GAIN_ON_DAMAGE);
                            if (g?.missionStats) g.missionStats.damageTaken += p.damage;

                            // ヒットストップ（2〜3フレーム）
                            if (g) {
                                g.hitStop = Math.max(g.hitStop, 3);
                                g.camera_shake = Math.max(g.camera_shake, 5);
                                // 実ダメージ数値をポップアップ
                                g.particles.damageNum(hitX + (Math.random() * 40 - 20), hitY - 20, `-${Math.round(p.damage)}`, '#FF4444');
                            }
                        }

                        if (p.type === 'fire') this.playerFireEffect = 180;
                        if (p.type === 'ice') this.playerIceEffect = 120;
                        if (p.type === 'thunder') this.thunderFlash = 15;

                        if (g) {
                            g.particles.explosion(hitX, hitY, '#F44336', 35);
                            g.particles.smoke(hitX, hitY, 3);
                            // 被弾フラッシュは赤
                            g.screenFlash = 6;
                            g.screenFlashType = 'hit';
                        }
                    } else {
                        // 着弾座標: 敵タンク上部（上画面）
                        const eHitX = CONFIG.CANVAS_WIDTH - 140 + this.enemyTankX;
                        const eHitY = CONFIG.CANVAS_HEIGHT * 0.4 + this.enemyTankY;

                        // ★バグ修正: dodgeProbが初期化されているのに一切使われていなかった
                        // → 敵タンクタイプの回避判定を実装
                        const dodged = (this.enemyDodgeTimer <= 0) && (Math.random() < (this.enemyDodgeProb || 0.1));
                        if (dodged) {
                            this.enemyDodgeTimer = 45; // 回避後クールタイム
                            if (g) {
                                g.particles.rateEffect(eHitX, eHitY - 30, 'DODGE!', '#80CBC4');
                                g.particles.smoke(eHitX, eHitY, 3);
                            }
                        } else {
                            // ★バグ修正: インデントを正しく整形
                            // 👑 復活中・コア奪取中・Phase2演出中・潜り込み中は敵HP0にしない
                            const minHPProj = (this.skRevivalActive || this.coreStealActive || this.skPhase2Active || this.skInfiltrating) ? 1 : 0;
                            this.enemyTankHP = Math.max(minHPProj, this.enemyTankHP - p.damage);
                            this.enemyDamageFlash = 12;
                            this.specialGauge = Math.min(CONFIG.SPECIAL.GAUGE_MAX, this.specialGauge + CONFIG.SPECIAL.GAIN_ON_HIT);

                            // ★バグ修正: 飛び道具の持ち主（ドローン等）にEXPを付与
                            if (p.owner && p.owner.gainExp) {
                                p.owner.gainExp(Math.max(1, Math.floor(p.damage * 0.1)));
                            }

                            if (g?.missionStats) g.missionStats.totalDamage += p.damage;


                            // ヒットストップ（プレイヤー弾命中は強め）
                            if (g) {
                                g.hitStop = Math.max(g.hitStop, 4);
                                g.camera_shake = Math.max(g.camera_shake, 4);
                                // 実ダメージ数値ポップアップ
                                const dmgRounded = Math.round(p.damage);
                                const dmgColor = dmgRounded >= 30 ? '#FF9800' : dmgRounded >= 20 ? '#FFD700' : '#FFFFFF';
                                g.particles.damageNum(eHitX + (Math.random() * 40 - 20), eHitY - 30, `${dmgRounded}`, dmgColor);
                            }

                            // コンボ加算
                            if (g) {
                                g.comboCount = (g.comboCount || 0) + 1;
                                g.comboTimer = 180;
                                g.comboFlashTimer = 40;
                                if (g.comboCount > (g.maxCombo || 0)) g.maxCombo = g.comboCount;
                                if (g.comboCount >= 3 && g.particles) {
                                    const comboColors = ['#FFF','#FFD700','#FF9800','#FF4444','#E040FB'];
                                    const col = comboColors[Math.min(g.comboCount - 3, 4)];
                                    g.particles.rateEffect(CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.3, `${g.comboCount}HIT!!`, col);
                                    if (g.comboCount >= 5) g.camera_shake = Math.min(10, g.comboCount + 2);
                                }
                            }

                            if (p.type === 'fire') this.enemyFireEffect = 180;
                            if (p.type === 'ice') this.enemyIceEffect = 120;
                            if (p.effect === 'wind') {
                                // ★バグ修正: 効果を適用した時だけパーティクルを出す
                                // 残り5秒以下のときだけ延長（連打で止まって見える問題を修正）
                                const windApplied = (this.enemyWindEffect || 0) <= 300;
                                if (windApplied) {
                                    this.enemyWindEffect = 600; // 10秒セット
                                    if (g) {
                                        g.particles.damageNum(eHitX, eHitY - 50, '💨 かぜ！', '#A5D6A7');
                                        for (let j = 0; j < 5; j++) {
                                            g.particles.sparkle(eHitX - 40 + Math.random() * 80, eHitY - 10 + Math.random() * 50, '#81C784');
                                        }
                                    }
                                }
                            }
                            if (p.effect === 'burn') {
                                this.enemyBurnEffect = Math.min(540, (this.enemyBurnEffect || 0) + 90); // ★最大9秒上限
                                if (g) {
                                    g.particles.damageNum(eHitX, eHitY - 50, '☀️ やけど！', '#FF8F00');
                                    for (let j = 0; j < 4; j++) {
                                        g.particles.sparkle(eHitX - 30 + Math.random() * 60, eHitY + Math.random() * 40, '#FFA726');
                                    }
                                }
                            }
                            if (p.type === 'thunder') {
                                this.thunderFlash = 15;
                                if (g) {
                                    g.particles.damageNum(eHitX, eHitY - 50, '⚡ ZAAAP!', '#FFEB3B');
                                    for (let j = 0; j < 6; j++) {
                                        g.particles.sparkle(eHitX - 50 + Math.random() * 100, eHitY - 20 + Math.random() * 60, '#FFEB3B');
                                    }
                                    g.hitStop = Math.max(g.hitStop, 6); // 雷は長め
                                }
                            }

                            if (g) {
                                g.particles.explosion(eHitX, eHitY, '#FFC107', 40);
                                g.particles.smoke(eHitX, eHitY, 4);
                                // 命中フラッシュは白（強いほど長い）
                                g.screenFlash = Math.min(8, 4 + Math.floor(p.damage / 15));
                                g.screenFlashType = 'white';
                            }
                        } // end dodge else
                    }
                }
                // 非activeはスキップ（配列に残さない）
            } else {
                // activeなものだけ前に詰める
                this.projectiles[projWriteIdx++] = p;
            }
        }
        this.projectiles.length = projWriteIdx;

        // Apply Fire Damage from Interior (DoT)
        if (window.game && window.game.state === 'battle' && window.game.tank && window.game.tank.fireDamage) {
            // ★バグA補足修正: 潜り込み中・コア奪取中・復活中・Phase2演出中はプレイヤーHP0にしない
            const _interiorFireMin = (this.skInfiltrating || this.coreStealActive || this.skRevivalActive || this.skPhase2Active) ? 1 : 0;
            if (window.game && window.game.tank) this.playerTankHP = Math.max(_interiorFireMin, this.playerTankHP - (window.game.tank.fireDamage || 0));
            if (window.game.missionStats) window.game.missionStats.damageTaken += window.game.tank.fireDamage;
            if (window.game.frame % 30 === 0 && window.game.tank.fireDamage > 0) {
                window.game.particles.smoke(CONFIG.TANK.OFFSET_X + 50, CONFIG.TANK.OFFSET_Y + 50, 2);
            }
        }

        // Update Incoming shots list (manual loop to avoid .filter() allocation)
        let shotsCount = 0;
        for (let i = 0; i < this.projectiles.length; i++) {
            const p = this.projectiles[i];
            if (p.dir === -1 && p.active) {
                this.incomingShots[shotsCount++] = p;
            }
        }
        this.incomingShots.length = shotsCount;

        // Enemy fires at player
        if (this.phase === 'battle') {
            // Apply Ice Effect (Slow down enemy - when enemy is hit by player's ice)
            let currentTick = effectiveTick; // Use effectiveTick which includes SLOW_TIME powerup
            if (this.enemyIceEffect > 0) {
                this.enemyIceEffect--;
                if (window.game && window.game.frame % 3 !== 0) currentTick = 0; // Slower tick
            }

            // Apply Wind Effect (leaf_storm: 敵射撃間隔延長 - 5フレームに1回だけ行動)
            if (this.enemyWindEffect > 0) {
                this.enemyWindEffect--;
                if (window.game && window.game.frame % 5 !== 0) currentTick = 0; // さらに遅い
                if (window.game && this.enemyWindEffect % 60 === 0) {
                    window.game.particles.rateEffect(
                        CONFIG.CANVAS_WIDTH - 140, CONFIG.TANK.OFFSET_Y + 60,
                        `💨 ${Math.ceil(this.enemyWindEffect / 60)}秒`, '#A5D6A7'
                    );
                }
            }

            // Apply Burn DoT to enemy tank (sun_stone: 毎秒3ダメージ)
            if (this.enemyBurnEffect > 0) {
                this.enemyBurnEffect--;
                if (window.game && window.game.frame % 20 === 0) {
                    // 👑 復活中・コア奪取中・Phase2演出中・潜り込み中は敵HP0にしない
                    const minHP = (this.skRevivalActive || this.coreStealActive || this.skPhase2Active || this.skInfiltrating) ? 1 : 0;
                    this.enemyTankHP = Math.max(minHP, this.enemyTankHP - 3);
                    if (window.game) window.game.particles.damageNum(
                        CONFIG.CANVAS_WIDTH - 100, CONFIG.CANVAS_HEIGHT * 0.35, '☀️3', '#FF8F00'
                    );
                }
            }

            // Apply Fire DoT to enemy tank (when enemy is hit by player's fire)
            if (this.enemyFireEffect > 0) {
                this.enemyFireEffect--;
                if (window.game && window.game.frame % 30 === 0) {
                    // 👑 復活中・コア奪取中・Phase2演出中・潜り込み中は敵HP0にしない
                    const minHP2 = (this.skRevivalActive || this.coreStealActive || this.skPhase2Active || this.skInfiltrating) ? 1 : 0;
                    this.enemyTankHP = Math.max(minHP2, this.enemyTankHP - 2);
                    if (window.game) window.game.particles.damageNum(CONFIG.CANVAS_WIDTH - 100, CONFIG.CANVAS_HEIGHT * 0.38, '🔥2', '#FF5722');
                }
            }

            // Apply Fire DoT to player tank (when player is hit by enemy's fire)
            if (this.playerFireEffect > 0) {
                this.playerFireEffect--;
                if (window.game && window.game.frame % 30 === 0) {
                    // ★バグA修正: 潜り込み中・コア奪取中・復活中・Phase2演出中はプレイヤーHP0にしない
                    const _playerDotMin = (this.skInfiltrating || this.coreStealActive || this.skRevivalActive || this.skPhase2Active) ? 1 : 0;
                    this.playerTankHP = Math.max(_playerDotMin, this.playerTankHP - 2);
                    if (window.game) window.game.particles.damageNum(CONFIG.TANK.OFFSET_X + 80, CONFIG.CANVAS_HEIGHT * 0.38, '🔥2', '#FF4444');
                }
            }
            // Emergency Support from Allies
            const hpPercent = this.playerTankMaxHP > 0 ? (this.playerTankHP / this.playerTankMaxHP) * 100 : 100;
            if (hpPercent < CONFIG.SUPPORT.HP_THRESHOLD && Math.random() < CONFIG.SUPPORT.PROBABILITY) {
                this.triggerSupport();
            }

            // specialActive は使用しない(game.jsのspecialAnimTimerで管理)

            // ===== 👑 スライム王専用フェーズ更新 =====
            if (this.isSlimeKingBoss && this.phase === 'battle') {
                const skHpRatio = this.enemyTankMaxHP > 0 ? this.enemyTankHP / this.enemyTankMaxHP : 1;

                // Phase1→2：HP50%で激怒形態へ
                if (this.skPhase === 1 && !this.skPhase2Triggered && skHpRatio <= 0.5) {
                    this.skPhase2Triggered = true;
                    this.triggerSlimeKingPhase2();
                }

                // ★新機能: 戦闘中セリフ（HP閾値ごとにスライム王が一言呟く）
                if (this.skPhase === 1 && !this.skSpeech75Done && skHpRatio <= 0.75) {
                    this.skSpeech75Done = true;
                    this._showBattleSpeech('……なかなかやるな。');
                }
                if (this.skPhase === 3 && !this.skSpeech25Done && skHpRatio <= 0.25) {
                    this.skSpeech25Done = true;
                    this._showBattleSpeech('……まだ、立つか。');
                }
                if (this.skPhase === 3 && !this.skSpeech10Done && skHpRatio <= 0.10) {
                    this.skSpeech10Done = true;
                    this._showBattleSpeech('……いい旅だったな、スラりん。');
                }

                // Phase2/3：潜り込みインターバル更新
                if (this.skPhase >= 2 && !this.skInfiltrating && !this.skRevivalActive && !this.coreStealActive && !this.skPhase2Active) {
                    this.skInfilTimer += currentTick;
                    const interval = this.skPhase === 3 ? 600 : 900;
                    if (this.skInfilTimer >= interval) {
                        this.skInfilTimer = 0;
                        this.triggerSlimeKingInfiltration();
                    }
                }

                // 潜り込み中：ダメージとデバフ
                if (this.skInfiltrating) {
                    this.skInfilDuration -= currentTick;

                    // ★新ギミック①: 気配スポーン（最初は2秒後、以降150fごと）
                    // skKehaiNextSpawnが0のままだと初フレームで即スポーンするため、
                    // triggerSlimeKingInfiltration側で初期値を120に設定している
                    this.skKehaiNextSpawn = (this.skKehaiNextSpawn || 120) - currentTick;
                    if (!this.skKehaiActive && this.skKehaiNextSpawn <= 0 && !this.skKehaiHit) {
                        this.skKehaiActive = true;
                        this.skKehaiTimer = 90; // 90f=1.5秒で消える
                        this.skKehaiNextSpawn = 150;
                        this.skKehaiX = CONFIG.TANK.OFFSET_X + 40 + Math.random() * (CONFIG.TANK.INTERIOR_W - 80);
                        this.skKehaiY = CONFIG.TANK.OFFSET_Y + 30 + Math.random() * (CONFIG.TANK.INTERIOR_H - 60);
                        if (window.game) {
                            window.game.particles.rateEffect(
                                this.skKehaiX, this.skKehaiY - 20, '👑 ！', '#FFD700'
                            );
                            window.game.camera_shake = Math.max(window.game.camera_shake, 5);
                        }
                    }
                    if (this.skKehaiActive) {
                        this.skKehaiTimer -= currentTick;
                        if (this.skKehaiTimer <= 0) this.skKehaiActive = false;
                    }

                    // ★リブート: 毎60fダメージ強化
                    if (Math.floor(this.skInfilDuration / 60) !== Math.floor((this.skInfilDuration + currentTick) / 60)) {
                        const infilDmg = 25;
                        this.playerTankHP = Math.max(1, this.playerTankHP - infilDmg);
                        if (window.game) {
                            for (let i = 0; i < 3; i++) {
                                window.game.particles.damageNum(
                                    CONFIG.TANK.OFFSET_X + 60 + Math.random() * 140,
                                    CONFIG.TANK.OFFSET_Y + 40 + Math.random() * 120,
                                    i === 0 ? `👑 -${infilDmg}` : `💀`, '#FFD700'
                                );
                            }
                            window.game.camera_shake = Math.max(window.game.camera_shake, 8);
                            window.game.screenFlash = 4;
                            window.game.screenFlashType = 'hit';
                            window.game.sound?.play('damage');
                        }
                    }

                    if (window.game && Math.floor(this.skInfilDuration) % 10 === 0) {
                        window.game.camera_shake = Math.max(window.game.camera_shake, 2);
                    }

                    if (window.game && Math.floor(this.skInfilDuration) % 120 === 119) {
                        const secLeft = Math.ceil(this.skInfilDuration / 60);
                        window.game.particles.rateEffect(
                            CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.38,
                            `……あと ${secLeft} 秒`, '#FF4400'
                        );
                    }

                    if (this.skInfilDuration <= 0) {
                        this.skInfiltrating = false;
                        this.skKehaiActive = false;
                        // ★バグ修正: skKehaiHitを参照してからリセット（逆順だと常に300になる）
                        const hpRecovery = this.skKehaiHit ? 100 : 300;
                        this.skKehaiHit = false;
                        this.enemyTankHP = Math.min(this.enemyTankMaxHP, this.enemyTankHP + hpRecovery);
                        if (window.game) {
                            window.game.camera_shake = 25;
                            window.game.screenFlash = 20;
                            window.game.screenFlashType = 'white';
                            window.game.hitStop = Math.max(window.game.hitStop, 8);
                            for (let i = 0; i < 3; i++) {
                                window.game.particles.explosion(
                                    CONFIG.TANK.OFFSET_X + 80 + Math.random() * 120,
                                    CONFIG.TANK.OFFSET_Y + 60 + Math.random() * 100,
                                    '#FFD700', 50
                                );
                            }
                            window.game.particles.explosion(
                                CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.38, '#FF6600', 60
                            );
                            window.game.particles.rateEffect(
                                CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.22,
                                '👑 脱出——HP吸収！', '#FFD700'
                            );
                            window.game.particles.rateEffect(
                                CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.38,
                                '内側から引き剥がされた……！', '#FF4444'
                            );
                            window.game.sound?.play('destroy');
                        }
                        this.enemyFireInterval = this.stageData.enemyFireInterval * (this.skPhase === 3 ? 0.55 : 0.70);
                    }
                }

                // Phase3：コア奪取トリガー監視
                if (this.skPhase === 3 && !this.coreStealTriggered && !this.coreStealActive && !this.skRevivalActive) {
                    this.coreStealForceTimer += currentTick;
                    const playerHpRatio = this.playerTankMaxHP > 0 ? this.playerTankHP / this.playerTankMaxHP : 1;
                    const forceTriggered = this.coreStealForceTimer >= this.coreStealForceLimit;
                    const pinchTriggered = playerHpRatio <= 0.2;

                    if (forceTriggered || pinchTriggered) {
                        this.coreStealTriggered = true;
                        this.coreStealActive = true;
                        if (forceTriggered && !pinchTriggered && window.game) {
                            // 強プレイヤー用：強制発動前に一瞬だけピンチ演出（自然に見せる）
                            window.game.particles.rateEffect(
                                CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.35,
                                'スライム王の力が……！', '#FF4444'
                            );
                        }
                        // 少し間を置いてからイベント開始
                        this.burstQueue.push({ delay: 60, fn: () => this.triggerCoreStealEvent() });
                    }
                }
            }

            // === ラスボス必殺技システム ===
            const isBossStage = this.stageData && this.stageData.isBoss;
            if (isBossStage && !this.bossSpecialActive && !this.skPhase2Active) {
                this.bossSpecialTimer += currentTick;

                // HPが50%以下なら必殺技の発動確率UP
                const hpRatio = this.enemyTankMaxHP > 0 ? (this.enemyTankHP / this.enemyTankMaxHP) : 0;
                const specialChance = hpRatio < 0.5 ? 0.7 : 0.5;

                // 定期的に必殺技を使う
                if (this.bossSpecialTimer >= this.bossSpecialInterval && Math.random() < specialChance) {
                    this.activateBossSpecial();
                    this.bossSpecialTimer = 0;
                }
            }

            // ENEMY SHOOTS (Automatic)
            if (!this.bossSpecialActive && !this.skPhase2Active) { // 必殺技中・Phase2演出中は通常攻撃しない
                this.enemyFireTimer -= currentTick;
                if (this.enemyFireTimer <= 0) {
                    let ammo = 'rock';
                    const typeInfo = CONFIG.ENEMY.TYPES[this.enemyTankType] || CONFIG.ENEMY.TYPES.NORMAL;

                    if ((typeInfo.specialAmmoProb || 0) > 0 && Math.random() < typeInfo.specialAmmoProb) {
                        const specials = ['fire', 'ice', 'thunder'];
                        ammo = specials[Math.floor(Math.random() * specials.length)];
                    }

                    this.enemyFire(ammo);
                    this.enemyFireTimer = this.enemyFireInterval + Math.random() * 40;
                    this.enemyMuzzleFlash = 8;
                }

                // ★新ギミック③: Phase3限定・王冠弾（180fごとに3方向同時発射）
                if (this.isSlimeKingBoss && this.skPhase === 3 && !this.skInfiltrating) {
                    this.skCrownShotTimer = (this.skCrownShotTimer || 0) + currentTick;
                    if (this.skCrownShotTimer >= 180) {
                        this.skCrownShotTimer = 0;
                        if (window.game) {
                            window.game.particles.rateEffect(
                                CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.2,
                                '👑', '#FFD700'
                            );
                        }
                        // 3方向に王冠弾（高ダメージ）を一斉発射
                        const crownDmg = Math.round(this.enemyDamage * 2.0);
                        const px = CONFIG.CANVAS_WIDTH - 50 + (this.enemyTankX || 0);
                        const targets = [
                            { tx: CONFIG.TANK.OFFSET_X + 100, ty: CONFIG.TANK.OFFSET_Y + 60 },
                            { tx: CONFIG.TANK.OFFSET_X + 100, ty: CONFIG.TANK.OFFSET_Y + CONFIG.TANK.INTERIOR_H / 2 },
                            { tx: CONFIG.TANK.OFFSET_X + 100, ty: CONFIG.TANK.OFFSET_Y + CONFIG.TANK.INTERIOR_H - 60 },
                        ];
                        targets.forEach((t, i) => {
                            this.burstQueue.push({ delay: i * 8, fn: () => {
                                if (!window.game || window.game.state !== 'battle') return;
                                const py2 = CONFIG.TANK.OFFSET_Y + 80 + (i - 1) * 80 + (this.enemyTankY || 0);
                                const proj = new Projectile(px, py2, t.tx, t.ty + (this.playerTankY || 0), 'thunder', -1, crownDmg);
                                proj.arcHeight = 60 + i * 30;
                                this.projectiles.push(proj);
                                window.game.sound?.play('cannon');
                                window.game.particles.sparkle(px, py2, '#FFD700');
                            }});
                        });
                    }
                }
            }
        }

        // Check enemy disabled or phase transition
        if (this.enemyTankHP <= 0 && this.phase === 'battle') {
            // ===== 👑 スライム王：復活ギミック =====
            if (this.isSlimeKingBoss && !this.skHasRevived && !this.skRevivalActive) {
                this.skRevivalActive = true;
                this.skHasRevived = true;
                this.triggerSlimeKingRevival();
                return; // 通常撃破処理をスキップ
            }

            // ★フェイルセーフ: 復活演出中にburstQueueが止まった場合でも300fで強制復活完了
            if (this.isSlimeKingBoss && this.skRevivalActive) {
                this._revivalSafeTimer = (this._revivalSafeTimer || 0) + 1;
                if (this._revivalSafeTimer > 300) {
                    this.skRevivalActive = false;
                    this._revivalSafeTimer = 0;
                    const revivalHP = Math.round((this.stageData.enemyHP || 5500) * 0.65);
                    if (this.enemyTankHP <= 0) {
                        this.enemyTankHP = revivalHP;
                        this.enemyTankMaxHP = revivalHP;
                    }
                    this.skPhase = 3;
                }
                return; // 復活中は通常撃破しない
            }

            // 第二形態がある場合は形態変化
            if (this.hasPhaseTwo && this.bossPhase === 1 && !this.phaseTransitionActive) {
                this.phaseTransitionActive = true;
                this.transitionToPhaseTwo();
            } else {
                // 通常の敵撃破処理
                this.phase = 'enemy_disabled';

                // 図鑑に敵を追加
                // ★バグ修正B: ボスラッシュ時は stageData.tankType ではなく
                // 現在のボス型(enemyTankType)を登録する
                // (以前は常に最初のボスのtankTypeが登録されていた)
                // ★バグ修正H: SaveManager が未定義の場合にクラッシュしないようガードを追加
                if (window.SaveManager && window.game && this.stageData) {
                    const currentEnemyType = this.enemyTankType || this.stageData.tankType;
                    if (currentEnemyType) {
                        const isNew = SaveManager.addEnemyToCollection(window.game.saveData, currentEnemyType);
                        if (isNew && window.game.particles) {
                            window.game.particles.rateEffect(
                                CONFIG.CANVAS_WIDTH / 2,
                                CONFIG.CANVAS_HEIGHT * 0.3,
                                '図鑑に登録！',
                                '#9C27B0'
                            );
                        }
                    }
                }

                // デイリーミッション: defeat_enemiesはmissionStatsで集計してバトル終了時に一括更新
                if (window.game?.missionStats) window.game.missionStats.enemiesDefeated++;

                // --- BOSS RUSH CHECK ---
                if (this.stageData.isBossRush && this.stageData.bosses) {
                    this.currentBossIndex++;
                    if (this.currentBossIndex < this.stageData.bosses.length) {
                        // NEXT BOSS!
                        this.enemyTankType = this.stageData.bosses[this.currentBossIndex];
                        const typeInfo = CONFIG.ENEMY.TYPES[this.enemyTankType] || CONFIG.ENEMY.TYPES.NORMAL;

                        // Recalculate stats for the new boss
                        this.enemyTankHP = this.stageData.enemyHP || 1000;
                        this.enemyTankMaxHP = this.enemyTankHP;
                        this.enemyFireInterval = (this.stageData.enemyFireInterval || CONFIG.ENEMY.BASE_FIRE_INTERVAL * 1.2) * (typeInfo.fireRateMod || 1.0);
                        this.enemyFireTimer = this.enemyFireInterval;
                        this.enemyDodgeProb = typeInfo.dodgeProb || 0.1;

                        // Effect & Reset
                        if (window.game) {
                            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.3, `NEXT BOSS: ${this.enemyTankType}!`, '#FF0');
                            window.game.sound.play('confirm');
                            window.game.camera_shake = 12;
                            window.game.screenFlash = 8;
                        }

                        // Return to battle state instead of finishing
                        this.phase = 'battle';
                        return;
                    }
                }

                // skipInvasionフラグがある場合は直接勝利へ
                if (this.stageData.skipInvasion) {
                    this.invasionAvailable = false;
                    this.phase = 'victory'; // 侵攻なしで即勝利
                } else {
                    this.invasionAvailable = true;
                }

                // Spawn powerup on enemy defeat
                if (window.game && Math.random() < CONFIG.POWERUP_SPAWN_RATE) {
                    window.game.powerupManager.spawnRandomPowerup(
                        CONFIG.CANVAS_WIDTH - 100 + Math.random() * 100,
                        150 + Math.random() * 100
                    );
                    if (window.game.sound) window.game.sound.play('coin');
                }
            }
        }

        // Check defeat (同時撃破の場合はプレイヤー勝利を優先)
        // 👑 コア奪取イベント中・復活中・Phase2演出中・潜り込み中はプレイヤーHPが0でも敗北しない
        if (this.playerTankHP <= 0 && this.phase !== 'defeat' && this.phase !== 'enemy_disabled') {
            if (this.coreStealActive || this.skRevivalActive || this.skPhase2Active || this.skInfiltrating) {
                this.playerTankHP = 1; // イベント中は最低1HP維持
            } else {
                this.phase = 'defeat';
            }
        }

        // Check projectile collisions (Interception)
        this.checkProjectileCollisions();
    }

    checkProjectileCollisions() {
        // パフォーマンス改善: playerと enemyを事前分離→O(n²)→O(p*e)に削減
        const projs = this.projectiles;
        const pLen = projs.length;
        if (pLen < 2) return; // 弾が1個以下は衝突なし

        // 4フレームに1回だけチェック（視覚的影響ほぼなし、CPU大幅削減）
        if (window.game && window.game.frame % 4 !== 0) return;

        // プレイヤー弾と敵弾を分離
        const playerProjs = [];
        const enemyProjs = [];
        for (let i = 0; i < pLen; i++) {
            const p = projs[i];
            if (!p.active || p.phase !== 'flying') continue;
            if (p.dir === 1) playerProjs.push(p);
            else if (p.dir === -1) enemyProjs.push(p);
        }

        const pP = playerProjs.length;
        const eP = enemyProjs.length;
        if (pP === 0 || eP === 0) return;

        for (let pi = 0; pi < pP; pi++) {
            const pp = playerProjs[pi];
            if (!pp.active) continue;
            for (let ei = 0; ei < eP; ei++) {
                const ep = enemyProjs[ei];
                if (!ep.active) continue;

                const dx = pp.x - ep.x;
                const dy = pp.y - ep.y;
                if (dx * dx + dy * dy < 1600) { // 距离40px以内（40²=1600）
                    if (pp.onHit) pp.onHit();
                    if (ep.onHit) ep.onHit();
                    pp.active = false;
                    ep.active = false;
                    if (window.game) {
                        const mid = Renderer._toUpperCoord((pp.x + ep.x) / 2, (pp.y + ep.y) / 2, CONFIG.CANVAS_WIDTH, CONFIG.CANVAS_HEIGHT * 0.5);
                        window.game.particles.explosion(mid.x, mid.y, '#FFF', 8);
                        window.game.sound.play('confirm');
                    }
                    this.specialGauge = Math.min(CONFIG.SPECIAL.GAUGE_MAX, this.specialGauge + 2);
                    break; // pp は既にヒット済みなので内側ループ脱出
                }
            }
        }
    }

    triggerSpecial() {
        if (this.specialGauge < CONFIG.SPECIAL.GAUGE_MAX) return false;
        this.specialGauge = 0;
        if (window.game) {
            window.game.specialAnimTimer = 55; // カットイン演出(約0.9秒)
            window.game.specialImpactTimer = 55; // インパクトエフェクト演出（テキスト25f+衝撃波30f）
            try { window.game.sound.play('victory'); } catch (e) { }
            window.game.screenFlash = 8;
            // ★バグ修正: デイリーミッション進捗はバトル終了時に missionStats.specialsUsed
            // で一括更新するため、ここでの即時呼び出しを削除（二重カウント防止）
        }
        return true;
    }

    triggerSupport() {
        if (!window.game) return;
        // Use standard deck selection for support too, effectively just giving "more ammo"
        const deck = (window.game.saveData && window.game.saveData.deck && window.game.saveData.deck.length > 0)
            ? window.game.saveData.deck
            : ['rock'];

        const type = deck[Math.floor(Math.random() * deck.length)];
        window.game.ammoDropper.spawnItem(window.game.tank.dropX, window.game.tank.dropY, window.game.tank.dropW, type);
        window.game.sound.play('victory');
        // Show message
        window.game.particles.damageNum(CONFIG.TANK.OFFSET_X + 200, CONFIG.TANK.OFFSET_Y + 100, 'あきらめるな！', '#FFF');
    }

    // ステージ進行ボーナスを計算するヘルパー（playerFire / onPlayerFire で共用）
    _calcStageBonus() {
        const clearedCount = (window.game && window.game.saveData && window.game.saveData.clearedStages)
            ? window.game.saveData.clearedStages.length : 0;
        // 0〜5クリア: +0, 6〜10: +8/stage, 11〜20: +4/stage, 21以上: 固定+80
        if (clearedCount <= 5)  return 0;
        if (clearedCount <= 10) return (clearedCount - 5) * 8;
        if (clearedCount <= 20) return 40 + (clearedCount - 10) * 4;
        return 80;
    }

    playerFire(type = 'rock') {
        const info = CONFIG.AMMO_TYPES[type];
        if (!info) return;

        // Normal ammo: create projectile
        const px = CONFIG.TANK.OFFSET_X + CONFIG.TANK.INTERIOR_W + 20 + this.playerTankX; // Adjusted for player tank movement
        const py = CONFIG.TANK.OFFSET_Y + CONFIG.TANK.INTERIOR_H / 2 + this.playerTankY; // Adjusted for player tank movement

        // Target random position on enemy tank
        const tx = CONFIG.CANVAS_WIDTH - 120 + this.enemyTankX; // Adjusted for enemy tank movement
        const ty = CONFIG.TANK.OFFSET_Y + 50 + Math.random() * 200 + this.enemyTankY; // Adjusted for enemy tank movement

        const stageBonus = this._calcStageBonus();
        const damage = Math.floor((info.damage + stageBonus) * (this.attackMultiplier || 1.0));
        this.projectiles.push(new Projectile(px, py, tx, ty, type, 1, damage));
        if (info.effect) {
            this.projectiles[this.projectiles.length - 1].effect = info.effect;
        }
        if (window.game) {
            window.game.sound.play('cannon');
            window.game.particles.smoke(px, py, 3); // パフォーマンス改善: 6→3
        }

        // ★修正: 発射時に自分の戦車も反動でわずかに動く（敵と同様の挙動）
        if (this.dodgeTimer <= 0) {
            this.playerTankTargetX = (Math.random() - 0.5) * 30;
            this.playerTankTargetY = (Math.random() - 0.5) * 20;
            this.dodgeTimer = 20;
        }
    }

    // Player cannon fired
    onPlayerFire(fireResult) {
        if (!fireResult) return;
        const info = CONFIG.AMMO_TYPES[fireResult.type];
        if (!info) return;
        // プレイヤー砲口フラッシュ
        this.playerMuzzleFlash = 8;

        // ★新ギミック①: 気配ヒット判定（潜り込み中かつ気配が出現中）
        if (this.skInfiltrating && this.skKehaiActive && !this.skKehaiHit) {
            // 発射Y座標と気配Yが近ければヒット（タンク内部は縦方向で判定）
            const fireY = fireResult.y || 0;
            const kehaiDist = Math.abs(fireY - this.skKehaiY);
            if (kehaiDist < 60) {
                // 気配命中！早期脱出
                this.skKehaiHit = true;
                this.skKehaiActive = false;
                this.skInfiltrating = false;
                this.skInfilDuration = 0;
                // スライム王にダメージ＋プレイヤーHP回復
                const kehaiDmg = Math.round(this.enemyTankMaxHP * 0.05); // 最大HP5%
                const minHPK = (this.skRevivalActive || this.coreStealActive) ? 1 : 0;
                this.enemyTankHP = Math.max(minHPK, this.enemyTankHP - kehaiDmg);
                this.playerTankHP = Math.min(this.playerTankMaxHP, this.playerTankHP + 50);
                if (window.game) {
                    window.game.camera_shake = 30;
                    window.game.screenFlash = 25;
                    window.game.screenFlashType = 'white';
                    window.game.hitStop = Math.max(window.game.hitStop, 10);
                    window.game.sound?.play('destroy');
                    window.game.particles.explosion(this.skKehaiX, this.skKehaiY, '#FFD700', 70);
                    window.game.particles.rateEffect(
                        CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.25,
                        '👑 気配を撃ち抜いた！！', '#FFD700'
                    );
                    window.game.particles.rateEffect(
                        CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.3,
                        `💥 ${kehaiDmg} ダメージ！`, '#FF6600'
                    );
                    window.game.particles.damageNum(
                        CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.45,
                        '+50HP 回復！', '#4CAF50'
                    );
                }
                this.enemyFireInterval = this.stageData.enemyFireInterval * (this.skPhase === 3 ? 0.55 : 0.70);
                return; // 通常発射処理はスキップ
            }
        }

        if (info.heal) {
            // Herb heals player tank
            this.playerTankHP = Math.min(this.playerTankMaxHP, this.playerTankHP + info.heal);
            if (window.game) {
                window.game.sound.play('heal');
                window.game.particles.damageNum(
                    CONFIG.TANK.OFFSET_X + CONFIG.TANK.INTERIOR_W / 2,
                    CONFIG.TANK.OFFSET_Y + 50,
                    `+${info.heal}HP`, '#4CAF50'
                );
            }
            return;
        }
        if (info.block) {
            this.shieldActive = true;
            return;
        }
        // きんのたまご：仲間全員にEXP+50
        if (info.special === 'expBoost' || (fireResult.type === 'exp_boost')) {
            if (window.game && window.game.allies) {
                window.game.allies.forEach(ally => ally.gainExp(50));
                window.game.particles.damageNum(
                    CONFIG.TANK.OFFSET_X + CONFIG.TANK.INTERIOR_W / 2,
                    CONFIG.TANK.OFFSET_Y + 50,
                    'みんな EXP+50！', '#FFF176'
                );
                window.game.sound.play('powerup');
            }
            return;
        }
        // ターボパーツ：装填時間を600フレーム間(10秒)半減
        if (fireResult.type === 'turbo_parts') {
            this.turboBoostTimer = Math.min(1800, (this.turboBoostTimer || 0) + 600); // ★最大30秒上限
            if (window.game) {
                window.game.particles.damageNum(
                    CONFIG.TANK.OFFSET_X + CONFIG.TANK.INTERIOR_W / 2,
                    CONFIG.TANK.OFFSET_Y + 50,
                    'ターボ加速！', '#03A9F4'
                );
                window.game.sound.play('powerup');
            }
            return;
        }
        // おうかん：大ダメージ(120) + 敵5秒スタン（即勝利は廃止・弱体化）
        if (info.special === 'victory') {
            const crownDmg = 120;
            // ★バグ②修正: 復活中・コア奪取中・Phase2演出中・潜り込み中は敵HP0にしない
            const _crownMinHP = (this.skRevivalActive || this.coreStealActive || this.skPhase2Active || this.skInfiltrating) ? 1 : 0;
            this.enemyTankHP = Math.max(_crownMinHP, this.enemyTankHP - crownDmg);
            this.enemyFireTimer = (this.enemyFireTimer || 0) + 300; // 5秒スタン追加
            this.enemyDamageFlash = 30;
            if (window.game) {
                window.game.sound.play('destroy');
                window.game.hitStop = Math.max(window.game.hitStop, 10);
                window.game.camera_shake = Math.max(window.game.camera_shake, 12);
                window.game.particles.explosion(CONFIG.CANVAS_WIDTH - 150, CONFIG.TANK.OFFSET_Y + 100, '#FFD700', 60);
                window.game.particles.damageNum(CONFIG.CANVAS_WIDTH - 150, CONFIG.TANK.OFFSET_Y + 60, `${crownDmg}!!`, '#FFD700');
                window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH - 150, CONFIG.TANK.OFFSET_Y + 30, '👑 王の一撃！5秒スタン', '#FFD700');
            }
            return;
        }
        // もくのよろい：ダメージ軽減バリア（defense値をシールド量として付与）
        if (info.defense) {
            this.woodArmorActive = true;
            this.woodArmorHP = (this.woodArmorHP || 0) + info.defense;
            if (window.game) {
                window.game.sound.play('confirm');
                window.game.particles.damageNum(
                    CONFIG.TANK.OFFSET_X + CONFIG.TANK.INTERIOR_W / 2,
                    CONFIG.TANK.OFFSET_Y + 50,
                    `守備+${info.defense}`, '#8D6E63'
                );
            }
            return;
        }
        // Normal ammo: create projectile
        const px = CONFIG.TANK.OFFSET_X + CONFIG.TANK.INTERIOR_W + 20 + this.playerTankX; // Adjusted for player tank movement
        // ★バグ修正F: fireResult.y が undefined の場合 py が NaN になり弾が消えるバグを修正
        // フォールバックとしてタンク内部の中心Y座標を使う
        const _fireY = (fireResult.y != null) ? fireResult.y : (CONFIG.TANK.OFFSET_Y + CONFIG.TANK.INTERIOR_H / 2);
        const py = _fireY + this.playerTankY; // Adjusted for player tank movement

        // Target random position on enemy tank
        const tx = CONFIG.CANVAS_WIDTH - 120 + this.enemyTankX; // Adjusted for enemy tank movement
        const ty = CONFIG.TANK.OFFSET_Y + 50 + Math.random() * 200 + this.enemyTankY; // Adjusted for enemy tank movement

        let mult = fireResult.damageMultiplier || 1;

        // Apply DOUBLE_AMMO powerup
        if (window.game && window.game.powerupManager && window.game.powerupManager.hasEffect('doubleAmmo')) {
            mult *= window.game.powerupManager.getEffectValue('doubleAmmo', 'multiplier');
        }

        const upgradeMult = this.attackMultiplier || 1.0;
        const totalMult = mult * upgradeMult;

        // ステージ進行ボーナス（_calcStageBonus()で playerFire() と統一）
        const stageBonus = this._calcStageBonus();
        const damage = Math.floor((info.damage + stageBonus) * totalMult);

        // ★新機能: コア奪取変身後は弾を金色に（見た目をfireからgoldFireへ）
        const _transformedType = this.playerTransformed ? 'fire' : fireResult.type;
        const p = new Projectile(px, py, tx, ty, _transformedType, 1, damage);
        if (this.playerTransformed) {
            p.color = '#FFD700'; // 金色フラグ
            p.scale = Math.min(2.0, (mult || 1) * 1.4); // 一回り大きく
        } else if (mult > 1) {
            // ★バグ修正Q: 変身中は if-else で分岐し、変身時のスケールを上書きしないよう修正
            // （以前は変身+強化倍率>1の場合にスケールが上書きされていた）
            p.scale = Math.min(2.0, mult);
        }

        if (info.effect) {
            p.effect = info.effect;
        }
        this.projectiles.push(p);

        // ★修正: 発射時に自分の戦車も反動でわずかに動く（敵と同様の挙動）
        if (this.dodgeTimer <= 0) {
            this.playerTankTargetX = (Math.random() - 0.5) * 30;
            this.playerTankTargetY = (Math.random() - 0.5) * 20;
            this.dodgeTimer = 20;
        }

        // ★2本目の弾：反対側の砲口から（上砲口から撃った→下砲口からも、逆も同様）
        // cannon_doubleまたは二連装砲カスタムで常時2本、それ以外は50%で2本目
        const cannonId = (window.game && window.game.saveData && window.game.saveData.tankCustom && window.game.saveData.tankCustom.cannon) || 'cannon_normal';
        const isDouble = cannonId === 'cannon_double';
        if (isDouble || Math.random() < 0.5) {
            const ox = CONFIG.TANK.OFFSET_X;
            const oy = CONFIG.TANK.OFFSET_Y;
            const ih = CONFIG.TANK.INTERIOR_H;
            // 上砲口と下砲口のY座標
            const topCannonY = oy + 65;
            const botCannonY = oy + ih - 65;
            // 現在の砲口と反対側から発射
            const py2 = (py < oy + ih / 2) ? botCannonY : topCannonY;
            const ty2 = CONFIG.TANK.OFFSET_Y + 50 + Math.random() * 200 + this.enemyTankY;
            const damage2 = Math.floor(damage * 0.7); // 2本目は70%ダメージ
            // ★バグ修正R: 2本目の弾がコア奪取変身後も fireResult.type（変身前）を使っており
            // 金色弾にならなかった。_transformedType に統一して変身状態を正しく反映する
            const p2 = new Projectile(px, py2, tx, ty2, _transformedType, 1, damage2);
            if (this.playerTransformed) { p2.color = '#FFD700'; p2.scale = Math.min(1.5, (mult || 1) * 1.1); }
            else if (mult > 1) p2.scale = Math.min(1.5, mult * 0.8);
            if (info.effect) p2.effect = info.effect;
            this.projectiles.push(p2);
        }
    }


    launchAllyMissile(allyData, onHitCallback) {
        if (!allyData) { if (onHitCallback) onHitCallback(); return; }
        // Start from Player Tank
        const px = CONFIG.TANK.OFFSET_X + CONFIG.TANK.INTERIOR_W / 2 + this.playerTankX;
        const py = CONFIG.TANK.OFFSET_Y - 20 + this.playerTankY; // Top hatch?

        // Target: Center of Enemy Tank
        const tx = CONFIG.CANVAS_WIDTH - 150 + this.enemyTankX;
        const ty = CONFIG.TANK.OFFSET_Y + 150 + this.enemyTankY;

        // ダメージ計算：仲間を大砲に投げ込んだ時のダメージは30固定 * 倍率
        const totalDamage = Math.floor(30 * (this.attackMultiplier || 1.0));

        const p = new Projectile(px, py, tx, ty, 'missile', 1, totalDamage);
        p.onHit = () => {
            // Explosion
            if (window.game) {
                window.game.particles.explosion(tx, ty, allyData.color || '#FFF', 40);
                window.game.sound.play('destroy');
                window.game.camera_shake = 12;
                window.game.particles.damageNum(tx, ty - 50, totalDamage.toString() + '!', '#F00');
            }

            // Damage enemy tank
            // ★バグ①修正: 復活中・コア奪取中・Phase2演出中・潜り込み中は敵HP0にしない
            const _missileMinHP = (this.skRevivalActive || this.coreStealActive || this.skPhase2Active || this.skInfiltrating) ? 1 : 0;
            this.enemyTankHP = Math.max(_missileMinHP, this.enemyTankHP - totalDamage);
            this.enemyDamageFlash = 20;

            // Disable enemy fire temporarily (Stun)
            this.enemyFireTimer += 90; // +1.5 seconds delay (Nerfed)

            // Callback to return ally
            if (onHitCallback) onHitCallback();
        };
        this.projectiles.push(p);
    }

    enemyFire(forcedAmmo) {
        // Attack Patterns
        const rand = Math.random();
        // ★バグ修正D: STAGES.findIndex()が-1を返すと stageLevel=0 になり
        // 敵の攻撃パターンが全て無効化される（イベントステージ等で稀に発生）
        // ★バグ修正E: 第2〜5章のステージは STAGES_CHAPTER2〜5 にあるため STAGES だけでは
        // 必ず -1 になり第2章以降でバースト射撃・特殊弾が一切発動しなかった
        const _allStages = [
            ...(window.STAGES           || []),
            ...(window.STAGES_CHAPTER2  || []),
            ...(window.STAGES_CHAPTER3  || []),
            ...(window.STAGES_CHAPTER4  || []),
            ...(window.STAGES_CHAPTER5  || []),
        ];
        const stageIdx = (this.stageData && this.stageData.id)
            ? _allStages.findIndex(s => s && s.id === this.stageData.id)
            : -1;
        const stageLevel = stageIdx >= 0 ? stageIdx + 1 : 1; // -1の場合はレベル1にフォールバック

        let type = forcedAmmo || 'rock';
        let count = 1;

        // ★バグ修正: forcedAmmo が指定されている場合はステージパターン選択をスキップする。
        // 以前は forcedAmmo で 'fire' などを渡してもステージパターン判定で無条件上書きされていた。
        if (!forcedAmmo) {
            // Pattern selection based on stage level
            // ★バグ修正④: 0.15 * stageLevel がステージ7以上で 1.0 超え → 特殊弾100%確定バグを修正
            // Math.min で上限 0.75 にキャップ（最高難度でも25%は通常弾が来る）
            if (rand < Math.min(0.75, 0.15 * stageLevel)) {
                // Special ammo
                const specials = ['bomb', 'ironball', 'arrow', 'shield'];
                type = specials[Math.floor(Math.random() * specials.length)];
            }

            // BOSS/TRUE_BOSS の specialAmmoProb による魔法弾上書き
            // （update()側でも判定しているが、forcedAmmoなし時のenemyFire()直接呼び出しにも対応）
            const typeInfo = CONFIG.ENEMY.TYPES[this.enemyTankType] || CONFIG.ENEMY.TYPES.NORMAL;
            const specialProb = typeInfo.specialAmmoProb || 0;
            if (specialProb > 0 && Math.random() < specialProb) {
                const magicAmmo = ['fire', 'ice', 'thunder'];
                type = magicAmmo[Math.floor(Math.random() * magicAmmo.length)];
            }
        }

        if (stageLevel >= 2 && rand > 0.7) count = 2; // Burst fire
        if (stageLevel >= 4 && rand > 0.85) count = 3; // Triple burst

        // ★バグ修正G: px を外側で計算するとバーストの遅延発射中に敵タンクが動いた場合に
        // 発射元座標がズレるため、クロージャ内（実行時）に都度 enemyTankX を参照する
        for (let i = 0; i < count; i++) {
            const delay = Math.round(i * 15); // 15フレーム間隔（≒250ms）
            this.burstQueue.push({
                delay, fn: () => {
                    if (!window.game || window.game.state !== 'battle' || this.phase !== 'battle') return;

                    const px = CONFIG.CANVAS_WIDTH - 50 + this.enemyTankX; // ★修正: 実行時に計算

                    // Check Ammo Type behavior
                    const info = CONFIG.AMMO_TYPES[type];
                    const safeType = (info && info.block) ? 'rock' : type;

                    const py = CONFIG.TANK.OFFSET_Y + 80 + Math.random() * 100 + this.enemyTankY;
                    const tx = CONFIG.TANK.OFFSET_X + 100 + this.playerTankX;
                    const ty = CONFIG.TANK.OFFSET_Y + Math.random() * CONFIG.TANK.INTERIOR_H + this.playerTankY;

                    this.projectiles.push(new Projectile(px, py, tx, ty, safeType, -1, this.enemyDamage));

                    if (window.game) {
                        window.game.sound.play('cannon');
                        window.game.particles.smoke(px, py, 2); // パフォーマンス改善: 6→2
                    }
                }
            });
        }

        // Potential enemy movement/dodge
        if (Math.random() < 0.3) {
            // ★バグ修正: speedMod を回避範囲にも反映（速い敵ほど大きく動く）
            const _dodgeSpeedMod = (CONFIG.ENEMY.TYPES[this.enemyTankType] || {}).speedMod || 1.0;
            this.enemyTankTargetX = (Math.random() - 0.5) * 60 * _dodgeSpeedMod;
            this.enemyTankTargetY = (Math.random() - 0.5) * 40 * _dodgeSpeedMod;
            this.enemyDodgeTimer = 30;
        }
    }

    // === ラスボス必殺技 ===
    activateBossSpecial() {
        this.bossSpecialActive = true;
        this.bossSpecialPhase = 0;

        const specialTypes = [
            'barrage',      // 弾幕攻撃
            'laser',        // レーザービーム
            'meteor',       // 隕石落下
            'shockwave'     // 衝撃波
        ];

        // 真ボスはより強力な技を使う
        const isTrueBoss = this.stageData && this.stageData.tankType === 'TRUE_BOSS';
        const specialType = isTrueBoss
            ? specialTypes[Math.floor(Math.random() * specialTypes.length)]
            : (Math.random() < 0.5 ? 'barrage' : 'meteor');
        this.bossSpecialType = specialType; // ui.jsで技名表示に使う

        // 警告演出
        if (window.game) {
            window.game.camera_shake = 12;
            window.game.screenFlash = 8;
            window.game.sound.play('invade');
            window.game.particles.rateEffect(
                CONFIG.CANVAS_WIDTH / 2,
                CONFIG.CANVAS_HEIGHT * 0.3,
                '⚠ 必殺技！ ⚠',
                '#FF0000'
            );
        }

        // 必殺技実行（60フレーム後 = 約1秒）
        this.burstQueue.push({
            delay: 60, fn: () => {
                if (!window.game || window.game.state !== 'battle') return;

                switch (specialType) {
                    case 'barrage':
                        this.bossBarrageAttack();
                        break;
                    case 'laser':
                        this.bossLaserAttack();
                        break;
                    case 'meteor':
                        this.bossMeteorAttack();
                        break;
                    case 'shockwave':
                        this.bossShockwaveAttack();
                        break;
                }
            }
        });

        // 必殺技終了（240フレーム後 = 約4秒）
        this.burstQueue.push({
            delay: 240, fn: () => {
                this.bossSpecialActive = false;
                this.bossSpecialType = null;
            }
        });
    }

    // 弾幕攻撃（扇状に大量の弾を発射）
    bossBarrageAttack() {
        const bulletCount = 10; // 15 -> 10
        const px = CONFIG.CANVAS_WIDTH - 50;
        const py = CONFIG.TANK.OFFSET_Y + 150;

        for (let i = 0; i < bulletCount; i++) {
            const delay = Math.round(i * 5); // 5フレーム間隔（≒80ms）
            this.burstQueue.push({
                delay, fn: () => {
                    if (!window.game || window.game.state !== 'battle') return;

                    // 扇状にばらまく
                    const angle = -Math.PI / 3 + (Math.PI * 2 / 3) * (i / bulletCount);
                    // ★バグ修正③: playerTankX を考慮して実際のタンク位置を狙う
                    const tx = CONFIG.TANK.OFFSET_X + 100 + this.playerTankX + Math.cos(angle) * 200;
                    const ty = CONFIG.TANK.OFFSET_Y + this.playerTankY + Math.sin(angle) * 100 + 150;

                    const type = Math.random() < 0.3 ? ['fire', 'ice', 'thunder'][Math.floor(Math.random() * 3)] : 'rock';
                    this.projectiles.push(new Projectile(px, py, tx, ty, type, -1, Math.round(this.enemyDamage * 0.8)));

                    window.game.sound.play('cannon');
                    window.game.particles.smoke(px, py, 3);
                }
            });
        }
    }

    // レーザービーム（直線的な連続攻撃）
    bossLaserAttack() {
        // フレームベース処理 - update() の laserActive ブロックで処理
        this.laserActive = true;
        this.laserFrames = 0;
    }

    // 隕石落下（上から大きな弾が降ってくる）
    bossMeteorAttack() {
        const meteorCount = 8;

        for (let i = 0; i < meteorCount; i++) {
            const delay = Math.round(i * 18); // 18フレーム間隔（≒300ms）
            this.burstQueue.push({
                delay, fn: () => {
                    if (!window.game || window.game.state !== 'battle') return;

                    const px = CONFIG.TANK.OFFSET_X + Math.random() * CONFIG.TANK.INTERIOR_W;
                    const py = 0; // 画面上から
                    const tx = px;
                    const ty = CONFIG.TANK.OFFSET_Y + CONFIG.TANK.INTERIOR_H / 2;

                    this.projectiles.push(new Projectile(px, py, tx, ty, 'bomb', -1, Math.round(this.enemyDamage * 1.5)));

                    window.game.particles.sparkle(px, py, '#FFA500');
                    window.game.sound.play('destroy');
                }
            });
        }
    }

    // 衝撃波（画面全体を揺らす強力な攻撃）
    bossShockwaveAttack() {
        if (!window.game) return;

        // 大きな衝撃波エフェクト
        window.game.camera_shake = 12;
        window.game.screenFlash = 8;

        // 中央から放射状に
        const waveCount = 12; // 20 -> 12
        for (let i = 0; i < waveCount; i++) {
            const delay = Math.round(i * 3); // 3フレーム間隔（≒50ms）
            this.burstQueue.push({
                delay, fn: () => {
                    if (!window.game || window.game.state !== 'battle') return;

                    const angle = (Math.PI * 2 * i) / waveCount;
                    const px = CONFIG.CANVAS_WIDTH - 150;
                    const py = CONFIG.TANK.OFFSET_Y + 150;
                    const tx = px + Math.cos(angle) * 300;
                    const ty = py + Math.sin(angle) * 200;

                    this.projectiles.push(new Projectile(px, py, tx, ty, 'ironball', -1, this.enemyDamage));

                    window.game.particles.spark(px, py, Math.cos(angle) * 10, Math.sin(angle) * 10, '#FFD700');
                }
            });
        }

        window.game.sound.play('destroy');
    }

    // === 形態変化システム ===
    transitionToPhaseTwo() {
        // 第二形態への変化処理
        this.bossPhase = 2;

        // HPを第二形態の値に設定
        const phase2HP = this.stageData.enemyHPPhase2 || 2666;
        this.enemyTankHP = phase2HP;
        this.enemyTankMaxHP = phase2HP;

        // ★ 第二形態スキン切り替え（enemySkinPhase2が設定されている場合）
        if (this.stageData.enemySkinPhase2) {
            this.enemySkinType = this.stageData.enemySkinPhase2;
        }

        // BGMを最強の音楽に変更
        if (window.game && window.game.sound) {
            window.game.sound.playBGM('final_boss');
        }

        // 画面演出（フラッシュ＋テキスト）
        if (window.game) {
            window.game.camera_shake = 15;
            // 白フラッシュ→赤フラッシュの2段演出
            window.game.screenFlash = 12;
            window.game.screenFlashType = 'white';
            window.game.particles.rateEffect(
                CONFIG.CANVAS_WIDTH / 2,
                CONFIG.CANVAS_HEIGHT * 0.3,
                '⚠ 第二形態！ ⚠',
                '#FF00FF'
            );
            // 少し遅らせて2発目のテキスト（burstQueueで代替）
            this.burstQueue.push({ delay: 40, fn: () => {
                if (!window.game) return;
                window.game.screenFlash = 8;
                window.game.screenFlashType = 'hit';
                window.game.particles.rateEffect(
                    CONFIG.CANVAS_WIDTH / 2,
                    CONFIG.CANVAS_HEIGHT * 0.45,
                    '真の姿を見よ！',
                    '#FF4444'
                );
            }});
        }

        // 形態変化完了
        this.phaseTransitionActive = false;
    }

    // ============================================================
    // 👑 スライム王 Phase2：激怒形態移行
    // ============================================================
    triggerSlimeKingPhase2() {
        if (!window.game) return;

        // 演出中フラグ：潜り込み・必殺技・通常攻撃をブロック
        this.skPhase2Active = true;
        this.enemyFireInterval = 9999;

        // ── 予兆：BGM停止、一瞬だけ静寂 ──
        window.game.camera_shake = 6;
        window.game.sound?.stopBGM?.();
        window.game.particles.rateEffect(
            CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.28,
            '……？', '#FFFFFF'
        );

        // delay 50：「ぐ……」震え始め
        this.burstQueue.push({ delay: 50, fn: () => {
            if (!window.game) return;
            window.game.camera_shake = 10;
            window.game.particles.rateEffect(
                CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.28,
                '👑 「……ぐ。まだ、足りんか。」', '#FF8800'
            );
            window.game.sound?.play('invade');
        }});

        // delay 110：強いシェイク＋オレンジフラッシュ
        this.burstQueue.push({ delay: 110, fn: () => {
            if (!window.game) return;
            window.game.camera_shake = 20;
            window.game.screenFlash = 14;
            window.game.screenFlashType = 'hit';
            window.game.particles.rateEffect(
                CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.22,
                'これが……本当の力だ——ッ！！', '#FF6600'
            );
        }});

        // delay 170：爆発＋パーティクル放射
        this.burstQueue.push({ delay: 170, fn: () => {
            if (!window.game) return;
            window.game.camera_shake = 25;
            window.game.screenFlash = 18;
            window.game.screenFlashType = 'hit';
            window.game.particles.explosion(
                CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.38, '#FF6600', 50
            );
            window.game.particles.explosion(
                CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.28, '#FFD700', 30
            );
            window.game.sound?.play('destroy');
        }});

        // delay 240：実際にPhase2へ移行 + BGM再起動
        this.burstQueue.push({ delay: 240, fn: () => {
            if (!window.game) return;
            // フェイルセーフ：復活等で既にPhase3以降になっていたら上書きしない
            if (this.skPhase < 2) {
                this.skPhase = 2;
                this.enemyFireInterval = this.stageData.enemyFireInterval * 0.70;
            }
            this.skPhase2Active = false;
            window.game.sound?.playBGM('final_boss');
            window.game.camera_shake = 20;
            window.game.screenFlash = 22;
            window.game.screenFlashType = 'white';
            window.game.particles.rateEffect(
                CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.20,
                '👑 「……長い眠りから、目覚めた。」', '#FF4400'
            );
        }});

        // delay 310：速射宣言テキスト
        this.burstQueue.push({ delay: 310, fn: () => {
            if (!window.game) return;
            window.game.particles.rateEffect(
                CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.36,
                '速射開始——受け止めてみせろ！！', '#FFD700'
            );
            window.game.camera_shake = 12;
        }});
    }

    // ============================================================
    // 👑 スライム王 復活ギミック（偽撃破→復活）
    // ============================================================
    triggerSlimeKingRevival() {
        if (!window.game) return;
        window.game.camera_shake = 20;
        window.game.screenFlash = 15;
        window.game.screenFlashType = 'white';
        window.game.sound?.play('destroy');
        window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.3, '撃破……！？', '#FFFFFF');

        this.burstQueue.push({ delay: 90, fn: () => {
            if (!window.game) return;
            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.35, '……ドクン', '#FF0000');
            window.game.sound?.play('invade');
        }});
        this.burstQueue.push({ delay: 160, fn: () => {
            if (!window.game) return;
            window.game.camera_shake = 25;
            window.game.screenFlash = 20;
            window.game.screenFlashType = 'hit';
            window.game.particles.explosion(CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.4, '#FFD700', 60);
            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.2, '👑 「……まだだ。まだ、終われん。」', '#FFD700');
            window.game.sound?.playBGM('final_boss');
            const revivalHP = Math.round((this.stageData.enemyHP || 5500) * 0.65);
            this.enemyTankHP = revivalHP;
            this.enemyTankMaxHP = revivalHP;
            this.skPhase = 3;
            this.skRevivalActive = false;
            this._revivalSafeTimer = 0; // フェイルセーフタイマーもリセット
            this.enemyFireInterval = this.stageData.enemyFireInterval * 0.55;
            this.coreStealForceTimer = 0;
            // バグA修正：潜り込みタイマーをリセット（Phase3突入直後に即発動しないよう）
            this.skInfilTimer = 0;
            // バグB修正：潜り込み中にHP0→復活した場合、潜り込み状態を強制解除
            this.skInfiltrating = false;
            this.skInfilDuration = 0;
        }});
        this.burstQueue.push({ delay: 220, fn: () => {
            if (!window.game) return;
            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.35, '👑 最終形態！', '#FF4444');
        }});
    }

    // ============================================================
    // 👑 スライム王 戦闘中セリフ表示
    // ============================================================
    _showBattleSpeech(text) {
        if (!window.game) return;
        // 敵タンク上部に名前付きセリフをポップアップ
        window.game.particles.rateEffect(
            CONFIG.CANVAS_WIDTH * 0.75,
            CONFIG.CANVAS_HEIGHT * 0.18,
            `👑 「${text}」`, '#FFD700'
        );
        window.game.camera_shake = Math.max(window.game.camera_shake, 5);
        // 少し間をあけてセリフが消えた後に余韻
        this.burstQueue.push({ delay: 60, fn: () => {
            if (!window.game) return;
            window.game.screenFlash = 4;
            window.game.screenFlashType = 'white';
        }});
    }

    // ============================================================
    // 👑 スライム王 潜り込みギミック
    // ============================================================
    triggerSlimeKingInfiltration() {
        if (!window.game) return;
        this.skInfiltrating = true;
        this.skInfilDuration = this.skPhase === 3 ? 360 : 480;
        this.skKehaiActive = false;
        this.skKehaiHit = false;
        this.skKehaiNextSpawn = 120; // ★バグ修正: 開始直後スポーンを防ぐため2秒待機
        this.enemyFireInterval = 9999;

        // ★リブート: 開始演出を大幅強化
        window.game.camera_shake = 20;
        window.game.screenFlash = 15;
        window.game.screenFlashType = 'white';
        window.game.hitStop = Math.max(window.game.hitStop, 6);
        window.game.sound?.play('invade');
        window.game.particles.rateEffect(
            CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.22,
            '👑 ……消えた。', '#FFD700'
        );
        window.game.particles.explosion(CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.38, '#FFD700', 50);

        // 0.5秒後：不穏なテキスト
        this.burstQueue.push({ delay: 30, fn: () => {
            if (!window.game) return;
            window.game.camera_shake = 12;
            window.game.screenFlash = 8;
            window.game.screenFlashType = 'hit';
            window.game.particles.rateEffect(
                CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.38,
                '——どこにいる……！？', '#FF4444'
            );
        }});

        // 1秒後：内側から浸食開始
        this.burstQueue.push({ delay: 60, fn: () => {
            if (!window.game) return;
            window.game.camera_shake = 15;
            window.game.screenFlash = 10;
            window.game.screenFlashType = 'hit';
            for (let i = 0; i < 4; i++) {
                window.game.particles.explosion(
                    CONFIG.TANK.OFFSET_X + 40 + Math.random() * 160,
                    CONFIG.TANK.OFFSET_Y + 30 + Math.random() * 130,
                    '#FF8C00', 25
                );
            }
            window.game.particles.rateEffect(
                CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.32,
                '👑 内側から……溶かされている……！', '#FF8C00'
            );
            window.game.sound?.play('damage');
        }});
    }

    // ============================================================
    // 👑 コア奪取イベント → 黄金神龍タンク変身
    // ============================================================
    triggerCoreStealEvent() {
        if (!window.game) return;
        this.skInfiltrating = false;
        this.projectiles = this.projectiles.filter(p => p.dir !== -1);

        window.game.camera_shake = 20;
        window.game.screenFlash = 18;
        window.game.screenFlashType = 'white';
        window.game.sound?.stopBGM?.();
        window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.25, 'くっ……もう限界か……！？', '#FFFFFF');

        this.burstQueue.push({ delay: 60, fn: () => {
            if (!window.game) return;
            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.3, 'あの輝き——でんせつのコアが……！', '#FFD700');
        }});
        this.burstQueue.push({ delay: 110, fn: () => {
            if (!window.game) return;
            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.3, 'ぼくを……呼んでる！！', '#FFD700');
            window.game.camera_shake = 15;
        }});
        this.burstQueue.push({ delay: 150, fn: () => {
            if (!window.game) return;
            window.game.screenFlash = 12; window.game.screenFlashType = 'hit';
            window.game.camera_shake = 25;
            window.game.particles.explosion(CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.3, '#FFD700', 50);
            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.25, '👑 王冠が……ひび割れた！？', '#FF4444');
            window.game.sound?.play('destroy');
        }});
        this.burstQueue.push({ delay: 210, fn: () => {
            if (!window.game) return;
            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.3, 'もらった——ッ！！！', '#FFD700');
            window.game.camera_shake = 30; window.game.screenFlash = 25; window.game.screenFlashType = 'white';
            window.game.sound?.play('powerup');
        }});
        this.burstQueue.push({ delay: 260, fn: () => {
            if (!window.game) return;
            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.2, '✨ でんせつのコア 獲得！！ ✨', '#FFD700');
            window.game.camera_shake = 20;
            for (let i = 0; i < 5; i++) {
                this.burstQueue.push({ delay: i * 8, fn: () => {
                    if (!window.game) return;
                    window.game.particles.sparkle(
                        CONFIG.CANVAS_WIDTH / 2 + (Math.random() - 0.5) * 200,
                        CONFIG.CANVAS_HEIGHT / 2 + (Math.random() - 0.5) * 150, '#FFD700'
                    );
                }});
            }
        }});
        this.burstQueue.push({ delay: 330, fn: () => {
            if (!window.game) return;
            this.originalPlayerSkin = window.game.saveData?.tankCustom?.skin || 'skin_default';
            if (window.game.saveData?.tankCustom) {
                // ★バグ修正: リトライ時に startBattle() のスキン復元ロジックが機能するよう
                // _preDragonSkin を退避してから skin_dragon に切り替える
                // （未設定だとリトライ時も skin_dragon の HP×2・ATK×2 ボーナスが残り続けるバグ）
                if (!window.game.saveData.tankCustom._preDragonSkin) {
                    window.game.saveData.tankCustom._preDragonSkin = window.game.saveData.tankCustom.skin || 'skin_default';
                }
                window.game.saveData.tankCustom.skin = 'skin_dragon';
            }
            this.playerTransformed = true;
            window.game.screenFlash = 30; window.game.screenFlashType = 'white';
            window.game.camera_shake = 25; window.game.sound?.play('invade');
            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH * 0.25, CONFIG.CANVAS_HEIGHT * 0.2, '🐉 黄金神龍タンク 覚醒！！', '#FFD700');
        }});
        this.burstQueue.push({ delay: 400, fn: () => {
            if (!window.game) return;
            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.3, '「これが……でんせつのコアの力ッ！！！」', '#FFF176');
        }});
        this.burstQueue.push({ delay: 480, fn: () => {
            if (!window.game) return;
            // HP全回復・コアダメージ・攻撃力2倍
            this.playerTankHP = this.playerTankMaxHP;
            this.enemyTankHP = Math.round(this.enemyTankHP * 0.70);
            this.attackMultiplier *= 2.0;
            this.enemyFireInterval = this.stageData.enemyFireInterval * 0.50;
            this.coreStealActive = false;
            window.game.sound?.playBGM('final_boss');
            window.game.camera_shake = 30; window.game.screenFlash = 20; window.game.screenFlashType = 'hit';
            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.25, '⚡ 攻撃力2倍・HP全回復！ ⚡', '#FFD700');
            window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH * 0.75, CONFIG.CANVAS_HEIGHT * 0.35, '「な……バカな！！わしのコアで……！！？」', '#FF4444');
        }});
        this.burstQueue.push({ delay: 490, fn: () => {
            if (!window.game?.saveData) return;
            const sd = window.game.saveData;
            if (!sd.unlockedSkins) sd.unlockedSkins = [];
            if (!sd.unlockedSkins.includes('skin_dragon')) {
                sd.unlockedSkins.push('skin_dragon');
                window.game.particles.rateEffect(CONFIG.CANVAS_WIDTH / 2, CONFIG.CANVAS_HEIGHT * 0.5, '👑 黄金神龍タンク 永久アンロック！', '#FFD700');
            }
        }});
    }

    // Projectiles are drawn by Renderer on upper screen,
    // but we keep this method if other battle layers are needed.
    draw(ctx) {
    }
}

window.BattleManager = BattleManager;
window.Projectile = Projectile;
